// Generado por tools/tiempos.py desde 03_GUION/tiempos.txt — no editar a mano.
window.TIEMPOS = {
 "duracion": 35.0,
 "musica": "no",
 "semilla": 7,
 "pregunta": "¿En cuántas horas / llenan esto?",
 "tPregunta": 3.6,
 "frase": "Dividiéndose cada 20 minutos, / 1 *E. coli* llega a 600 en unas 3 horas.",
 "tFrase": 30.0,
 "fuente": "Sezonov, Joseleau-Petit y D'Ari (2007), «Escherichia coli physiology in Luria-Bertani broth», Journal of Bacteriology 189(23): 8746-8749",
 "param": {
  "tDiv": 3.2,
  "nMax": 600.0
 }
};
