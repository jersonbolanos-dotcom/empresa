// Generado por tools/tiempos.py desde 03_GUION/tiempos.txt — no editar a mano.
window.TIEMPOS = {
 "duracion": 32.0,
 "musica": "no",
 "semilla": 5,
 "pregunta": "¿Qué forma / crecerá aquí?",
 "tPregunta": 3.6,
 "frase": "Partículas pegándose al azar / forman ramas como las de un *rayo*.",
 "tFrase": 27.4,
 "fuente": "Witten, T. A. y Sander, L. M. (1981), «Diffusion-limited aggregation, a kinetic critical phenomenon», Physical Review Letters 47: 1400-1403; Niemeyer, L., Pietronero, L. y Wiesmann, H. J. (1984), «Fractal dimension of dielectric breakdown», Physical Review Letters 52: 1033-1036",
 "param": {
  "n": 6000.0,
  "lento": 1.3,
  "A": 4.0
 }
};
