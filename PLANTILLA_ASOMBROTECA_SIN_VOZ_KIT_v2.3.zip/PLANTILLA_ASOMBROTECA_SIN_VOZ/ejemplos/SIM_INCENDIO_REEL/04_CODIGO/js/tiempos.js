// Generado por tools/tiempos.py desde 03_GUION/tiempos.txt — no editar a mano.
window.TIEMPOS = {
 "duracion": 40.0,
 "musica": "no",
 "semilla": 244,
 "pregunta": "¿Se quemará / todo el bosque?",
 "tPregunta": 3.6,
 "frase": "Por debajo del *59 %* de árboles, el fuego ya no cruza el bosque.",
 "tFrase": 35.4,
 "fuente": "Umbral de percolación de sitios en la red cuadrada p_c = 0,59274621 (Newman y Ziff, 2000, Physical Review Letters 85: 4104); Stauffer y Aharony (1994), Introduction to Percolation Theory, Taylor & Francis",
 "param": {
  "densidad": 0.86,
  "queda1": 0.66,
  "queda2": 0.44
 }
};
