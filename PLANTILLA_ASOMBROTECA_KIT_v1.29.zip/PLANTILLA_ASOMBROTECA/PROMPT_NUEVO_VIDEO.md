# Prompt para producir un vídeo nuevo · v1.29 (copiar y pegar en Claude Code)

Rellena lo que va entre corchetes. Usa siempre el mismo chat de Claude Code con la plantilla ya cargada.

---

```
Usa la PLANTILLA ASOMBROTECA (v1.29) para producir un vídeo vertical terminado. No crees otra plantilla: si le falta
algo, amplíala sin romper lo existente (versión nueva en CAMBIOS_PLANTILLA.md).

Antes de empezar, lee: 00_LEEME_PRIMERO.md, GUIA_ESTILOS.md (bloques v1.29 y v1.27 primero),
SUPERPROMPT_PLANTILLA_ASOMBROTECA.md, INSTRUCCIONES_PLANTILLA.md y ejemplo_demo_v126/04_CODIGO/js/episodio.js.

DATOS DEL VÍDEO
- Tema: [p. ej. «¿Tu móvil se carga mejor en modo avión?»]
- Estilo: [asombroteca (por defecto) | cartoon | noche | blueprint | dossier | producto | tecno | elige tú]
- Ganchos: [3 hablados (≈ 250 créditos extra) | 3 visuales (0 créditos extra) | solo 1]
- Marca: ASOMBROTECA
- Fotos reales: [ninguna | adjuntas, con su licencia]

AHORRO DE CRÉDITOS (obligatorio, estoy con presupuesto justo)
- UNA sola generación en ElevenLabs: creative_generate_speech con generations_count: 1. Nunca pidas dos tomas.
- Modelo Eleven v4, voz Dan (9F4C8ztpNUmXkdDDbz3J). Pausas con [short pause], «…» y [long pause] (una vez en el cuerpo).
- Guion completo (ganchos incluidos) de 1.300 caracteres como máximo. Dime cuántos caracteres tiene ANTES de generar.
- Nunca regeneres el audio entero. Pausa corta → [PAUSA x] en tramos.txt. Palabra mal dicha → regenera solo ese tramo
  corto y avísame de cuántos caracteres es antes de hacerlo.

CÓMO TRABAJAR
1. GANCHOS: proponme 3 ganchos de ≤ 2 s (contradicción, cifra imposible, algo en juego o desmentir un mito, en segunda
   persona; prohibido «Imagina», «En el año…», «Antes de…»). Para cada uno, describe también la imagen de los primeros
   2 s. ESPERA mi respuesta.
2. GUION: escríbelo con la fórmula de GUIA_ESTILOS.md, 45-70 s, 3-4 pausas antes de cada revelación, y cierre
   «Envíaselo a ese amigo que…». Verifica cada cifra en 2 fuentes. Enséñamelo con su número de caracteres y ESPERA mi OK.
3. VOZ (una sola toma):
   - Ganchos hablados: los 3 ganchos al principio, separados por «… [short pause] …», y luego el cuerpo, todo en la
     misma generación. En tramos.txt márcalos [GANCHO A], [GANCHO B] y [GANCHO C].
   - Ganchos visuales o 1 gancho: el guion normal con un solo gancho.
   Si no puedes guardar el audio en el proyecto, dame el enlace de ElevenLabs y te lo adjunto.
4. Proyecto y alineación:
   python3 PLANTILLA_ASOMBROTECA/tools/nuevo_proyecto.py NOMBRE --estilo ESTILO --marca "ASOMBROTECA" --voz AUDIO
   python3 PLANTILLA_ASOMBROTECA/tools/producir.py NOMBRE voz      (corrige tramos.txt; cifras habladas: 500|quinientos)
   python3 PLANTILLA_ASOMBROTECA/tools/producir.py NOMBRE alinear
5. episodio.js: una idea visual por frase, metáfora sostenida, protagonista grande (≥ 60 % del ancho de la zona segura),
   ≤ 2 etiquetas de 1-3 palabras, cifras como contadores, P.ctaShare al final. Ancla tiempos con wa()/wt().
   Los primeros 2 s dependen de window.GANCHO ('A', 'B' o 'C') para que cada variante tenga su propia imagen inicial.
6. UNA ronda de prueba: producir.py NOMBRE prueba (10-12 instantes). Revisa 07_QC/prueba.jpg: nada encimado en
   transiciones, nada cortado en los bordes, nada flota, pantalla llena. Mándame la hoja antes del render.
7. Render y QC: producir.py NOMBRE variantes (o «todo» si hay un solo gancho). El QC debe salir «TODO CORRECTO» en cada
   MP4, con sonido desde el fotograma 0 (≤ 0,5 s de silencio inicial) y ≤ 1 s de silencio final.
8. Entrega en 07_OUTPUT/:
   - los MP4 (VARIANTE_A, VARIANTE_B, VARIANTE_C o FINAL);
   - portada.jpg 1080×1920: fondo oscuro, 2-4 palabras gigantes con UNA en rojo y etiqueta amarilla pequeña;
   - PUBLICAR.md: título y descripción para YouTube, Facebook, Instagram y TikTok. Gancho como pregunta SIN dar la
     respuesta, invitación a comentar (nunca «dale like» ni «comparte si…»), 3-5 hashtags;
   - FUENTES_Y_DECISIONES.md con las 2 fuentes de cada dato.
```

---

## Variantes rápidas

- **Corregir un vídeo ya hecho:** «Respalda la versión actual en `V1/` y cambia solo esto: …». Luego pasos 6 y 7. No regeneres la voz.
- **Reel sin voz (hipnótico):** usa la plantilla `PLANTILLA_ASOMBROTECA_SIN_VOZ` y su `PROMPT_NUEVO_REEL.md`.
- **Probar ganchos:** sube las 3 variantes a Instagram como «Reel de prueba». A las 24 h, comparte al perfil la que más retuvo en los primeros 3 s y súbela a Facebook, YouTube y TikTok.
