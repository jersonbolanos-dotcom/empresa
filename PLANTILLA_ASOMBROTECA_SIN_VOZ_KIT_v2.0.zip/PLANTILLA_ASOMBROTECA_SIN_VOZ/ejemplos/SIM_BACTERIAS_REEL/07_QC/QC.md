# QC · SIM_BACTERIAS_FINAL.mp4

**TODO CORRECTO**

| Control | Resultado | |
|---|---|---|
| Formato | h264 1080×1920 30/1 · aac 48000 Hz | ✔ |
| Duración (25-45 s) / tamaño (< 100 MB) | 35.00 s · 18.8 MB | ✔ |
| Decodificación completa | 0 errores | ✔ |
| Una sola escena (sin cortes: scdet) | 0 cortes | ✔ |
| Movimiento continuo (cambio entre medios segundos) | mín. 0.88/255 · 0 congelados > 1 s · 0 negros | ✔ |
| Movimiento desde el fotograma 0 | 2.49/255 en 0,5 s | ✔ |
| Fondo oscuro (luminancia media) | 17.7/255 | ✔ |
| Sonoridad (−14 LUFS, pico ≤ −1 dBTP) | -14.1 LUFS · pico -2.0 dBTP | ✔ |
| Sonido sacado de la simulación (arranques = eventos ±25 ms) | 125/125 arranques coinciden con eventos (347033 eventos) | ✔ |
| Música (muy baja o ninguna) | ninguna | ✔ |
| Silencios > 1 s (informativo) | 0 | ✔ |
| Determinismo (simulación precalculada incluida) | OK | ✔ |
| Zona segura IG (texto en 220 ≤ y ≤ 1450, x ≤ 940) | 0 textos fuera | ✔ |
| Texto mínimo (solo pregunta, contador, frase y marca) | tipos: contador (máx. 1 a la vez), frase (máx. 1 a la vez), marca (máx. 1 a la vez), pregunta (máx. 1 a la vez) | ✔ |
| Pregunta y frase nunca juntas (empalme limpio) | 0 muestras con las dos | ✔ |
| Pregunta ≤ 6 palabras en el fotograma 0 · contador visible | «¿Llenarán el círculo antes del final?» (6 palabras) · fotograma 0: sí · contador: sí | ✔ |
| Una sola frase final con el dato · fuente | «Una *E. coli* puede dividirse cada 20 minutos.» (8 palabras) a 30.0 s · fuente: sí | ✔ |
| Marca de agua «ASOMBROTECA» todo el vídeo | 350/350 muestras | ✔ |
| Bucle (último fotograma ≈ primero) | diferencia media 0.1/255 | ✔ |
| Nada flota (revisión visual de la hoja de contacto) | OK | ✔ |

Reel SIN VOZ de simulación (v2.0): sin comprobación de voz ni de md5. Hoja de contacto: `hoja_contacto.jpg`. Dato y fuente en `FUENTES_Y_DECISIONES.md`.

## Revisión visual

nada flota: OK
Revisión de hoja_contacto.jpg (12 fotogramas del MP4) y de la prueba del arranque y del final: el plano se ve desde arriba y sin gravedad; las bolas solo se mueven por inercia, rebotes en el aro y choques entre ellas. La bola grande arranca desde el borde izquierdo con estela y se divide a los 0,8 s; las hijas reparten su área. El círculo se llena (600) a los 33,5 s, el aro brilla y todo se contrae en la bola inicial (empalme con el fotograma 0). El contador queda separado del aro, la pregunta y la frase nunca coinciden y la marca de agua está en la esquina inferior derecha durante todo el vídeo.
