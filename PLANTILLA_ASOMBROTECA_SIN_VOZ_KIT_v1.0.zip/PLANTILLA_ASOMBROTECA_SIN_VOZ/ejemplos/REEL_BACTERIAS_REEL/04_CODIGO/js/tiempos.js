// Generado por tools/tiempos.py desde 03_GUION/tiempos.txt — no editar a mano.
window.TIEMPOS = {
 "duracion": 20.0,
 "musica": "pulso",
 "lineas": [
  {
   "t0": 0.0,
   "d": 2.0,
   "texto": "¿Cuántas habrá al *final* del video?",
   "sfx": [
    "whoosh"
   ],
   "clave": "gancho"
  },
  {
   "t0": 2.0,
   "d": 2.8,
   "texto": "Se divide en dos cada *20 minutos*",
   "sfx": [
    "pop"
   ],
   "clave": "divide"
  },
  {
   "t0": 5.0,
   "d": 2.8,
   "texto": "Y cada copia, *también*",
   "sfx": [
    "pop"
   ],
   "clave": "copia"
  },
  {
   "t0": 8.0,
   "d": 3.2,
   "texto": "Cada *clic* son / 20 minutos",
   "sfx": [
    "popAgudo"
   ],
   "clave": "clic"
  },
  {
   "t0": 11.4,
   "d": 3.0,
   "texto": "*Sin parar*",
   "sfx": [
    "golpe"
   ],
   "clave": "sinparar"
  },
  {
   "t0": 14.6,
   "d": 3.0,
   "texto": "10 horas: / *más de mil millones*",
   "sfx": [
    "revelar"
   ],
   "clave": "final"
  },
  {
   "t0": 17.8,
   "d": 2.2,
   "texto": "Y empezó con *una sola*",
   "sfx": [
    "pop"
   ],
   "clave": "una"
  }
 ]
};
