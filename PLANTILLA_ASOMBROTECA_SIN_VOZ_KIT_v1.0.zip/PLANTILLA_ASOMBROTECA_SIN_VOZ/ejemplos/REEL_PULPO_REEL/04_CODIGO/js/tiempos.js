// Generado por tools/tiempos.py desde 03_GUION/tiempos.txt — no editar a mano.
window.TIEMPOS = {
 "duracion": 20.0,
 "musica": "suave",
 "lineas": [
  {
   "t0": 0.0,
   "d": 7.6,
   "texto": "¿Cuántos *corazones* tiene un pulpo?",
   "sfx": [
    "whoosh"
   ],
   "clave": "gancho"
  },
  {
   "t0": 1.0,
   "d": 0.1,
   "texto": "",
   "sfx": [],
   "clave": "opciones"
  },
  {
   "t0": 2.4,
   "d": 5.0,
   "texto": "",
   "sfx": [],
   "clave": "cuenta"
  },
  {
   "t0": 7.6,
   "d": 1.6,
   "texto": "¡*Tres* corazones!",
   "sfx": [
    "correcto"
   ],
   "clave": "revela"
  },
  {
   "t0": 9.2,
   "d": 2.8,
   "texto": "Dos bombean sangre a las *branquias*",
   "sfx": [
    "pop"
   ],
   "clave": "branquias"
  },
  {
   "t0": 12.0,
   "d": 2.8,
   "texto": "Uno la envía al *resto del cuerpo*",
   "sfx": [
    "pop"
   ],
   "clave": "cuerpo"
  },
  {
   "t0": 14.8,
   "d": 2.8,
   "texto": "Y su sangre es *azul*",
   "sfx": [
    "chispa"
   ],
   "clave": "azul"
  },
  {
   "t0": 17.6,
   "d": 2.4,
   "texto": "¿Acertaste? / *Comenta tu respuesta*",
   "sfx": [
    "pop"
   ],
   "clave": "comenta"
  }
 ]
};
