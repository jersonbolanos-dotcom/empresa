# PLANTILLA ASOMBROTECA · Instrucciones maestras para cualquier video

Este documento resume lo importante de todos los prompts anteriores (Binance, Elon/Zhao, Helicóptero y Submarino) y de los videos de referencia virales. Sirve para producir cualquier explainer vertical con la misma calidad, sin empezar de cero.

---

## 1. Reglas que no se rompen

1. **La voz es sagrada.** No se altera, no se sintetiza, no se acelera ni se recorta. Solo se convierte a estéreo y se rellena con silencio al final.
2. **El audio manda.** Si el guion propuesto no coincide con lo que se oye, gana el audio: se transcribe (Whisper local) y se reportan las diferencias. Nunca se falsifican subtítulos.
3. **El guion no se cambia.** Lo que dice la voz es lo que aparece en los subtítulos.
4. **Rigor:**
   - No se inventan números.
   - Cada dato en pantalla (fechas, cifras, nombres) se verifica con fuentes y se anota en `FUENTES_Y_DECISIONES.md`.
   - Si las fuentes no coinciden, no se pone la cifra.
   - Si algo es incierto, se rotula como «posible» o «probable».
5. **Respeto en temas sensibles.** Nada de explosiones ni dramatización de muertes. En esos momentos va silencio o casi silencio.
6. **Sin logos de terceros.** La marca solo aparece como la palabra **ASOMBROTECA** en el cierre.
7. **Formato:**
   - 1080×1920 vertical, 30 fps, H.264 (yuv420p, faststart) y AAC 48 kHz.
   - MP4 de menos de 100 MB.
8. **Determinismo.**
   - Cada fotograma es función pura de `t`: `window.seek(t)`, `window.DURATION`, `window.scoreSound`.
   - Todo el azar viene de `H.rng`/`H.makeNoise`; nunca de `Math.random`.
   - `lib/harness.js` (H) y `lib/sound.js` (SOUND) se usan sin modificar.
9. **Versiones.**
   - Nunca se sobrescribe una versión entregada: V1, V2, V3… y se guarda copia de la anterior.
   - Si algo ya funciona, no se rehace: solo se corrige lo pedido.
10. **No se dice que algo está terminado sin el MP4 exportado y revisado.**

## 2. Cómo se cuenta la historia

Toda historia sigue esta estructura: **PROBLEMA → EXPLICACIÓN → CASO o CONSECUENCIA → SOLUCIÓN o LECCIÓN → CIERRE**.

- **Gancho en menos de 2 s.** Desde el primer fotograma ocurre algo: movimiento, sonido o una pregunta. Nada de intros lentas.
- **Algo cambia cada 1–2 s, sincronizado con una palabra concreta de la voz.** Puede ser:
  - un icono que aparece;
  - un número que cuenta;
  - un bocadillo, una tachadura o una flecha que se dibuja;
  - un zoom con lupa.
- **Elementos visuales que explican, no que decoran:**
  - comparaciones de escala con objetos cotidianos;
  - metáforas visuales (dominó para una cadena de causas, lupa para ver dentro);
  - flechas de fuerza o de flujo;
  - antes/después;
  - ✗ para lo que falla y ✓ para lo que funciona.
- **Un momento de énfasis** en la idea clave: rebote, anillo, sello o sacudida.
- **Una solución explícita** cuando existe. El espectador debe salir sabiendo qué se hizo o qué se aprendió.
- **El cierre se mantiene en pantalla al menos ~1 s**, con ASOMBROTECA y «la ciencia oculta de lo imposible».

## 3. Subtítulos

- Van **arriba** (y ≈ 300), en trozos de 1 a 4 palabras.
- Las palabras **aparecen a medida que se dicen**: la actual en blanco y negrita, las anteriores en gris.
- La **palabra clave** lleva un **recuadro de selección con asas** en el color de acento.
- La lista de palabras clave se escribe a mano en cada episodio. Admite límites de tiempo (`['necesita', t0, t1]`) para no repetir el recuadro.
- Sombra suave, sin caja opaca.
- Ningún elemento importante en los 250 px inferiores (zona de la interfaz de Instagram y TikTok).

## 4. Sonido

- **Sincronía exacta.** El sonido empieza en el fotograma exacto en que aparece su evento.
- **Cada bloque tiene su efecto** (`PLANTILLA.FX`):

  | Efecto | Evento |
  |---|---|
  | `aparece` | algo aparece en pantalla |
  | `etiqueta` | una etiqueta se coloca |
  | `flecha` | una flecha se dibuja |
  | `tachado` | algo se tacha |
  | `correcto` | algo sale bien |
  | `sello` | un sello o rótulo cae |
  | `contador` | un número cuenta (máximo 12 clics por segundo) |
  | `onomatopeya` | aparece una onomatopeya |
  | `burbujas`, `siseo`, `agua`, `alarma`, `sonar`, `crujido`, `golpeSordo`, `domino`, `clic`, `campana` | sonidos ambientales y de objetos |

- **Las transiciones suenan solas** según su tipo.
- **Jerarquía:** la voz siempre delante, luego los efectos y la música muy por debajo. Como máximo unos 3 sonidos a la vez, con pequeños silencios para que los golpes importantes se noten.
- **Stems separados:** `sfx.wav` (voiceover:true) y `musica.wav` (voiceover:false).
- **Mezcla de referencia:**

```
ffmpeg -i voz.mp3 -i musica.wav -i sfx.wav -filter_complex "[0:a]aresample=48000,pan=stereo|c0=c0|c1=c0,apad=whole_dur=D[v];[1:a]volume=3dB[m];[2:a]volume=-5dB[s];[v][m][s]amix=inputs=3:duration=longest:normalize=0,volume=4dB,alimiter=limit=0.87:level=false:attack=3:release=60,atrim=0:D[o]"
```

  Objetivo: unos −15 LUFS con pico verdadero ≤ −1 dBFS.

**Ducking (música bajo la voz):** la música se comprime con la voz como señal de control:

```
[1:a]volume=3dB[m0];[v]asplit[v1][vk];[m0][vk]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[m]
```

## 5. Pieles visuales

| Piel | Aspecto | Cuándo usarla |
|---|---|---|
| `plana` | Ilustración plana de colores cálidos, formas redondeadas sin contorno, sombras planas, tipografías Nunito y Fredoka | Ciencia cotidiana, cuerpo humano, naturaleza, historias |
| `oscura` | «Editor técnico»: fondo casi negro, acento dorado y coral, rellenos oscurecidos con borde dorado fino, grano, Space Grotesk e IBM Plex Mono | Tecnología, dinero, internet, datos, IA |

La piel se elige con `skin: 'plana' | 'oscura'` en `PLANTILLA.make`. Los bloques usan colores semánticos (`ink`, `paper`, `accent`, `red`, `green`, `blue`…), así que la misma escena funciona con cualquier piel.

## 6. Bloques disponibles (`PLANTILLA.P`)

| Grupo | Bloques |
|---|---|
| Formas | `rr` (rectángulo redondeado con sombra plana), `circle`, `poly` |
| Texto | `bigText`, `pill`, `text` |
| Animación | `popS` / `withPop` (aparición con rebote) |
| Indicadores | `arrow` (flecha que se dibuja), `cross` ✗, `check` ✓, `shield` (escudo con ✓, para la solución) |
| Recursos de los videos de referencia | `bubble` (bocadillo con icono), `onoma` (onomatopeya con temblor), `counter` (número que rueda, con o sin caja), `lens` (lupa dorada para ver dentro de algo) |
| Datos | `gauge` (manómetro cualitativo, sin cifras), `domino` (cadena de causas), `person` (icono de persona para cuadrículas respetuosas) |
| Cierre y ambiente | `finger` (dedo que toca «Seguir»), `bubbles` (burbujas o partículas deterministas) |

**Añadidos en v1.2** (episodio del microondas):

| Bloque | Uso |
|---|---|
| `camAt(keys, t)` + `camApply` | Cámara 2.5D: dolly, travelling y cambios de escala sobre una escena en espacio-mundo |
| `glow` | Luz o energía aditiva |
| `heat(v)` | Rampa térmica azul → amarillo → naranja → rojo. Solo para TEMPERATURA |
| `wave` | Onda electromagnética como cinta sinusoidal. Con `over: true` se dibuja sobre fondos claros |
| `water` | Molécula de agua con su ángulo de dipolo y color térmico |

**Añadidos en v1.4** (episodio del aire acondicionado):

| Bloque | Uso |
|---|---|
| `path(pts)` + `strokePath` | Recorridos medidos para tuberías, cables o rutas |
| `fluid(ctx, path, t, {phase, temp})` | Fluido dentro de un tubo. La FASE (líquido, vapor, mezcla) y la TEMPERATURA se representan por separado |
| `airStreaks` | Trazadores de aire, en lugar de humo |
| `fanAxial` y `fanCross` | Ventiladores axial y de flujo cruzado |

**Añadidos en v1.5** (episodio del GPS):

| Bloque | Uso |
|---|---|
| `phone` | Celular con pantalla programable |
| `mapCity` | Mapa de ciudad visto desde arriba |
| `pin` y `dot` | Pin de ubicación y punto azul pulsante |
| `rangeCircle` | Círculo de distancia (trilateración) |
| `globe` | Globo terrestre con continentes |
| `satellite` | Satélite genérico |
| `rings` | Ondas de radio, en anillo o dirigidas |
| `clock` | Reloj analógico |

**Bloques v1.14 (episodio «Gran Muralla China»)** — montañas con cresta, murallas, tierra apisonada y logística:

| Bloque | Uso |
|---|---|
| `ranges(ctx, t, {hor, sky, sun, layers, seed, arid, fogA, front:{y, amp}, nearC, farC})` | Cordilleras por capas con niebla de valle, luz en las laderas y vegetación. `arid` (0..1) pasa a paisaje seco. **Devuelve `ridge(x)`**, la cresta delantera, para apoyar murallas y caminos |
| `wallPath(ctx, pts, t, {style, h, w, build, towers, towerS, ruin, crenel, smokeAt, smoke, glow})` | **Muralla que sigue el terreno** (por ejemplo, `pts` sobre `ridge`): cara con hiladas según el material (`tierra`, `piedra` o `ladrillo`), adarve en escorzo, almenas, sombra de contacto y torres en fracciones del recorrido. `build` la construye a lo largo del camino; `ruin`, la deteriora |
| `watchtower(ctx, x, y, s, t, {style, smoke, fire, ruin, glow})` | Torre de vigilancia o de señales (ladrillo o piedra con ventanas arqueadas y almenas; de tierra, ataludada). Humo (día) o fuego (noche) deterministas |
| `rammedEarth(ctx, x, y, w, h, t, {total, done, loose, compact, form, workers, hit, cut, glowLayer})` | **Tierra apisonada**: capas terminadas con su textura; capa actual suelta que baja de altura y se densifica con `compact`; encofrado (tablones en corte); pisones que tocan la superficie y levantan polvo; `cut` marca las capas |
| `mingSection(ctx, x, y, w, h, t, {build, glow})` | Corte de muro Ming: cimiento de piedra, paramentos de ladrillo ataludados (se colocan hilada a hilada), núcleo de tierra y cascajo, adarve y parapeto. Devuelve puntos para rótulos |
| `chinaMap(ctx, x, y, w, h, t, {lon0, lon1, lat0, lat1})` + `mapWall(ctx, pts, p, t, {c, w})` + `CNWALLS` | Mapa esquemático del norte de China (mar de Bohai, Shandong, Liaodong, río Amarillo, Gobi, Ordos y relieve) y tramos de muralla con símbolo cartográfico. `CNWALLS` trae esquemas aproximados de Reinos Combatientes, Qin, Han y Ming |
| `laborer`, `porter`, `oxcart`, `packAnimal` | Trabajador con ropa y sombrero variados; porteador con pértiga y dos cestas; carro de dos ruedas con buey y ruedas que giran; mula con alforjas. Cargas: `tierra`, `piedra` o `ladrillos` |
| `dust(ctx, x, y, t, t0, {s})` | Nube de polvo determinista |

**v1.20 · módulo yakhchal (arquitectura pasiva del desierto, episodio «Yakhchal: hielo en el desierto»):**

| Bloque | Uso |
|---|---|
| `YK` · `ykR(y)` · `ykWall(y)` · `ykRin(y)` | MODELO MAESTRO en dm (x = este, z = sur): cúpula escalonada (R0, H, n bandas, pared que se adelgaza), pozo (`pitR`, `pitD`), entrada al sur, camino, estanque al norte del muro de sombra este–oeste y canal desde el oeste. Todas las vistas leen YK |
| `ykSun(elev, az)` · `ykShadow(p, sun)` | Vector solar (acimut desde el norte; 180 = sur) y sombra de un punto sobre el suelo. Las caras se iluminan y las sombras se proyectan con el MISMO vector |
| `ykWorld(ctx, cam, t, {sun, night, water, ice, blocks, town, dome:{cut}})` | Complejo 3D (P.cam3, dm): cielo diurno o nocturno con estrellas, desierto, canal, estanque (agua → hielo, cuadrícula de corte), camino, sombras calculadas, muro, cúpula y casas lejanas (nunca junto a la cámara). Devuelve `pr()` para rótulos |
| `ykDome(ctx, cam, t, {sun, night, col, ledge})` | Cúpula escalonada con cornisas, entrada en arco al sur y huecos de servicio |
| `ykSection(ctx, ox, gy, s, t, {flip, ice, melt, heat, site, sun, night, pondIce})` | SECCIÓN norte–sur derivada de YK: estratos, pozo con bloques, escalera, sumidero de drenaje, envolvente con su espesor, cámara, entrada, flechas de calor que se frenan en la pared y (`site`) camino, estanque y muro con su sombra. `flip` = norte a la derecha (vista desde el este, para alinear con `cam3`) |
| `ykCompass(ctx, cam, x, y, r)` | Brújula: el norte del modelo proyectado con la cámara |
| `pondSection(ctx, x, y, w, h, t, {water, freeze, layers, loss})` | Estanque en corte: lámina de agua (grosor exagerado), hielo que crece desde la superficie, capas de noches anteriores y flechas de energía hacia el cielo y el aire |
| `iceBlock(ctx, x, y, w, h, {melt, rot})` | Bloque de hielo translúcido con aristas claras; `melt` lo redondea y encoge |
| `persianWorker(ctx, x, y, h, t, {pose, ph, lift, dir, var})` | Trabajador persa de vestimenta plausible genérica (túnica con faja, pantalón amplio, gorro de tela), con brazos y piernas por cinemática inversa. Poses: `walk`, `stand`, `pick` (pico a dos manos), `carry` (bloque a la espalda con las dos manos, inclinado por el peso), `lower` (agachado, bloque en las manos), `rake`. El pie toca `y`. Devuelve las manos |
| `seasonDial(ctx, cx, cy, r, u, {label})` | Indicador de estaciones (invierno → primavera → verano → otoño) |
| `ykDesert(ctx, t, {heat, horizon, sunX, sunY})` | Desierto 2D: cielo de calor, sol, dunas y reverberación |

**v1.21 · yakhchal fiel a la fotografía (bloques nuevos; los de v1.20 siguen igual):**

| Bloque | Uso |
|---|---|
| `YK2` · `ykR2(y)` · `ykRin2(y)` · `ykPitR(y)` | Perfil CURVO medido sobre la foto de Meybod (r = R0·(1 − y/H)^0,55, sin escalones), interior con la misma ley (12 dm de bóveda), muro de contención ataluzado del pozo, vestíbulo `YK2.ent`, escalera `YK2.stair` (sur → oeste), zanja de corte `YK2.cut` |
| `ykDome2(ctx, cam, t, {sun, night, col, amb, cutx, noVest})` | Cúpula lisa de adobe en 3D: sombreado por cara con la normal del perfil, textura mineral, desgaste en la base, hiladas tenues, muescas de la escalera, agujeros del remate, vestíbulo en bóveda al sur y sombra de contacto |
| `ykWorld2(ctx, cam, t, {sun, night, water, ice, ripple, dry, town, rays, cut:{c, ice, melt, straw, warm, dim, actors}, skyTop, skyMid, actors})` | Escena completa (sustituye a `ykWorld`): montañas lejanas, estanque histórico, camino desde el vestíbulo, sombras del muro y de la silueta completa de la cúpula, muro de adobe con hiladas, `actors` ordenados por profundidad ({d, f}) y, con `cut`, el depósito en corte |
| `ykCutaway(ctx, cam, t, {c, ice, melt, straw, warm, dim, seed, actors})` | Depósito en CORTE por x = c (visto desde el este, sur a la izquierda): bóveda interior con luz indirecta, sección de la pared y del paso de entrada, rellano, revestimiento, escalera tallada, sumidero y drenaje, pila de hielo. Con `c: 1e9` la cámara puede estar DENTRO de la cúpula. Devuelve puntos (`pit`, `wall`, `entrance`, `stairPt(k)`…) |
| `iceBox3(ctx, cam, x0, x1, y0, y1, z0, z1, {seed, melt, dim, straw})` · `ykIceStack({fill, straw, seed})` | Bloque 3D translúcido (canto claro, burbujas, fisuras, línea de contacto) y pila variada y estable (apoyo ≥ 40 %, paja entre capas, sin invadir la escalera) |
| `ykPond3` · `ykSunRays(ctx, cam, sun, t, {a, xs, L})` | Estanque con taludes, caballón, volumen, ondas y cristales que crecen desde las orillas; rayos del sol que rozan la arista del muro y marcan el borde de la sombra |
| `ykSection2(ctx, ox, gy, s, t, {flip, ice, melt, heat, grad, tint, site, sun, night, straw})` | Sección técnica con el perfil curvo, revoque claro, núcleo de adobe, vestíbulo, pozo ataluzado con escalera separada del hielo por un murete, drenaje al norte, calor cualitativo que se atenúa (llega una pequeña parte) |
| `ykPondSide(ctx, x0, gy, w, L, t, {n, water, freeze, loss, grooves, cut, night, maxN})` | Estanque en corte lateral: capas de noches anteriores, lámina que se congela desde arriba con agujas, flechas de pérdida de energía y ranuras de corte |
| `persianWorker2(ctx, x, y, h, t, {pose, lift, ph, dir, var, feet, surf, block, release, tip})` · `iceSlab2` | Trabajador con anatomía mejorada. Poses `pry`, `lift`, `carry`, `descend`, `place`, `rake`, `walk`, `stand`; las manos agarran el bloque o la barra y los pies se apoyan (o `feet` en peldaños) |
| `iceMacro2(ctx, t, {zoom, drip, warm, seed})` (v1.21.1) | Primer plano de HIELO NATURAL (esquina de un bloque en la penumbra): superficie irregular, núcleo lechoso, burbujas en columna, canto translúcido, reflejos discretos, escarcha y gota que resbala. Preferir a `iceMacro` |
| `iceMacro(ctx, t, {zoom, drip, warm})` | Macro del hielo para ganchos: burbujas, fracturas, escarcha, gotas de condensación y una gota que resbala |
| `ykLabel(ctx, s, anchor, x, y, t, t0, t1, {sub, al, col, px})` · `ykKicker(ctx, num, s, t, t0, t1, {sub})` · `ykRecon(ctx, t, t0, t1)` | Rótulos editoriales discretos: etiqueta con guía fina, rótulo de capítulo en la esquina y sello pequeño «RECONSTRUCCIÓN» |

**v1.22 · Verne / Apolo (1865 → 1969), unidades 3D en metros:**

| Bloque | Uso |
|---|---|
| `floatPhoto(ctx, img, cx, cy, w, t, t0, t1, {rotY, from, tag, label, sub, drift, frame, shadow})` | DOCUMENTO AUTÉNTICO FLOTANTE: plano con perspectiva (giro en Y por tiras), entrada lateral suave, paralaje, sombra tenue, marco fino, etiqueta superior y pie ≥ 32 px. No deforma ni anima la imagen. Usar 1,5–3 s, entre el 25 % y el 50 % del ancho y por encima de y = 1420 |
| `engraveGrade(ctx, amt, t)` | Convierte lo dibujado en grabado de época (desatura, papel/tinta, tramado, grano y viñeta). `amt` 0..1 para transiciones |
| `moon3(ctx, cx, cy, r, t, {rot, light, glow, res})` · `earth3(ctx, cx, cy, r, t, {rot, light})` | Luna 3D (mares aproximados, cráteres, Tycho, terminador) y Tierra estilizada; resolución adaptativa |
| `vFrustum(ctx, cam, x, z, y0, y1, r0, r1, colFn, {N, L, amb})` | Tronco de cono 3D con color por ángulo/altura y luz direccional (base de cohetes y cápsulas) |
| `vCapsule3(ctx, cam, base, t, {col, L})` | Proyectil de Verne (ficción): aluminio, remate ojival y portillas, sin motores |
| `saturnV3(ctx, cam, base, t, {stage, les, engines, L})` · `SV` | Saturno V del Apolo 11 (110,6 m): S-IC con patrón negro y blanco y aletas, S-II, S-IVB, IU, SLA, módulos de servicio y de mando, torre de escape y 5 F-1 |
| `pad39A(ctx, cam, t, {arms, sky, sea, skyTop, skyMid})` | Plataforma 39A: devuelve `{ tower, towerDepth }` para ordenar la torre umbilical (brazos que se retiran) con el cohete |
| `plume3(ctx, cam, nozzles, t, {tg, power, len})` | Chorro de los motores y nube de vapor y humo que crece desde el encendido |
| `columbiad3(ctx, cam, t, {cap, sky, palms})` · `columbiadSection(ctx, ox, gy, s, t, {p, v, acc, flash, people})` | Columbiad de la NOVELA (ficticio): exterior con brocal, profundidad, andamio y proyectil; corte de 274 m con el proyectil en p (0 fondo, 1 boca), flechas de velocidad y aceleración, destello y personas como escala |
| `study1865(ctx, t, cam, {write, lamp})` · `writer1865` · `book1865` · `traveler1865` · `steamEngine` | Estudio de 1865 (capas con paralaje: estantería, ventana, globo, escritorio, lámpara), escritor genérico escribiendo, libro con título real, viajeros con levita y chistera, máquina de vapor de balancín |
| `usMap(ctx, cx, cy, w, t, {tilt, hl, pins, era})` | Mapa de EE. UU. inclinado con canto, Florida resaltada y marcas lon/lat; paleta de sepia (era 0) a azul (era 1) |
| `lunarPath(ctx, mode, earth, moon, u, t, {col, lw})` | Esquema Tierra–Luna (no a escala): `apollo` (órbita, inyección translunar, órbita lunar) o `verne` (rodeo de la Luna y regreso) |
| `eagleLM(ctx, x, y, s, t, {legs, thrust})` · `csm(ctx, x, y, s, ang)` | Módulo lunar Eagle y módulo de mando y servicio |
| `accelCompare(ctx, x, y, w, h, u, t, {labels})` | Velocidad–tiempo cualitativo: cañón «de golpe» frente a cohete «varios minutos», con aceleración no constante. Sin cifras |

**v1.22.1 · bloques añadidos / versiones 2:**

| Bloque | Uso |
|---|---|
| `vCapsule3(ctx, cam, pos, t, {rot, L})` · `vCapsuleAt(ctx, x, y, hpx, ang, t, {az, el, rot})` · `P.VC` | Proyectil maestro de Verne (ficción). Usar SIEMPRE el mismo modelo en todas las escenas (`vCapsuleAt` para iconos 2D, trayectorias y planos lejanos) |
| `earth3(ctx, cx, cy, r, t, {rot, light, tilt})` · `moon3(ctx, cx, cy, r, t, {rot, light, glow, res})` | Tierra con continentes reales, nubes y atmósfera; Luna con mares y cráteres sombreados. Etiquetar «ESQUEMA · NO A ESCALA» cuando se exagere el tamaño |
| `florida1865(ctx, cam, t, {sky, seed, palms})` · `capsuleCradle(ctx, cam, t)` → top | Entorno de Florida en 1865 con profundidad y cuna de madera con sombra de contacto (apoyar el proyectil en `[0, top, 0]`) |
| `traveler1865(ctx, x, y, h, t, {var, pose, dir, ph})` v2 | 3 viajeros distintos (`var` 0–2) y poses `stand, walk, point, wave, hat, talk` |
| `columbiadSection(…, {p, v, acc, flash, gas})` v2 | Corte del cañón con mampostería, tubo con bridas, cámara de carga y gases; devuelve `{cap, mouth, bottom, vArrow, aArrow, charge}` |
| `accelLanes(ctx, x, y, w, h, u, t)` | Carriles cañón (tramo corto) vs Saturno V (S-IC/S-II/S-IVB) y filas VELOCIDAD / ACELERACIÓN separadas; cualitativo, sin cifras |
| `floridaMap(ctx, cx, cy, w, t, {era, pins:[{id, lon, lat, col, glow, a}]})` → `{pr, pins}` | Mapa de Florida con escala y norte; distinguir lugares ficticios (Stone's Hill) de reales (Cabo Kennedy 39A) |
| `saturnV3` v2 · `pad39A(…, {arms})` v2 · `eagleLM` v2 · `astronaut(ctx, x, y, h, t, {dir, walk, step})` | Tecnología real del s. XX: marcas, etapas, LES, brazos de servicio, módulo lunar con etapas de descenso/ascenso |
| `lunarPath(ctx, mode, earth, moon, u, t, {lm, col, lw})` v2 → `{pos, ang, landing}` | Trayectorias suaves; `lm: true` añade la rama de alunizaje del Apolo |
| `floatPhoto(…, {credit})` | Línea de crédito discreta bajo la etiqueta |

FX v1.22: `canonazo(k, t, g)` (en la atmósfera) y `saturno(k, t, d, g)` (despegue en tierra). En el vacío no se usan explosiones.

FX v1.20: `hieloCrujir`, `pico`, `bloque` y `escarcha`. Música: `MUS.persa(k, t0, t1, {bpm, root, santur, daf, drone, mode})` (original, de inspiración persa: santur pulsado sobre un modo de tipo Homayun, bordón y daf).

**v1.19.2 · manos coherentes:**

| Bloque | Uso |
|---|---|
| `fingertip` (rehecho) | Una sola silueta continua (índice + palma + nudillos + pulgar) rellena de una vez, con sombreado solo en el borde exterior. Pliegues, nudillos y uña siempre DENTRO de la silueta |
| `handHold(..., { v2: true })` | Mano que sostiene el teléfono con la masa de la mano y las falanges en una sola silueta (los dedos salen del dorso). Recomendado para episodios nuevos; sin `v2`, el dibujo es el de v1.18.1 |

**v1.19.1 · corrección final del episodio del primer disco duro (fotos documentales, IBM 350 rediseñado):**

| Bloque | Uso |
|---|---|
| `ibm350` (rediseñado, misma firma) | Basado en la foto histórica: zócalo, panel inferior, GRAN ventana de inspección con marco fino, panel derecho con rejillas y pilotos, banda superior oscura. Pila de 50 discos anulares (óxido marrón, canto metálico, agujero central ≈ 0,49 R con cubo) con paso de 1,5 cm. Mecanismo de acceso con dos guías, carro, cable con polea y brazo radial con dos cabezas. Para cambiar de disco: retirar el brazo (`ext` 0), mover `k` y volver a extender |
| `worker1956` (rediseñado) | Proporciones reales, codos y manos, sombreado, balanceo y `point` 0..1 animable. Devuelve `hand` (mano derecha en pantalla) para sostener objetos |
| `fingertip` (rediseñado) | Mano con la palma hacia arriba en perspectiva: índice con volumen, pliegues y borde de la uña, dedos flexionados, pulgar a lo largo de la palma y palma que sale del cuadro. La tarjeta se apoya con sombra de contacto, a escala real |
| `photoCard(ctx, img, cx, cy, maxW, maxH, t, t0, t1, {tag, label, credit, zoom, radius})` | Tarjeta documental para FOTOGRAFÍAS REALES: esquinas redondeadas, marco fino, sombra moderada, entrada 96 → 100 %, acercamiento lento, rótulo «FOTOGRAFÍA REAL», pie y crédito (≥ 32 px). Proporción original y contenido intactos |
| `magTrack(ctx, x, y, w, h, t, {mode: 'write'\|'read', speed, bw})` | Pista magnética GRANDE: regiones como bloques imantados (→/←) que pasan bajo la cabeza, con hueco de aire. En `write` la bobina cambia la magnetización (lo no escrito, tenue). En `read` los cambios dan pulsos de señal y bits (cambio = 1, simplificado) |
| `flashCell(ctx, x, y, w, h, t, {charge})` | Celda flash en corte (transistor de puerta flotante): electrones atrapados según la carga y canal que conduce o no. Devuelve puntos `cg`, `fg`, `ch`, `src` y `drn` |

**v1.19 · almacenamiento: del IBM 350 (1956) al HDD, la flash y la microSD (episodio «El primer disco duro era una máquina gigantesca»):**

| Bloque | Uso |
|---|---|
| `RM` · `R350` · `r350y(k)` | Paleta del módulo (fondo industrial, metal de época, madera, luz cálida, disco, cian, datos, oro) y geometría del IBM 350 en **centímetros**: armario ≈ 152 × 172 × 74, 50 discos de 61 cm (R = 30,5), paso 1,27 cm. `r350y(k)` da la altura del disco k |
| `box3(ctx, cam, x0, x1, y0, y1, z0, z1, col, {only, alpha, k, edge})` | Caja 3D con caras sombreadas y ocultación. `only: 'back' \| 'front'` para dibujar el interior entre las caras traseras y las delanteras |
| `ibm350(ctx, cam, t, {rot, open, xray, arm:{k, ext}, hl, count, extract:{k, u}, lights, x, z})` | IBM 350 en 3D con `P.cam3`: armario con ventana, rejillas y pilotos; panel frontal que se retira (`open`); cubiertas transparentes (`xray`); 50 discos con grosor sobre un eje, con huecos oscuros entre ellos y marcas que giran; motor; columna con carro y brazo radial que entra en el hueco `k` (`ext` 0 = fuera, 1 = pista interior); resaltado y recuento de discos; extracción de un disco. Devuelve puntos para rótulos (`top`, `front`, `armTip`, `column`, `disk(k)`…). La cámara puede entrar entre dos discos |
| `room1956(ctx, cam, t, {warm, door, back})` | Sala informática de 1956: baldosas, paredes con zócalo, puerta de 2,1 m como referencia, ventanas altas y luz cálida |
| `worker1956(ctx, cam, foot, t, {pose, var, h})` | Técnico de los años 50 (camisa, corbata, pantalón) a la escala de la proyección en el punto 3D `foot`. Referencia de tamaño. Pose `point` para señalar o sostener algo |
| `ramac305(ctx, cam, t, {x, z, consoleDx})` | Resto del sistema IBM 305 RAMAC (genérico): armario de proceso con pilotos, consola de madera con máquina de escribir e impresora |
| `microSD(ctx, cx, cy, mm, {rot, back, glow, tilt})` | Tarjeta microSD con su forma real (11 × 15 mm, escalón lateral). `back` muestra los contactos. `mm` = px por milímetro |
| `fingertip(ctx, cx, tipY, fw, t, {skin, card, cardRot, glow})` | Yema del dedo (lado de la palma) que sale del borde inferior, con la microSD apoyada y sombra de contacto (escala real: dedo ≈ 17 mm) |
| `photoTile(ctx, x, y, s, seed, {rot})` | Miniatura de foto (paisaje estilizado) para visualizar contenido de forma conceptual |
| `platterFace(ctx, cx, cy, r, t, {tilt, rot})` | Disco del IBM 350 en 2D (frente o inclinado) con pistas, brillo y agujero central |
| `magSurface(ctx, x, y, w, h, t, {rows, speed, write})` | Macro de la superficie magnética: pistas que pasan con regiones magnetizadas (flechas N→/←S didácticas) |
| `magSection(ctx, x, y, w, h, t, {n, speed})` | Corte: sustrato de aluminio + recubrimiento magnético con regiones. Devuelve puntos para rótulos |
| `headTrack(ctx, x, y, w, h, t, {mode: 'write'\|'read', speed})` | Cabeza sobre una pista, con colchón de aire visible (nunca toca el disco). En `write` la bobina magnetiza al pasar; en `read` los cambios generan una señal eléctrica |
| `capBars(ctx, x, y, w, items, max, u, {bh, gap})` | Barras de capacidad en escala lineal (`items: [{label, mb, col}]`) |
| `hdd35(ctx, cx, cy, s, t, {rot, arm, plate, cover, angle})` | HDD de 3,5″ abierto (genérico): plato, eje, brazo pivotante que apunta al plato e imán. `plate` 0→1 hace desaparecer el plato (para pasar a flash). `s` = px/mm |
| `driveBox(ctx, cx, baseY, s, kind, t)` | Unidades cerradas a escala: `'1970'` (armario de discos removibles), `'525'`, `'35'` y `'25'` |
| `flashChip(ctx, cx, cy, s, t, {die, glow})` | Chip flash sobre placa con patas y pistas. `die` abre la matriz de celdas |
| `flashCells(ctx, x, y, w, h, t, {cols, rows, prog})` | Celdas flash conceptuales: puerta flotante que retiene electrones (carga = bit), sin piezas que giran |
| `floppy35(ctx, cx, cy, s, {rot, shutter, col})` | Disquete de 3,5″ (90 × 94 mm): persiana metálica, etiqueta y muesca |
| `dimLine(ctx, x0, y0, x1, y1, label, {col, px, off, a})` · `rulerCm(ctx, x, y, L, s)` | Cota con flechas y rótulo (≥ 32 px) y regla graduada en cm para comparar tamaños |

FX v1.19: `sala1956`, `motorDiscos` (suave, nunca una turbina), `carro`, `panel`, `interruptor`, `escribir`, `leer`, `chipFlash`, `disquete` y `miniaturizar`. Música: `MUS.industrial(k, t0, t1, {bpm, chords, perc, strings})` (percusión mecánica suave, relés, bordón y cuerdas).

**v1.18 · comunicaciones y épocas, 1926 ↔ hoy (episodio «Nikola Tesla imaginó el celular en 1926»):**

| Bloque | Uso |
|---|---|
| `ERA.old` / `ERA.now` · `mixc(a, b, u)` | Paletas oficiales de época: 1926 (sepia, café, papel, bronce) y hoy (azul, cian, noche, hielo, oro). `mixc` mezcla dos colores para transiciones graduales |
| `eraGrade(ctx, amt, t, {grain, dust})` · `techGrade(ctx, amt)` | Gradación de película de 1926 sobre lo dibujado: tono sepia, velo cálido, parpadeo, viñeta, grano suave a 12 cambios/s, polvo y rayas, todo determinista. `amt` 1→0 para retirarla poco a poco. `techGrade` aplica velo azul y viñeta fría. Llamar dentro del beat (antes de los subtítulos); con `clip` sirve para una sola tarjeta |
| `radioWaves(ctx, x, y, t, {dir, spread, n, col, r0, r1, speed, a, w})` | Arcos de señal que nacen en un punto y se desvanecen (conceptual) |
| `candlestick(ctx, x, y, s, t, {lift, ear, ring, wireTo})` | Teléfono de candelero apoyado en una superficie: auricular colgado en la horquilla (`lift` lo lleva a `ear`), vibración de timbre y cable a la pared |
| `switchboard(ctx, x, sueloY, w, t, {n, plug(i,c,t), lamps})` | Centralita manual: paneles de jacks, lamparitas, repisa con clavijas que se conectan con su cordón y operadoras de espaldas en sillas apoyadas en el suelo |
| `city1926(ctx, t, {gy, poles, wires, cut, cars, seed})` · `car1926(ctx, x, y, s, t, dir)` | Calle genérica de los años 20: rascacielos escalonados, postes con crucetas, aisladores y haces de cables, autos de época con ruedas que giran. `cut` 0→1 hace desaparecer los cables de izquierda a derecha («el cable se vuelve señal») |
| `radioTower(ctx, x, gy, h, t, {waves, wcol, r1})` | Torre de radio de celosía con riostras, apoyada en el suelo, que emite arcos |
| `teslaOld(ctx, x, y, s, t, {hand, handL, look})` | Tesla hacia 1926 (≈70 años), figura ESTILIZADA y no retrato: delgado, traje de tres piezas, cuello alto, pelo gris con raya al medio y bigote. Manos `down`, `chin`, `point` o `pocket`. Solo respira y parpadea: sin labios ni diálogo. Rotular «RECONSTRUCCIÓN» |
| `magazine1926(ctx, cx, cy, s, t, {title, date, head, by, page, hi, tag})` | Revista RECONSTRUIDA, no facsímil: cabecera en Fraunces, metadatos reales, texto ilegible (nunca citas inventadas), paso de página, resaltado de un párrafo y sello «RECONSTRUCCIÓN CONCEPTUAL» |
| `vestPocket(ctx, x, y, w, h, t, {dev, glow})` | Chaleco en primer plano (botones, cadena de reloj, bolsillo) con un aparato conceptual que asoma |
| `smartphone(ctx, cx, cy, h, t, {screen, cut, rot, glow, body})` | Smartphone GENÉRICO sin marca. `screen(ctx, x, y, w, h)` dibuja la pantalla. `cut` 0→1 abre la vista de corte y devuelve `camera`, `mic`, `chip`, `antenna` y `battery` para rotular |
| `handHold(ctx, cx, cy, h, 'back'|'front', {skin, sleeve})` | (v1.18.1) Mano derecha con agarre real, vista por quien sostiene el teléfono. La palma va detrás, con el talón bajo el borde inferior y la base del pulgar fuera del borde derecho. Los cuatro dedos rodean el borde izquierdo, con las yemas y las uñas apoyadas en el frente. El pulgar se apoya en la pantalla con sombra de contacto. La muñeca, el antebrazo y la manga llegan al borde inferior (nada flota). Orden: `back`, luego el teléfono, luego `front`. Para que la mano entre o cambie de sitio, muévela opaca (sube desde abajo o se desliza); nunca con un fundido de opacidad |
| `persona(ctx, cx, cy, s, t, {skin, hair, shirt, style, look, ph})` | Persona en plano medio con parpadeo y leve movimiento de cabeza (sin labios sincronizados) |
| `videoCall(ctx, x, y, w, h, t, {t0, remote, self, connect})` | Interfaz genérica de videollamada: persona remota, recuadro propio, tiempo de llamada, micrófono, cámara y colgar. `connect` 0→1 para conectar |
| `cellTower(ctx, x, gy, h, t, {waves, dir})` | Estación base: monopolo, tres sectores de antenas de panel, armario y valla. Devuelve `ant` |
| `fiberPath(ctx, pts, t, {prog, pulses, speed, col, w})` | Fibra óptica con funda, núcleo y pulsos de luz. `prog` revela el tendido |
| `dataPackets(ctx, x0, y0, x1, y1, t, {n, size, speed, arc, col, a})` | Paquetes de datos (0/1) que viajan entre dos puntos |
| `earthNight(ctx, cx, cy, r, t, {lon0, lat0, arcs, lights})` | Tierra nocturna ortográfica con luces agrupadas en torno a ~70 metrópolis reales y arcos de ENLACE CONCEPTUAL con un punto que viaja. Rotularlos como conceptuales: la señal real viaja por redes |
| `yearRoll(ctx, cx, cy, px, desde, hasta, u, {col, font})` | Marcador de año mecánico (1926 → 2026), cada dígito rueda por separado |
| `evoGrid(ctx, cx, y, t, k, {steps})` | Cadena de evolución 3×2 con iconos (TELÉFONO ANTIGUO → IDEA → INALÁMBRICO → BOLSILLO → SMARTPHONE → VIDEOLLAMADA). `k` = pasos encendidos. El color pasa de sepia a cian |
| `eraLabel(ctx, texto, cx, cy, px, t, t0, era, {t1})` | Título o cápsula de época: Fraunces sobre sepia oscuro (era < 0,5) o Nunito sobre azul noche |

FX v1.18: `timbre`, `auricular`, `clavija`, `oficina`, `paginas`, `radio1920`, `saltoTiempo`, `senalRadio`, `encender`, `llamada`, `flujoDatos` y `calle1920`. Música v1.18: `MUS.piano(k, t0, t1, {bpm, chords, melody, strings, waltz})` (piano con caída natural y cuerdas) y `MUS.pulso(k, t0, t1, {bpm, chords, kick, arp, pad})` (pulsos electrónicos). Los nombres `P.phone`, `P.person`, `FX.senal`, `FX.datos` y `FX.tiempo` siguen siendo los de v1.5 y anteriores: comprueba que un nombre no exista antes de crearlo.

**v1.17.1 · material documental, bandera y sección detallada (corrección final de «Tacoma Narrows»):**

| Bloque | Uso |
|---|---|
| `docPhoto(ctx, img, cx, cy, maxW, maxH, t, t0, t1, {label, tag, zoom, tilt})` | Tarjeta documental para fotografías REALES sin alterarlas: relación de aspecto original, marco fino, sombra suave, entrada 96 %→100 % con desplazamiento vertical sutil, salida suave, acercamiento lento dentro del marco (`zoom: [cx0, cy0, z0, cx1, cy1, z1]`), rótulos «ARCHIVO HISTÓRICO» y pie de foto. Las imágenes se incrustan como `data:` en un `js/fotos.js` y se cargan en `EPISODIO.init` |
| `usFlag(ctx, x, y, h)` · `flagPill(ctx, texto, cx, cy, t, t0, t1)` | Bandera de EE. UU. con proporciones oficiales (1:1,9; 13 franjas; cantón; 50 estrellas) y cápsula informativa discreta con entrada y salida suaves |
| `tacSection3D(ctx, cx, cy, s, th, t, {rot})` | Sección 2,5D extruida del tablero de 1940: losa, vigas laterales de alma llena con alas y rigidizadores, vigas transversales, eje y flecha de giro; devuelve puntos para cotas y rótulos |
| `tacSection` (`type: 'celosia'`) | Sección de celosía profunda (ejemplo del puente de 1950) abierta al viento, para comparar en el túnel de viento |
| `TAC.w` (`trav`) · `TK` | La oscilación vertical combina onda estacionaria y una componente que avanza (nula en las torres); acero y cables más oscuros para contrastar con el cielo; las péndolas conservan su longitud (el cable sigue al borde) |

**v1.17 · motor 3D ligero y puente colgante (episodio «Tacoma Narrows»):**

| Bloque | Uso |
|---|---|
| `cam3(pos, tgt, f, roll)` | Cámara 3D en perspectiva: `pr(p)` proyecta un punto, `clip(pts)` recorta un polígono contra el plano cercano antes de proyectar (evita caras perdidas o invertidas), `depth(p)`. Base para cualquier escena 3D con orden del pintor y ocultación de caras traseras |
| `TAC`, `TK` | Geometría del puente de 1940 (vano 853 m, laterales 335 m, tablero 11,9 m, vigas de alma llena de 2,4 m, torres de ~130 m, péndolas cada 15,24 m) y paleta del episodio. `TAC.w(x, m)` modo vertical (semiondas) y `TAC.th(x, m)` torsión con un nodo en el centro del vano |
| `tacBridge(ctx, t, {cam, m, cars, xray, glow, fog})` | Puente colgante completo en 3D: tablero por estaciones (calzada, cara exterior de las vigas, coronación, fondo) que se deforma con `w` y gira con `th` sección a sección; dos cables parabólicos que siguen a cada borde; péndolas conectadas; torres con dos patas, travesaños y arriostramiento en X sobre pilas; pilas de los vanos laterales y anclajes. Colapso por tramos `m.fail = [[xa, xb, tRotura, giro, cabeceo], …]` (caída con gravedad y giro, hundimiento), péndolas que se rompen `m.snap`, cable que sube al perder carga (`m.lift`), vanos laterales que se hunden (`m.sideSag`). Coches de 1940. Devuelve `sect(x)` (puntos de la sección deformada) y `cableY` |
| `tacWorld(ctx, t, {cam, warm})` | Estrecho en 3D: cielo con nubes, colinas boscosas, orillas con talud y árboles, agua con destellos y niebla ligera |
| `tacWind(ctx, t, cam, {k})` | Trazos de viento semitransparentes que cruzan el estrecho |
| `tacSection(ctx, cx, cy, s, th, t, {flow, vortex, moment, w, edges, type})` | Sección transversal del mismo tablero (`'H'` 1940 o `'cajon'`) que gira `th`; líneas de corriente que la rodean sin atravesarla, separación y estela, remolinos que recorren el tablero según la fase del giro y momento aerodinámico (flecha curva) en el sentido de la velocidad de giro `w` (aporta energía) |
| `windTunnel(ctx, cx, cy, w, h, th, t, {type})` | Ensayo de un modelo seccional sobre muelles en un túnel de viento |
| `mapWA(ctx, x, y, w, h, t)` | Mapa estilizado del estado de Washington con Puget Sound y el punto de Tacoma Narrows |
| FX `aleteo`, `desgarro`, `salpicadura` | Oscilación lenta del tablero (un golpe de aire por medio ciclo), desgarro de acero (sin explosión), impacto de un tramo en el agua |

**v1.16.1 · tuneladora como un solo sistema mecánico (corrección final de «Túnel bajo el río»):**

| Bloque | Uso |
|---|---|
| `tbmState` (ciclo completo) | excavar (0–0,6) → retraer cilindros (0,6–0,66) → montar 7 dovelas (0,66–0,94) → apoyar cilindros en el anillo nuevo (0,94–1). Añade `retr` |
| `tbmSide` (rediseñado) | Todas las piezas se sitúan respecto al frente `xm` y al eje: cabeza con aberturas que giran (el terreno pasa por ellas a la cámara), árbol al rodamiento principal, mamparo con sensores, cámara LLENA de terreno acondicionado, boca del tornillo dentro de la cámara, hélice que gira con marina visible, motor y compuerta, tolva a la cinta, 4 cilindros anclados al anillo de empuje con vástago y zapata sobre el último anillo, erector con brazo telescópico y alimentador de dovelas. Mismo orden de montaje que `ringBuild` (solera primero, llave en la clave) |
| `cutterFace` (rediseñado) | Cabeza EPB 2,5D: aro robusto con cortadores perimetrales, 6 brazos en cajón con profundidad, placas frontales con ranuras de entrada, rascadores, rippers, refuerzo interior, centro con cortador cola de pez y terreno moviéndose tras las ranuras |
| `ringBuild` (rediseñado) | Dovelas con volumen (cara + canto), anillo anterior con juntas longitudinales escalonadas, erector con corona giratoria, contrapeso, brazo telescópico y pinza de dos patines; devuelve `held` y `prev` |
| `ringSection(ctx, cx, cy, R, t, {grout, press, glowJoint})` | Sección transversal del revestimiento en el terreno: terreno con agua en los poros, hueco anular que la lechada llena desde la solera hacia la clave, 7 dovelas con sellos en las juntas, interior seco |
| `tunWorld` / `tunCross` | Capa de sedimentos sobre el lecho, cáusticas y neblina en el agua; nuevos puntos de anclaje para rótulos (`bulkhead`, `screwIn`, `screwOut`, `cyl`, `tail`) |
| `tunnelView` | Vía con ancho proporcionado al túnel, andén con barandilla, bandejas de cables y niebla de profundidad |

**v1.16 · túneles bajo ríos (episodio «Túnel bajo el río»):**

| Bloque | Uso |
|---|---|
| `TUN`, `TC` | **Sistema de coordenadas único** del río y el túnel: nivel del terreno `GS`, superficie del agua `WS`, perfil del lecho `bed(x)`, capas `layers` (arena, arcilla, grava, roca), eje `TY`, radio `R`, anchura de anillo `w`, espesor `ti`, pozos `x0`/`x1`; `TC` = paleta (agua, terreno, acero, cabeza de corte, hormigón, sellos, presión, zona protegida) |
| `tbmState(cyc, base)` | Estado de avance a partir de un número continuo de anillos: excava (0–0,6: la cabeza avanza una anchura de anillo empujada por los cilindros) y monta (0,6–1: el erector coloca 7 dovelas). Devuelve `xm` (frente), `rf` (cara del último anillo), `build`, `adv` |
| `tunWorld(ctx, t, {st, mode, press, support, watertable, tbm, glow, dusk})` | Sección longitudinal por el eje del túnel: cielo, ciudad en profundidad, río en sección con rayos y partículas, barcos, capas, nivel freático, pozo de ataque (y de salida), revestimiento de anillos con juntas escalonadas y sellos, relleno anular de lechada, y la tuneladora (`tbmSide`) o el túnel terminado (solera, vía, luces, tren). `press` = empuje del terreno y del agua; `support` = presión de soporte en la cámara. Devuelve puntos para rótulos |
| `tbmSide(ctx, st, t, o)` | Tuneladora EPB en sección: cabeza de corte (solo ella gira), cámara con terreno acondicionado, mamparo con sensores, tornillo sinfín con hélice animada, cinta, vagonetas, cilindros de empuje apoyados en el último anillo, erector con dovela, cepillos de cola, inyección de lechada y equipos posteriores sobre ruedas. `glow`: `head`, `chamber`, `screw`, `cyl`, `erector` |
| `tunCross(ctx, t, {mode, train, press, xray, flow, boats, dusk})` | Sección transversal: el río fluye a lo ancho (barcos, corriente, rayos), lecho con vegetación, capas y el túnel (anillo de 7 dovelas con sellos, lechada, interior con vía y tren de frente). `xray` = corte transparente del terreno sobre el túnel |
| `riverAerial(ctx, t, {alt, tunnel, dusk})` | Toma aérea en perspectiva de un río entre manzanas de ciudad, barcos con estela; `alt` 1→0 desciende hasta el agua; `tunnel` dibuja el trazado bajo el río |
| `cutterFace(ctx, cx, cy, R, ang, t)` | Cabeza de corte de frente: aro, radios, cortadores de disco, rascadores y aberturas por donde entra el terreno |
| `ringBuild(ctx, cx, cy, R, t, {placed})` | Montaje de un anillo de frente dentro del escudo: anillo anterior con juntas desfasadas, dovelas colocadas y el erector que toma, eleva, gira y posiciona la actual; la llave cierra el anillo (`placed` 0–7 continuo) |
| `gasketHD(ctx, cx, cy, s, t, {close, water})` | Macro de una junta: dos cantos de dovela con ranura, sello elastomérico con huecos que se comprime, agua a presión desde fuera, lechada, perno e interior seco |
| `tunnelView(ctx, t, {train, speed, cam})` | Interior de un túnel ferroviario terminado en perspectiva: anillos rellenos con juntas, luminarias, bandejas, andén, vía y un tren que se acerca |
| FX `corteTBM`, `sinfin`, `tren` | Giro de la cabeza de corte contra el terreno, tornillo sinfín, paso de un tren (se combinan con `chapuzon`, `bajoAgua`, `corriente`, `hidraulico`, `encaje`, `compresion`) |

**v1.15.1 · puente cinematográfico y primeros planos mecánicos (revisión de «Puentes sísmicos»):**

| Bloque | Uso |
|---|---|
| `bridge` (`D` variable) | La profundidad `D` es ahora una **cámara**: `[44,-30]` lateral, `[150,-105]` tres cuartos, `[80,-14]` bajo el tablero. Interpolar `D` entre claves da una órbita suave sin cambiar de geometría. El valle tiene volumen (franjas de profundidad, río que lo cruza, árboles a su profundidad, terreno cercano que entierra las zapatas), sombra del tablero, losa + vigas con rigidizadores y diafragmas, pretiles con baranda, carriles, apoyos en dos filas en vistas anchas y juntas de peine sin «agujero» bajo la losa. El terreno cae junto al muro del estribo (no tapa el extremo del tablero) |
| `isolatorHD(ctx, cx, cy, s, t, {base, top, cut, n, glow})` | Aislador con núcleo de plomo en detalle 2,5D: cabezal de pila, placa inferior anclada, capas de caucho y láminas de acero que se cortan sin separarse, núcleo de plomo que se deforma con ellas (no es un pistón), placa superior y viga del tablero en alzado. `base` = movimiento de la subestructura, `top` = del tablero. Devuelve puntos para rótulos |
| `damperHD(ctx, ax, ay, bx, s, t, {cut, vel, heat, force})` | Disipador viscoso en detalle: placa de anclaje atornillada al estribo, articulaciones con pasador, cilindro de longitud fija, vástago, pistón con orificios, fluido en dos cámaras con flujo esquemático en sentido contrario al pistón, calor cualitativo y flecha de **resistencia** opuesta a la velocidad (∝ √|v|) |
| `roadView(ctx, t, {vy, jz, gap, finger, cars, glow, dusk})` | Vista desde la calzada con punto de fuga: carriles, pretiles, farolas y una **junta de peine** cuya abertura `gap` nunca supera la longitud de los dientes (capacidad). Coches de frente o de espaldas |
| `bridgeSection(ctx, cx, gy, s, t, {ug, up, ud, flow, hl, iso})` | Corte transversal por una pila: estratos, pilotes, zapata, fuste, cabezal en martillo, cuatro apoyos, vigas en I, losa y pretiles; `flow` anima el **camino de cargas** del suelo al tablero |

**v1.15 · ingeniería sísmica: puente completo, sismo físico y mecanismos (episodio «Puentes sísmicos»):**

| Bloque | Uso |
|---|---|
| `quakeGround({t0, t1, amp, seed, freqs, pulses, floor})` | Movimiento del suelo determinista: suma de senos con envolvente. `pulses: [[a, b, k], …]` sube y baja la intensidad al ritmo del guion (`floor` = nivel entre pulsos; 0 = calma). Devuelve `{env(t), ug(t), ag(t)}` (desplazamiento y aceleración) |
| `sdof(ag, Tn, zeta, tA, tB, dt)` | Oscilador de un grado de libertad (Newmark) bajo aceleración de base: **la respuesta de la estructura sale de la física**, no de un seno inventado. Puente aislado ≈ `Tn 2.5, zeta 0.2`; rígido ≈ `Tn 0.6, zeta 0.05`. Devuelve `u(t)` con `.max` y `.vel(t)` (precalcular una vez, fuera de `draw`) |
| `bridge(ctx, t, {mode, ug, up, ud, section, forces, demand, xray, cut, heat, vel, glow, cars, piers, x0, x1, deckTop, bearH, plateau, valley, ground, trees, river})` | **Puente de vigas como un solo sistema**: valle con terraplenes, losas de acceso, estribos encajados en el talud (asiento, muro de guarda), zapatas que siguen la pendiente (pilotes en `section`), pilas que se curvan como ménsulas, cabezales, apoyos (`mode 'aislado'` = aisladores elastoméricos; `'rigido'` = apoyos fijos), tablero cajón con calzada, barandas y coches, juntas de peine y disipadores viscosos en los estribos. `ug` suelo, `up` deriva de la cabeza de pila, `ud` tablero absoluto. Los mecanismos se dibujan con todo su detalle dentro de la geometría: **un primer plano es solo un zoom de cámara**. Devuelve `{piers, bearings, dampers, joints}` con puntos para rótulos |
| `isolatorDetail(ctx, cx, cy, w, h, shear, t, {layers, lead, glow, bolts})` | Aislador laminado: placas atornilladas, capas de caucho y láminas de acero que se cortan en paralelogramo sin separarse, núcleo de plomo opcional. Devuelve `{top, bottom, rubber, shim, lead}` |
| `damperDetail(ctx, a, b, t, {cut, heat, vel, r, body, rod})` | Disipador viscoso entre anclajes: cuerpo de longitud fija, vástago, pistón con orificios; en corte (`cut`) se ve el fluido, el flujo según `vel` y el calor (`heat`). Devuelve `{body, piston, rod, a, b}` |
| `jointDetail(ctx, x, y, w, h, gap, t, {glow})` | Junta de dilatación en alzado (uso suelto; `bridge` ya incluye juntas de peine en la calzada) |
| `hArrow(ctx, x, y, len, c, w)` · `car(ctx, x, y, s, c)` · `SEC` | Flecha horizontal con signo; coche de perfil; paleta de ingeniería (hormigón, acero, caucho, disipación, fuerza, control, terreno, vegetación) |
| FX `temblor`, `estructura`, `hidraulico`, `metal`, `trafico` | Retumbo grave sin estruendo, crujido estructural suave, flujo hidráulico, contacto metálico leve, tráfico lejano (sin sonidos de catástrofe) |

**v1.14.2 · sistema único terreno + muralla + torres (corrección geométrica):**

| Bloque | Uso |
|---|---|
| `wallSystem(ctx, gy, xa, xb, t, {style, h, thick, build, towersX, towerSmoke, towerFire, pavilionX, ruin, sunLeft, crenel, glow})` | **Sistema único**: comparte la cresta `gy(x)` y una proyección oblicua (`D`) para muros, almenas y torres. La muralla se divide en **tramos que terminan en las caras de cada torre**. Orden de dibujo: tramo → torre → tramo, para que el muro quede delante de la cara lateral de la torre y detrás de su cara frontal. El adarve va en rampa donde la pendiente local es suave y en peldaños donde es fuerte, y se enlaza al nivel de cada torre. La cara frontal baja hasta el terreno (zócalo de piedra en el ladrillo). Las torres tienen zócalo que llega al suelo, cara lateral con **puerta al nivel del adarve donde entra el tramo**, ventanas, almenas y pabellón opcional. Las sombras proyectadas siguen la posición del sol (`sunLeft`). Devuelve las torres (`roof`, `door`, `F`) y `walk(x)` |
| `ridgePeaks(gy, xa, xb, gap)` | Cumbres de una cresta con separación mínima: se usan para poner las torres en los puntos altos |
| `rangeRidge(o)` | La misma cresta delantera de `ranges(o)`, sin dibujar (para colocar torres o cámaras antes del dibujo) |
| `ranges` (`rugged`) | Crestas rocosas y estribaciones con lado iluminado y lado en sombra según el sol |
| `wallPath`, `watchtower` | Ahora usan `wallSystem` y la misma torre (compatibles con la firma anterior) |

**Añadidos y mejoras v1.14.1 (revisión final de «Gran Muralla»):**

| Bloque | Uso |
|---|---|
| `figure(ctx, x, y, h, ph, {pose, var, dir, lift, target})` | **Persona proporcionada** (cabeza, torso, brazos y piernas articulados con IK) con túnica cruzada, faja, pantalón y calzado, y sombrero de paja, pañuelo, moño o gorro según `var`. **El pie más bajo toca siempre `y`**. Poses: `walk`, `stand`, `carry` (pértiga), `ram` (pisón con las dos manos, `lift` 0..1), `chisel` (`target`), `look` y `lead`. Para que no patine: `ph = distancia recorrida / (h · 0,85)`. Devuelve las manos, la cabeza, el hombro y los pies |
| `laborer`, `porter` (mejorados) | Usan `figure`; el porteador lleva la pértiga al hombro y la sujeta con la mano |
| `wallPath` (rediseñado) | Muralla 2,5D: sombra proyectada, cimiento que baja a la ladera, adarve con grosor, pretil interior, almenas con cara, techo y lateral, troneras, zócalo de piedra (ladrillo), mampostería (piedra) o capas erosionadas (tierra), cara final con grosor y torres integradas cuya base llega al terreno. `pavilion` añade un pabellón con tejado a las torres indicadas |
| `watchtower` (rediseñado) | Cara frontal, cara lateral con puerta al nivel del adarve, ventanas arqueadas, almenas con volumen y pabellón opcional; humo o fuego desde la azotea |
| `matFill(ctx, pts, mat, {layer, reeds, bh, glow})` | Relleno de material para cortes: `tierra` (capas), `grava` (cascajo), `piedra`, `ladrillo` (aparejo), `madera` y cañas |
| `wallSection(ctx, x, y, w, h, t, kind, {reeds, build, glow})` | **Cortes comparables**: `tierra` (apisonada, con capas de cañas opcionales), `piedra` (mampostería con relleno) y `ming` (cimiento de piedra, núcleo de tierra y cascajo, paramentos de ladrillo que se colocan hilada a hilada, adarve y parapeto). Devuelve puntos para rótulos |
| `ranges` (`part`) | `part: 'back'` / `'front'` para dibujar las capas lejanas con una cámara atenuada (**paralaje**) |
| `rammedEarth` (mejorado) | Trabajadores `figure` con pisón sujeto con las dos manos; anillo de impacto y polvo al tocar; capa suelta solo un 35 % más alta que la compactada; encofrado con travesaño atado |

Efectos `FX` de v1.14: `apisonar` (golpes de pisón), `vertido` (tierra), `ruedas`, `cascos`, `ladrillo`, `hoguera` y `pasosTierra`.

**Bloques v1.13 (episodio «Vikingos en América»)** — mar cinematográfico, barco nórdico, mapas de rutas, arqueología y tiempo:

| Bloque | Uso |
|---|---|
| `seaHD(ctx, t, {hor, sky, sun, sunA, clouds, mood, amp, flow, fogA, seed, x0, x1, part, split})` | **Mar cinematográfico** por filas en perspectiva: cielo, nubes, sol, olas de varias escalas, crestas con espuma y niebla. `mood`: `calma`, `fresco` o `tormenta`. `flow` hace que el mar pase junto al barco. Se dibuja en dos pasadas (`part: 'back'` hasta `split`, luego el barco, luego `part: 'front'`) para que el agua tape bien el casco. **Devuelve `float(x, y, eslora)` → `{y, ang}`** para que el barco cabecee y suba con las olas |
| `seaWave(o, x, y, t)` | Altura del agua en un punto (misma fórmula del mar) |
| `knarr(ctx, x, y, s, t, {ang, sail, billow, oars, oarN, oarPhase, xray, flex, crew, wake, glow, flip})` | **Barco mercante nórdico** de perfil, con casco trincado (tablas superpuestas con remaches), roda y codaste, remo de gobierno, mástil, verga, vela cuadrada con franjas, jarcia, remos opcionales y tripulación sobria (sin cascos con cuernos). `xray` vuelve el casco transparente y muestra la quilla, las cuadernas y los bancos. `flex` es una flexión sutil. **Devuelve puntos** (`mastTop`, `sailC`, `keelC`, `hull(u, f)`, `oar`…) para los rótulos |
| `clinkerSection(ctx, cx, cy, w, h, t, {explode, flex, glow, n})` | Corte transversal del casco trincado: tracas que se solapan, remaches, quilla, cuaderna y bao. `explode` separa las tablas para mostrar el solape. Devuelve `overlaps`, `keel`, `rib`, `beam` |
| `northAtlantic(ctx, x, y, w, h, t, {lon0, lon1, lat0, lat1, ice, grid})` | Mapa ESTILIZADO del Atlántico Norte (Escandinavia, Islandia, Groenlandia con hielo, Baffin, Labrador y Terranova). **Devuelve `proj([lon, lat])`** |
| `seaRoute(ctx, pts, p, t, {c, w, ship, shipS, glow})` | Ruta marítima suave que se dibuja con `p` y lleva un barquito en la punta |
| `coast(ctx, y, t, {kind, h, x0, x1, c, snow, green})` | Costa lejana sobre el horizonte: `fiordo`, `volcanica`, `glaciar` o `baja` |
| `iceberg(ctx, x, y, s, t)` | Iceberg con la parte sumergida insinuada |
| `sodHouse(ctx, x, y, w, h, t, {ruin, smoke, doorX, glow})` | Casa nórdica de madera y césped; `ruin` la convierte en los restos arqueológicos (bases de muros bajo la hierba) |
| `treeRings(ctx, x, y, r, t, {n, hi, count, cut})` | Corte de madera con anillos de crecimiento, anillo destacado, recuento hasta la corteza y marca de corte. Devuelve `at(i, ángulo)` |
| `timeline(ctx, x0, x1, y, t, {from, to, step, p, marks, span, spanP})` | Línea temporal con marcas grandes y un tramo luminoso entre dos fechas. Devuelve `map(año)` |
| `nightSky(ctx, t, {a, y0, y1, n, band, mark})` | Cielo nocturno con estrellas que titilan y vía láctea |
| `norse(ctx, x, y, h, ph, {pose})` | Persona nórdica estilizada (túnica, capa y gorro); poses `stand`, `look`, `row`, `point` y `walk` |

**Añadidos y mejoras v1.13.1 (revisión maestra de «Vikingos»):**

| Bloque | Uso |
|---|---|
| `knarr` (rediseñado) | Casco con volumen: cara interior de la borda opuesta, cuadernas, bancos y carga (`cargo`), tracas con vetas y tonos variables, juntas de empalme, remaches, quilla marcada, timón lateral con caña y tojo, obenques con vigotas, braza y escotas. `roll` inclina la borda y el mástil; la vela «respira» con ráfagas. Devuelve además `wl` (línea de flotación), `bowWL`, `sternWL` y `oarTips` |
| `knarrWater(ctx, K, t, {speed, spray})` | Espuma en la línea de flotación, bigote de proa, estela y reflejo oscuro. Se dibuja **después** del mar delantero |
| `seaHD` (mejorado) | Sombreado por fila (crestas claras, senos oscuros), destellos del sol sobre el agua, nubes suaves, `flash` (relámpago) y `crest` |
| `clinkerSection` (nuevos parámetros) | `assemble` (las tablas entran una a una) y `rivets` (los remaches aparecen en orden) |
| `northAtlantic` (mejorado) | Costas más fieles (fiordos de Noruega, golfo de Botnia, Islandia, Groenlandia completa, Baffin, Labrador, golfo de San Lorenzo, Terranova) y `latRef` para la proyección |
| `navigator(ctx, x, y, h, t, {look, turn, wind, rim})` | Navegante nórdico de espaldas en 3/4: túnica con cinturón, capa con broche al viento, polainas, gorro y barba; mano a la frente que se anima (`look`) y luz de contorno |
| `longhouse(ctx, x, y, w, d, h, t, {roof, ruin, smoke, door, glow})` | Casa larga de madera y turba en 3/4, apoyada en el suelo con sombra de contacto: muros de turba en espiga, tejado de turba con hierba y puerta con marco. `ruin` la convierte en las bases de muros excavadas |
| `timber(ctx, x, y, w, h, t, {glowEnd, cuts})` | Pieza de madera arqueológica con borde de corteza, cortes de herramienta y testa con anillos |
| `timeline` (mejorado) | Los rótulos nunca salen del lienzo y se omiten las cifras del eje que chocan con una marca |

Efectos `FX` de v1.13: `oleaje`, `madera` (crujidos del casco), `vela` (se iza y se llena), `cuerdas`, `remo`, `pasos`, `martillo` (remachado), `mapa`, `descubrir` y `costa`.

**Música orquestal sintética `PLANTILLA.MUS`** (v1.13; no modifica `SOUND`): `MUS.epica(k, t0, t1, {bpm, chords, gain, drums, strings, drone, ostinato})` combina cuerdas de ataque lento, bordón grave, ostinato y percusión de tambor grave. `MUS.golpe(k, t, {chord})` es un golpe orquestal para las revelaciones. Se usa dentro de `music(k)`.

**Bloques v1.12 (episodio «Machu Picchu»)** — montaña, mampostería, terrazas, drenaje y agua:

| Bloque | Uso |
|---|---|
| `andes(ctx, t, {sky, sun, peaks, layers})` | Cordillera por capas con perspectiva atmosférica |
| `fog(ctx, y, h, t, {a, speed})` | Banda de niebla que deriva entre montañas |
| `rainSheet(ctx, t, {x, y, w, h, n, a})` | Lluvia en diagonal sobre un área |
| `granite(ctx, pts, {c1, c2, bevel})` | Relleno de granito con motas y bisel, para cualquier polígono |
| `stoneWall(ctx, x, y, w, h, {style, skip})` | Muro `poligonal` (bloques que comparten vértices: encajan sin huecos), `sillar` (hiladas) o `rustica` (piedra de campo con juntas de barro). `skip` deja un hueco para animar un bloque que encaja. **Devuelve los polígonos** |
| `terraces(ctx, x0, y0, sw, sh, n, t, {build, cut, water})` | Terrazas escalonadas sobre una ladera, en corte: muros y relleno por capas que se construyen y se revelan, con agua que se infiltra |
| `terraceCut(ctx, x, y, w, h, t, {reveal, labels, water})` | **Corte grande de una terraza** (diagrama clave): muro, capas suelo/arena/grava/piedras con rótulos, roca de la ladera, infiltración y salida del agua al pie del muro |
| `channel(ctx, pts, t, {fill})` | Canal de piedra con agua que fluye (abastecimiento por gravedad) |
| `incaFountain(ctx, x, y, s, t, on)` | Fuente tallada con caño, chorro y pila |
| `citadel(ctx, cx, cy, s, t, {age, canal, glow, fogA, seed, frontRows})` | Ciudadela de montaña (v1.12.1). La geometría se construye desde las **plataformas**: el perfil del cerro sale de ellas, y cada edificio se apoya en una plataforma urbana (fila trasera sobre un escalón de granito) con sombra de contacto, así que nada flota. Incluye sector agrícola con andenes, sector urbano, plaza, escalinatas, muros de contención de granito, terrazas frontales en la ladera (`frontRows`, 5 por defecto), pico de fondo separado (sin edificios) y canal que baja en escalera hasta las fuentes. `age` 0 = reconstrucción (techos de paja), 1 = estado actual. `glow` resalta muros, drenaje y agua por separado. Devuelve `{plats, ground(x)}` para colocar personas u objetos sobre el suelo |

Efectos `FX` de v1.12: `lluviaFuerte`, `golpePiedra` (percusión), `abrasion`, `encaje` (bloque que asienta), `arroyo` (agua por un canal) y `tiempo` (transición histórica).

**Bloques v1.11 (Andrómeda V2, rediseño cinematográfico)** — 3D ligero, nave, espacio profundo y gráficas:

| Bloque | Uso |
|---|---|
| `M3` (`loft`, `box`, `draw`, `project`, `rot`) | Mini motor 3D para Canvas: mallas de caras con sombreado lambert, luz de contorno, brillo especular, orden por profundidad y perspectiva. Sirve para cualquier objeto técnico que deba verse en 3/4 |
| `starship(ctx, x, y, s, t, {yaw, pitch, roll, thrust, ring})` | **Nave interestelar Asombroteca** (diseño original, siempre la misma): escudo frontal contra polvo, espina de titanio, carenado, anillo habitable giratorio, depósitos, radiadores, 3 toberas con chorro de partículas y luces de navegación. Vistas lateral, frontal, trasera y 3/4. `pitch = π/2` = proa hacia arriba |
| `deepSpace(ctx, t, {px, py, streak, dir, neb})` | Espacio profundo con nebulosa tenue y 3 capas de estrellas con **paralaje** (la cámara «viaja» con px/py); estelas opcionales (estilizadas) |
| `galaxyHD(ctx, x, y, r, {seed, tilt, rot, spin})` | Galaxia de ~120.000 partículas: disco, brazos, bulbo, regiones HII, polvo y bloom (en caché) |
| `holoClock(ctx, x, y, r, secs, color, label, value, {sub})` | Reloj holográfico con barrido de segundero y valor digital grande |
| `chart(ctx, x, y, w, h, series, {xr, yr, logY, p, xTicks, yTicks, xLabel, yLabel})` | Gráfica científica integrada (ejes grandes, rejilla, curvas con brillo que se dibujan con `p`, escala logarítmica opcional). **Devuelve `map(x, y)`** para añadir marcas |

Efectos `FX` de v1.11: `encendido` (motores que arrancan), `pasada` (la nave pasa junto a la cámara) y `holo` (interfaz holográfica).

**Bloques v1.10 (episodio «Viaje a Andrómeda»)** — espacio y relatividad:

| Bloque | Uso |
|---|---|
| `REL.trip(D, a)` | **Simulación** de un viaje con aceleración propia constante (acelera la 1.ª mitad y frena la 2.ª) en años y años luz: `tauTot`, `tTot` y `at(f)` → `{ tau, t, x, beta, gamma, eta, oneMinusBeta }`. Úsala como fuente única de relojes, velocidades y distancias; `REL.G1` = 1 g |
| `betaText(1 − v/c)` | v/c como texto con los nueves necesarios (nunca «1 c») |
| `space(ctx)` · `starfield(ctx, t, {eta, cy, F})` | Fondo espacial y campo de estrellas con aberración relativista estilizada (rapidez `eta`) |
| `galaxy(ctx, x, y, r, {seed, tilt, rot, core, arm})` | Galaxia espiral en caché (brazos, bulbo y polvo) |
| `spaceship(ctx, x, y, s, ang, t, {thrust, cut})` | Nave interestelar con chorro de propulsión y corte por zonas |
| `missionClock(ctx, x, y, label, value, color, {sub, prog})` | Panel de reloj o contador de misión |
| `speedGauge(ctx, x, y, r, 1 − v/c)` | Velocímetro logarítmico que se acerca a c sin tocarla |
| `spacetime(ctx, x, y, w, h, lines)` | Diagrama de Minkowski: líneas de universo, cono de luz y marcas de tiempo propio |
| `cockpit(ctx, t, view)` | Cabina con ventana panorámica (el exterior se dibuja en un callback), consolas y astronauta de espaldas |
| `scientist(ctx, x, y, h)` | Silueta histórica estilizada |

Efectos `FX` de v1.10: `espacio`, `propulsion`, `aceleracion`, `frenado`, `reloj`, `galaxia`, `contraer` y `llegada`. Son recursos cinematográficos: en el vacío no se propaga el sonido.

**Bloques v1.9 (episodio «El barco de acero»)** — flotación, hidrostática y barcos:

| Bloque | Uso |
|---|---|
| `seaProfile(ctx, y, t, {sky, sun, depth, x0, x1, bottom})` | Mar de perfil completo: cielo, sol, agua con cáusticas y oleaje |
| `underwater(ctx, y, t, {...})` | Velo de agua para lo sumergido (se dibuja DESPUÉS del objeto) |
| `cargoShip(ctx, x, y, L, draft, t, {H, rows, cut, comps, flood, disp, plimsoll, trim, extraBay})` | Portacontenedores de perfil: calado real, corte longitudinal con mamparos, compartimentos que se inundan, volumen sumergido resaltado, marca Plimsoll, asiento y contenedores añadidos. **Devuelve geometría** (`deck`, `keel`, `bay(i)`, `comps`) |
| `hullSection(ctx, cx, wl, w, h, sink, t, {disp, sep, cargo, flood})` | Sección transversal del casco con aire, carga y el volumen desplazado (que se puede separar). **Devuelve `cob`** (centro de empuje) |
| `forceArrow(ctx, x, y, len, dir, color, label)` | Flecha de fuerza gruesa (empuje, peso, tensión…) |
| `pressureArrows(ctx, pts, y0, t)` | Presión normal a una superficie sumergida, creciendo con la profundidad |
| `splash(ctx, x, y, t, t0)` | Salpicadura determinista |
| `container`, `gantryCrane` | Contenedor y grúa de muelle (**devuelve el spreader**) |
| `beaker`, `greek`, `column` | Vaso con rebosadero, figura clásica y columna (historia de la ciencia) |

Efectos `FX` de v1.9: `chapuzon`, `hundirse`, `casco` (crujido metálico), `grua`, `contenedor`, `inundacion`, `bocina` (de barco) y `equilibrio` (acorde de resolución).

**Bloques v1.8 (episodio «Las pirámides»)** — historia antigua, construcción y trabajo humano:

| Bloque | Uso |
|---|---|
| `desert(ctx, y, t, {sky, sunX, sunY})` | Desierto con sol y dunas; **devuelve `yAt(x)`** del suelo |
| `pyramid(ctx, x, y, w, h, {built, courses, casing, joints})` | Pirámide 3/4 por hiladas: `built` la construye por niveles (con plataforma), `casing` añade el revestimiento liso. **Devuelve `{apex, base, at(cara, u, v)}`** para poner rampas, personas o marcas sobre las caras |
| `block(ctx, x, y, w, h, {c})` | Bloque de piedra en perspectiva (caliza o granito) |
| `sled(ctx, x, y, s)` | Trineo de madera con bloque; **devuelve el punto de amarre de la cuerda** |
| `worker(ctx, x, y, h, fase, {pose})` | Persona estilizada que camina (`walk`), tira (`pull`), vierte agua (`pour`), está quieta (`stand`) o trabaja (`chisel`); **devuelve la posición de las manos** |
| `rope(ctx, pts, w)` | Cuerda trenzada |
| `ramp(ctx, pir, tipo, p, {top})` | Rampas sobre una pirámide: `recta`, `zigzag`, `espiral`, `interna` (hipótesis) |
| `papyrus`, `tool(ctx, tipo, …)` | Papiro con signos estilizados; herramientas: `cincel`, `mazo`, `sierra`, `codo`, `plomada`, `escuadra` |
| `palm`, `qmark` | Palmera que se mece; signo de interrogación flotante (dudas e hipótesis abiertas) |

Efectos `FX` de v1.8: `arrastre` (piedra sobre arena), `cuerda` (tensión), `esfuerzo` (tirones rítmicos), `vertido` (agua), `cincel`, `piedra` (bloque que se asienta) y `viento` (desierto).

**Bloques v1.7 (episodio «La represa»)** — agua, energía y electricidad:

| Bloque | Uso |
|---|---|
| `waterBody(ctx, pts, t, {surf, top, bottom})` | Masa de agua (embalse, río) en un polígono, con degradado por profundidad y superficie con brillo |
| `concrete(ctx, pts, {joints, stains, light})` | Hormigón con juntas y manchas (represas, muros, edificios técnicos) |
| `pipe(ctx, pts, w, t, {fill, flow, speed})` | Tubería con agua que la LLENA (`fill` = hasta dónde llegó) y trazadores de flujo |
| `gate(ctx, x, y, w, h, open)` | Compuerta deslizante de toma |
| `francis(ctx, x, y, r, ang, {open, flow, t})` | Turbina Francis vista desde arriba: carcasa espiral, álabes directrices FIJOS y rodete que GIRA |
| `waterwheel(ctx, x, y, r, ang)` | Rueda de molino |
| `genSection(ctx, x, y, r, ang, {poles, field, current})` | Generador en corte: rotor con electroimanes N/S que gira, estator fijo con bobinas que se encienden y líneas de campo conceptuales |
| `sine(ctx, x, y, w, h, t, {phases})` | Corriente alterna (una o tres fases) |
| `transformer(ctx, x, y, s, {n1, n2, flux})` | Transformador: núcleo y dos devanados (n2 > n1 = eleva la tensión) |
| `pylon` y `powerLine` | Torre de alta tensión (**devuelve los puntos de amarre**) y cable con catenaria y paquetes de energía |
| `house`, `factory`, `skyline` | Casa, fábrica y ciudad con ventanas que se encienden |
| `bulb`, `switchWall` | Bombilla con halo e interruptor |
| `cloud` (con `rain`), `sun`, `fish` | Ciclo del agua y ecosistemas |

Efectos `FX` de v1.7: `compuerta`, `corriente` (agua que fluye), `turbina` (giro que acelera), `generador` (zumbido de 60 Hz), `induccion`, `transformador`, `lineas` (zumbido y chasquidos de alta tensión), `bombilla` y `lluvia`.

**Bloques v1.6 (episodio «Internet bajo el mar»)** — océano, cables submarinos y telecomunicaciones:

| Bloque | Uso |
|---|---|
| `spline(pts, seg)` | Curva suave que pasa por los puntos (rutas, cables colgando, contornos) |
| `ocean(ctx, t, depth, {x,y,w,h,snow,rays,dy})` | Mar de perfil: color según profundidad (0 superficie → 1 abismo), rayos de luz y «nieve marina». `dy` crece durante un descenso |
| `waves(ctx, y, t, {sky,amp,w})` | Superficie del mar con oleaje; `sky` pinta el cielo encima |
| `seabed(ctx, y, t, {seed,rocks,bottom})` | Fondo marino; **devuelve `yAt(x)`** para apoyar cables u objetos en el fondo |
| `ship(ctx, x, y, s, t, {tanks,flip})` | Barco cablero de perfil que se mece; **devuelve el punto de la roldana de popa** (de donde sale el cable) |
| `cableSection(ctx, x, y, r, {p,armor})` | Corte del cable: fibras en gel y tubo, hilos de acero, cobre, polietileno (+ armadura y cubierta con `armor`). **Devuelve las capas con su radio** para rotular |
| `fiber(ctx, x0, x1, y, h, t, {bits,gap,speed,att,boost})` | Fibra de perfil (revestimiento + núcleo) con pulsos de luz GUIADOS (sin zigzag). `att` = pérdida de brillo a lo largo; `boost` = posiciones de amplificadores |
| `repeater(ctx, x, y, s, ang, glow)` | Repetidor submarino; `glow` = amplificando |
| `worldMap(ctx, x, y, w, h, {lon0,lon1,lat0,lat1,...})` | Mapa del mundo ESTILIZADO (equirrectangular). **Devuelve `proj([lon,lat])`**. Rotular siempre «mapa estilizado» |
| `cableRoute(ctx, pts, prog, t, {c,w,dots,speed,smooth})` | Ruta luminosa que se dibuja con paquetes de luz viajando; devuelve `P.path` |
| `depthGauge(ctx, x, y0, y1, v, max, {step})` | Regla vertical de profundidad con marcador |
| `rov`, `plow` | Vehículo submarino operado a distancia (focos, brazo, umbilical) y arado submarino que entierra cables |
| `anchor`, `grapnel`, `station` | Ancla, garfio de recuperación y estación de aterrizaje en la costa |

Efectos `FX` de v1.6: `bajoAgua` (ambiente submarino con burbujas), `inmersion` (zambullida), `olas`, `pulsoLuz` (destellos de luz/datos ópticos), `amplifica`, `cabrestante` (máquina que suelta o recoge cable), `ancla` (cadena + golpe), `rotura` y `empalme` (chispas de unión).

Efectos `FX` de v1.5: `senal`, `datos`, `tictac` y `ubicacion`.

Efectos `FX` de v1.4: `ventilador`, `compresion`, `expansion`, `goteo` y `calor`.

Efectos `FX` añadidos: `pitido`, `zumbido`, `motor`, `campo`, `escala`, `revelar`, `puerta`, `fin`.

**Subtítulos «barra»** (`capStyle: 'barra'`, estándar Asombroteca): frase completa en blanco, barra amarilla animada bajo la palabra que se dice y palabras clave en amarillo. Por defecto van en la franja segura inferior (y ≈ 1500). El estilo «selección» (arriba, con asas) sigue disponible.

**Transiciones** (campo `in` de cada beat):

| Tipo | Efecto | Uso |
|---|---|---|
| `cut` | corte directo | — |
| `iris` | círculo que se abre desde un punto | — |
| `zoom` | la escena anterior se agranda hacia un punto mientras se abre la nueva | ideal tras una lupa |
| `slide` | barrido lateral con desenfoque | — |
| `rise` | la nueva escena sube desde abajo | — |
| `fade` | fundido a negro | momentos de silencio |

## 7. Cómo hacer un video nuevo (paso a paso)

1. **Preparar la carpeta.** Copiar `nuevo_video/` con el nombre del video (por ejemplo `video_tripas/`), dentro de esta misma carpeta de plantilla.
2. **Poner la voz** en `01_ENTRADA/audio/`. Las fotos reales, si las hay, van en `01_ENTRADA/fotos/`.
3. **Analizar la voz.**
   - Ejecutar `bash ../tools/preparar_voz.sh 01_ENTRADA/audio/<voz>.mp3 trabajo/`. Mide la duración, detecta las pausas y transcribe con Whisper.
   - Revisar `trabajo/tramos_borrador.txt`: corregir nombres propios y escribir las cifras con su forma hablada.
   - Guardarlo como `03_GUION/tramos.txt`.
4. **Alinear y generar subtítulos.**
   - `python3 -I ../tools/alinear.py trabajo/sil_major.txt trabajo/sil_minor.txt $(cat trabajo/duracion.txt) 04_CODIGO/alineacion.json 03_GUION/tramos.txt`
   - `python3 -I ../tools/subtitulos.py 04_CODIGO/alineacion.json 06_SUBTITULOS/subtitulos.srt 04_CODIGO/js/datos.js`
5. **Investigar y verificar los datos** y escribir `FUENTES_Y_DECISIONES.md`.
6. **Escribir `04_CODIGO/js/episodio.js`** partiendo de la base comentada:
   - tabla `T` de palabras;
   - beats `{t0, t1, in, draw, sfx}`;
   - piel, palabras clave, música y ambiente.

   Para fotos reales, seguir el patrón de `ejemplo_submarino` (`js/foto_*.js` en base64 + `init`).
7. **Construir y revisar.**
   - Desde `04_CODIGO`: `python3 -I ../../tools/build.py`.
   - Revisar fotogramas con `node ../../tools/frames.js index.html qc 1 5 10 …` y `python3 -I ../../tools/sheet.py hoja.png 6 qc/*.png`.
   - Corregir solapes antes del render.
8. **Renderizar e integrar.**
   - Render: `node ../../tools/render.js index.html frames 6`.
   - Stems: `node ../../tools/audio.js index.html ../05_AUDIO`.
   - Mezcla (sección 4) y codificación:

```
ffmpeg -framerate 30 -i frames/f_%05d.jpg -i mix.wav -c:v libx264 -preset slow -crf 19 -maxrate 10M -bufsize 20M -pix_fmt yuv420p -c:a aac -b:a 256k -ar 48000 -movflags +faststart -shortest 07_OUTPUT/VIDEO.mp4
```

9. **Cerrar.** QC (sección 8), README, commit y push.

## 8. Lista de control de calidad (antes de entregar)

- [ ] ffprobe: 1080×1920, 30 fps, H.264 + AAC 48 kHz, duración = voz + cola.
- [ ] Decodificación completa sin errores; sin negros ni congelados (blackdetect/freezedetect).
- [ ] Sonoridad cerca de −15 LUFS y pico ≤ −1 dBFS; la voz siempre por delante.
- [ ] El md5 de la voz de entrada coincide con el archivo recibido.
- [ ] Determinismo: mismo `t` → mismos píxeles, en dos órdenes distintos.
- [ ] Hoja de contacto revisada: sin textos encimados, sin rótulos cortados, nada importante abajo del todo.
- [ ] Datos en pantalla verificados y con fuente.
- [ ] Documentación: README, QC.md, FUENTES_Y_DECISIONES.md y mapa voz → escenas.

## 9. La plantilla crece: cómo añadir algo nuevo

Si un video necesita algo que la plantilla no tiene, se crea y **se incorpora a la plantilla** para que los videos siguientes también puedan usarlo. Puede ser un objeto o personaje, un tipo de gráfico, una transición, un efecto de sonido o una piel nueva.

Pasos:

1. **Decidir dónde va.**
   - Si es reutilizable (gráfico de barras, mapa, línea de tiempo, personaje genérico, transición), va en `motor/plantilla.js` como bloque de `P`, transición o efecto de `FX`.
   - Si es exclusivo del tema (el submarino, un intestino concreto), se queda en el `episodio.js` del video.
2. **Hacerlo genérico.**
   - Colores semánticos (`col('accent')`, `fill('#hex')`) para que funcione en las pieles «plana» y «oscura».
   - Parámetros con tiempos (`t`, `t0`).
   - Determinista (`H.rng`).
   - Con su sonido en `FX`.
3. **No romper lo anterior.**
   - Los bloques existentes no cambian de firma.
   - Antes y después del cambio, el `ejemplo_submarino` debe dar los mismos md5 de fotograma (prueba de determinismo).
4. **Mostrarlo.** Añadirlo al catálogo (`catalogo/catalogo_src.js`) y regenerar `catalogo.png`.
5. **Documentarlo.**
   - Añadirlo a la tabla de bloques (sección 6).
   - Anotar en `CAMBIOS_PLANTILLA.md` la versión, qué se añadió y para qué video.
6. **Entregar.** Regenerar `PLANTILLA_ASOMBROTECA_KIT.zip`, hacer commit y push.


**v1.23 · Tarjetas perforadas (unidades 3D en mm):**

| Bloque | Uso |
|---|---|
| `cardFrame(c, {yaw, pitch, roll, fmt})` → cd · `cardPt(cd, u, v, d)` · `holeUV(fmt, col, row)` · `CARDF` · `CROWS` | Marco de una tarjeta (sin giros: vertical mirando a +z; `pitch: -π/2` boca arriba; `pitch: +π/2` boca abajo) |
| `cardCode(ch)` · `cardHoles(línea80, {n})` | Código real de tarjeta (dígitos, letras, espacio y `, . - / * $`); `n` = columnas ya perforadas |
| `punchCard3(ctx, cam, cd, t, {holes, text, textN, print, fields, hl, band, thk, alpha})` → `{front, proj, s}` | Tarjeta con agujeros que se ven por detrás; `hl` resalta posiciones y `band` una columna; `thk` exagera el grosor en planos macro |
| `cardDeck3(ctx, cam, x, y, z, n, t, {yaw, topCard, topOpts, exag})` | Mazo apoyado (n tarjetas de 0,178 mm cada una) |
| `cardReader3(ctx, cam, t, {card, contacts, hopper, stacker, cover})` · `readerSection(ctx, x, y, w, h, t, {u, rows})` → `{contact, passed}` · `readerSectionU` | Lector de escobillas en 3D y en corte; `contacts` = columnas cuya escobilla toca el rodillo |
| `decodePanel(ctx, x, y, w, h, t, {rows, sym, note})` | Las 12 posiciones de una columna → símbolo |
| `keypunch3(ctx, cam, t, {card, press, key, hopper, stacker})` · `operatorSeated(ctx, x, y, h, t, {press})` | Perforadora de teclado (crea los agujeros; no confundir con el lector) |
| `hollerithPress(ctx, x, y, w, h, t, {press, holes, counts, bell})` · `tabulator1890(ctx, cam, t, {press, counts, lid, lidA})` · `office1890(ctx, cam, t)` | Censo de 1890: agujas con resorte, mercurio, 40 diales, mesa de clasificación (electromecánico) |
| `computerRoom60(ctx, cam, t, {pulse, lights, reader})` | Sala genérica de mediados del s. XX con lector, cable de datos y consola |

FX v1.23: `perforar(k, t, g)`, `tecleo(k, t, n, dt, g)`, `tarjetaRoce(k, t, d, g)`, `escobilla(k, t, g)`, `cascadaTarjetas(k, t, d, g)`, `dialHollerith(k, t, g)`.

**v1.23.1 · añadidos:**

| Bloque | Uso |
|---|---|
| `punchMech3(ctx, cam, t, {card, rows, ph, label, rack})` | Mecanismo de perforación en primer plano; `ph` 0..1 es la fase de una pulsación (tecla, punzón, recorte y avance) |
| `sdFrame(c, {yaw, pitch})` · `microSD3(ctx, cam, sd, t)` | microSD 3D de 11 × 15 × 1 mm con contactos; apoyarla siempre sobre una base o una mesa |
| `cardReader3(…, {roll, signal, sigAge})` · `readerSection(…, {sigAge})` | Giro de rodillos, cable y lámpara de señal; dos estados de contacto separados en el tiempo |
| `P.poly3(ctx, cam, pts, fill)` | Polígono 3D recortado contra la cámara, para escenarios sencillos en los episodios |

**v1.24 · Telégrafo óptico Chappe (unidades 3D en metros):**

| Bloque | Uso |
|---|---|
| `chappeTower(ctx, cam, pos, t, {cfg, yaw, scope, glow, ropeHi})` · `chappeMech(ctx, cam, base, cfg, {yaw, sc, ropes})` · `CHP` · `chappeGeom(cfg, sc)` | Modelo maestro ÚNICO de estación. `cfg = {reg, li, ri}` en grados (regulador 0/90; indicadores respecto a la prolongación del regulador, pasos de 45°) |
| `chappeAt(keys, t, ch)` · `chappeLerp` | Secuencias `[[t, cfg]…]`: cada cambio dura `ch` s y la posición se mantiene hasta el siguiente cambio |
| `chappeSky(ctx, {dusk, storm, night, fog, drift})` · `chappeLand(ctx, cam, t, {towers, near, fog, storm, night, dusk, road})` → `{hz, shade}` · `chappeHeight(x, z, towers)` | Paisaje del norte de Francia con estaciones en las cimas. Mantener la cámara por encima del terreno (en el episodio, `C3`). `near` añade detalle cercano |
| `rainFX(ctx, t, a)` · `fogFX(ctx, a, night)` | Lluvia y niebla de pantalla |
| `chappeSection(ctx, x, y, w, h, t, {cfg, man, look, moving, hi})` | Corte de estación: operador, telescopio, manipulador, cuerdas y mecanismo con la misma forma |
| `chappeMap(ctx, cx, cy, w, t, {u, n})` | Mapa esquemático París–Lille con la señal avanzando |
| `horseRider(ctx, x, y, h, t, {dir, rate})` · `telegraphKey(ctx, x, y, s, t, {press})` · `telegraphPoles(ctx, cam, hz, t, {a, pulse})` · `workshop1790(ctx, cam, t, {cfg})` | Mensajero a caballo, telégrafo eléctrico del s. XIX y taller con un modelo a escala del mecanismo maestro |

FX v1.24: `galope(k, t, d, g)`, `polea(k, t, d, g)`, `telescopio(k, t, g)`, `clicMorse(k, t, n, g)`.

**v1.24.1 · añadidos:**

| Bloque | Uso |
|---|---|
| `figure18c(ctx, x, y, h, t, {dir, coat, hair, reach, reachL})` → `{hand, head}` | Figura masculina de finales del s. XVIII; `reach` = punto en pantalla que toca la mano derecha (palanca, ocular) |
| `chappeMini(ctx, x, yb, s, cfg, {lit, colL, colR})` → `{top, G, toS}` | Estación 2D con la misma geometría que la 3D (para esquemas y comparaciones) |
| `relayPanorama(ctx, x, y, w, h, t, cfgAt, {n, done, los, scale})` | Estaciones en cimas con copia secuencial; `done(i)` resalta el progreso |
| `telegraphScene(ctx, x, y, w, h, t, {press, pulse, recv})` | Telégrafo eléctrico: manipulador, pila, hilo con impulso y receptor |
| `chappeTower(…, {colL, colR, night})` · `chappeSky(…, {seed})` | Resaltar un indicador; silueta nocturna; nubes distintas por escena |

**v1.25 · Órbitas y satélites (geometría compartida con `earth3`):**

| Bloque | Uso |
|---|---|
| `P.ORB` | Constantes: `Re` 6378 km, `geoAlt` 35 786 km, `geoR` 42 164 km, `k` 6,61 radios, `vGeo` 3,07 km/s |
| `orbView(cx, cy, r, rot, tilt)` → `{pt(lat, lon, k), vec, fromVec, hidden(p)}` | Proyecta puntos de la Tierra (k = 1) o del espacio (k radios) con el mismo convenio que `earth3({rot, tilt})`. Para el giro real, `rot` DISMINUYE con el tiempo. Un GEO es `pt(0, lonFija, k)` |
| `orbRing(ctx, V, k, {part, col, lw, dash, glow})` | Órbita ecuatorial: `part:'back'` antes de `earth3`, `'front'` después |
| `orbLat(ctx, V, lat, {col, lw, dash})` | Ecuador u otro paralelo (cara visible) |
| `orbFootprint(ctx, V, lon, {k, col:'r,g,b', a, shrink})` | Cobertura por horizonte geométrico (`shrink` 0,94 ≈ elevación mínima 5°) |
| `orbBeam(ctx, A, B, t, {u, col, w, n, speed})` | Enlace de radio esquemático con frentes de onda (u = avance) |
| `satGEO / station1945 / sputnik1 / satLEO (ctx, x, y, s, t, {face \| ang})` | Satélite GEO moderno, estación conceptual de 1945, Sputnik 1, satélite pequeño |
| `dishAntenna(ctx, x, y, s, el, t, {tx})` → `{feed, dir}` | Antena parabólica sobre pedestal; `el` = elevación en pantalla |
| `groundStation(ctx, x, y, w, h, t, {day, sun, el, tx, dishX, dishS})` → `{dish, gy}` | Estación terrena con cielo día/noche y estrellas |
| `repeaterDiagram(ctx, x, y, w, h, t, {u})` | Repetidor recibe→amplifica→cambia→amplifica→envía (h ≥ 300; dos filas si w < 1180) |
| `paperSketch(ctx, cx, cy, s, t, {u, bg})` · `magazine1945(ctx, x, y, w, t, {rot})` | Boceto a tinta (3 estaciones a 120°) que se dibuja · recreación editorial de revista (rotular «RECREACIÓN») |
| `figure1945(ctx, x, y, h, t, {dir, reach, reachL, glasses})` · `office1945(ctx, cam, t)` → `{paper}` | Figura de los años 40 · despacho con máquina de escribir (metros; teclado ≈ [-0.38, 0.92, -0.08]) |
| `timelineBar(ctx, x, y, w, y0, y1, marks, u, t)` | Línea de tiempo con años `[[año, etiqueta]]` |
| `tv1950(ctx, x, y, s, t, {on})` · `roofDish(ctx, x, y, w, t, {el, day})` → `{feed, dir}` | Televisor doméstico (apóyalo en un mueble) · tejado con antena parabólica |

FX v1.25: `enlaceSube(k, t, g)`, `enlaceBaja(k, t, g)`, `orbitaPulso(k, t, d, g)`.

Patrón de escena orbital (ver ep. 07, `orbScene`): anillo trasero → satélites con z < 0 → `earth3` → ecuador/coberturas/estaciones → anillo delantero → satélites con z ≥ 0 → enlaces. Dibuja un enlace solo si la estación ve el satélite (elevación > 0 con k real y con el k esquemático). Con k esquemático, limita r·k ≤ 520 px para que el satélite no salga del encuadre.

**v1.25.1 · añadidos (retoque cinematográfico del ep. 07):**

| Bloque | Uso |
|---|---|
| `earthHQ(ctx, cx, cy, r, t, {rot, tilt, light, clip})` | Igual convenio que `earth3`, sin «flor» polar (ruido 3D sobre la esfera). Úsalo siempre que se vean los polos o la Tierra sea grande; `clip:[0,0,W,H]` evita calcular píxeles fuera de cuadro |
| `satGEO3(ctx, x, y, s, t, {face, yaw, sun, rx, tx})` | Satélite moderno ilustrativo con volumen (envergadura ±285 px a s = 1); `rx`/`tx` 0..1 iluminan el reflector receptor/transmisor |
| `earlyBird(ctx, x, y, s, t, {ang})` | Intelsat I «Early Bird» (1965), cilindro con células solares |
| `satCutaway(ctx, x, y, w, h, t, {u})` → `{rx, tx}` | Repetidor transparente en corte; `u` = avance de la señal; devuelve las antenas para enlazar haces |
| `modernHouse(ctx, x, y, w, t, {day})` → `{roof(fx, fy), gy}` · `homeDish(ctx, x, y, s, el, t)` → `{feed, lnb, dir}` | Casa contemporánea en perspectiva · antena offset doméstica para colocar sobre `roof()` |

---

## v1.26 · Plantilla universal (estilos, interfaz, datos, personajes, historia, tecnología, 3D)

Extraído de 7 vídeos virales de referencia. Guía de uso, fórmula de guion y cuándo usar cada estilo: `GUIA_ESTILOS.md`.
Captura de todo: `catalogo/catalogo_v126.jpg`. Ejemplo completo: `ejemplo_demo_v126/04_CODIGO/js/episodio.js`.

**Montaje y estilo**

| Bloque | Uso |
|---|---|
| `PL.make({ estilo, marca: { nombre }, capIcons, capAhead, capSel, … })` | `estilo`: `asombroteca`, `viral`, `cartoon`, `noche`, `blueprint`, `dossier`, `producto` o `tecno` (fija piel, subtítulos y posición; lo explícito manda). `capStyle: 'ios'` o `'mono'` también se pueden pedir sueltos |
| `PL.kit(A, { lead, tail })` → `{ wt, T, B0, DURATION, txt, title, lab, recon, vign, bill, shot, fotos, IMG }` | Quita el código repetido de cada episodio. `wt(tramo, 'palabra', n)`, `T.s3`, `T.end`, `B0.b3 = T.s3 − lead`, `await K.fotos()` en `init` |
| `P.fondo(ctx, t, estilo?, { c0, c1, glow, seed, pan, lx, ly })` | Fondo completo del estilo (por defecto el de la piel activa) |
| `P.bokeh(ctx, t, o)` · `P.motes(ctx, t, o)` · `P.gridBP(ctx, o)` | Bokeh que deriva · motas que suben · cuadrícula de plano técnico |
| `P.marca(ctx, t, t0, { y, nombre })` | Nombre del canal discreto al final (`P.MARCA.nombre`, configurable) |
| `P.mini(ctx, x, y, w, h, fn)` | Dibuja una escena de 1080×1920 reducida dentro de un rectángulo (vista previa en el móvil, fotograma) |

**Interfaz y cierre**

| Bloque | Uso |
|---|---|
| `P.icon(ctx, nombre, x, y, s, { mode: 'line' \| 'flat', col, col2, lw })` | 49 iconos (`P.ICONOS`): persona, grupo, botella, copa, reloj, corazon, cerebro, pulmones, gota, rayo, llave, candado, movil, casa, coche, avion, barco, moneda, calendario, lupa, alerta, check, cruz, estrella, fuego, hoja, sol, luna, nube, nota, cafe, pastilla, adn, atomo, globo, pin, camara, micro, chat, enviar, ojo, bombilla, engranaje, escudo, trofeo, grafico, dinero, musculo, virus |
| `P.avatar(ctx, x, y, r, seed, { bg, ring, check })` | Persona ilustrada determinista (piel, pelo, ropa, gafas) |
| `P.scrShare / scrChat / scrLock / scrAlert / scrCamera (ctx, x, y, w, h, t, o)` | Pantallas para `P.smartphone(…, { screen })`: hoja de compartir, chat, bloqueo con notificación, aviso del sistema, cámara grabando |
| `P.keyboardUI(ctx, x, y, w, t, { hi: { e: 0.86 }, press, glow })` → posiciones | Teclado QWERTY español con probabilidades y teclas resaltadas |
| `P.ctaShare(ctx, t, t0, t1, { preview, names, seeds, sel, y, h })` + `FX.compartir(k, t0)` | Cierre «Envíaselo a ese amigo…»: el móvil sube, se abre la hoja de compartir, el dedo toca un contacto, luego «Enviar» y queda «✓ Enviado» |
| `P.tag(ctx, texto, x, y, t, t0, t1, { to: [[x, y]…], mono, px, col, bg })` | Etiqueta en píldora oscura con 1 o 2 líneas guía discontinuas |

**Datos**

| Bloque | Uso |
|---|---|
| `P.hud(ctx, t, [{ label, value \| from, to, t0, t1, x: 'left' \| 'right', y, hi, suffix }])` | Contadores tipo HUD (versalitas y número monoespaciado; miles con punto) |
| `P.iconGrid(ctx, x, y, w, h, n, icono, { cols, hi(i), reveal, labels(i) })` | Cuadrícula de pictogramas |
| `P.dotMatrix(ctx, x, y, filas, cols, f(r, c), { rowLabels, colLabels })` | Tabla de círculos llenos o vacíos (combinaciones) |
| `P.barsGrow(ctx, x, y, w, h, valores, u, { labels, hi(i), line: { v, label }, fmt })` | Barras que crecen una a una |
| `P.statBig(ctx, texto, x, y, t, t0, t1, { px, sub, col, badge })` | Cifra grande con rótulo |
| `P.clockBP(ctx, x, y, r, horas, { hi: [h0, h1], label })` | Reloj de trazo con arco de intervalo y hora digital |

**Personajes y metáforas**

| Bloque | Uso |
|---|---|
| `P.face(ctx, x, y, s, t, { mood, look, seed, blink })` | Cara para cualquier objeto. Ánimos: feliz, contento, triste, enfadado, asustado, sorpresa, dormido, mareado, serio |
| `P.character(ctx, tipo, x, y, s, t, { col, mood, bounce, face, glow })` | Personajes: bola, pinchos, gota, pastilla, celula, corazon, cerebro, pulmones, estomago, diente, virus, nube, sol, molecula |
| `P.keyLock(ctx, x, y, s, t, { u, turn, ok, fake, keyCol, lockCol, from })` | Cerradura y llave (receptores, contraseñas, compatibilidad). `fake` = llave falsa que entra pero no gira |
| `P.filmStrip(ctx, x, y, w, h, t, { scroll, frame(i, x, y, w, h), empty(i) })` · `P.recBadge(ctx, x, y, t)` | Tira de película con fotogramas (memoria, recuerdos) · indicador REC |

**Historia (dossier)**

| Bloque | Uso |
|---|---|
| `P.mapTop(ctx, x, y, w, h, t, { seed, density, view: { cx, cy, z }, roads, places, units, routes })` → `map(u, v)` | Mapa cenital: bosque de copas, caminos, castillo/pueblo/casa, tropas (enjambres de puntos que avanzan por un camino) y rutas punteadas |
| `P.dossier(ctx, img \| null, x, y, w, t, { name, role, rot, unknown, stamp: { text, t0 } })` | Ficha tipo polaroid (foto en grises o silueta; «?» si es desconocido) |
| `P.stamp(ctx, texto, x, y, w, t, t0, { col, rot })` + `FX.sello(k, t0)` | Sello de goma que golpea, con textura gastada |
| `P.emblem(ctx, 'estrella' \| 'cruz' \| 'letras' \| 'franjas', x, y, r, { text, cols, label, hi })` | Emblemas circulares de bando o equipo |
| `P.scope(ctx, x, y, r, t, inner(ctx), { ring, ticks })` | Mira o telescopio con retícula; `inner` dibuja lo que se ve |

**Tecnología y 3D**

| Bloque | Uso |
|---|---|
| `P.layerStack(ctx, x, y, w, t, { layers: [{ name, h, kind: 'vidrio' \| 'rejilla' \| 'pantalla' \| 'pcb' \| 'color' }], electrodes, field: { touch: { x, y, u, r } }, values: { base } })` | Corte por capas con arcos de campo eléctrico que se curvan hacia el dedo y lecturas que bajan donde se toca |
| `P.mesh.box(w, h, d, { bevel })` · `extrude(poli2d, d, { bevel })` · `cyl(r, h, { r2, seg })` · `sphere(r)` · `lathe([[r, y]…])` | Mallas sencillas. Torneado de abajo arriba, empezando y terminando en el eje |
| `P.render3(ctx, cam, [{ mesh, pos, rot, scale, col, cols: { lado, frente, atras, bisel }, spec, shin, alpha, shadow, suelo, paint }], { light, amb })` | Render con luz suave, brillo especular, sombras de contacto difuminadas, superficies de apoyo (`suelo`) y pintura sobre caras (`paint`: vetas, marcas, texto) |

FX v1.26: `toque(k, t)`, `compartir(k, t0)`, `llave(k, t)`, `latido(k, t, n, gap)`, `chispa(k, t, d)`, `disparos(k, t, n)`, `tanque(k, t, d)`, `rec(k, t)`, `alertaMovil(k, t)`, `personaje(k, t)`, `pasarPagina(k, t)`.

**Herramientas v1.26**

| Herramienta | Uso |
|---|---|
| `tools/nuevo_proyecto.py NOMBRE --estilo E --marca M --voz V [--titulo T] [--destino D]` | Crea el proyecto con su esqueleto. Las rutas a la plantilla se calculan solas |
| `tools/producir.py PROYECTO voz \| alinear \| build \| prueba t… \| render \| qc \| todo \| limpiar` | Producción completa. `render` incluye la mezcla con sidechain y corrige la sonoridad a −14 LUFS con pico ≤ −1 dBTP. `qc` escribe `07_QC/QC.md` con ✔/✘ |
| `tools/determinismo.js index.html [t…]` | Comprueba que cada fotograma depende solo de t |

---

## v1.27 · Más visualizaciones (zona segura, pausas, pantalla limpia, QC de publicación)

Las reglas 99-105 del SUPERPROMPT mandan sobre todo lo anterior. Todo se activa al usar `PL.make({ estilo })`; los episodios sin `estilo` no cambian.

| Elemento | Uso |
|---|---|
| `P.SAFE = { top: 220, bottom: 1450, right: 940, on }` | Zona segura de Instagram. Con `on` (lo pone `make` si `zonaSegura`), `P.tag` se recoloca dentro y `P.hud`/`P.ykRecon` alinean a la derecha en x = 930 |
| `PL.make({ estilo, zonaSegura, pausas, capMaxKW, pausaMin, pausaMax })` | Los estilos ya traen `zonaSegura: true`, `pausas: true` y `capMaxKW: 1`. `asombroteca` = subtítulos `ios` arriba (capY 420); `blueprint` = `mono` arriba (capY 430); los demás capY 380 |
| `P.pausas(A, min = 0.4, max = 1.6)` → `[[a, b]…]` | Silencios entre palabras. Con `pausas`, `make` frena el tiempo de dibujo en el centro de cada pausa (`P.pausaWarp`: casi quieto, sin saltos), añade `FX.pausa(k, a, d)` y `EP.pausas` las expone |
| `K.wa('palabra', n)` | Instante de la n-ésima aparición de la palabra en toda la voz (no depende de los tramos, que cambian al añadir pausas) |
| `PLANTILLA.safeLog()` (con `window.__SAFE_QC = true`) | Cajas de texto dibujadas en el último fotograma: subtítulos, etiquetas, avisos, cifras, títulos y marca |
| `tools/zona_segura.js index.html [paso]` | Recorre el vídeo y devuelve los textos fuera de zona, el máximo de etiquetas simultáneas y si hay título |
| `producir.py qc` | Añade: zona segura ✘, pantalla limpia ✘, pausas (informativo), gancho sin contexto ✘, cierre «Envíaselo…» sin «Sigue a…» ✘, movimiento desde el fotograma 0 ✘, duración (aviso > 75 s, ✘ > 90 s) |
| `producir.py render` | Baja la música al 40 % durante cada pausa dramática (desde `alineacion.json`) |

FX v1.27: `pausa(k, t, d)` (respiración grave suave + campanilla lejana).

**Voz con ElevenLabs (regla 103).** Modelo Eleven v4, voz Dan (`9F4C8ztpNUmXkdDDbz3J`), con `creative_generate_speech`. v4 no acepta `<break>`: 3-4 pausas antes de cada revelación con `[short pause]`, `[long pause]` (una sola vez) y puntos suspensivos («…»). Guardar el audio en `01_ENTRADA/audio/` (o pedir al usuario que lo descargue del enlace y lo adjunte) → `producir.py voz` → `03_GUION/tramos.txt` (cada pausa larga separa dos líneas). Las etiquetas entre corchetes y `<…>` se eliminan en `alinear.py` y `subtitulos.py`: nunca salen en los subtítulos, y el QC falla si alguna se cuela.

## v1.28 · Pausas en posproducción y QC de voz por tramo

Para alargar un silencio sin regenerar la voz (por ejemplo, antes de una revelación), escribe en `03_GUION/tramos.txt` una línea que sea **solo** `[PAUSA x]`, con x entre 0.3 y 1.0 segundos, entre dos tramos de voz:

```
Y eso lo cambia todo.
[PAUSA 0.8]
Cinco horas después…
```

| Elemento | Qué hace |
|---|---|
| `[PAUSA x]` en `tramos.txt` | Inserta x s de silencio exacto en el centro del hueco entre el tramo anterior y el siguiente. Admite `0.8`, `0,8` y `0.8s`, en mayúsculas o minúsculas |
| `alinear.py` | Desplaza todas las palabras y tramos siguientes (`alineacion.json`). Cada tramo conserva su tiempo en el original en `s0`/`e0`; la primera palabra tras la pausa lleva `pausa: x`; añade `pausas_post` y `duracion_original` |
| `subtitulos.py` | `datos.js` y `subtitulos.srt` salen con los tiempos desplazados; «[PAUSA x]» nunca aparece |
| `tools/montar_voz.py voz alineacion.json salida.wav` | Crea `05_AUDIO/voz_montada.wav`: la voz original con ceros insertados (WAV float, misma frecuencia y canales). No modifica ninguna muestra de voz. `producir.py alinear` lo ejecuta solo (y borra una voz montada vieja si ya no hay pausas) |
| `build.py`, `producir.py render` | Si la alineación tiene `pausas_post`, usan `voz_montada.wav` (y `build.py` la regenera si falta o es más vieja que la alineación, p. ej. al descomprimir el kit); si no, la voz de `01_ENTRADA/audio` como siempre |
| `P.pausas(A)` | Reconoce las pausas de posproducción igual que las naturales: animación frenada, `FX.pausa`, música al 40 % |
| QC «Voz intacta (md5 por tramo)» | md5 del archivo original frente a `voz_md5.txt` **y** md5 de las muestras de cada tramo en la voz montada frente al original («8/8 tramos idénticos»). Falla si cambia un solo tramo |
| QC «Duración» | Aviso (no fallo) por debajo de 45 s y por encima de 75 s; fallo por encima de 90 s |

**Errores (detienen `alinear.py` con el número de línea, nunca se ignoran):** `[PAUSA x]` con x fuera de 0.3–1.0; valor mal escrito (`[PAUSA abc]`); `[PAUSA x]` dentro de una línea con texto; pausa antes del primer tramo o después del último. Cualquier otra etiqueta entre corchetes (`[short pause]`, `[long pause]`, `[laughs]`…) o `<…>` se sigue quitando de los subtítulos sin error.

Ancla los tiempos del episodio con `wa('palabra', n)` o `wt(tramo, 'palabra')`: se desplazan solos al añadir o quitar pausas.

## v1.29 · Ahorro de créditos y crecimiento (una toma, 3 ganchos, portada, PUBLICAR.md)

### ElevenLabs: una sola generación
- `creative_generate_speech` se llama **SIEMPRE con `generations_count: 1`**. Nunca dos tomas.
- Modelo Eleven v4, voz Dan (`9F4C8ztpNUmXkdDDbz3J`). Pausas con `[short pause]`, «…» y `[long pause]` (una vez en el cuerpo).
- El guion completo, **ganchos incluidos**, no pasa de **1.300 caracteres** (≈ 45-70 s). Se le dice al usuario el número de caracteres ANTES de generar.
- Nunca se regenera el audio entero: pausa corta → `[PAUSA x]` en `tramos.txt`; palabra mal dicha → se regenera solo ese tramo corto (avisando antes de su número de caracteres).

### Tres ganchos en el mismo audio
Guion para ElevenLabs: `Gancho A… [short pause] … Gancho B… [short pause] … Gancho C… [short pause] … Cuerpo…`. En `03_GUION/tramos.txt`:

```
[GANCHO A] Tu cuerpo no está cansado.
[GANCHO B] Mil botellas, y una está envenenada.
[GANCHO C] Esto NO es lo que crees.
Primera línea del cuerpo…
…
```

| Elemento | Qué hace |
|---|---|
| `[GANCHO A/B/C] texto` | Tramo(s) de cada gancho. Todos antes del cuerpo; un gancho puede ocupar varias líneas seguidas con la misma letra. Errores: gancho después del cuerpo, sin texto, líneas de una letra no seguidas, etiqueta mal escrita, `[PAUSA]` entre ganchos, sin cuerpo |
| `alinear.py` | `alineacion.json` (audio completo, con `ganchos` y `cuerpo_desde`) y además `alineacion_A/B/C.json`: el gancho elegido + el cuerpo, con los tiempos desplazados. Cada uno lleva `gancho`, `montaje` (trozos del original `{de, a}` y silencios `{silencio}` de las `[PAUSA x]` del cuerpo) y `s0`/`e0` por tramo. Los silencios entre ganchos no pasan a ninguna variante; entre el gancho y el cuerpo queda el silencio original que había tras el último gancho |
| `montar_voz.py voz alineacion_X.json voz_X.wav` | Junta los trozos del original sin tocar ninguna muestra (WAV float) → `05_AUDIO/voz_A/B/C.wav`. `producir.py alinear` lo hace solo, y también `datos_X.js` y `06_SUBTITULOS/subtitulos_X.srt` |
| `build.py --gancho X` | Usa `js/datos_X.js` y `voz_X.wav` y define `window.GANCHO = 'X'` antes de los datos. Con ganchos y sin `--gancho`, la A. Sin ganchos, igual que la v1.28 (mismo `index.html`) |
| `window.GANCHO` | En `episodio.js`: `const GANCHO = window.GANCHO \|\| 'A';` y los primeros 2 s dependen de él (imagen, movimiento y frase grande propios) |
| `producir.py NOMBRE variantes` | Para cada gancho: render + QC → `07_OUTPUT/VARIANTE_A.mp4`, `_B`, `_C` y `07_QC/QC_A.md`, `qc_tecnico_A.txt`, `hoja_contacto_A.jpg`… Sin ganchos, igual que `todo` |
| `--gancho X` | En `build`, `prueba` (→ `07_QC/prueba_X.jpg`), `render` y `qc`, elige la variante (por defecto la A) |
| QC «Voz intacta» | En cada variante, md5 de las muestras de cada tramo frente al mismo tramo del original («7/7 tramos idénticos») |

Sin créditos para ganchos hablados: 3 variantes **visuales** con el mismo audio (cambia lo que se ve en los primeros 2 s con una constante y `--salida VARIANTE_X.mp4`).

### QC nuevo
| Control | Criterio |
|---|---|
| Silencio inicial / final | < −50 dB pegado al principio ≤ 0,5 s y al final ≤ 1 s; si no, ✘ |
| Nada encimado | Dos textos o contadores distintos (subtítulo, etiqueta, cifra, aviso, título, marca) visibles a la vez que se cruzan > 20 % de la caja menor → ✘. Las palabras de un mismo subtítulo no cuentan entre sí. Lo mide `zona_segura.js` (`encimados`) |
| Pantalla llena | ≈ cada 0,5 s, ancho que ocupa el dibujo (bordes, sin las cajas de texto) dentro de la zona segura 0-940 × 220-1450. Menos del 60 % durante más de 3 s seguidos → **aviso** (no ✘) con los tramos (`llena.avisos`) |

### Portada fija (maqueta estándar v1.30)
`python3 PLANTILLA_ASOMBROTECA/tools/producir.py NOMBRE portada "LÍNEA 1 / LÍNEA 2" "PALABRA_ROJA" "ETIQUETA" SEGUNDO [--gancho A] [--bajar 280]` → `07_OUTPUT/portada.jpg` (1080×1920, `tools/portada.js`). Ejemplo: `… portada "13 AÑOS / ESPERANDO" "13" "GTA VI" 2.6 --gancho A --bajar 280`.

| Elemento | Maqueta (la misma en todos los vídeos) |
|---|---|
| Fondo | Fotograma **NÍTIDO** del propio vídeo en el `SEGUNDO` exacto (4.º argumento, o `--t`), dibujado desde el episodio **sin subtítulos**; nada de desenfoque. Elige un instante con la escena principal bien visible. `--gancho X` elige la variante; `--bajar PX` baja el fotograma para dejar cielo libre al texto (la franja de arriba se rellena con el borde superior del fotograma) |
| Texto | Corto, en dos líneas **arriba de la escena**: la línea con la `PALABRA_ROJA` en rojo y más grande, la otra en blanco; Nunito 900 con **borde oscuro** y sombra para leerse sobre la imagen. «/» separa las líneas |
| Etiqueta | Píldora amarilla pequeña encima del texto (el nombre o el tema) |
| Marca | Discreta, abajo, dentro del recorte |
| Posición | Todo **centrado en x = 540** y dentro del **recorte 3:4 del perfil (240 ≤ y ≤ 1680)**; `portada.js` falla si algo se sale o se descentra |

Las maquetas de la v1.29 (texto centrado o abajo sobre fondo desenfocado) siguen disponibles con `--bloque centro|abajo`, solo para rehacer portadas antiguas.

### PUBLICAR.md
`nuevo_proyecto.py` copia `tools/plantillas_proyecto/PUBLICAR.md` a `07_OUTPUT/PUBLICAR.md`. Se rellena por vídeo: título y descripción para YouTube (con `#shorts`), Facebook, Instagram y TikTok; gancho como pregunta sin respuesta, invitación a comentar (nunca «dale like» ni «comparte si…»), 3-5 hashtags.

## v1.31 · Formatos de serie (`series/`)

Un formato de serie fija lo que se repite en todos los capítulos: bloques propios, portada, PUBLICAR.md y estructura del guion.

| Serie | Carpeta | Qué trae |
|---|---|---|
| «¿MITO O VERDAD?» | `series/serie_mito_verdad/` | `P.veredicto` + `FX.veredicto` (sello MITO / VERDAD / A MEDIAS que cae con su golpe), `P.serieTitulo`, portada fija (etiqueta «¿MITO O VERDAD?», la pregunta en 2 líneas con la palabra clave en rojo, fotograma nítido, maqueta v1.30), `PUBLICAR.md` de la serie y `LEEME.md` con la estructura del guion |
| «¿QUÉ PASA SI…?» | `series/serie_que_pasa_si/` | `P.queHacer` + `FX.queHacer` (remate «QUÉ HACER» con 2-3 consejos con ✓, en lugar del sello), `P.serieTitulo`, portada fija (etiqueta «¿QUÉ PASA SI…?», pregunta en 2 líneas con la palabra clave en rojo, fotograma nítido de la escena real centrado en x = 540), `PUBLICAR.md` y `LEEME.md` con las reglas fijas del formato (v1.37) |

```
python3 PLANTILLA_ASOMBROTECA/tools/nuevo_proyecto.py MITO_CAP4_TEMA --serie serie_mito_verdad --capitulo 4 --estilo tecno --voz AUDIO
python3 PLANTILLA_ASOMBROTECA/tools/producir.py MITO_CAP4_TEMA_PROYECTO portada "¿PREGUNTA LÍNEA 1 / LÍNEA 2?" "CLAVE" SEGUNDO [--gancho A] [--bajar 200]
```
En `episodio.js`: `const tV = wt(SEG, 'medias.') - 0.05; P.veredicto(ctx, t, tV, 'A MEDIAS');` y en `sfx(k)`: `FX.veredicto(k, tV, 'A MEDIAS');`.
Por defecto el sello va centrado en la zona segura (x = 480, ancho 760) para que el rebote no se salga de x ≤ 940.

**Bloque v1.31 · `P.mano(ctx, x, y, s, { ang, skin, izq })`**: mano plana que señala con el índice (palma, índice extendido con uña, pulgar a un lado, tres dedos doblados, muñeca). `(x, y)` = punta del índice; `s` = ancho del dedo (≈ 60-80 px); `ang` = giro (0 = hacia arriba, −0,45 = viene de abajo a la derecha); `izq` = mano izquierda. En el cierre: `P.ctaShare(…, { mano: true })`.

**v1.32 · Portada:** `--escala 0.84` reduce el fotograma de fondo (bordes fundidos con el fondo) para que el objeto quepa entero bajo el texto; `--marca-pos arriba` pone la marca sobre la etiqueta (las series lo hacen solas). En las series, el fondo es el objeto cotidiano del capítulo, nunca la metáfora.

## v1.33 · Mano natural reutilizable (`P.mano`)

`P.mano(ctx, x, y, s, { pose, ang, skin, izq, objeto, sombra, t })` — mano plana con volumen suave y proporciones reales, dibujada como UNA sola silueta (un contorno, sin costuras; la muñeca se ensancha en curva hasta la palma; un solo degradado de piel). Úsala SIEMPRE que salga una mano (señalar, tocar una pantalla, sujetar un objeto, saludar); no dibujes manos a mano en los episodios.

| Pose | Ancla (x, y) | Uso |
|---|---|---|
| `senalar` (por defecto) | punta del índice | señalar algo; los otros dedos doblados con nudillos y el pulgar recogido junto al índice |
| `tocar` | punta del índice | tocar una pantalla o botón; pasa `t` para la onda de toque |
| `abierta` | centro de la palma | mano abierta (saludar, «alto», mostrar) |
| `sujetar` | centro del objeto | sujetar un cargador, un celular…: `objeto: (c) => { … }` dibuja el objeto DETRÁS de la mano (vemos el dorso), centrado en (0, 0) |

`s` = ancho del índice (≈ 50-90 px; la mano mide ≈ 11 s de alto con la muñeca). `ang` = giro (0 = dedos hacia arriba; −0,45 = mano que entra desde abajo a la derecha). `izq: true` = mano izquierda. `skin` = tono base (por defecto `#e0a67f`; la luz y la sombra se calculan solas). `sombra: false` la quita. En el cierre: `P.ctaShare(…, { mano: true })`.


## v1.34 · Un solo vídeo por defecto, fórmula de los más vistos, encuadre como fallo y mano «sujetar» curvada

### Modo por defecto: UN solo vídeo
Se siguen proponiendo 3 ganchos, pero el usuario elige UNO y la voz (una toma) lleva solo ese gancho + el cuerpo.

| Qué | Cómo |
|---|---|
| `tramos.txt` | El gancho elegido, solo y marcado con su letra: `[GANCHO B] Vas en un avión… y se apagan los motores.` (o sin marca: entonces `window.GANCHO` no se define y `episodio.js` usa la A) |
| `producir.py NOMBRE video` | Nuevo nombre del paso por defecto (= `todo`): build + render + QC → `07_OUTPUT/<NOMBRE>_FINAL.mp4`, `07_QC/QC.md`, `qc_tecnico.txt`, `hoja_contacto.jpg`, `prueba.jpg` (sin sufijo de letra) |
| `--gancho` | Con un solo gancho no hace falta: se toma la letra que haya (`build.py` define `window.GANCHO = 'B'` si el elegido es la B) |
| 3 variantes (OPCIONAL) | Solo si el usuario las pide: los 3 ganchos `[GANCHO A/B/C]` en la misma toma y `producir.py NOMBRE variantes` (igual que en la v1.29). `variantes` con un solo gancho produce un solo vídeo |

Retrocompatible: los proyectos con 3 ganchos producen lo mismo que antes (`VARIANTE_A/B/C.mp4`, `QC_A.md`…); los que no tienen ganchos, también.

### Fórmula de los vídeos más vistos (guion y gancho)
Avión sin motores (303 mil), submarino (235 mil), rayo en un avión (46 mil): peligro en un medio de transporte tipo «¿Qué pasa si…?»; el espectador dentro de la situación en segunda persona («Vas en un avión…») con el peligro en los primeros 2 s; promesa de respuesta («y la explicación es sorprendente»); un solo objeto grande y en movimiento desde el fotograma 0; la pregunta escrita arriba durante los primeros segundos (única excepción a «sin título fijo», hasta ≈ 4 s). Detalle en `GUIA_ESTILOS.md` y reglas 121-125 del SUPERPROMPT.

**QC del gancho:** «Imagina…» ya no falla siempre: pasa si la primera frase (hasta `. ? ! … , :`) termina a ≤ 2,0 s («Imagina que vas en un avión y se apagan los motores.»). «En el año…», «Antes de…», «Hace mucho…» siguen fallando.

### Encuadre (el QC lo marca como FALLO)
`tools/zona_segura.js` mide cada 0,5 s el dibujo (bordes, sin las cajas de texto) dentro de la **franja de escena** = zona segura (x 0-940, y 220-1450) menos la franja de subtítulos (con `capY` 330: de ≈ 440 a 1450; con `capY` 1540: de 220 a 1450). Cada fila cuenta como mucho un 25 % del ancho, para que el canto de una mesa no pese como un objeto.

| Falla si durante más de 3 s seguidos… | Motivo en el QC |
|---|---|
| el dibujo ocupa < 60 % del ancho seguro | `estrecho` |
| su centro vertical está a más del 12 % de la franja de su centro | `arriba` / `abajo` |
| más del 32 % de la franja queda vacío por arriba o por abajo (percentiles 10/90) | `vacío arriba` / `vacío abajo` |

El cierre (`P.ctaShare`, maqueta fija) no cuenta: se marca solo con `safeLog('cierre')`. Fila del QC: «Encuadre (…; > 3 s = fallo)». `producir.py NOMBRE qc --encuadre-aviso` lo deja como aviso, solo para volver a pasar el QC de vídeos anteriores a la v1.34.

**Bloques nuevos para cumplirlo:**

| Bloque | Qué hace |
|---|---|
| `P.franjaEscena(capY = 330)` | `{ x0, y0, x1, y1, cx, cy, w, h }` de la franja de escena (subtítulos arriba → `capY + 110` a 1430; abajo → 240 a `capY − 110`) |
| `P.encuadrar(ctx, caja, dibujo, { capY, ancho = 0.8, alto = 0.86, franja })` | Dibuja `dibujo(ctx)` (en sus propias coordenadas, con su caja `[x0, y0, x1, y1]`) escalado y centrado en la franja: el grupo ocupa `ancho` × 940 px sin pasar de `alto` × alto de la franja. Devuelve `{ k, ox, oy, map(x, y) }` para colocar etiquetas en las mismas coordenadas |

Ejemplo: `P.encuadrar(ctx, [100, 600, 900, 1420], (c) => { mesa(c); telViejo(c, 240, 1110, 0.62, t); pila(c, 640, 1080, 380, 640, t); }, { capY: 330 });` — varios objetos pequeños se agrupan y se encuadran juntos, con su mesa (nada flota).

### Mano (v1.34)
- **`senalar` y `tocar`:** el pulgar va AL COSTADO de la mano (sale del borde de la palma, de lado y algo en sombra) y su punta queda tapada por el índice y el corazón doblado, como en una mano real; ya no cruza en diagonal por encima de los dedos.
- **`abierta`:** sin cambios.
- **`sujetar`:** rehecha vista desde la palma (el objeto entre el pulgar, delante, y los dedos, detrás, de los que solo asoman las puntas; muñeca en la misma dirección que la mano; `o.caja = [x0, y0, x1, y1]` del objeto). **NO se usa en los vídeos:** todavía no se ve natural. En las escenas con cargador se muestra solo el cargador y el cable, sin mano. Para «tocar» una pantalla o «señalar», las otras poses.
- Hoja: `catalogo/mano_v134.jpg`.

## v1.35 · Manos ilustradas (`P.manoImg`)

Las manos de los vídeos salen ahora de la **hoja de manos ilustradas** del canal (`manos/hoja_manos_original.png`, 21 poses), recortadas con fondo transparente. Sustituyen a `P.mano` (la mano dibujada por código queda solo por retrocompatibilidad).

`P.manoImg(ctx, nombre, x, y, alto, { ancla, ang, espejo, alpha, sombra })`

| Parámetro | Qué hace |
|---|---|
| `nombre` | `frente`, `abierta`, `paz`, `ok`, `pulgar_arriba`, `pulgar_abajo`, `puno`, `lado_izquierdo`, `lado_derecho`, `dorso`, `palma`, `apunta_derecha`, `apunta_izquierda`, `sujeta_celular`, `escribe`, `sostiene_taza`, `sostiene_tarjeta`, `palma_arriba`, `palma_abajo`, `pinza`, `garra` (catálogo: `catalogo/manos_v135.jpg`) |
| `alto` | alto del dibujo en px. Calidad buena hasta ≈ 800 px (el sprite está ampliado ×2 desde la hoja; si se necesita más grande, pedir la hoja en más resolución y volver a ejecutar la herramienta) |
| `ancla` | `'punta'` = punta del índice (por defecto en `frente`, `lado_izquierdo`, `lado_derecho`, `apunta_derecha`, `apunta_izquierda`; marcada en amarillo en el catálogo), `'base'` = centro de la muñeca (por defecto en las demás), `'centro'` |
| `ang` / `espejo` | giro alrededor del ancla / mano izquierda |
| `sombra` | sombra suave (por defecto sí; `false` la quita) |

- No hace falta incrustar nada: si `episodio.js` usa `P.manoImg`, `build.py` incrusta `motor/manos.js` (≈ 0,7 MB) antes del motor; los demás proyectos no cambian. Las imágenes se cargan en `K.fotos()` (o `await P.cargarManos()` en `init`).
- Cierre: `P.ctaShare(ctx, t, t0, t1, { …, manoImg: 'frente' })` (o cualquier pose que señale) dibuja la mano ilustrada tocando «Enviar».
- Para tocar una pantalla: `apunta_izquierda`/`apunta_derecha` o `frente`/`lado_*` con `ancla: 'punta'` en el punto tocado (+ la onda de `FX.toque`).
- Para sostener: usar las poses que ya traen su objeto (`sujeta_celular`, `sostiene_taza`, `sostiene_tarjeta`, `escribe`). Para un objeto distinto (p. ej. un cargador) no hay pose: se muestra el objeto solo, sin mano.
- **Celular de `sujeta_celular`:** es genérico y sin logo, pero su cámara recuerda a un modelo comercial; usarlo pequeño o de espaldas solo cuando importe que sea «un celular», no una marca.
- **Créditos:** en `CREDITOS_IMAGENES.md` de cada vídeo: «Manos: hoja de manos ilustradas aportada por el canal (uso propio)».
- **Regenerar:** `python3 -I PLANTILLA_ASOMBROTECA/tools/extraer_manos.py HOJA.png [--escala 2]` detecta la cuadrícula (7 × 3, fondo oscuro liso, rótulos debajo), recorta cada mano con alfa suave sin halo, quita astillas de las vecinas, amplía con Lanczos y escribe `manos/*.png` y `motor/manos.js` (WebP en base64, con la «punta» de las poses que señalan). Con otra hoja u otro orden: `--nombres a,b,c,…`.

## v1.36 · La pregunta escrita arriba (`P.pregunta`)

`P.pregunta(ctx, '¿CERRAR APPS / AHORRA BATERÍA?', t, 0, 4.8, { capY: 330, px: 70, clave: 'BATERÍA?' })`

- Para la regla 122: la pregunta del vídeo, escrita arriba durante los primeros segundos (que desaparezca antes de 5 s).
- Opciones: `x` (centro; 470 = zona segura, 540 = centro de la pantalla) y `dy` (px extra de separación del subtítulo). El QC de encuadre descuenta la pregunta de la franja de escena mientras está.
- « / » separa las dos líneas; `clave` = palabra en amarillo; se reduce sola si no cabe en 880 px.
- Posición: con los subtítulos arriba (`capY` < 960) va justo debajo de ellos (y ≈ capY + 100); con los subtítulos abajo, en y = 250.
- Devuelve el y inferior: la escena del gancho empieza debajo (con `P.encuadrar(…, { franja: { …, y0: ese y + 20 } })` si hace falta).
- QC: se registra como 'pregunta' (zona segura y encimados); no cuenta como título fijo.

**v1.36b · `P.pregunta` va FIJA:** se dibuja en la capa de los subtítulos, fuera de la cámara: no hace zoom ni se desliza con las transiciones. `x` por defecto 540 (centro de la pantalla). Con `t0` ≤ 0,05 se ve entera desde el fotograma 0. Pon `t1` antes del siguiente subtítulo (p. ej. `S(2) - 0.15`) y usa `dy` (≈ 100) para separarla del subtítulo.

## v1.37 · Formato de serie «¿QUÉ PASA SI…?» (`series/serie_que_pasa_si/`)
- `nuevo_proyecto.py NOMBRE --serie serie_que_pasa_si --capitulo N --estilo noche --voz AUDIO`.
- Reglas fijas (ver `LEEME.md` de la serie): el espectador dentro de la situación, en segunda persona, con el peligro en < 2 s;
  un solo objeto grande (≥ 60 % del ancho) y en movimiento desde el fotograma 0; `P.pregunta` fija y centrada; promesa de
  respuesta tras el gancho; remate «QUÉ HACER» con 2-3 consejos; «Envíaselo a ese amigo que…».
- `P.queHacer(ctx, t, t0, [{ t, txt }, …], { x = 540, y = 470, w = 800, t1, titulo = 'QUÉ HACER', px = 54 })` + `FX.queHacer(k, t0, consejos)`.
- Portada: `producir.py P portada "¿QUÉ PASA SI… / …?" "ROJA" SEGUNDO` (la etiqueta sale de `SERIE.json`); fondo = escena real.

## v1.38 · Borde oscuro en los subtítulos (`capBorde`)
- `PL.make({ …, capBorde: true })` (o un número: grosor relativo al tamaño de letra; `true` = 0,16). Contorno `rgba(8,10,16,0.92)` bajo cada palabra.
- Úsalo cuando haya fondos claros o destellos a pantalla completa (fogonazo de un rayo, nieve, cielo blanco). `P.pregunta` ya lleva su borde.

## v1.39 · Quitar un tramo de la voz sin regenerarla (`[QUITAR]`)
- En `03_GUION/tramos.txt`, antepón `[QUITAR] ` a la línea del tramo que no debe ir al vídeo (p. ej. para bajar de 65 s). Se alinea igual y el montaje lo salta; los demás tramos quedan intactos.
- Si una frase son varios tramos (p. ej. «Y tercero,» y la frase siguiente), marca todos. Después: `producir.py NOMBRE alinear` y revisa los índices de `wt(tramo, …)` en `episodio.js` (los tramos quitados no cuentan).

## v1.40 · Marca de la portada a una altura fija

- `python3 PLANTILLA_ASOMBROTECA/tools/producir.py PROYECTO portada "L1 / L2" "ROJA" "ETIQUETA" SEGUNDO --marca-y 1850`
- Pone la marca en y = 1850 en lugar de la posición de la maqueta (y ≈ 1630). Úsalo cuando el dibujo baja hasta casi el borde inferior y la marca va en una franja corta debajo (pinta esa franja en la rama `PORTADA` del episodio).
- Con `--marca-y`, el aviso del recorte 3:4 solo comprueba el texto: la marca queda fuera de la cuadrícula de Instagram a propósito.
- Sin la opción, la portada es idéntica a la de la v1.30.

## v1.41 · `[PAUSA]` después de un `[QUITAR]`

- En `03_GUION/tramos.txt` se puede escribir un tramo `[QUITAR] …` y, en la línea siguiente, `[PAUSA 0.6]`: la pausa queda entre el último tramo dicho antes del quitado y el siguiente tramo que se dice.
- Ejemplo (moto): `[QUITAR] Ahora, el dato.` + `[PAUSA 0.6]` antes de «A unas seis mil vueltas por minuto…».
- Sin esa combinación, `alinear.py` funciona igual que en la v1.40.

## v1.42 · Sonido de las etiquetas

- `PL.make({ …, etiquetas: 'suave' })`: `FX.etiqueta` suena a −10 dB (y el «ding» de `FX.revelar` también). `etiquetas: 'silencio'`: `FX.etiqueta` no suena. Sin la opción (episodios viejos), el sonido es el de siempre.
- `FX.clave(k, t)`: el «tin» de siempre (pop de 700 Hz + tic). Úsalo solo en 3-4 momentos clave por vídeo (la revelación, los números o pasos importantes).
- Los golpes (`thud`, `FX.golpeSordo`, destellos) no cambian.

## v1.43 · Personajes nuevos y mano vectorial (predeterminados)

- `P.personaje(ctx, t, x, y, alto, o)` — x, y = pies en el suelo; alto = altura total en px. Devuelve `{ manoD, manoI, cabeza, k }` en px.
  - `o.tipo`: `'adulto'` | `'adulta'` | `'nino'` | `'abuela'` | `'abuelo'` | `'conductor'`
  - `o.expr`: `'normal'` | `'sorpresa'` | `'susto'` | `'alegria'` | `'desesperacion'`
  - `o.pose`: `'pie'` | `'senala'` | `'celular'` | `'cabeza'` | `'saluda'` (o `manoD`/`manoI` a mano no; las poses ya colocan los brazos con codo)
  - `o.ropa`, `o.ropa2` (pantalón o falda), `o.piel`, `o.pelo`, `o.mira` (−1..1), `o.seed`, `o.espejo`, `o.lentes`, `o.corbata`, `o.casco`, `o.pantalla` (color de la pantalla del celular), `o.objeto(ctx, x, y, ang, k)` (dibujo extra; en la pose `celular` se dibuja sobre la pantalla), `o.dedos` (true/false fuerza manos con dedos o simples; por defecto, con dedos cuando la mano mide más de ≈ 9 px de radio).
- `P.manoV(ctx, pose, x, y, alto, o)` — mano vectorial grande. Poses: `frente`, `lado_derecho`, `apunta_derecha`, `apunta_izquierda`, `abierta`, `puno`, `pulgar_arriba`, `pinza`, `sujeta_celular`, `sostiene_tarjeta`, `palma_arriba`, `toca`, `relajada`. `o.ancla`: `'punta'` (punta del índice; por defecto), `'base'` (muñeca) o `'centro'`; `o.ang`, `o.espejo`, `o.piel`, `o.sombra` (false sin sombra), `o.objeto: { col, pantalla, dibujo(ctx, x, y, w, h) }` para el celular o la tarjeta.
- Catálogo con todas las variantes, expresiones, poses y manos: `catalogo/personajes_v143.jpg`.

## v2.0 · MODO VIRAL

`PL.make({ modo: 'viral', capOcultar: [[0, fin_del_gancho]], … })` — manda sobre todo lo anterior en los vídeos nuevos (reglas 128–157 del SUPERPROMPT y bloque v2.0 de `GUIA_ESTILOS.md`). Los episodios viejos no cambian.

**Lo que hace el modo viral en el motor:** sin música (`musica: 'baja'` la deja a −10 dB) ni ambiente (`ambiente: true` lo devuelve); `FX.etiqueta` y `FX.pausa` mudos (un sonido solo cuando pasa algo importante); `capOcultar` quita los subtítulos en los tramos indicados.

**Cámara continua (un solo mundo, máximo 3 cortes):**
- `P.camino(t, [[t, x, y, zoom, giro], …])` → `[x, y, zoom, giro]` con interpolación suave (zoom logarítmico). `P.aplicaCamara(ctx, cam, [sx, sy])` lo aplica (centro 540, 960).
- `P.atravesar(ctx, t, t0, t1, fuera(ctx), dentro(ctx, u), { centro: [x, y], zoom })`: la cámara entra en un objeto (zoom + círculo que se abre). `P.salir(…)` es lo mismo al revés.

**Luz y profundidad:** `P.capaDesenfoque(ctx, px, dibujo, { bruma, col })`, `P.resplandor(ctx, x, y, r, 'r,g,b', a)`, `P.reflejo(ctx, forma, t, { ancho, a, vel, ang })`, `P.vineta(ctx, a, 'r,g,b')`, `P.grano(ctx, t, a)`, `P.particulas(ctx, t, { tipo: 'polvo' | 'chispas' | 'burbujas' | 'lluvia', n, area, a, tam, col, seed })`.

**Textos de datos:**
- `P.contador(ctx, t, x, y, valor, { t0, px, final, colFinal, unidad, etiqueta, a })` — el número sube EN SILENCIO; suena un golpe solo al llegar a `final`.
- `P.titular(ctx, 'TEXTO', x, y, t, t0, t1, { px, clave, col })` — titular grande con UNA palabra de color (en vez de etiquetas pequeñas).
- `P.tachado(ctx, 'texto', x, y, t, t0, t1, { px, col, retraso })` — para el «No es X: es Y».
- `P.fuenteCifra(ctx, 'Fuente…', x, y, { px = 36, franja = true })` — letra pequeña con franja oscura detrás.

**Manos y dedo:**
- `P.dedoPP(ctx, x, y, ancho, { vista: 'dorso' | 'yema', piel, ang, largo, luz })` → `{ punta, una }` (la uña sirve de apoyo para una tarjeta).
- `P.manoR(ctx, pose, x, y, alto, o)` — una sola silueta. Poses: senala, toca, boton, celular, celular_pulgar (teléfono AGARRADO), pinza (de lado, con tarjeta / moneda / grano), palma, alto, saludo, puno (pulgar por delante), pulgar (dedos curvos), ok, agarrar (manubrio, taza, cuchara), perilla, llave, golpecito, espolvorear, contar1–5, relajada (con `giro: { roll: 180 }` = manos en el teclado). `o`: vista, lado, piel, guante, ancla, ang, giro, t, objeto, pantalla, dibujoPantalla, capa. Catálogo: `catalogo/manos_v20_2x.jpg`.

**QC (`producir.py … qc`, avisos que no hacen fallar):** cambios bruscos (escena > 0,4) > 3; protagonista del fotograma 0 < 70 % del ancho; piso de sonido entre frases que nunca baja de −45 dB; más de 5 efectos de sonido por cada 10 s (v2.3; inicios en `05_AUDIO/efectos_sonido.wav`; un sonido continuo cuenta una vez); más de 4 `FX.clave`. En modo viral el cierre «Envíaselo» ya no es obligatorio.

**Ejemplo completo:** `DISQUETE_MEMORIA_PROYECTO/04_CODIGO/js/episodio.js` (avalancha → uña → disquete por dentro → tarjeta por dentro → montaña y torre → vuelta al fotograma 0).

## v2.0.1 · Acortar una pausa de la grabación (`tools/acortar_pausa.py`)

Cuando la voz trae un silencio demasiado largo entre dos frases y no se puede regenerar: desde `04_CODIGO`, `python3 -I ../../PLANTILLA_ASOMBROTECA/tools/acortar_pausa.py alineacion_C.json 18 0.6` deja 0,6 s de silencio después del tramo 18 (índices desde 0). Solo corta silencio (si encuentra sonido por encima de −30 dBFS no cambia nada), los tramos de voz quedan idénticos y el QC lo comprueba por md5. Luego `python3 -I $T/subtitulos.py alineacion_C.json ../06_SUBTITULOS/subtitulos_C.srt js/datos_C.js` y `build.py` (rearma la voz). Si se vuelve a ejecutar `alinear.py`, hay que repetir el recorte. No sirve para pausas de posproducción (`[PAUSA x]`): esas se cambian en `tramos.txt`.

## v2.1 · Recuadro azul fino en los subtítulos (`recuadro`)

En modo viral, `PL.make` pone un recuadro azul fino alrededor de UNA palabra clave más o menos cada 2-3 frases. Por defecto la elige sola (`recuadro: true`); para elegirlas a mano: `recuadro: [['sombra', S(4), S(5)], ['luz', S(10), S(11)], …]` (palabra y ventana de tiempo) o `recuadro: ['sombra', 'luz']` (la primera vez que se dicen). `recuadro: false` lo quita. Durante `capOcultar` no hay subtítulos y, por tanto, tampoco recuadro. Ejemplo: `RELOJES_ANTIGUOS_PROYECTO/04_CODIGO/js/episodio.js`.

## v2.2 · Biblioteca de estilos (`estilos/`)

`PL.make({ modo: 'viral', estilo: 'engineering_blueprint', … })`. El estilo es una PIEL: no dibuja el tema, le da su medio.

- **Dibujar el tema con la piel:** `const pl = PL.piel();` y luego `pl.fondo(ctx, t, o)`, `pl.forma(ctx, figura, { rol, t, p })`, `pl.linea(ctx, puntos, { rol, ancho, p, punteada, flecha, t })`, `pl.brillo(ctx, x, y, r, { t })`. Figuras: `{ tipo: 'elipse', x, y, rx, ry, rot }`, `{ tipo: 'circulo', x, y, r }`, `{ tipo: 'rect', x, y, w, h, r }`, `{ tipo: 'poli', pts: [[x, y], …] }`. Roles: `fondo`, `fondo2`, `objeto`, `objeto2`, `detalle`, `sombra`, `acento`, `rojo`. Se puede seguir dibujando a mano con canvas y mezclar (p. ej. el mundo real con luz y profundidad, y las explicaciones con la piel).
- **Lo que hace solo el motor:** la pasada de acabado del estilo (bloom, píxeles, fósforo, papel, grano…), los textos grandes después del acabado con su tipografía y la palabra clave en rojo, y los subtítulos con su franja.
- **Transición del medio:** en un beat, `in: { type: 'piel', d: 0.6 }` (pasar hoja, mosaico, rodado del tubo, mano de crema…); su sonido sale de `pl.sonidos.transicion`.
- **Sonidos del medio:** `pl.sonidos.aparece(k, t)`, `trazo(k, t, d)`, `transicion(k, t, d)`, `golpe(k, t)` (un evento cada uno).
- **Reglas 2.2:** con estilo (o `reglas: '2.2'` sin estilo) `P.contador` muestra el valor final desde que aparece, con un golpe de entrada; `reglas: '2.0'` lo desactiva.
- **QC:** `producir.py … qc` añade los avisos v2.2 (contadores, un texto grande a la vez, plano quieto 4 s).
- **Muestra:** `python3 -I PLANTILLA_ASOMBROTECA/tools/muestra_estilos.py ESTILOS_PRUEBA_PROYECTO 14.3` → `07_QC/muestra_estilos.jpg`.
- **Estilo nuevo:** copiar uno de `estilos/`, registrarlo con `PL.estilosComun.registrar('nombre', { paleta, textos, fondo, forma, linea, brillo, acabado, transicion, sonidos })` y añadirlo a la tabla de GUIA_ESTILOS.

## v2.4 · Modo «historia» (Facebook)

`PL.make({ modo: 'historia', estilo: 'engineering_blueprint', … })`. El modo viral sigue igual (TikTok e Instagram).

- **Motor:** el mismo comportamiento que el viral (estilos v2.2, sonido v2.3, etiquetas mudas, sin música, recuadro azul) con `pausaMin: 0,3` por defecto para que las respiraciones de 0,3-0,5 s también frenen la cámara. `PL.modo()` devuelve el modo activo.
- **Guion (85-100 s):** 0-3 s el peligro · 3-12 s lo que está en juego con una cifra · 12-20 s promesa abierta · 20-75 s el mecanismo en 3-4 pasos, cada uno con frase de tensión («pero aquí viene el problema…», «y entonces pasa algo que casi nadie sabe…») y un giro cada ~15 s · 75-90 s desenlace que resuelve la promesa · 90-100 s pregunta concreta para comentar + «sigue a Asombroteca» (sin repetir el fotograma 0).
- **Revisar el guion antes de la voz:** `python3 -I PLANTILLA_ASOMBROTECA/tools/guion_historia.py <PROYECTO>/03_GUION/guion.txt [car_por_s]` (por defecto 16 car./s, la velocidad medida de Dan; las líneas `[PAUSA x]` cuentan). Con Dan, 85-100 s son ~1.350-1.600 caracteres.
- **Ritmo:** 6-8 escenas de 4-8 s, todas con movimiento; nunca el mismo plano más de 6 s; pausas de 0,3-0,5 s antes de cada giro y de la revelación final (`[PAUSA 0.4]` en `tramos.txt`), con el fondo ambiental bajando a silencio.
- **QC (`producir.py … qc`):** detecta `modo: 'historia'`; duración 85-100 s (aviso < 75 / > 110 s), cierre obligatorio (pregunta + «sigue a Asombroteca»), avisos de estructura, cambios bruscos máx. 8, plano casi igual a los 6 s y que el último plano no repita el fotograma 0.
- **Se mantienen** las reglas de siempre: un solo texto grande a la vez, contadores con el valor final y quietos ~1,5 s, cifras redondeadas con la fuente exacta en letra pequeña, recuadro azul en la palabra clave de los subtítulos.
- **Validador antes del render:** `producir.py <P> video` (o `render`) lo ejecuta solo en modo historia sobre `03_GUION/guion.txt` (o `tramos.txt`); solo avisa.
- **Ficha de la hoja (todos los modos):** `sheet.py hoja.jpg 6 <pngs> --ficha <modo> <duración>` o `tools/ficha_hoja.py hoja.jpg <modo> <duración>`: modo, duración final y casilla «Resultado FB 24 h» (tiempo promedio > 20 s; reproducciones de 3 s / visualizaciones > 50 %). `producir.py` la pone sola en la hoja de contacto y en la de prueba, y la casilla también va en `07_QC/QC.md`.

## v2.5 · Referencia rápida de `PL.make({ … })`

| Opción | Valores | Por defecto | Para qué |
|---|---|---|---|
| `align`, `duration`, `beats` | datos del proyecto | — | alineación (`window.ALIGN`), duración (`K.DURATION`) y escenas `{ t0, t1, in, draw, sfx }` |
| `modo` | `'viral'` · `'historia'` · (nada) | clásico | viral = TikTok/Instagram (40-90 s); historia = Facebook (85-100 s); sin modo = episodios anteriores |
| `estilo` | uno de los 15 de `estilos/` (o un estilo clásico v1.26) | — | la piel v2.2 (solo con `modo`) |
| `reglas` | `'2.2'` · `'2.0'` | `'2.2'` con estilo | contadores con el valor final desde que aparecen |
| `recuadro` | `true` · `false` · `['palabra', …]` · `[['palabra', t0, t1], …]` | `true` en viral/historia | recuadro azul fino en una palabra clave de los subtítulos |
| `capOcultar` | `[[t0, t1], …]` | `[]` | sin subtítulos (gancho con un solo texto, cierre) |
| `capStyle`, `capY`, `capPx`, `capFam`, `capColor`, `capCaja`, `capSel`, `capBorde`, `capMaxKW` | — | según modo/estilo | aspecto de los subtítulos (con estilo: `ios`, y 330, letra del estilo) |
| `marca` | `{ nombre: 'ASOMBROTECA' }` | — | la marca discreta del final (`P.marca`) |
| `etiquetas` | `'clasico'` · `'suave'` · `'silencio'` | `'silencio'` en viral/historia | sonido de las etiquetas |
| `musica` | `'baja'` | sin música en viral/historia | −10 dB si se pide |
| `ambience` + `ambiente: true` | función de sonido | apagado en viral/historia | ambiente continuo (mejor: fondos por escena en `sfx`, regla 162) |
| `pausas`, `pausaMin`, `pausaMax` | — | `true`, 0,4 (0,3 en historia), 1,6 | la cámara frena en las pausas de la voz |
| `zonaSegura` | `true` | `true` con estilo | registra los textos para el QC de zona segura |

**Trucos aprendidos (v2.5):**
- `wt(seg, 'palabra', n)` cuando la palabra se repite en el tramo (la consola avisa).
- Contadores sólidos en la palabra: que entren 0,3 s antes (`t0: wt(…) - 0,3`) y duren ≥ 1,5 s; dos contadores seguidos no deben pisarse (el QC avisa).
- Manos al volante: `P.manoR(ctx, 'puno', …)` sobre el aro (la pose `agarrar` sale con la palma abierta).
- Fondos de sonido: ≈ 30-40 dB bajo la voz; tonos ≥ 98 Hz y ruido filtrado en bandas medias (el ruido grave «late» y el QC lo cuenta como golpes).
- Para probar un tramo: `python3 -I PLANTILLA_ASOMBROTECA/tools/clip.py <PROYECTO> t0 t1`.
