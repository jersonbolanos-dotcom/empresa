// Catálogo visual de bloques de la plantilla, en las dos pieles (piezas estáticas en t = 5 s)
(function () {
 const PL = window.PLANTILLA, P = PL.P, TAU = Math.PI * 2;
 const items = [
  ['Píldora / etiqueta', (c, t) => P.pill(c, 'CIENTOS DE METROS', 200, 150, 30, t, 0)],
  ['Contador con caja', (c, t) => P.counter(c, 200, 150, 90, t, 0, 1, 0, 1963, { box: PL.SKINS[c.__sk].c.accent, c: '#1d1b3a' })],
  ['Bocadillo + ✗', (c, t) => P.bubble(c, 200, 130, 200, 160, t, 0, (x, y) => P.cross(c, x, y, 110, 1), { tailX: 0 })],
  ['Onomatopeya', (c, t) => P.onoma(c, '¡GLUB!', 200, 150, 90, t, 4.7, 9, { shake: false })],
  ['Flecha que se dibuja', (c, t) => P.arrow(c, 60, 200, 340, 100, 1, PL.SKINS[c.__sk].c.blue, 26)],
  ['Lupa', (c, t) => P.lens(c, 200, 150, 95, 1, () => { c.fillStyle = '#3fa9f5'; c.fillRect(0, 0, 400, 300); c.fillStyle = '#ffffff'; c.beginPath(); c.arc(200, 150, 40, 0, TAU); c.fill(); })],
  ['Manómetro (sin cifras)', (c, t) => P.gauge(c, 200, 160, 100, 0.8, '')],
  ['Dominó (cadena de causas)', (c, t) => { [0, 1, 2].forEach((i) => { c.save(); c.translate(90 + i * 110 + 40, 260); c.rotate(i < 2 ? 0.35 : 0); P.rr(c, -80, -200, 80, 200, 14, ['#3fa9f5', '#ff9f43', '#e8505b'][i], { sy: 8 }); c.restore(); }); }],
  ['✓ correcto · escudo solución', (c, t) => { P.check(c, 120, 150, 110, 1); P.shield(c, 280, 150, 80, '#2fbf71', 1); }],
  ['Personas (respeto)', (c, t) => { for (let i = 0; i < 24; i++) P.person(c, 70 + (i % 8) * 38, 90 + Math.floor(i / 8) * 60, 34, '#cfe6ff'); }],
  ['Botón «Seguir» + dedo', (c, t) => { P.rr(c, 90, 110, 220, 80, 40, PL.SKINS[c.__sk].c.accent, { sy: 8 }); P.text(c, 'SEGUIR', 200, 152, 38, '#1d1b3a'); P.finger(c, 250, 170, 90, 1); }],
  ['Burbujas / partículas', (c, t) => P.bubbles(c, 40, 20, 320, 260, t, 4, 16, 1)],
  ['Onda electromagnética (v1.2)', (c, t) => P.wave(c, [[30, 150], [370, 150]], t, { amp: 40, lam: 140 })],
  ['Molécula de agua (v1.2)', (c, t) => { P.water(c, 130, 150, 60, -1.2); P.water(c, 280, 150, 60, 0.6, { hot: 1 }); }],
  ['Rampa térmica (v1.2)', (c, t) => { for (let i = 0; i < 300; i++) { c.fillStyle = H.rgba(P.heat(i / 299)); c.fillRect(50 + i, 120, 1, 60); } P.text(c, 'FRÍO → CALIENTE', 200, 220, 26, '#ffffff'); }],
  ['Fluido en tubo: fase ≠ temperatura (v1.4)', (c, t) => { const pa = P.path([[30, 100], [370, 100]]), pb = P.path([[30, 200], [370, 200]]); c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(20, 84, 360, 32); c.fillRect(20, 184, 360, 32); P.fluid(c, pa, t, { w: 26, phase: (u) => u, temp: () => 0.12, seed: 2 }); P.fluid(c, pb, t, { w: 26, phase: (u) => 1 - u, temp: () => 0.85, seed: 3 }); }],
  ['Trazadores de aire (v1.4)', (c, t) => { P.airStreaks(c, P.path([[20, 150], [200, 120], [380, 150]]), t, { n: 14, temp: 0.12, spread: 120, seed: 4 }); }],
  ['Ventilador axial (v1.4)', (c, t) => P.fanAxial(c, 200, 150, 120, t * 3)],
  ['Ventilador de flujo cruzado (v1.4)', (c, t) => P.fanCross(c, 50, 120, 300, 60, t * 4)],
  ['Celular con pantalla (v1.5)', (c, t) => P.phone(c, 200, 150, 120, (x, y, w, h) => { P.mapCity(c, x, y, w, h, 3, { block: 30, street: 7 }); P.dot(c, x + w / 2, y + h / 2, 8, t); })],
  ['Globo terrestre (v1.5)', (c, t) => P.globe(c, 200, 150, 110, t * 0.3)],
  ['Satélite + ondas de radio (v1.5)', (c, t) => { P.satellite(c, 200, 110, 60, 0.2); P.rings(c, 200, 140, t, { r: 120, dir: Math.PI / 2, spread: 0.6 }); }],
  ['Reloj analógico (v1.5)', (c, t) => P.clock(c, 200, 150, 100, 43200 + t * 60)],
  ['Mapa, pin y rango (v1.5)', (c, t) => { P.mapCity(c, 0, 0, 400, 300, 5, { block: 60, street: 12 }); P.rangeCircle(c, 170, 150, 90, 1, '#2f80ed'); P.pin(c, 170, 150, 60); }],
  ['Brillo / luz (v1.2)', (c, t) => { P.glow(c, 140, 150, 120, '255,190,120', 0.9); P.glow(c, 270, 150, 90, '80,220,255', 0.9); }],
  ['Mar de perfil + fondo marino (v1.6)', (c, t) => { P.ocean(c, t, 0.5, { w: 400, h: 300, snow: 30 }); P.waves(c, 40, t, { w: 400, amp: 5, sky: '#2b5c8f' }); P.seabed(c, 240, t, { w: 400, bottom: 300, rocks: 3 }); }],
  ['Barco cablero (v1.6)', (c, t) => { P.ocean(c, t, 0.3, { y: 170, w: 400, h: 130, snow: 0, rays: 0 }); P.waves(c, 170, t, { w: 400, amp: 4 }); const [sx, sy] = P.ship(c, 180, 172, 120, t); P.strokePath(c, P.spline([[sx, sy], [sx + 20, sy + 60], [380, 290]]), 5, '#1a2129'); }],
  ['Corte del cable submarino (v1.6)', (c, t) => { P.cableSection(c, 120, 150, 110, { p: 1 }); P.cableSection(c, 300, 150, 90, { p: 1, armor: true }); }],
  ['Fibra óptica con pulsos (v1.6)', (c, t) => P.fiber(c, 0, 400, 150, 120, t, { gap: 40, speed: 200, att: 0.8, boost: [200] })],
  ['Repetidor · ROV · arado (v1.6)', (c, t) => { P.repeater(c, 90, 90, 50, 0, 1); P.rov(c, 300, 110, 90, t, { light: true }); P.plow(c, 200, 260, 90, t); }],
  ['Mapa del mundo estilizado + ruta (v1.6)', (c, t) => { const pr = P.worldMap(c, 0, 40, 400, 220, { lon0: -130, lon1: 165, lat0: -50, lat1: 72 }); P.cableRoute(c, [[-76, 36.8], [-40, 40], [-3, 43]].map(pr), 1, t, { w: 3 }); }],
  ['Ancla · garfio · estación costera (v1.6)', (c, t) => { P.anchor(c, 90, 150, 90, 0.2); P.grapnel(c, 200, 160, 70); P.station(c, 320, 200, 100, { on: true }); }],
  ['Regla de profundidad (v1.6)', (c, t) => P.depthGauge(c, 120, 40, 270, 3000, 4000, { step: 1000 })],
  ['Agua + hormigón (v1.7)', (c, t) => { P.waterBody(c, [[0, 80], [200, 80], [200, 300], [0, 300]], t, { surf: [0, 200, 82] }); P.concrete(c, [[200, 50], [250, 50], [380, 300], [200, 300]], { joints: 30 }); }],
  ['Tubería forzada + compuerta (v1.7)', (c, t) => { P.pipe(c, [[40, 80], [200, 80], [360, 240]], 40, t, { fill: 0.8 }); P.gate(c, 30, 60, 16, 40, 0.6); }],
  ['Turbina Francis (v1.7)', (c, t) => P.francis(c, 160, 160, 80, t * 2, { flow: 1, t })],
  ['Rueda de molino (v1.7)', (c, t) => P.waterwheel(c, 200, 150, 110, t)],
  ['Generador en corte (v1.7)', (c, t) => P.genSection(c, 200, 150, 125, t * 0.8, { field: 1, current: 1, t })],
  ['Transformador + onda alterna (v1.7)', (c, t) => { P.transformer(c, 200, 120, 90, { n1: 4, n2: 12, flux: 1, t, bg: c.__sk === 'plana' ? '#2b2f5e' : '#0b0c10' }); P.sine(c, 40, 260, 320, 50, t, { phases: 3, lw: 3 }); }],
  ['Torres y líneas (v1.7)', (c, t) => { const a = P.pylon(c, 100, 280, 200), b = P.pylon(c, 320, 280, 200); for (let k = 0; k < 3; k++) P.powerLine(c, a[k], b[k], 30, t, { dots: 2 }); }],
  ['Ciudad · fábrica · casa (v1.7)', (c, t) => { P.skyline(c, 20, 220, 270, 0.8, 4, { maxH: 200 }); P.factory(c, 290, 270, 90, 1); P.house(c, 360, 270, 50, 1); }],
  ['Bombilla · interruptor (v1.7)', (c, t) => { P.bulb(c, 140, 140, 60, 1); P.switchWall(c, 300, 160, 90, true); }],
  ['Sol · nube con lluvia · pez (v1.7)', (c, t) => { P.sun(c, 90, 90, 40, t); P.cloud(c, 260, 110, 70, { rain: true, t }); P.fish(c, 200, 260, 60, 1); }],
  ['Desierto + pirámide en construcción (v1.8)', (c, t) => { c.save(); c.scale(400 / 1080, 300 / 1920 * 2.4); P.desert(c, 600, t, { sunX: 850, sunY: 260 }); c.restore(); P.pyramid(c, 200, 250, 300, 190, { built: 0.7, courses: 14 }); }],
  ['Pirámide con revestimiento (v1.8)', (c, t) => P.pyramid(c, 200, 260, 320, 220, { courses: 14, casing: 1 })],
  ['Bloque de piedra (v1.8)', (c, t) => { P.block(c, 80, 120, 150, 100, {}); P.block(c, 260, 140, 90, 80, { c: '#8a7f86' }); }],
  ['Trineo + trabajadores + cuerda (v1.8)', (c, t) => { const a = P.sled(c, 90, 230, 140, {}); const hs = [0, 1, 2].map((i) => P.worker(c, 230 + i * 50, 240, 90, t * 0.5 + i * 0.2, { pose: 'pull' })); P.rope(c, [a, ...hs], 3); }],
  ['Rampas: recta y zigzag (v1.8)', (c, t) => { const a = P.pyramid(c, 130, 260, 200, 150, { built: 0.8, courses: 8 }); P.ramp(c, a, 'zigzag', 1, { top: 0.8, w: 5 }); const b = P.pyramid(c, 320, 260, 140, 110, { built: 0.8, courses: 6 }); P.ramp(c, b, 'recta', 1, { top: 0.8, len: 60 }); }],
  ['Papiro · herramientas (v1.8)', (c, t) => { P.papyrus(c, 30, 40, 170, 110, {}); P.tool(c, 'cincel', 250, 100, 90, -0.4); P.tool(c, 'sierra', 330, 100, 90, 0.3); P.tool(c, 'codo', 110, 230, 150, 0); P.tool(c, 'plomada', 280, 230, 80, 0); }],
  ['Palmera · signos de pregunta (v1.8)', (c, t) => { P.palm(c, 120, 280, 230, t); P.qmark(c, 280, 130, 90, t); P.qmark(c, 340, 220, 60, t + 1); }],
  ['Mar de perfil + portacontenedores (v1.9)', (c, t) => { c.save(); c.translate(0, -60); P.seaProfile(c, 230, t, { x0: 0, x1: 400, bottom: 400, sun: [330, 120], snow: 10 }); P.cargoShip(c, 200, 230, 340, 28, t, { H: 40, rows: 3 }); P.underwater(c, 230, t, { x0: 0, x1: 400, bottom: 400 }); c.restore(); }],
  ['Portacontenedores en corte + inundación (v1.9)', (c, t) => { c.fillStyle = '#063A5B'; c.fillRect(0, 180, 400, 120); P.cargoShip(c, 200, 180, 360, 50, t, { H: 80, rows: 2, cut: 1, comps: 6, flood: [0, 0, 0, 0.7, 0, 0] }); }],
  ['Sección del casco + volumen desplazado (v1.9)', (c, t) => { c.fillStyle = '#063A5B'; c.fillRect(0, 170, 400, 130); P.hullSection(c, 200, 170, 220, 160, 80, t, { disp: 1, cargo: 2 }); }],
  ['Flechas de fuerza + presión (v1.9)', (c, t) => { P.forceArrow(c, 140, 260, 180, 1, '#37E6C0', 'EMPUJE', { w: 18, px: 22 }); P.forceArrow(c, 280, 60, 180, -1, '#FF7D65', 'PESO', { w: 18, px: 22 }); }],
  ['Grúa de muelle + contenedor (v1.9)', (c, t) => { const s = P.gantryCrane(c, 90, 290, 220, 0.6, 120); P.container(c, s[0] - 25, s[1], 50, 22, '#B7473C'); }],
  ['Salpicadura (v1.9)', (c, t) => { c.fillStyle = '#1378A8'; c.fillRect(0, 200, 400, 100); P.splash(c, 200, 200, 0.35, 0, { s: 70 }); }],
  ['Vaso con rebosadero · Arquímedes · columna (v1.9)', (c, t) => { P.column(c, 50, 290, 200, 30); P.greek(c, 130, 290, 160, { point: 1 }); P.beaker(c, 210, 150, 110, 130, 0.7, t, { spout: true, overflow: 1 }); }],
  ['Espacio + estrellas + galaxia (v1.10)', (c, t) => { c.fillStyle = '#02040D'; c.fillRect(0, 0, 400, 300); P.galaxy(c, 200, 150, 140, { seed: 31, tilt: 0.36, rot: -0.5, core: '255,206,140', arm: '170,190,255' }); }],
  ['Nave interestelar con propulsión (v1.10)', (c, t) => { c.fillStyle = '#02040D'; c.fillRect(0, 0, 400, 300); P.spaceship(c, 230, 150, 150, 0, t, { thrust: 1 }); }],
  ['Reloj de misión (v1.10)', (c, t) => { c.save(); c.translate(200, 150); c.scale(0.8, 0.8); c.translate(-200, -150); P.missionClock(c, 200, 150, 'RELOJ DE LA NAVE', '28,6 años', '#46E6D2', { w: 420, px: 50, sub: 'tiempo propio', prog: 1 }); c.restore(); }],
  ['Velocímetro relativista (v1.10)', (c, t) => P.speedGauge(c, 200, 160, 110, 3e-13, {})],
  ['Diagrama de espacio-tiempo (v1.10)', (c, t) => P.spacetime(c, 50, 30, 300, 230, [{ pts: [[0, 0], [0, 0.95]], c: '#FFB45B', label: 'Tierra' }, { pts: [[0, 0], [0.2, 0.3], [0.7, 0.75], [0.85, 0.95]], c: '#46E6D2', ticks: [[0.2, 0.3], [0.7, 0.75]], label: 'nave' }])],
  ['Cabina con ventana · científico (v1.10)', (c, t) => { c.save(); c.scale(400 / 1080, 300 / 1920 * 1.6); P.cockpit(c, t, (x, y, w, h) => { c.fillStyle = '#081B42'; c.fillRect(x, y, w, h); }); c.restore(); P.scientist(c, 330, 290, 140, { c: '#cfe6ff' }); }],
 ];
 window.drawCatalog = function () {
  document.querySelectorAll('canvas[data-i]').forEach((cv) => {
   const sk = cv.dataset.sk, c = cv.getContext('2d'); c.__sk = sk; PL.setSkin(sk);
   const S = PL.SKINS[sk]; c.fillStyle = sk === 'plana' ? '#2b2f5e' : '#0b0c10'; c.fillRect(0, 0, 400, 300);
   items[+cv.dataset.i][1](c, 5);
   if (sk === 'oscura') H.grain(c, 400, 300, 0.05, 3, true);
  });
  PL.setSkin('plana');
 };
 window.CATALOG = items.map((x) => x[0]);
})();
