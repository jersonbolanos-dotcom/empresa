// =====================================================================================================
// PLANTILLA ASOMBROTECA · motor universal de explainers verticales (1080x1920, 30 fps, voz original)
// ------------------------------------------------------------------------------------------------------
// Un episodio = voz + alineación (window.ALIGN) + una lista de BEATS. Cada beat dibuja su escena en función de t
// y declara sus sonidos. El motor pone: transiciones entre beats, subtítulos «palabra a palabra» con la palabra
// clave seleccionada, piel visual (plana o oscura-técnica), acabado, y genera scoreSound/scoreMusic.
// Todo es función pura de t (H.rng / H.makeNoise; nunca Math.random) => window.seek(t) en cualquier orden.
// Requiere: lib/harness.js (H) y lib/sound.js (SOUND) sin modificar.
// =====================================================================================================
(function () {
 const W = 1080, HH = 1920, TAU = Math.PI * 2;
 const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
 const sm = (a, b, x) => H.smooth(a, b, x);
 const E = H.ease, lerp = H.lerp;
 const win = (t, a, b) => cl((t - a) / Math.max(1e-6, b - a));

 // ---------------- PIELES ----------------
 // Una piel define colores semánticos, tipografías y el acabado. Los bloques sólo usan nombres semánticos.
 const SKINS = {
  plana: {
   name: 'plana',
   c: { ink: '#1d1b3a', ink2: '#3b3866', paper: '#ffffff', mute: '#c9c6e3', accent: '#f0b90b', red: '#e8505b', green: '#2fbf71', blue: '#3fa9f5', teal: '#25b8a8', pink: '#f28fae', violet: '#7a6cf0', orange: '#ff9f43', shadow: 'rgba(15,10,40,0.22)', handle: '#f0b90b' },
   font: { cap: 'Nunito', capW: 800, capDim: 700, title: 'Fredoka', titleW: 700, label: 'Nunito', labelW: 900, mono: 'Nunito' },
   rim: null, grain: 0.022, vignette: 0.28, vigCol: '10,8,30',
  },
  oscura: {
   name: 'oscura',
   c: { ink: '#0b0c10', ink2: '#1b1d25', paper: '#f4f1e8', mute: '#7d7a70', accent: '#f2b84b', red: '#ff6b57', green: '#5fd38d', blue: '#5aa9ff', teal: '#3fd6c6', pink: '#ff8fb1', violet: '#9b8cff', orange: '#ffb057', shadow: 'rgba(0,0,0,0.5)', handle: '#f2b84b' },
   font: { cap: 'Space Grotesk', capW: 700, capDim: 400, title: 'Space Grotesk', titleW: 700, label: 'IBM Plex Mono', labelW: 600, mono: 'IBM Plex Mono' },
   rim: '#f2b84b', grain: 0.05, vignette: 0.55, vigCol: '0,0,0',
   // la piel oscura: fondo casi negro, acentos vivos, blancos en papel cálido, borde dorado fino y grano (look «editor técnico»)
   // colores saturados se mantienen vivos (acentos sobre negro); blancos → papel cálido; neutros medios → gris carbón
   tone: (hex) => { const [r, g, b] = H.hex(hex), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (r + g + b) / 3; if (mx - mn < 40) return l > 180 ? '#ece7da' : H.rgba([l * 0.55 + 10, l * 0.55 + 12, l * 0.55 + 16]); return H.rgba([r * 0.92, g * 0.92, b * 0.92]); },
  },
 };
 let SK = SKINS.plana;
 const col = (name) => SK.c[name] || name;
 const fill = (c) => (SK.tone && c[0] === '#' ? SK.tone(c) : c);

 // ---------------- PRIMITIVAS PLANAS ----------------
 const P = {};
 P.rr = (ctx, x, y, w, h, r, c, o = {}) => {
  ctx.save();
  if (o.shadow !== false) { ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.roundRect(x + (o.sx ?? 0), y + (o.sy ?? 12), w, h, r); ctx.fill(); }
  ctx.fillStyle = fill(c); ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill();
  if (SK.rim && o.rim !== false) { ctx.strokeStyle = SK.rim; ctx.globalAlpha *= 0.7; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.restore();
 };
 P.circle = (ctx, x, y, r, c, o = {}) => {
  ctx.save();
  if (o.shadow) { ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.arc(x, y + 10, r, 0, TAU); ctx.fill(); }
  ctx.fillStyle = fill(c); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  if (SK.rim && o.rim !== false) { ctx.strokeStyle = SK.rim; ctx.lineWidth = 2; ctx.globalAlpha *= 0.7; ctx.stroke(); }
  ctx.restore();
 };
 P.poly = (ctx, pts, c, o = {}) => {
  ctx.save(); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath();
  ctx.fillStyle = fill(c); ctx.fill();
  if (SK.rim && o.rim) { ctx.strokeStyle = SK.rim; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.restore();
 };
 P.font = (kind, px) => { const f = SK.font; return kind === 'title' ? `${f.titleW} ${px}px "${f.title}"` : kind === 'mono' ? `${f.labelW} ${px}px "${f.mono}"` : `${f.labelW} ${px}px "${f.label}"`; };
 // texto con contorno grueso (estilo «6 METROS»/onomatopeya)
 P.bigText = (ctx, s, x, y, px, c, o = {}) => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); const sc = o.scale ?? 1; ctx.scale(sc, sc);
  ctx.font = P.font(o.kind || 'title', px); ctx.textAlign = o.align || 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  if (o.stroke !== false) { ctx.strokeStyle = o.strokeCol || col('ink'); ctx.lineWidth = px * 0.16; ctx.strokeText(s, 0, 0); }
  ctx.fillStyle = c || col('paper'); ctx.fillText(s, 0, 0);
  ctx.restore();
 };
 P.text = (ctx, s, x, y, px, c, o = {}) => { ctx.save(); ctx.font = P.font(o.kind || 'label', px); ctx.textAlign = o.align || 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = c; ctx.globalAlpha *= o.a ?? 1; ctx.fillText(s, x, y); ctx.restore(); };
 P.tw = (ctx, s, font) => { ctx.save(); ctx.font = font; const w = ctx.measureText(s).width; ctx.restore(); return w; };
 // aparición con rebote (escala back-out), devuelve escala 0..~1.08..1
 P.popS = (t, t0, d = 0.32) => { const u = win(t, t0, t0 + d); return u <= 0 ? 0 : E.back(u); };
 P.withPop = (ctx, t, t0, x, y, fn, d) => { const s = P.popS(t, t0, d); if (s <= 0.001) return; ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.translate(-x, -y); fn(); ctx.restore(); };
 // flecha gruesa redondeada que se dibuja (p 0..1)
 P.arrow = (ctx, x0, y0, x1, y1, p, c, w = 22) => {
  if (p <= 0) return; const xe = lerp(x0, x1, p), ye = lerp(y0, y1, p), an = Math.atan2(y1 - y0, x1 - x0), hl = w * 1.6;
  ctx.save(); ctx.strokeStyle = fill(c); ctx.fillStyle = fill(c); ctx.lineCap = 'round'; ctx.lineWidth = w;
  ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(xe - Math.cos(an) * hl * 0.6, ye - Math.sin(an) * hl * 0.6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(xe + Math.cos(an) * hl * 0.25, ye + Math.sin(an) * hl * 0.25); ctx.lineTo(xe - Math.cos(an - 0.6) * hl, ye - Math.sin(an - 0.6) * hl); ctx.lineTo(xe - Math.cos(an + 0.6) * hl, ye - Math.sin(an + 0.6) * hl); ctx.closePath();
  ctx.lineJoin = 'round'; ctx.lineWidth = w * 0.35; ctx.fill(); ctx.stroke();
  ctx.restore();
 };
 // X roja con borde blanco (tachado) y ✓ verde
 P.cross = (ctx, x, y, s, p, c) => {
  if (p <= 0) return; const a = cl(p * 2), b = cl(p * 2 - 1);
  ctx.save(); ctx.lineCap = 'round';
  for (const [w, cc] of [[s * 0.34, col('paper')], [s * 0.2, c || col('red')]]) { ctx.strokeStyle = cc; ctx.lineWidth = w;
   ctx.beginPath(); ctx.moveTo(x - s / 2, y - s / 2); ctx.lineTo(x - s / 2 + s * a, y - s / 2 + s * a); ctx.stroke();
   if (b > 0) { ctx.beginPath(); ctx.moveTo(x + s / 2, y - s / 2); ctx.lineTo(x + s / 2 - s * b, y - s / 2 + s * b); ctx.stroke(); } }
  ctx.restore();
 };
 P.check = (ctx, x, y, s, p, c) => {
  if (p <= 0) return; const pts = [[x - s * 0.45, y], [x - s * 0.12, y + s * 0.32], [x + s * 0.5, y - s * 0.38]];
  const L1 = Math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]), L2 = Math.hypot(pts[2][0] - pts[1][0], pts[2][1] - pts[1][1]), d = p * (L1 + L2);
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  for (const [w, cc] of [[s * 0.3, col('paper')], [s * 0.17, c || col('green')]]) { ctx.strokeStyle = cc; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(...pts[0]);
   if (d <= L1) ctx.lineTo(lerp(pts[0][0], pts[1][0], d / L1), lerp(pts[0][1], pts[1][1], d / L1)); else { ctx.lineTo(...pts[1]); ctx.lineTo(lerp(pts[1][0], pts[2][0], (d - L1) / L2), lerp(pts[1][1], pts[2][1], (d - L1) / L2)); } ctx.stroke(); }
  ctx.restore();
 };
 // bocadillo blanco con cola y un icono dibujado por callback
 P.bubble = (ctx, x, y, w, h, t, t0, icon, o = {}) => {
  P.withPop(ctx, t, t0, x + (o.tailX ?? -w * 0.3), y + h / 2 + 40, () => {
   ctx.save(); ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2 + 10, w, h, h * 0.35); ctx.fill();
   ctx.fillStyle = fill('#ffffff'); ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, h * 0.35); ctx.fill();
   const tx = x + (o.tailX ?? -w * 0.3); ctx.beginPath(); ctx.moveTo(tx - 26, y + h / 2 - 4); ctx.lineTo(tx - 34, y + h / 2 + 46); ctx.lineTo(tx + 22, y + h / 2 - 4); ctx.closePath(); ctx.fill();
   if (SK.rim) { ctx.strokeStyle = SK.rim; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, h * 0.35); ctx.stroke(); }
   ctx.restore(); icon(x, y);
  });
 };
 // píldora con texto (etiqueta tipo «cada 1,5 - 2 h»)
 P.pill = (ctx, s, x, y, px, t, t0, o = {}) => {
  ctx.save(); ctx.font = P.font(o.kind || 'label', px); const w = ctx.measureText(s).width + px * 1.2, h = px * 1.6; ctx.restore();
  P.withPop(ctx, t, t0, x, y, () => { P.rr(ctx, x - w / 2, y - h / 2, w, h, h / 2, o.bg || '#ffffff', { sy: 8 }); P.text(ctx, s, x, y + 2, px, o.fg || col('ink'), { kind: o.kind }); }, 0.28);
  return w;
 };
 // onomatopeya (GRRR, BIP BIP…) con temblor
 P.onoma = (ctx, s, x, y, px, t, t0, t1, o = {}) => {
  const a = sm(t0, t0 + 0.08, t) * (1 - sm(t1 - 0.15, t1, t)); if (a <= 0) return;
  const sh = o.shake === false ? 0 : Math.sin(t * 60) * 4 * (1 - win(t, t0, t0 + 0.4));
  ctx.save(); ctx.globalAlpha = a; P.bigText(ctx, s, x + sh, y, px, o.c || col('paper'), { rot: o.rot ?? -0.12, scale: P.popS(t, t0, 0.25) || 0.001 }); ctx.restore();
 };
 // contador que rueda (enteros); devuelve el valor mostrado
 P.counter = (ctx, x, y, px, t, t0, t1, from, to, o = {}) => {
  const u = E.out(win(t, t0, t1)), v = Math.round(lerp(from, to, u));
  const s = (o.prefix || '') + (o.fmt ? o.fmt(v) : String(v)) + (o.suffix || '');
  P.withPop(ctx, t, t0 - 0.1, x, y, () => {
   if (o.box) { ctx.save(); ctx.font = P.font('title', px); const w = ctx.measureText(s).width + px * 0.7; ctx.restore(); P.rr(ctx, x - w / 2, y - px * 0.72, w, px * 1.44, px * 0.22, o.box, { sy: 12 }); }
   P.bigText(ctx, s, x, y, px, o.c || col('paper'), { stroke: !o.box });
  });
  return v;
 };
 // lupa: anillo dorado y contenido recortado (como mirar dentro de algo)
 P.lens = (ctx, x, y, r, s, draw) => {
  if (s <= 0.001) return; const R = r * s;
  ctx.save(); ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.arc(x, y + 14, R + 18, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.clip(); draw(); ctx.restore();
  ctx.save(); ctx.lineWidth = 22 * s; ctx.strokeStyle = fill('#d9a42b'); ctx.beginPath(); ctx.arc(x, y, R + 9 * s, 0, TAU); ctx.stroke();
  ctx.lineWidth = 6 * s; ctx.strokeStyle = fill('#f6d47a'); ctx.beginPath(); ctx.arc(x, y, R + 3 * s, -2.6, -1.2); ctx.stroke(); ctx.restore();
 };
 // manómetro cualitativo (sin cifras): la aguja va de verde a rojo
 P.gauge = (ctx, x, y, r, v, label) => {
  P.circle(ctx, x, y, r + 16, col('ink2'), { shadow: true }); P.circle(ctx, x, y, r, '#ffffff');
  const a0 = Math.PI * 0.8, a1 = Math.PI * 2.2;
  [['#2fbf71', 0, 0.45], ['#f0b90b', 0.45, 0.72], ['#e8505b', 0.72, 1]].forEach(([c, u0, u1]) => { ctx.save(); ctx.strokeStyle = fill(c); ctx.lineWidth = r * 0.16; ctx.beginPath(); ctx.arc(x, y, r * 0.78, lerp(a0, a1, u0), lerp(a0, a1, u1)); ctx.stroke(); ctx.restore(); });
  const an = lerp(a0, a1, cl(v)) + Math.sin(v * 80) * 0.01;
  ctx.save(); ctx.strokeStyle = fill(col('ink')); ctx.lineWidth = r * 0.07; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(an) * r * 0.7, y + Math.sin(an) * r * 0.7); ctx.stroke(); ctx.restore();
  P.circle(ctx, x, y, r * 0.1, col('ink'));
  if (label) P.text(ctx, label, x, y + r * 0.45, r * 0.16, col('ink'));
 };
 // ficha de dominó que cae (p 0..1) con icono
 P.domino = (ctx, x, y, w, h, p, c, icon) => {
  ctx.save(); ctx.translate(x + w / 2, y + h); ctx.rotate(E.in(cl(p)) * 1.25);
  P.rr(ctx, -w / 2, -h, w, h, 18, c, { sy: 10 }); ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(-w / 2 + 14, -h + 14, 12, h - 28);
  if (icon) icon(0, -h * 0.5); ctx.restore();
 };
 // persona (icono) para cuadrículas respetuosas
 P.person = (ctx, x, y, s, c) => { ctx.save(); ctx.fillStyle = fill(c); ctx.beginPath(); ctx.arc(x, y - s * 0.55, s * 0.28, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.roundRect(x - s * 0.36, y - s * 0.2, s * 0.72, s * 0.62, [s * 0.34, s * 0.34, s * 0.08, s * 0.08]); ctx.fill(); ctx.restore(); };
 // escudo con ✓ (solución)
 P.shield = (ctx, x, y, s, c, p) => {
  ctx.save(); ctx.translate(x, y); ctx.fillStyle = col('shadow'); const sh = () => { ctx.beginPath(); ctx.moveTo(0, -s); ctx.quadraticCurveTo(s * 0.55, -s * 0.78, s * 0.85, -s * 0.8); ctx.quadraticCurveTo(s * 0.9, s * 0.35, 0, s); ctx.quadraticCurveTo(-s * 0.9, s * 0.35, -s * 0.85, -s * 0.8); ctx.quadraticCurveTo(-s * 0.55, -s * 0.78, 0, -s); };
  ctx.translate(0, 12); sh(); ctx.fill(); ctx.translate(0, -12); ctx.fillStyle = fill(c); sh(); ctx.fill(); ctx.restore();
  P.check(ctx, x, y + s * 0.05, s * 0.8, p, '#ffffff');
 };
 // dedo que toca (cierre «Seguir»)
 P.finger = (ctx, x, y, s, press) => {
  ctx.save(); ctx.translate(x, y + press * 10); ctx.rotate(-0.35);
  ctx.fillStyle = fill('#f1b48c'); ctx.beginPath(); ctx.roundRect(-s * 0.22, -s * 0.05, s * 0.44, s * 1.3, s * 0.22); ctx.fill();
  ctx.fillStyle = fill('#f7d0b5'); ctx.beginPath(); ctx.roundRect(-s * 0.15, 0, s * 0.3, s * 0.28, s * 0.12); ctx.fill();
  ctx.fillStyle = fill('#e39c76'); ctx.fillRect(-s * 0.22, s * 0.55, s * 0.44, 4); ctx.restore();
 };
 // partículas deterministas (burbujas, polvo…)
 P.bubbles = (ctx, x, y, w, h, t, seed, n, a, o = {}) => {
  if (a <= 0) return; const R = H.rng(seed);
  for (let i = 0; i < n; i++) { const bx = x + R() * w, sp = R.range(0.3, 1), r = R.range(o.r0 || 6, o.r1 || 18), ph = R(); const u = ((t * sp * (o.speed || 0.5) + ph) % 1);
   const yy = y + h - u * h, xx = bx + Math.sin(t * 2 + i) * 8;
   ctx.save(); ctx.globalAlpha = a * (1 - u) * 0.9; ctx.strokeStyle = o.c || 'rgba(255,255,255,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(xx, yy, r, 0, TAU); ctx.stroke();
   ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(xx - r * 0.35, yy - r * 0.35, r * 0.25, 0, TAU); ctx.fill(); ctx.restore(); }
 };


 // ---------------- BLOQUES v1.2 (episodio microondas) ----------------
 // cámara 2.5D por fotogramas clave [t, x, y, zoom, rot]: devuelve el estado y lo aplica (centro de pantalla = punto mirado)
 P.camAt = (keys, t) => { if (t <= keys[0][0]) return keys[0].slice(1); for (let i = 0; i < keys.length - 1; i++) { const a = keys[i], b = keys[i + 1]; if (t <= b[0]) { const u = E.inOut(win(t, a[0], b[0])); return [lerp(a[1], b[1], u), lerp(a[2], b[2], u), Math.exp(lerp(Math.log(a[3]), Math.log(b[3]), u)), lerp(a[4] || 0, b[4] || 0, u)]; } } return keys[keys.length - 1].slice(1); };
 P.camApply = (ctx, c) => { ctx.translate(W / 2, HH / 2); ctx.rotate(c[3] || 0); ctx.scale(c[2], c[2]); ctx.translate(-c[0], -c[1]); };
 // brillo aditivo (luz, energía): no se usa para «partículas de onda»
 P.glow = (ctx, x, y, r, rgb, a) => { if (a <= 0.003 || r <= 0) return; const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${rgb},${a})`); g.addColorStop(0.4, `rgba(${rgb},${a * 0.35})`); g.addColorStop(1, `rgba(${rgb},0)`); ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = g; ctx.fillRect(x - r, y - r, 2 * r, 2 * r); ctx.restore(); };
 // rampa térmica (temperatura, NO intensidad de campo): 0 frío azul → 0.5 amarillo → 0.75 naranja → 1 rojo
 P.heat = (v) => { const st = [[0, [40, 110, 230]], [0.35, [90, 200, 235]], [0.55, [250, 215, 70]], [0.78, [250, 140, 40]], [1, [225, 45, 40]]]; v = cl(v); for (let i = 0; i < st.length - 1; i++) { const [a, ca] = st[i], [b, cb] = st[i + 1]; if (v <= b) { const u = (v - a) / (b - a); return [lerp(ca[0], cb[0], u), lerp(ca[1], cb[1], u), lerp(ca[2], cb[2], u)]; } } return st[st.length - 1][1]; };
 // onda electromagnética estilizada: cinta luminosa sinusoidal a lo largo de una polilínea (dos hebras desfasadas = volumen)
 P.wave = (ctx, pts, t, o = {}) => {
  const amp = o.amp || 26, lam = o.lam || 120, sp = o.speed || 260, a = o.a ?? 1, rgb = o.rgb || '90,220,255', prog = o.prog ?? 1;
  const seg = []; let L = 0; for (let i = 0; i < pts.length - 1; i++) { const d = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]); seg.push([L, d, i]); L += d; }
  const at = (s) => { for (const [l0, d, i] of seg) if (s <= l0 + d || i === seg.length - 1) { const u = d ? (s - l0) / d : 0, p = pts[i], q = pts[i + 1]; return [p[0] + (q[0] - p[0]) * u, p[1] + (q[1] - p[1]) * u, Math.atan2(q[1] - p[1], q[0] - p[0])]; } };
  const Lp = L * cl(prog); if (Lp < 2 || a <= 0.01) return;
  // o.over: dibujar en modo normal (sobre fondos claros, donde el modo aditivo se vuelve blanco)
  ctx.save(); ctx.globalCompositeOperation = o.over ? 'source-over' : 'lighter'; ctx.lineCap = 'round';
  for (const [ph, w, al] of [[0, 9, 0.18], [0, 3, 0.85], [Math.PI / 2, 2, 0.45]]) {
   ctx.beginPath();
   for (let s2 = 0; s2 <= Lp; s2 += 4) { const [x, y, an] = at(s2), env = Math.min(1, s2 / 40, (Lp - s2) / 40 + 0.2), off = Math.sin((s2 - t * sp) / lam * TAU + ph) * amp * env * (ph ? 0.6 : 1); const px = x - Math.sin(an) * off, py = y + Math.cos(an) * off; s2 ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
   ctx.strokeStyle = `rgba(${rgb},${al * a})`; ctx.lineWidth = w; ctx.stroke();
  }
  ctx.restore();
 };
 // molécula de agua (O rojo, 2 H blancos a ~104,5°), ángulo = orientación del dipolo
 P.water = (ctx, x, y, s, ang, o = {}) => {
  const hx = (k) => [x + Math.cos(ang + k * 0.912) * s * 0.95, y + Math.sin(ang + k * 0.912) * s * 0.95];
  ctx.save();
  for (const k of [-1, 1]) { const [px, py] = hx(k); ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = s * 0.22; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(px, py); ctx.stroke(); }
  const oc = o.hot != null ? P.heat(0.15 + 0.85 * o.hot) : [230, 70, 70];
  const g = ctx.createRadialGradient(x - s * 0.2, y - s * 0.2, s * 0.1, x, y, s * 0.62); g.addColorStop(0, '#ffffff'); g.addColorStop(0.25, H.rgba(oc)); g.addColorStop(1, H.rgba(oc.map((v) => v * 0.55)));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, s * 0.6, 0, TAU); ctx.fill();
  for (const k of [-1, 1]) { const [px, py] = hx(k), gh = ctx.createRadialGradient(px - s * 0.1, py - s * 0.1, 1, px, py, s * 0.36); gh.addColorStop(0, '#ffffff'); gh.addColorStop(1, '#b9c4d6'); ctx.fillStyle = gh; ctx.beginPath(); ctx.arc(px, py, s * 0.34, 0, TAU); ctx.fill(); }
  ctx.restore();
 };


 // ---------------- BLOQUES v1.4 (episodio aire acondicionado) ----------------
 // Recorrido: polilínea con longitud acumulada; at(s) → [x, y, ángulo]. Reutilizable para tuberías, cables, rutas.
 P.path = (pts) => { const L = [0]; for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); const total = L[L.length - 1];
  const at = (s) => { s = Math.max(0, Math.min(total, s)); let i = 1; while (i < L.length - 1 && L[i] < s) i++; const u = (s - L[i - 1]) / Math.max(1e-6, L[i] - L[i - 1]), a = pts[i - 1], b = pts[i]; return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, Math.atan2(b[1] - a[1], b[0] - a[0])]; };
  return { pts, L: total, at }; };
 P.strokePath = (ctx, pts, w, col, o = {}) => { ctx.save(); ctx.lineCap = o.cap || 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = col; ctx.lineWidth = w; ctx.globalAlpha *= o.a ?? 1; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); ctx.restore(); };
 // Fluido dentro de un conducto transparente. FASE y TEMPERATURA son independientes:
 //   phase(u) 0 = líquido · 1 = vapor · intermedio = mezcla (líquido con burbujas); temp(u) 0..1 → P.heat (azul frío → rojo caliente)
 //   u = fracción del recorrido. o: { w ancho, speed px/s, phase, temp, a, seed }
 P.fluid = (ctx, path, t, o = {}) => {
  const w = o.w || 12, sp = o.speed || 60, a = o.a ?? 1, ph = o.phase || (() => 0), tp = o.temp || (() => 0.5), R = H.rng(o.seed || 1);
  if (a <= 0.01) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.lineCap = 'round';
  // núcleo líquido: grosor ∝ fracción líquida, color = temperatura
  const step = 6;
  for (let s = 0; s < path.L - step; s += step) { const u = s / path.L, f = ph(u), lw = w * 0.78 * (1 - f); if (lw < 0.6) continue; const [x0, y0] = path.at(s), [x1, y1] = path.at(s + step + 0.5); ctx.strokeStyle = H.rgba(P.heat(tp(u)), 0.85); ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
  // partículas que avanzan: en líquido, puntos densos; en vapor y mezcla, burbujas (anillos)
  const n = Math.floor(path.L / (w * 0.9));
  for (let i = 0; i < n; i++) { const off = R() * path.L, s = (off + t * sp) % path.L, u = s / path.L, f = ph(u), [x, y, an] = path.at(s), j = (R() - 0.5) * w * 0.55, px = x - Math.sin(an) * j, py = y + Math.cos(an) * j, col = H.rgba(H.mix(P.heat(tp(u)), [255, 255, 255], 0.35), 0.95);
   if (R() < f) { const r = w * (0.16 + 0.14 * R()); ctx.strokeStyle = col; ctx.lineWidth = Math.max(1.2, w * 0.09); ctx.beginPath(); ctx.arc(px, py, r, 0, TAU); ctx.stroke(); }
   else if (R() < 0.7) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px, py, Math.max(1.2, w * 0.1), 0, TAU); ctx.fill(); } }
  ctx.restore();
 };
 // Trazadores de aire: rayas cortas que viajan por una trayectoria (no humo). temp 0..1 tiñe el aire.
 P.airStreaks = (ctx, path, t, o = {}) => {
  const n = o.n || 14, sp = o.speed || 220, len = o.len || 46, a = o.a ?? 1, R = H.rng(o.seed || 3), spread = o.spread || 40;
  if (a <= 0.01) return; ctx.save(); ctx.lineCap = 'round';
  for (let i = 0; i < n; i++) { const off = R() * path.L, lane = (R() - 0.5) * spread, s = (off + t * sp * (0.8 + 0.4 * R())) % path.L, u = s / path.L, tt = typeof o.temp === 'function' ? o.temp(u) : (o.temp ?? 0.5), al = a * Math.sin(Math.PI * u) * 0.9;
   const [x0, y0, an] = path.at(s), [x1, y1] = path.at(Math.max(0, s - len)), nx = -Math.sin(an) * lane, ny = Math.cos(an) * lane;
   const g = ctx.createLinearGradient(x1 + nx, y1 + ny, x0 + nx, y0 + ny); const c = P.heat(tt); g.addColorStop(0, H.rgba(c, 0)); g.addColorStop(1, H.rgba(H.mix(c, [255, 255, 255], 0.3), al));
   ctx.strokeStyle = g; ctx.lineWidth = o.w || 4; ctx.beginPath(); ctx.moveTo(x1 + nx, y1 + ny); ctx.lineTo(x0 + nx, y0 + ny); ctx.stroke(); }
  ctx.restore();
 };
 // Ventilador axial (unidad exterior): aspas que giran + rejilla
 P.fanAxial = (ctx, x, y, r, ang, o = {}) => {
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = o.bg || '#1a2230'; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
  ctx.rotate(ang); const nb = o.blades || 3;
  for (let k = 0; k < nb; k++) { ctx.save(); ctx.rotate(k * TAU / nb); ctx.fillStyle = o.blade || '#5f6f82'; ctx.beginPath(); ctx.moveTo(r * 0.12, -r * 0.08); ctx.bezierCurveTo(r * 0.5, -r * 0.42, r * 0.92, -r * 0.3, r * 0.9, r * 0.05); ctx.bezierCurveTo(r * 0.6, r * 0.12, r * 0.3, r * 0.1, r * 0.12, r * 0.08); ctx.closePath(); ctx.fill(); ctx.restore(); }
  ctx.fillStyle = o.hub || '#9aa7b6'; ctx.beginPath(); ctx.arc(0, 0, r * 0.14, 0, TAU); ctx.fill();
  ctx.rotate(-ang); if (o.grille !== false) { ctx.strokeStyle = 'rgba(200,210,225,0.35)'; ctx.lineWidth = 2; for (let k = 1; k <= 5; k++) { ctx.beginPath(); ctx.arc(0, 0, r * k / 5, 0, TAU); ctx.stroke(); } for (let k = 0; k < 8; k++) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(k * TAU / 8) * r, Math.sin(k * TAU / 8) * r); ctx.stroke(); } }
  ctx.restore();
 };
 // Ventilador de flujo cruzado (unidad interior): cilindro horizontal con álabes que se desplazan
 P.fanCross = (ctx, x0, y0, w, h, ph, o = {}) => {
  ctx.save(); const g = ctx.createLinearGradient(0, y0, 0, y0 + h); g.addColorStop(0, '#2b3442'); g.addColorStop(0.5, '#5d6b7e'); g.addColorStop(1, '#232b37');
  ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(x0, y0, w, h, h / 2); ctx.fill(); ctx.clip();
  ctx.strokeStyle = o.blade || 'rgba(220,230,245,0.55)'; ctx.lineWidth = 2; const sp = h * 0.45;
  for (let x = x0 - sp + ((ph * sp) % sp); x < x0 + w + sp; x += sp) { ctx.beginPath(); ctx.moveTo(x, y0); ctx.quadraticCurveTo(x + sp * 0.3, y0 + h / 2, x, y0 + h); ctx.stroke(); }
  ctx.restore();
 };


 // ---------------- BLOQUES v1.5 (episodio GPS) ----------------
 // Celular: marco + pantalla con callback (la pantalla se recorta). (cx, cy) centro, w ancho.
 P.phone = (ctx, cx, cy, w, screen, o = {}) => {
  const h = w * 2.05, x = cx - w / 2, y = cy - h / 2, r = w * 0.14, b = w * 0.045;
  ctx.save(); ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.roundRect(x + 8, y + 18, w, h, r); ctx.fill();
  const g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, '#2b2f3a'); g.addColorStop(1, '#11141a'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill();
  ctx.save(); ctx.beginPath(); ctx.roundRect(x + b, y + b, w - 2 * b, h - 2 * b, r * 0.8); ctx.clip(); screen(x + b, y + b, w - 2 * b, h - 2 * b); ctx.restore();
  ctx.fillStyle = '#0b0d12'; ctx.beginPath(); ctx.roundRect(cx - w * 0.14, y + b + w * 0.03, w * 0.28, w * 0.07, w * 0.035); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(x + 1, y + 1, w - 2, h - 2, r); ctx.stroke();
  ctx.restore();
 };
 // Mapa de ciudad visto desde arriba (manzanas, calles, parque, río). Determinista por semilla.
 P.mapCity = (ctx, x, y, w, h, seed = 1, o = {}) => {
  const R = H.rng(seed); ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.fillStyle = o.ground || '#eef1f4'; ctx.fillRect(x, y, w, h);
  const bs = o.block || 90, st = o.street || 16;
  for (let yy = y - bs; yy < y + h + bs; yy += bs + st) for (let xx = x - bs; xx < x + w + bs; xx += bs + st) { const k = R(); ctx.fillStyle = k < 0.1 ? '#bfe3c0' : k < 0.16 ? '#cfe4f6' : '#dfe3e8'; ctx.beginPath(); ctx.roundRect(xx, yy, bs, bs, 8); ctx.fill(); }
  ctx.strokeStyle = '#ffffff'; ctx.lineWidth = st * 1.6; ctx.beginPath(); ctx.moveTo(x, y + h * 0.62); ctx.bezierCurveTo(x + w * 0.3, y + h * 0.5, x + w * 0.6, y + h * 0.78, x + w, y + h * 0.66); ctx.stroke();
  ctx.strokeStyle = '#ffd36b'; ctx.lineWidth = st * 0.9; ctx.stroke();
  ctx.strokeStyle = '#9fd0f2'; ctx.lineWidth = st * 2.4; ctx.beginPath(); ctx.moveTo(x + w * 0.15, y); ctx.bezierCurveTo(x + w * 0.05, y + h * 0.3, x + w * 0.35, y + h * 0.55, x + w * 0.2, y + h); ctx.stroke();
  ctx.restore();
 };
 // Pin de ubicación (gota) y punto azul pulsante
 P.pin = (ctx, x, y, s, c = '#e8505b') => { ctx.save(); ctx.fillStyle = col('shadow'); ctx.beginPath(); ctx.ellipse(x, y + 4, s * 0.35, s * 0.12, 0, 0, TAU); ctx.fill(); ctx.fillStyle = fill(c); ctx.beginPath(); ctx.moveTo(x, y); ctx.bezierCurveTo(x - s * 0.15, y - s * 0.35, x - s * 0.5, y - s * 0.55, x - s * 0.5, y - s * 0.85); ctx.arc(x, y - s * 0.85, s * 0.5, Math.PI, 0); ctx.bezierCurveTo(x + s * 0.5, y - s * 0.55, x + s * 0.15, y - s * 0.35, x, y); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, y - s * 0.85, s * 0.2, 0, TAU); ctx.fill(); ctx.restore(); };
 P.dot = (ctx, x, y, r, t, c = '#2f80ed') => { const ph = (t * 1.2) % 1; ctx.save(); ctx.fillStyle = `rgba(47,128,237,${0.35 * (1 - ph)})`; ctx.beginPath(); ctx.arc(x, y, r * (1 + 2.2 * ph), 0, TAU); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, y, r * 1.25, 0, TAU); ctx.fill(); ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.restore(); };
 // Círculo de distancia (rango) que se dibuja: p 0..1
 P.rangeCircle = (ctx, x, y, r, p, c = '#2f80ed', o = {}) => { if (p <= 0) return; ctx.save(); ctx.fillStyle = H.rgba(H.hex(c), o.fillA ?? 0.08); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.strokeStyle = c; ctx.lineWidth = o.w || 5; ctx.setLineDash(o.dash || [18, 12]); ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * cl(p)); ctx.stroke(); ctx.restore(); };
 // Globo terrestre plano con continentes estilizados (ruido), rotación ang, sombra de día/noche suave
 let GLOBE = null;
 P.globe = (ctx, x, y, r, ang = 0) => {
  if (!GLOBE) { const S = 512, c = H.layer(S * 2, S), g = c.getContext('2d'), nz = H.makeNoise(77), img = g.createImageData(S * 2, S); for (let j = 0; j < S; j++) for (let i = 0; i < S * 2; i++) { const lon = i / (S * 2) * TAU, lat = (j / S - 0.5) * Math.PI, v = nz.fbm3(Math.cos(lat) * Math.cos(lon) * 1.6, Math.cos(lat) * Math.sin(lon) * 1.6, Math.sin(lat) * 1.6, 4), land = v > 0.06, ice = Math.abs(lat) > 1.25, q = (j * S * 2 + i) * 4, c3 = ice ? [235, 242, 248] : land ? (v > 0.22 ? [150, 170, 110] : [95, 170, 95]) : [40, 120, 200]; img.data[q] = c3[0]; img.data[q + 1] = c3[1]; img.data[q + 2] = c3[2]; img.data[q + 3] = 255; } g.putImageData(img, 0, 0); GLOBE = c; }
  ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.clip();
  const S = GLOBE.height, off = ((ang / TAU) % 1 + 1) % 1 * S * 2;
  for (let k = -1; k <= 1; k++) ctx.drawImage(GLOBE, 0, 0, S * 2, S, x - r - off / (S * 2) * r * 4 + k * r * 4, y - r, r * 4, r * 2);
  const sh = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r * 1.05); sh.addColorStop(0, 'rgba(255,255,255,0.18)'); sh.addColorStop(0.6, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,10,30,0.55)'); ctx.fillStyle = sh; ctx.fillRect(x - r, y - r, 2 * r, 2 * r);
  ctx.restore();
  const at = ctx.createRadialGradient(x, y, r * 0.95, x, y, r * 1.12); at.addColorStop(0, 'rgba(120,190,255,0.5)'); at.addColorStop(1, 'rgba(120,190,255,0)'); ctx.save(); ctx.fillStyle = at; ctx.beginPath(); ctx.arc(x, y, r * 1.12, 0, TAU); ctx.fill(); ctx.restore();
 };
 // Satélite genérico (cuerpo + paneles solares + antena)
 P.satellite = (ctx, x, y, s, rot = 0, o = {}) => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  for (const sd of [-1, 1]) { ctx.fillStyle = '#2b4f8a'; ctx.fillRect(sd > 0 ? s * 0.32 : -s * 1.22, -s * 0.22, s * 0.9, s * 0.44); ctx.strokeStyle = 'rgba(200,220,255,0.55)'; ctx.lineWidth = Math.max(1, s * 0.03); for (let k = 1; k < 4; k++) { const xx = (sd > 0 ? s * 0.32 : -s * 1.22) + k * s * 0.225; ctx.beginPath(); ctx.moveTo(xx, -s * 0.22); ctx.lineTo(xx, s * 0.22); ctx.stroke(); } ctx.fillStyle = '#9aa7b6'; ctx.fillRect(sd > 0 ? s * 0.22 : -s * 0.32, -s * 0.04, s * 0.1, s * 0.08); }
  ctx.fillStyle = o.body || '#d9a42b'; ctx.beginPath(); ctx.roundRect(-s * 0.24, -s * 0.3, s * 0.48, s * 0.6, s * 0.06); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(-s * 0.2, -s * 0.26, s * 0.1, s * 0.52);
  ctx.fillStyle = '#e8edf3'; ctx.beginPath(); ctx.ellipse(0, s * 0.38, s * 0.18, s * 0.08, 0, 0, TAU); ctx.fill();
  ctx.restore();
 };
 // Ondas de radio que se expanden desde (x, y): anillos o arcos dirigidos (dir, abertura)
 P.rings = (ctx, x, y, t, o = {}) => { const n = o.n || 3, maxR = o.r || 220, per = o.period || 1.2, c = o.c || '120,220,255', a = o.a ?? 1; if (a <= 0) return; ctx.save(); ctx.lineCap = 'round'; for (let k = 0; k < n; k++) { const u = ((t / per + k / n) % 1), rr = 10 + u * maxR; ctx.strokeStyle = `rgba(${c},${a * (1 - u) * 0.9})`; ctx.lineWidth = o.w || 5; ctx.beginPath(); if (o.dir != null) ctx.arc(x, y, rr, o.dir - (o.spread || 0.6), o.dir + (o.spread || 0.6)); else ctx.arc(x, y, rr, 0, TAU); ctx.stroke(); } ctx.restore(); };
 // Reloj analógico (h, m, s en horas/minutos/segundos continuos)
 P.clock = (ctx, x, y, r, secs, o = {}) => {
  P.circle(ctx, x, y, r + r * 0.08, o.rim || col('ink2'), { shadow: true }); P.circle(ctx, x, y, r, o.face || '#ffffff');
  ctx.save(); ctx.strokeStyle = '#1d1b3a'; for (let k = 0; k < 12; k++) { const a = k / 12 * TAU; ctx.lineWidth = k % 3 ? 3 : 6; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.82, y + Math.sin(a) * r * 0.82); ctx.lineTo(x + Math.cos(a) * r * 0.95, y + Math.sin(a) * r * 0.95); ctx.stroke(); }
  const hand = (frac, len, w, c) => { const a = frac * TAU - Math.PI / 2; ctx.strokeStyle = c; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len); ctx.stroke(); };
  hand((secs / 43200) % 1, r * 0.5, r * 0.08, '#1d1b3a'); hand((secs / 3600) % 1, r * 0.72, r * 0.06, '#1d1b3a'); hand((secs / 60) % 1, r * 0.82, r * 0.025, o.sec || '#e8505b');
  ctx.fillStyle = '#1d1b3a'; ctx.beginPath(); ctx.arc(x, y, r * 0.07, 0, TAU); ctx.fill(); ctx.restore();
 };

 // ======================= v1.6 · OCÉANO, CABLES SUBMARINOS Y TELECOMUNICACIONES =======================
 const mixC = (a, b, u) => [lerp(a[0], b[0], u), lerp(a[1], b[1], u), lerp(a[2], b[2], u)];
 // Curva suave (Catmull-Rom) que pasa por los puntos: devuelve una polilínea densa (para rutas, cables, contornos)
 P.spline = (pts, seg = 10) => { if (pts.length < 3) return pts.slice(); const out = []; for (let i = 0; i < pts.length - 1; i++) { const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)]; for (let k = 0; k < seg; k++) { const u = k / seg, u2 = u * u, u3 = u2 * u; out.push([0, 1].map((j) => 0.5 * (2 * p1[j] + (-p0[j] + p2[j]) * u + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * u2 + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * u3))); } } out.push(pts[pts.length - 1].slice()); return out; };
 // Mar de perfil: degradado según la profundidad (0 superficie → 1 abismo), rayos de luz que se apagan al bajar
 // y «nieve marina» que deriva. o: { x, y, w, h, snow (nº partículas), rays, seed, dy (desplazamiento: descenso) }
 P.ocean = (ctx, t, depth = 0.5, o = {}) => {
  const x = o.x ?? 0, y = o.y ?? 0, w = o.w ?? W, h = o.h ?? HH, d = cl(depth);
  const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, H.rgba(mixC([22, 123, 255], [6, 42, 70], cl(d * 1.6)))); g.addColorStop(0.55, H.rgba(mixC([6, 60, 110], [3, 19, 34], d))); g.addColorStop(1, H.rgba(mixC([6, 42, 70], [2, 9, 18], d))); ctx.save(); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  const ra = (o.rays ?? 1) * Math.pow(1 - d, 1.6) * 0.16;
  if (ra > 0.005) { ctx.globalCompositeOperation = 'lighter'; for (let i = 0; i < 6; i++) { const cx = x + w * (0.1 + i * 0.17) + Math.sin(t * 0.4 + i * 1.7) * 40, sp = 60 + (i % 3) * 30; const rg = ctx.createLinearGradient(0, y, 0, y + h * 0.8); rg.addColorStop(0, `rgba(180,230,255,${ra})`); rg.addColorStop(1, 'rgba(180,230,255,0)'); ctx.fillStyle = rg; ctx.beginPath(); ctx.moveTo(cx - sp * 0.3, y); ctx.lineTo(cx + sp * 0.3, y); ctx.lineTo(cx + sp * 1.4 + 120, y + h * 0.8); ctx.lineTo(cx - sp * 0.2 + 120, y + h * 0.8); ctx.closePath(); ctx.fill(); } ctx.globalCompositeOperation = 'source-over'; }
  const n = o.snow ?? 90, R = H.rng(o.seed || 31), dy = o.dy || 0;
  for (let i = 0; i < n; i++) { const px = x + ((R() * w + Math.sin(t * 0.3 + i) * 12) % w + w) % w, sp = R.range(6, 18), py = y + (((R() * h - t * sp - dy * R.range(0.6, 1.4)) % h) + h) % h, r = R.range(0.8, 2.6); ctx.fillStyle = `rgba(210,235,255,${R.range(0.15, 0.45) * (0.5 + 0.5 * d)})`; ctx.beginPath(); ctx.arc(px, py, r, 0, TAU); ctx.fill(); }
  ctx.restore();
 };
 // Superficie del mar de perfil (línea ondulada con espuma). o: { x, w, amp, sky (color encima, null = no pinta), c }
 P.waves = (ctx, y, t, o = {}) => {
  const x0 = o.x ?? 0, w = o.w ?? W, amp = o.amp ?? 10, f = (x) => y + Math.sin(x * 0.012 + t * 1.6) * amp + Math.sin(x * 0.031 - t * 2.1) * amp * 0.4;
  ctx.save(); if (o.sky) { ctx.fillStyle = o.sky; ctx.beginPath(); ctx.moveTo(x0, y - 2000); for (let x = x0; x <= x0 + w; x += 12) ctx.lineTo(x, f(x)); ctx.lineTo(x0 + w, y - 2000); ctx.closePath(); ctx.fill(); }
  ctx.strokeStyle = o.c || 'rgba(230,248,255,0.85)'; ctx.lineWidth = 5; ctx.beginPath(); for (let x = x0; x <= x0 + w; x += 12) (x === x0 ? ctx.moveTo(x, f(x)) : ctx.lineTo(x, f(x))); ctx.stroke(); ctx.restore(); return f;
 };
 // Fondo marino de perfil: sedimento ondulado, rocas y una franja de arena. Devuelve yAt(x) (altura del fondo) para apoyar cables.
 P.seabed = (ctx, y, t, o = {}) => {
  const x0 = o.x ?? 0, w = o.w ?? W, s = o.seed || 7, bot = o.bottom ?? HH, yAt = (x) => y + Math.sin(x * 0.006 + s) * 14 + Math.sin(x * 0.019 + s * 2) * 6;
  ctx.save(); const g = ctx.createLinearGradient(0, y - 20, 0, bot); g.addColorStop(0, o.c || '#3a4a55'); g.addColorStop(1, o.c2 || '#141d24'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x0, bot); for (let x = x0; x <= x0 + w; x += 10) ctx.lineTo(x, yAt(x)); ctx.lineTo(x0 + w, bot); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(160,190,200,0.35)'; ctx.lineWidth = 3; ctx.beginPath(); for (let x = x0; x <= x0 + w; x += 10) (x === x0 ? ctx.moveTo(x, yAt(x)) : ctx.lineTo(x, yAt(x))); ctx.stroke();
  const R = H.rng(s * 13); for (let i = 0; i < (o.rocks ?? 7); i++) { const rx = x0 + R() * w, rw = R.range(20, 70), ry = yAt(rx); ctx.fillStyle = `rgba(${R.int(60, 90)},${R.int(75, 100)},${R.int(85, 110)},1)`; ctx.beginPath(); ctx.ellipse(rx, ry + rw * 0.15, rw, rw * 0.45, 0, Math.PI, TAU); ctx.fill(); }
  ctx.restore(); return yAt;
 };
 // Barco cablero de perfil sobre la línea de agua y (s = media eslora en px). Proa a la izquierda; popa a la derecha con
 // roldana (polea) por donde sale el cable. Se mece con t. o: { tanks (tambor/tanque visible), flip }. Devuelve [x, y] de la roldana.
 P.ship = (ctx, x, y, s, t, o = {}) => {
  const bob = Math.sin(t * 1.3) * s * 0.012, rot = Math.sin(t * 0.9) * 0.012, fl = o.flip ? -1 : 1;
  ctx.save(); ctx.translate(x, y + bob); ctx.rotate(rot); ctx.scale(fl, 1);
  ctx.fillStyle = '#c23b3b'; ctx.beginPath(); ctx.moveTo(-s * 0.98, s * 0.02); ctx.lineTo(s * 0.98, s * 0.02); ctx.lineTo(s * 0.9, s * 0.16); ctx.lineTo(-s * 0.8, s * 0.16); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#1d3b6a'; ctx.beginPath(); ctx.moveTo(-s * 1.08, -s * 0.2); ctx.lineTo(s, -s * 0.12); ctx.lineTo(s * 0.98, s * 0.03); ctx.lineTo(-s * 0.98, s * 0.03); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.fillRect(-s * 0.98, -s * 0.2, s * 1.96, s * 0.03);
  ctx.fillStyle = '#f4f7fb'; ctx.beginPath(); ctx.roundRect(-s * 0.85, -s * 0.5, s * 0.5, s * 0.32, s * 0.03); ctx.fill(); ctx.beginPath(); ctx.roundRect(-s * 0.78, -s * 0.66, s * 0.34, s * 0.17, s * 0.03); ctx.fill();
  ctx.fillStyle = '#1d2a3a'; for (let i = 0; i < 5; i++) ctx.fillRect(-s * 0.8 + i * s * 0.09, -s * 0.42, s * 0.055, s * 0.06); for (let i = 0; i < 3; i++) ctx.fillRect(-s * 0.74 + i * s * 0.09, -s * 0.6, s * 0.055, s * 0.05);
  ctx.fillStyle = '#e8b04a'; ctx.fillRect(-s * 0.62, -s * 0.84, s * 0.04, s * 0.18);
  if (o.tanks !== false) { ctx.fillStyle = '#7d8a99'; ctx.beginPath(); ctx.roundRect(-s * 0.2, -s * 0.34, s * 0.55, s * 0.16, s * 0.03); ctx.fill(); ctx.strokeStyle = '#222b36'; ctx.lineWidth = s * 0.012; for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.moveTo(-s * 0.17 + i * s * 0.09, -s * 0.33); ctx.lineTo(-s * 0.17 + i * s * 0.09, -s * 0.19); ctx.stroke(); } }
  ctx.strokeStyle = '#e8b04a'; ctx.lineWidth = s * 0.035; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(s * 0.62, -s * 0.15); ctx.lineTo(s * 0.86, -s * 0.52); ctx.lineTo(s * 1.0, -s * 0.15); ctx.stroke();
  const sx = s * 1.02, sy = -s * 0.16; ctx.fillStyle = '#d9dee5'; ctx.beginPath(); ctx.arc(sx, sy, s * 0.07, 0, TAU); ctx.fill(); ctx.fillStyle = '#4a5563'; ctx.beginPath(); ctx.arc(sx, sy, s * 0.025, 0, TAU); ctx.fill();
  ctx.restore();
  return [x + fl * (sx * Math.cos(rot) - sy * Math.sin(rot)), y + bob + sx * Math.sin(rot) + sy * Math.cos(rot)];
 };
 // Corte transversal de un cable submarino de fibra óptica (de dentro hacia fuera): fibras en gel dentro de un tubo de acero,
 // hilos de acero (resistencia), conductor de cobre (lleva la energía a los repetidores), aislante de polietileno y, si o.armor,
 // armadura de alambres y cubierta exterior (cables de aguas someras). o.p 0..1 revela las capas de dentro afuera.
 // Devuelve [{ id, r }] con el radio medio de cada capa (para rotular con flechas).
 P.cableSection = (ctx, x, y, r, o = {}) => {
  const arm = !!o.armor, p = o.p ?? 1, Lr = arm ? { tube: 0.17, steel: 0.36, cu: 0.42, pe: 0.72, arm: 0.92, out: 1 } : { tube: 0.2, steel: 0.44, cu: 0.52, pe: 1 };
  const ids = arm ? ['fibras', 'acero', 'cobre', 'polietileno', 'armadura', 'cubierta'] : ['fibras', 'acero', 'cobre', 'polietileno'];
  const vis = (i) => cl((p * ids.length - (ids.length - 1 - i)) * 1.2); // capa exterior primero en aparecer al abrir (p sube: aparecen las de dentro al final)
  const ring = (r0, r1, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r1 * r, 0, TAU); ctx.arc(x, y, r0 * r, 0, TAU, true); ctx.fill(); };
  ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.arc(x + r * 0.04, y + r * 0.08, r, 0, TAU); ctx.fill();
  const order = arm ? [['cubierta', Lr.arm, Lr.out], ['armadura', Lr.pe, Lr.arm], ['polietileno', Lr.cu, Lr.pe], ['cobre', Lr.steel, Lr.cu], ['acero', Lr.tube, Lr.steel], ['fibras', 0, Lr.tube]] : [['polietileno', Lr.cu, Lr.pe], ['cobre', Lr.steel, Lr.cu], ['acero', Lr.tube, Lr.steel], ['fibras', 0, Lr.tube]];
  const out = [];
  for (const [id, r0, r1] of order) {
   const a = vis(ids.indexOf(id)); out.push({ id, r: ((r0 + r1) / 2) * r, r0: r0 * r, r1: r1 * r }); if (a <= 0) continue; ctx.globalAlpha = a;
   if (id === 'cubierta') ring(r0, r1, '#2b2a24');
   else if (id === 'armadura') { ring(r0, r1, '#3b434d'); const n = 22, wr = (r1 - r0) * r * 0.5; for (let i = 0; i < n; i++) { const an = i / n * TAU, rr = (r0 + r1) / 2 * r; ctx.fillStyle = '#9aa5b2'; ctx.beginPath(); ctx.arc(x + Math.cos(an) * rr, y + Math.sin(an) * rr, wr * 0.95, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(x + Math.cos(an) * rr - wr * 0.3, y + Math.sin(an) * rr - wr * 0.3, wr * 0.35, 0, TAU); ctx.fill(); } }
   else if (id === 'polietileno') { const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r1 * r); g.addColorStop(0, '#f6f8fb'); g.addColorStop(1, '#c9d1db'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r1 * r, 0, TAU); ctx.arc(x, y, r0 * r, 0, TAU, true); ctx.fill(); }
   else if (id === 'cobre') ring(r0, r1, '#d9823b');
   else if (id === 'acero') { ring(r0, r1, '#5f6b78'); for (const [k, n] of [[0.32, 14], [0.75, 20]]) { const rr = (r0 + (r1 - r0) * k) * r, wr = Math.PI * rr / n * 0.92; for (let i = 0; i < n; i++) { const an = i / n * TAU + k; ctx.fillStyle = '#aeb8c4'; ctx.beginPath(); ctx.arc(x + Math.cos(an) * rr, y + Math.sin(an) * rr, wr, 0, TAU); ctx.fill(); } } }
   else { ring(r1 * 0.82, r1, '#c9d2dc'); ctx.fillStyle = '#ffe7a3'; ctx.beginPath(); ctx.arc(x, y, r1 * 0.82 * r, 0, TAU); ctx.fill(); const FC = ['#2f80ed', '#ff9b45', '#2fbf71', '#a0522d', '#8799a8', '#ffffff', '#e8505b', '#1d1b3a']; FC.forEach((c, i) => { const an = i / FC.length * TAU, rr = r1 * 0.45 * r; ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x + Math.cos(an) * rr, y + Math.sin(an) * rr, r1 * 0.13 * r, 0, TAU); ctx.fill(); }); }
  }
  ctx.restore(); return out;
 };
 // Fibra óptica vista de lado: revestimiento (cladding) de vidrio y núcleo; la luz va GUIADA dentro del núcleo como pulsos
 // (no como un rayo en zigzag). o: { bits ('1011…' patrón que se repite), gap px entre bits, speed px/s, att 0..1 (pérdida de brillo
 // a lo largo de cada tramo), boost [x…] (amplificadores: el brillo se recupera), c 'r,g,b', a, labels }
 P.fiber = (ctx, x0, x1, y, h, t, o = {}) => {
  const a = o.a ?? 1; if (a <= 0) return; const c = o.c || '73,230,255', bits = o.bits || '1101001110', gap = o.gap || 46, sp = o.speed || 420, ch = h * (o.core || 0.32);
  ctx.save(); ctx.globalAlpha *= a;
  const g = ctx.createLinearGradient(0, y - h / 2, 0, y + h / 2); g.addColorStop(0, 'rgba(200,235,255,0.35)'); g.addColorStop(0.5, 'rgba(200,235,255,0.12)'); g.addColorStop(1, 'rgba(200,235,255,0.35)'); ctx.fillStyle = g; ctx.fillRect(x0, y - h / 2, x1 - x0, h);
  ctx.strokeStyle = 'rgba(220,240,255,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(x0, y - h / 2, x1 - x0, h);
  ctx.fillStyle = `rgba(${c},0.14)`; ctx.fillRect(x0, y - ch / 2, x1 - x0, ch);
  const boosts = [x0, ...(o.boost || [])].sort((p, q) => p - q), att = o.att || 0;
  const bright = (x) => { let b0 = x0, b1 = x1; for (let i = 0; i < boosts.length; i++) if (boosts[i] <= x) { b0 = boosts[i]; b1 = boosts[i + 1] ?? x1; } return 1 - att * (x - b0) / Math.max(1, b1 - b0); };
  ctx.beginPath(); ctx.rect(x0, y - h / 2, x1 - x0, h); ctx.clip(); ctx.globalCompositeOperation = 'lighter';
  const head = t * sp, mA = Math.floor((head - (x1 - x0) - gap) / gap), mB = Math.floor((head + gap) / gap);
  for (let m = mA; m <= mB; m++) { const xx = x0 + head - m * gap; if (bits[((m % bits.length) + bits.length) % bits.length] !== '1' || xx < x0 - gap || xx > x1 + gap) continue; const b = cl(bright(cl(xx, x0, x1))); if (b <= 0.02) continue;
   ctx.save(); ctx.translate(xx, y); ctx.scale(2.6, 1); P.glow(ctx, 0, 0, ch * 1.3, c, 0.85 * b); ctx.restore(); ctx.fillStyle = `rgba(240,255,255,${0.9 * b})`; ctx.beginPath(); ctx.ellipse(xx, y, gap * 0.28, ch * 0.32, 0, 0, TAU); ctx.fill(); }
  ctx.restore();
 };
 // Repetidor submarino (carcasa cilíndrica con conos, en línea con el cable). glow 0..1 = amplificando (luz que se reaviva).
 P.repeater = (ctx, x, y, s, ang = 0, glow = 0) => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  const g = ctx.createLinearGradient(0, -s * 0.35, 0, s * 0.35); g.addColorStop(0, '#c9d2dc'); g.addColorStop(0.5, '#8794a3'); g.addColorStop(1, '#4b5664'); ctx.fillStyle = g;
  ctx.beginPath(); ctx.moveTo(-s * 1.3, -s * 0.1); ctx.lineTo(-s * 0.9, -s * 0.33); ctx.lineTo(s * 0.9, -s * 0.33); ctx.lineTo(s * 1.3, -s * 0.1); ctx.lineTo(s * 1.3, s * 0.1); ctx.lineTo(s * 0.9, s * 0.33); ctx.lineTo(-s * 0.9, s * 0.33); ctx.lineTo(-s * 1.3, s * 0.1); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#3b4552'; for (const k of [-0.55, 0, 0.55]) ctx.fillRect(s * k - s * 0.04, -s * 0.33, s * 0.08, s * 0.66);
  if (glow > 0) { P.glow(ctx, 0, 0, s * 1.6, '70,245,188', 0.55 * glow); ctx.fillStyle = `rgba(70,245,188,${0.9 * glow})`; ctx.beginPath(); ctx.arc(0, 0, s * 0.12, 0, TAU); ctx.fill(); }
  ctx.restore();
 };
 // Mapa del mundo ESTILIZADO (contornos simplificados, proyección equirrectangular). NO sirve para rutas exactas.
 // o: { lon0, lon1, lat0, lat1 (ventana), sea, land, coast, grid, round }. Devuelve proj([lon, lat]) → [px, py].
 const LAND = [
  [[-168, 66], [-140, 70], [-110, 72], [-85, 70], [-75, 62], [-62, 58], [-55, 50], [-66, 44], [-76, 35], [-81, 25], [-90, 29], [-97, 26], [-97, 20], [-87, 21], [-84, 10], [-78, 8], [-90, 14], [-105, 20], [-112, 30], [-118, 34], [-124, 40], [-124, 48], [-132, 55], [-150, 60], [-165, 60]],
  [[-52, 82], [-25, 82], [-20, 70], [-42, 60], [-55, 68]],
  [[-78, 8], [-60, 10], [-50, 0], [-35, -6], [-40, -22], [-48, -28], [-58, -38], [-65, -55], [-72, -50], [-73, -38], [-71, -18], [-81, -5], [-78, 2]],
  [[-10, 36], [-9, 43], [-1, 46], [-4, 48], [2, 51], [8, 54], [10, 57], [5, 62], [15, 69], [30, 71], [45, 68], [70, 73], [100, 77], [140, 72], [170, 69], [180, 66], [160, 60], [142, 52], [140, 42], [130, 35], [122, 31], [120, 23], [110, 20], [108, 12], [104, 1], [100, 8], [98, 16], [92, 22], [80, 15], [77, 8], [72, 20], [66, 25], [57, 25], [56, 26], [58, 22], [52, 16], [44, 12], [42, 18], [35, 28], [33, 31], [35, 36], [27, 37], [26, 40], [23, 36], [20, 40], [14, 40], [12, 44], [8, 44], [3, 43], [-1, 37], [-5, 36]],
  [[-17, 21], [-16, 12], [-8, 4], [5, 5], [9, 4], [10, -3], [13, -12], [12, -18], [18, -34], [26, -34], [33, -26], [40, -16], [40, -5], [44, 2], [51, 11], [43, 11], [37, 18], [33, 30], [22, 32], [11, 33], [10, 37], [-1, 36], [-6, 35], [-10, 30]],
  [[114, -22], [122, -18], [130, -12], [137, -12], [142, -11], [146, -19], [153, -26], [150, -37], [140, -38], [132, -32], [115, -34]],
  [[-5, 50], [1, 51], [0, 53], [-3, 56], [-6, 58], [-5, 55]], [[130, 31], [136, 34], [140, 36], [142, 40], [141, 45], [139, 38]],
  [[44, -25], [47, -25], [50, -15], [49, -12]], [[172, -34], [178, -38], [174, -41], [167, -46]], [[95, 5], [105, -6], [115, -8], [120, -9], [110, -3], [100, 2]], [[110, 2], [118, 6], [119, -2], [114, -4]],
 ];
 P.worldMap = (ctx, x, y, w, h, o = {}) => {
  const lon0 = o.lon0 ?? -180, lon1 = o.lon1 ?? 180, lat0 = o.lat0 ?? -60, lat1 = o.lat1 ?? 80;
  const proj = ([lo, la]) => [x + (lo - lon0) / (lon1 - lon0) * w, y + (lat1 - la) / (lat1 - lat0) * h];
  ctx.save(); ctx.beginPath(); ctx.roundRect(x, y, w, h, o.round ?? 0); ctx.clip(); ctx.fillStyle = o.sea || '#062A46'; ctx.fillRect(x, y, w, h);
  if (o.grid !== false) { ctx.strokeStyle = 'rgba(135,153,168,0.16)'; ctx.lineWidth = 1.5; for (let lo = -180; lo <= 180; lo += 30) { const [px] = proj([lo, 0]); ctx.beginPath(); ctx.moveTo(px, y); ctx.lineTo(px, y + h); ctx.stroke(); } for (let la = -60; la <= 80; la += 20) { const [, py] = proj([0, la]); ctx.beginPath(); ctx.moveTo(x, py); ctx.lineTo(x + w, py); ctx.stroke(); } }
  for (const poly of LAND) { const pts = poly.map(proj), n = pts.length; ctx.beginPath(); const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; let m = mid(pts[n - 1], pts[0]); ctx.moveTo(m[0], m[1]); for (let i = 0; i < n; i++) { const q = mid(pts[i], pts[(i + 1) % n]); ctx.quadraticCurveTo(pts[i][0], pts[i][1], q[0], q[1]); } ctx.closePath(); ctx.fillStyle = o.land || '#123a58'; ctx.fill(); ctx.strokeStyle = o.coast || 'rgba(73,230,255,0.45)'; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.restore(); return proj;
 };
 // Ruta de cable luminosa que se dibuja (prog 0..1) con paquetes de luz que viajan por ella. pts en píxeles (pasan por P.spline).
 // o: { c 'r,g,b', w, speed px/s, dots, a, smooth (false = tal cual) } · devuelve el objeto P.path de la ruta.
 P.cableRoute = (ctx, pts, prog, t, o = {}) => {
  const a = o.a ?? 1; if (a <= 0 || prog <= 0) return null; const pp = o.smooth === false ? pts : P.spline(pts, 12), L = P.path(pp), end = L.L * cl(prog), c = o.c || '73,230,255', w = o.w || 5;
  const part = [pp[0]]; let acc = 0; for (let i = 1; i < pp.length; i++) { acc += Math.hypot(pp[i][0] - pp[i - 1][0], pp[i][1] - pp[i - 1][1]); if (acc >= end) { const q = L.at(end); part.push([q[0], q[1]]); break; } part.push(pp[i]); }
  ctx.save(); ctx.globalAlpha *= a; P.strokePath(ctx, part, w * 3.2, `rgba(${c},0.18)`); P.strokePath(ctx, part, w, `rgba(${c},0.95)`);
  const nd = o.dots ?? Math.max(1, Math.round(L.L / 160)), sp = o.speed || 260; ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < nd; i++) { const s = ((t * sp + i * L.L / nd) % L.L); if (s > end) continue; const [dx, dy] = L.at(s); P.glow(ctx, dx, dy, w * 4, c, 0.9); ctx.fillStyle = '#f4faff'; ctx.beginPath(); ctx.arc(dx, dy, w * 0.75, 0, TAU); ctx.fill(); }
  ctx.restore(); return L;
 };
 // Regla vertical de profundidad: 0 m arriba (y0) → max abajo (y1); marcador en v metros con etiqueta. o: { step, a, c, fmt, side ('right') }
 P.depthGauge = (ctx, x, y0, y1, v, max, o = {}) => {
  const a = o.a ?? 1; if (a <= 0) return; const step = o.step || max / 4, c = o.c || 'rgba(244,250,255,0.85)', fmt = o.fmt || ((m) => (m > 0 ? '−' : '') + Math.round(m).toLocaleString('es-CO') + ' m'), sd = o.side === 'left' ? -1 : 1;
  ctx.save(); ctx.globalAlpha *= a; ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1); ctx.stroke();
  ctx.font = '600 24px "IBM Plex Mono"'; ctx.textAlign = sd > 0 ? 'left' : 'right'; ctx.textBaseline = 'middle';
  for (let m = 0; m <= max + 1e-6; m += step) { const yy = lerp(y0, y1, m / max); ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + sd * 18, yy); ctx.stroke(); ctx.globalAlpha = a * 0.7; ctx.fillText(fmt(m), x + sd * 28, yy); ctx.globalAlpha = a; }
  const my = lerp(y0, y1, cl(v / max)); ctx.fillStyle = '#FFD447'; ctx.beginPath(); ctx.moveTo(x - sd * 6, my); ctx.lineTo(x - sd * 34, my - 16); ctx.lineTo(x - sd * 34, my + 16); ctx.closePath(); ctx.fill();
  ctx.restore();
 };
 // ROV (vehículo submarino operado a distancia, con cable umbilical): chasis amarillo, flotador, propulsores y focos. o: { light, arm 0..1, umb [x,y] }
 P.rov = (ctx, x, y, s, t, o = {}) => {
  const bob = Math.sin(t * 2.1) * s * 0.03; ctx.save();
  if (o.umb) { ctx.strokeStyle = '#FFD447'; ctx.lineWidth = Math.max(2, s * 0.03); ctx.beginPath(); ctx.moveTo(o.umb[0], o.umb[1]); ctx.quadraticCurveTo((o.umb[0] + x) / 2 + s * 0.6, (o.umb[1] + y) / 2, x, y - s * 0.45 + bob); ctx.stroke(); }
  ctx.translate(x, y + bob);
  if (o.light) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(-s * 0.7, s * 0.1, 0, -s * 0.7, s * 0.1, s * 3); g.addColorStop(0, 'rgba(255,250,210,0.45)'); g.addColorStop(1, 'rgba(255,250,210,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-s * 0.7, s * 0.05); ctx.lineTo(-s * 3.2, s * 1.4); ctx.lineTo(-s * 3.2, -s * 0.5); ctx.closePath(); ctx.fill(); ctx.restore(); }
  ctx.fillStyle = '#f4c430'; ctx.beginPath(); ctx.roundRect(-s * 0.7, -s * 0.45, s * 1.4, s * 0.32, s * 0.08); ctx.fill();
  ctx.strokeStyle = '#3b4552'; ctx.lineWidth = s * 0.06; ctx.strokeRect(-s * 0.66, -s * 0.13, s * 1.32, s * 0.42);
  ctx.fillStyle = '#5f6b78'; ctx.fillRect(-s * 0.5, -s * 0.08, s * 0.7, s * 0.3);
  for (const k of [-0.55, 0.55]) { ctx.fillStyle = '#222b36'; ctx.beginPath(); ctx.roundRect(s * k - s * 0.14, s * 0.18, s * 0.28, s * 0.16, s * 0.05); ctx.fill(); }
  ctx.fillStyle = '#fffbe0'; ctx.beginPath(); ctx.arc(-s * 0.68, s * 0.05, s * 0.07, 0, TAU); ctx.fill();
  const am = o.arm ?? 0.3; ctx.strokeStyle = '#aeb8c4'; ctx.lineWidth = s * 0.05; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-s * 0.5, s * 0.25); ctx.lineTo(-s * 0.75, s * (0.35 + am * 0.3)); ctx.lineTo(-s * 0.95, s * (0.3 + am * 0.5)); ctx.stroke();
  ctx.restore();
 };
 // Arado submarino remolcado (perfil): avanza sobre patines, abre una zanja con la reja y deja el cable enterrado detrás.
 P.plow = (ctx, x, y, s, t, o = {}) => {
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = '#e8b04a'; ctx.beginPath(); ctx.roundRect(-s * 0.6, -s * 0.5, s * 1.2, s * 0.32, s * 0.06); ctx.fill();
  ctx.strokeStyle = '#3b4552'; ctx.lineWidth = s * 0.06; ctx.beginPath(); ctx.moveTo(-s * 0.55, -s * 0.18); ctx.lineTo(-s * 0.8, 0); ctx.lineTo(-s * 0.2, 0); ctx.moveTo(s * 0.55, -s * 0.18); ctx.lineTo(s * 0.4, 0); ctx.lineTo(s * 0.8, 0); ctx.stroke();
  ctx.fillStyle = '#5f6b78'; ctx.beginPath(); ctx.moveTo(s * 0.05, -s * 0.2); ctx.lineTo(s * 0.25, -s * 0.2); ctx.lineTo(s * 0.2, s * 0.45); ctx.lineTo(0, s * 0.35); ctx.closePath(); ctx.fill();
  const R = H.rng(Math.floor(t * 8)); ctx.fillStyle = 'rgba(160,140,110,0.45)'; for (let i = 0; i < 8; i++) { ctx.beginPath(); ctx.arc(s * (0.1 + R() * 0.6), -s * R() * 0.25, s * R.range(0.03, 0.08), 0, TAU); ctx.fill(); }
  ctx.restore();
 };
 // Ancla (con argolla, caña, cepo y uñas) y garfio de recuperación (rezón).
 P.anchor = (ctx, x, y, s, rot = 0, c = '#8799A8') => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.strokeStyle = c; ctx.lineWidth = s * 0.12; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(0, -s * 0.85, s * 0.14, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, -s * 0.7); ctx.lineTo(0, s * 0.5); ctx.moveTo(-s * 0.32, -s * 0.48); ctx.lineTo(s * 0.32, -s * 0.48); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, s * 0.55, 0.25, Math.PI - 0.25); ctx.stroke(); ctx.fillStyle = c; for (const sd of [-1, 1]) { const ax = sd * Math.cos(0.25) * s * 0.55, ay = Math.sin(0.25) * s * 0.55; ctx.beginPath(); ctx.moveTo(ax + sd * s * 0.1, ay - s * 0.2); ctx.lineTo(ax - sd * s * 0.15, ay - s * 0.05); ctx.lineTo(ax + sd * s * 0.12, ay + s * 0.08); ctx.closePath(); ctx.fill(); }
  ctx.restore();
 };
 P.grapnel = (ctx, x, y, s, rot = 0, c = '#c9d2dc') => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.strokeStyle = c; ctx.lineWidth = s * 0.12; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(0, -s * 0.8); ctx.lineTo(0, s * 0.3); ctx.stroke(); for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(0, s * 0.3); ctx.quadraticCurveTo(sd * s * 0.5, s * 0.35, sd * s * 0.5, -s * 0.15); ctx.stroke(); }
  ctx.beginPath(); ctx.arc(0, -s * 0.9, s * 0.1, 0, TAU); ctx.stroke(); ctx.restore();
 };
 // Estación de aterrizaje del cable en la costa (edificio técnico donde el cable submarino se conecta a la red terrestre).
 P.station = (ctx, x, y, s, o = {}) => {
  ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x - s * 0.55, y - 4, s * 1.2, 10);
  ctx.fillStyle = o.c || '#e9eef4'; ctx.fillRect(x - s * 0.5, y - s * 0.6, s, s * 0.6); ctx.fillStyle = '#8799A8'; ctx.fillRect(x - s * 0.56, y - s * 0.66, s * 1.12, s * 0.08);
  ctx.fillStyle = '#167BFF'; for (let i = 0; i < 3; i++) ctx.fillRect(x - s * 0.38 + i * s * 0.28, y - s * 0.45, s * 0.18, s * 0.14);
  ctx.fillStyle = '#5f6b78'; ctx.fillRect(x - s * 0.1, y - s * 0.24, s * 0.2, s * 0.24);
  if (o.on) { ctx.fillStyle = '#46F5BC'; ctx.beginPath(); ctx.arc(x + s * 0.36, y - s * 0.16, s * 0.05, 0, TAU); ctx.fill(); }
  ctx.restore();
 };

 // ======================= v1.7 · AGUA, ENERGÍA Y ELECTRICIDAD (centrales, máquinas, red eléctrica) =======================
 const polyPath = (ctx, pts) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); };
 // Masa de agua (embalse, río, canal) en un polígono: degradado por profundidad entre o.top y o.bottom y, si o.surf = [x0, x1, y],
 // superficie con brillo que se mueve. o: { c1, c2, c3, a }
 P.waterBody = (ctx, pts, t, o = {}) => {
  const ys = pts.map((p) => p[1]), top = o.top ?? Math.min(...ys), bot = o.bottom ?? Math.max(...ys);
  ctx.save(); ctx.globalAlpha *= o.a ?? 1; const g = ctx.createLinearGradient(0, top, 0, bot); g.addColorStop(0, o.c1 || '#38C9FF'); g.addColorStop(0.18, o.c2 || '#1a86c8'); g.addColorStop(1, o.c3 || '#0a3358'); ctx.fillStyle = g; polyPath(ctx, pts); ctx.fill();
  if (o.surf) { const [x0, x1, y] = o.surf; ctx.clip(); ctx.strokeStyle = 'rgba(245,250,255,0.75)'; ctx.lineWidth = 3; ctx.beginPath(); for (let x = x0; x <= x1; x += 8) { const yy = y + Math.sin(x * 0.03 + t * 2) * 2; x === x0 ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); } ctx.stroke(); ctx.strokeStyle = 'rgba(245,250,255,0.25)'; ctx.lineWidth = 2; for (let k = 0; k < 6; k++) { const xx = x0 + ((k * 0.17 + t * 0.03) % 1) * (x1 - x0), yy = y + 10 + k * 7; ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx + 40 + k * 6, yy); ctx.stroke(); } }
  ctx.restore();
 };
 // Hormigón (represas, muros, edificios técnicos) en un polígono: textura de juntas de vertido y manchas de humedad.
 // o: { c, joints (px entre juntas), stains, light ('left' | 'right') }
 P.concrete = (ctx, pts, o = {}) => {
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  ctx.save(); polyPath(ctx, pts); const g = ctx.createLinearGradient(x0, 0, x1, 0); const c = H.hex(o.c || '#778A99'), dk = H.rgba([c[0] * 0.72, c[1] * 0.72, c[2] * 0.72]), lt = H.rgba([Math.min(255, c[0] * 1.15), Math.min(255, c[1] * 1.15), Math.min(255, c[2] * 1.15)]);
  g.addColorStop(0, o.light === 'right' ? dk : lt); g.addColorStop(1, o.light === 'right' ? lt : dk); ctx.fillStyle = g; ctx.fill(); ctx.clip();
  ctx.strokeStyle = 'rgba(20,30,40,0.22)'; ctx.lineWidth = 2; for (let y = y0 + (o.joints || 46); y < y1; y += o.joints || 46) { ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke(); }
  const R = H.rng(o.seed || 17); for (let i = 0; i < (o.stains ?? 14); i++) { const sx = x0 + R() * (x1 - x0), sy = y0 + R() * (y1 - y0) * 0.6, sh = R.range(40, 200); const sg = ctx.createLinearGradient(0, sy, 0, sy + sh); sg.addColorStop(0, 'rgba(30,40,50,0.18)'); sg.addColorStop(1, 'rgba(30,40,50,0)'); ctx.fillStyle = sg; ctx.fillRect(sx, sy, R.range(4, 14), sh); }
  ctx.restore(); ctx.save(); ctx.strokeStyle = 'rgba(10,20,30,0.5)'; ctx.lineWidth = 3; polyPath(ctx, pts); ctx.stroke(); ctx.restore();
 };
 // Tubería (forzada, conducto) a lo largo de pts: pared metálica, sección transparente y agua que la LLENA y fluye.
 // o: { fill 0..1 (hasta dónde llegó el agua), flow 0..1 (velocidad relativa), speed px/s, glass (pared translúcida), c }
 P.pipe = (ctx, pts, w, t, o = {}) => {
  const L = P.path(pts), fill = cl(o.fill ?? 1), flow = o.flow ?? 1;
  P.strokePath(ctx, pts, w + 14, '#293F52', { cap: 'butt' }); P.strokePath(ctx, pts, w + 6, '#B8CCD8', { cap: 'butt', a: 0.55 });
  P.strokePath(ctx, pts, w, o.glass === false ? '#1b2b3a' : 'rgba(10,30,50,0.9)', { cap: 'butt' });
  if (fill > 0) { const part = []; let acc = 0; part.push(pts[0]); for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); if (acc + d >= L.L * fill) { const q = L.at(L.L * fill); part.push([q[0], q[1]]); break; } acc += d; part.push(pts[i]); }
   P.strokePath(ctx, part, w * 0.86, o.c || '#1a86c8', { cap: 'butt' }); P.strokePath(ctx, part, w * 0.3, 'rgba(56,201,255,0.45)', { cap: 'butt' });
   if (flow > 0) { const sp = (o.speed || 300) * flow, n = Math.ceil(L.L / 70); ctx.save(); ctx.strokeStyle = 'rgba(220,245,255,0.8)'; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(2, w * 0.08); for (let i = 0; i < n; i++) for (const off of [-0.22, 0.05, 0.25]) { const s = ((t * sp + i * 70 + off * 97) % L.L + L.L) % L.L; if (s > L.L * fill - 10) continue; const [x, y, a] = L.at(s), nx = -Math.sin(a) * w * off, ny = Math.cos(a) * w * off, len = Math.min(40, 14 + 26 * flow); ctx.beginPath(); ctx.moveTo(x + nx - Math.cos(a) * len / 2, y + ny - Math.sin(a) * len / 2); ctx.lineTo(x + nx + Math.cos(a) * len / 2, y + ny + Math.sin(a) * len / 2); ctx.stroke(); } ctx.restore(); }
  }
  return L;
 };
 // Compuerta de toma (deslizante vertical con guías). open 0..1 = cuánto se ha levantado.
 P.gate = (ctx, x, y, w, h, open = 0) => {
  ctx.save(); ctx.fillStyle = '#293F52'; ctx.fillRect(x - 10, y - h * 1.1, 10, h * 2.2); ctx.fillRect(x + w, y - h * 1.1, 10, h * 2.2);
  const gy = y - h * open; const g = ctx.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#5d7387'); g.addColorStop(0.5, '#B8CCD8'); g.addColorStop(1, '#5d7387'); ctx.fillStyle = g; ctx.fillRect(x, gy, w, h);
  ctx.strokeStyle = 'rgba(20,30,40,0.6)'; ctx.lineWidth = 2; for (let k = 1; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x, gy + h * k / 4); ctx.lineTo(x + w, gy + h * k / 4); ctx.stroke(); } ctx.fillStyle = '#FF9D4D'; ctx.fillRect(x, gy, w, 6); ctx.restore();
 };
 // Turbina Francis vista desde arriba: carcasa espiral, álabes directrices (FIJOS, se orientan con o.open) y rodete (GIRA con ang).
 // o: { casing, open 0..1, flow 0..1 (trazadores de agua entrando en espiral), t, blades }
 P.francis = (ctx, x, y, r, ang, o = {}) => {
  const t = o.t || 0, flow = o.flow ?? 0; ctx.save();
  if (o.casing !== false) { ctx.fillStyle = '#293F52'; ctx.beginPath(); for (let k = 0; k <= 64; k++) { const a = -Math.PI / 2 + k / 64 * TAU, rr = r * (1.02 + 0.5 * (1 - k / 64)); const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.lineTo(x + r * 1.52, y - r * 1.52); ctx.lineTo(x + r * 1.95, y - r * 1.52); ctx.lineTo(x + r * 1.95, y - r * 0.6); ctx.lineTo(x + r * 1.02, y - r * 0.1); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#B8CCD8'; ctx.lineWidth = 3; ctx.stroke();
   ctx.fillStyle = 'rgba(18,104,168,0.85)'; ctx.beginPath(); ctx.arc(x, y, r * 1.0, 0, TAU); ctx.fill(); }
  if (flow > 0) { ctx.save(); ctx.strokeStyle = `rgba(200,240,255,${0.75 * flow})`; ctx.lineWidth = Math.max(2, r * 0.018); ctx.lineCap = 'round'; for (let i = 0; i < 26; i++) { const u = ((t * 0.5 * flow + i / 26) % 1), a = -Math.PI / 2 + u * TAU * 1.15 + i * 0.7, rr = r * (1.45 - u * 0.75); ctx.beginPath(); ctx.arc(x, y, rr, a, a + 0.25); ctx.stroke(); } ctx.restore(); }
  const nv = 18, op = o.open ?? 0.7; for (let i = 0; i < nv; i++) { const a = i / nv * TAU, px = x + Math.cos(a) * r * 0.88, py = y + Math.sin(a) * r * 0.88; ctx.save(); ctx.translate(px, py); ctx.rotate(a + Math.PI / 2 + 0.5 + (1 - op) * 0.9); ctx.fillStyle = '#9fb3c2'; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.1, r * 0.028, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  ctx.fillStyle = '#3b5266'; ctx.beginPath(); ctx.arc(x, y, r * 0.74, 0, TAU); ctx.fill();
  const nb = o.blades || 13; ctx.strokeStyle = '#d6e3ec'; ctx.lineWidth = r * 0.05; ctx.lineCap = 'round'; for (let i = 0; i < nb; i++) { const a = ang + i / nb * TAU; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.7, y + Math.sin(a) * r * 0.7); ctx.quadraticCurveTo(x + Math.cos(a + 0.45) * r * 0.48, y + Math.sin(a + 0.45) * r * 0.48, x + Math.cos(a + 0.75) * r * 0.24, y + Math.sin(a + 0.75) * r * 0.24); ctx.stroke(); }
  ctx.fillStyle = '#B8CCD8'; ctx.beginPath(); ctx.arc(x, y, r * 0.22, 0, TAU); ctx.fill(); ctx.fillStyle = '#293F52'; ctx.beginPath(); ctx.arc(x, y, r * 0.12, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#FF9D4D'; ctx.lineWidth = r * 0.03; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(ang) * r * 0.12, y + Math.sin(ang) * r * 0.12); ctx.stroke();
  ctx.restore();
 };
 // Rueda de molino (de paletas, madera) que gira con ang
 P.waterwheel = (ctx, x, y, r, ang, o = {}) => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.strokeStyle = o.c || '#8a5a32'; ctx.lineWidth = r * 0.06; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, r * 0.82, 0, TAU); ctx.stroke();
  const n = 12; for (let i = 0; i < n; i++) { const a = i / n * TAU; ctx.lineWidth = r * 0.05; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * r * 0.82, Math.sin(a) * r * 0.82); ctx.stroke(); ctx.save(); ctx.rotate(a); ctx.fillStyle = '#a8703f'; ctx.fillRect(r * 0.8, -r * 0.05, r * 0.32, r * 0.1); ctx.restore(); }
  ctx.fillStyle = '#5a3a20'; ctx.beginPath(); ctx.arc(0, 0, r * 0.14, 0, TAU); ctx.fill(); ctx.restore();
 };
 // Generador en corte (vista desde el eje): ESTATOR fijo con bobinas y ROTOR que gira con polos N/S (electroimanes).
 // o: { poles (par), slots, field 0..1 (líneas de campo conceptuales), current 0..1 (bobinas que se encienden al pasar un polo) }
 P.genSection = (ctx, x, y, r, ang, o = {}) => {
  const np = o.poles || 8, ns = o.slots || 36, field = o.field ?? 0, cur = o.current ?? 0; ctx.save();
  ctx.fillStyle = '#293F52'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.arc(x, y, r * 0.7, 0, TAU, true); ctx.fill(); ctx.strokeStyle = '#B8CCD8'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
  for (let i = 0; i < ns; i++) { const a = i / ns * TAU, k = Math.abs(Math.cos(np / 2 * (a - ang))), lit = cur * Math.pow(k, 6); const cx = x + Math.cos(a) * r * 0.8, cy = y + Math.sin(a) * r * 0.8; ctx.save(); ctx.translate(cx, cy); ctx.rotate(a); ctx.fillStyle = '#c47a3a'; ctx.fillRect(-r * 0.09, -r * 0.035, r * 0.18, r * 0.07); if (lit > 0.03) { ctx.fillStyle = `rgba(255,212,71,${lit})`; ctx.fillRect(-r * 0.09, -r * 0.035, r * 0.18, r * 0.07); } ctx.restore(); if (lit > 0.3) P.glow(ctx, cx, cy, r * 0.12, '255,212,71', 0.5 * lit); }
  ctx.fillStyle = '#16283a'; ctx.beginPath(); ctx.arc(x, y, r * 0.69, 0, TAU); ctx.fill();
  for (let i = 0; i < np; i++) { const a = ang + i / np * TAU, N = i % 2 === 0; ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.fillStyle = N ? '#d9534f' : '#3f7fd1'; ctx.beginPath(); ctx.moveTo(r * 0.3, -r * 0.1); ctx.lineTo(r * 0.62, -r * 0.17); ctx.arc(0, 0, r * 0.64, -0.27, 0.27); ctx.lineTo(r * 0.3, r * 0.1); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#c47a3a'; ctx.fillRect(r * 0.33, -r * 0.13, r * 0.2, r * 0.26); ctx.restore();
   const lx = x + Math.cos(a) * r * 0.5, ly = y + Math.sin(a) * r * 0.5; ctx.save(); ctx.fillStyle = '#F5FAFF'; ctx.font = `800 ${r * 0.09}px Nunito`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(N ? 'N' : 'S', lx, ly); ctx.restore(); }
  if (field > 0) { ctx.save(); ctx.strokeStyle = `rgba(85,232,255,${0.55 * field})`; ctx.lineWidth = 2.5; ctx.setLineDash([8, 7]); ctx.lineDashOffset = -(o.t || 0) * 30; for (let i = 0; i < np; i++) { const a0 = ang + i / np * TAU, a1 = ang + (i + 1) / np * TAU; for (const k of [0.66, 0.74]) { ctx.beginPath(); ctx.moveTo(x + Math.cos(a0) * r * 0.64, y + Math.sin(a0) * r * 0.64); const am = (a0 + a1) / 2; ctx.quadraticCurveTo(x + Math.cos(am) * r * (k + 0.3), y + Math.sin(am) * r * (k + 0.3), x + Math.cos(a1) * r * 0.64, y + Math.sin(a1) * r * 0.64); ctx.stroke(); } } ctx.restore(); }
  ctx.fillStyle = '#B8CCD8'; ctx.beginPath(); ctx.arc(x, y, r * 0.2, 0, TAU); ctx.fill(); ctx.fillStyle = '#293F52'; ctx.beginPath(); ctx.arc(x, y, r * 0.1, 0, TAU); ctx.fill();
  ctx.restore();
 };
 // Onda de corriente alterna que avanza (osciloscopio). o: { cycles, c, a, phases (1 o 3), lw, grid }
 P.sine = (ctx, x, y, w, h, t, o = {}) => {
  const a = o.a ?? 1; if (a <= 0) return; const cyc = o.cycles || 3, ph = o.phases || 1, cols = o.c ? [o.c] : ['#FFD447', '#FF9D4D', '#55E8FF']; ctx.save(); ctx.globalAlpha *= a;
  if (o.grid !== false) { ctx.strokeStyle = 'rgba(245,250,255,0.18)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.stroke(); }
  for (let p = 0; p < ph; p++) { ctx.strokeStyle = cols[p % cols.length]; ctx.lineWidth = o.lw || 5; ctx.beginPath(); for (let i = 0; i <= w; i += 3) { const yy = y - Math.sin((i / w) * cyc * TAU - t * (o.speed || 6) + p * TAU / 3) * h / 2 * (o.amp ?? 1); i ? ctx.lineTo(x + i, yy) : ctx.moveTo(x + i, yy); } ctx.stroke(); }
  ctx.restore();
 };
 // Transformador: núcleo laminado y dos devanados (n1 vueltas a la izquierda, n2 a la derecha). n2 > n1 = eleva la tensión.
 // El flujo magnético (conceptual) recorre el núcleo. o: { n1, n2, flux 0..1, t, glow1, glow2 }
 P.transformer = (ctx, x, y, s, o = {}) => {
  const n1 = o.n1 || 4, n2 = o.n2 || 12, w = s * 1.6, h = s * 1.2, th = s * 0.26; ctx.save();
  ctx.fillStyle = '#5d6f80'; ctx.fillRect(x - w / 2, y - h / 2, w, h); ctx.fillStyle = o.bg || '#061522'; ctx.fillRect(x - w / 2 + th, y - h / 2 + th, w - 2 * th, h - 2 * th);
  ctx.strokeStyle = 'rgba(20,30,40,0.35)'; ctx.lineWidth = 1; for (let k = 4; k < th; k += 5) { ctx.strokeRect(x - w / 2 + k, y - h / 2 + k, w - 2 * k, h - 2 * k); }
  if ((o.flux ?? 0) > 0) { ctx.strokeStyle = `rgba(85,232,255,${0.7 * o.flux})`; ctx.lineWidth = 3; ctx.setLineDash([10, 8]); ctx.lineDashOffset = -(o.t || 0) * 60; ctx.strokeRect(x - w / 2 + th / 2, y - h / 2 + th / 2, w - th, h - th); ctx.setLineDash([]); }
  const coil = (cx, n, g) => { const ch = h - 2 * th + 10; for (let i = 0; i < n; i++) { const yy = y - ch / 2 + (i + 0.5) * ch / n; ctx.strokeStyle = '#c47a3a'; ctx.lineWidth = Math.max(3, ch / n * 0.7); ctx.beginPath(); ctx.ellipse(cx, yy, th * 0.85, ch / n * 0.4, 0, 0, TAU); ctx.stroke(); if (g > 0) { ctx.strokeStyle = `rgba(255,212,71,${g})`; ctx.stroke(); } } };
  coil(x - w / 2 + th / 2, n1, o.glow1 || 0); coil(x + w / 2 - th / 2, n2, o.glow2 || 0);
  ctx.restore();
 };
 // Torre de alta tensión (celosía). Devuelve los 3 puntos de amarre de los cables [[x, y]…].
 P.pylon = (ctx, x, y, h, o = {}) => {
  const c = o.c || '#B8CCD8', w = h * 0.32; ctx.save(); ctx.strokeStyle = c; ctx.lineWidth = Math.max(1.5, h * 0.012); ctx.lineJoin = 'round';
  const top = y - h, legs = [[x - w / 2, y], [x - w * 0.08, top + h * 0.12], [x + w * 0.08, top + h * 0.12], [x + w / 2, y]];
  ctx.beginPath(); ctx.moveTo(...legs[0]); ctx.lineTo(...legs[1]); ctx.moveTo(...legs[3]); ctx.lineTo(...legs[2]); ctx.stroke();
  for (let k = 0; k < 6; k++) { const u0 = k / 6, u1 = (k + 1) / 6, l0 = [lerp(legs[0][0], legs[1][0], u0), lerp(y, top + h * 0.12, u0)], r1 = [lerp(legs[3][0], legs[2][0], u1), lerp(y, top + h * 0.12, u1)], r0 = [lerp(legs[3][0], legs[2][0], u0), lerp(y, top + h * 0.12, u0)], l1 = [lerp(legs[0][0], legs[1][0], u1), lerp(y, top + h * 0.12, u1)]; ctx.beginPath(); ctx.moveTo(...l0); ctx.lineTo(...r1); ctx.moveTo(...r0); ctx.lineTo(...l1); ctx.stroke(); }
  const arms = [top + h * 0.12, top + h * 0.3]; ctx.beginPath(); ctx.moveTo(x - w * 0.75, arms[0]); ctx.lineTo(x + w * 0.75, arms[0]); ctx.moveTo(x - w * 0.55, arms[1]); ctx.lineTo(x + w * 0.55, arms[1]); ctx.moveTo(x, top); ctx.lineTo(x, top + h * 0.12); ctx.stroke(); ctx.restore();
  return [[x - w * 0.75, arms[0] + 8], [x + w * 0.75, arms[0] + 8], [x - w * 0.55, arms[1] + 8]];
 };
 // Cable aéreo con flecha (catenaria) entre a y b; o.dots = paquetes de energía que viajan (amarillo), o.t, o.c, o.w
 P.powerLine = (ctx, a, b, sag, t, o = {}) => {
  const pts = []; for (let i = 0; i <= 20; i++) { const u = i / 20; pts.push([lerp(a[0], b[0], u), lerp(a[1], b[1], u) + sag * 4 * u * (1 - u)]); }
  P.strokePath(ctx, pts, o.w || 2.5, o.c || 'rgba(200,215,225,0.8)');
  if (o.dots) { const L = P.path(pts); for (let k = 0; k < o.dots; k++) { const s = ((t * (o.speed || 200) + k * L.L / o.dots) % L.L); const [x, y] = L.at(s); P.glow(ctx, x, y, 16, '255,212,71', 0.9); P.circle(ctx, x, y, 3.5, '#FFF4C2'); } }
 };
 // Casa (fachada) con ventanas que se encienden (lit 0..1); fábrica con chimenea sin humo; ciudad (siluetas con ventanas)
 P.house = (ctx, x, y, s, lit = 0, o = {}) => {
  ctx.save(); ctx.fillStyle = o.wall || '#d8dee6'; ctx.fillRect(x - s * 0.5, y - s * 0.6, s, s * 0.6); ctx.fillStyle = o.roof || '#a8503c'; ctx.beginPath(); ctx.moveTo(x - s * 0.62, y - s * 0.58); ctx.lineTo(x, y - s * 1.02); ctx.lineTo(x + s * 0.62, y - s * 0.58); ctx.closePath(); ctx.fill();
  for (const dx of [-0.28, 0.28]) { ctx.fillStyle = lit > 0 ? `rgba(255,${200 + 30 * lit},${90 + 40 * lit},${0.35 + 0.65 * lit})` : '#2a3b4c'; ctx.fillRect(x + s * dx - s * 0.12, y - s * 0.45, s * 0.24, s * 0.2); if (lit > 0.2) P.glow(ctx, x + s * dx, y - s * 0.35, s * 0.35, '255,212,71', 0.35 * lit); }
  ctx.fillStyle = '#5b4636'; ctx.fillRect(x - s * 0.08, y - s * 0.3, s * 0.16, s * 0.3); ctx.restore();
 };
 P.factory = (ctx, x, y, s, lit = 0) => {
  ctx.save(); ctx.fillStyle = '#8a97a4'; ctx.fillRect(x - s * 0.7, y - s * 0.5, s * 1.4, s * 0.5); ctx.beginPath(); for (let i = 0; i < 4; i++) { ctx.moveTo(x - s * 0.7 + i * s * 0.35, y - s * 0.5); ctx.lineTo(x - s * 0.7 + i * s * 0.35, y - s * 0.75); ctx.lineTo(x - s * 0.7 + (i + 1) * s * 0.35, y - s * 0.5); } ctx.fill();
  ctx.fillRect(x + s * 0.4, y - s * 1.1, s * 0.14, s * 0.6); for (let i = 0; i < 5; i++) { ctx.fillStyle = lit > 0 ? `rgba(255,220,120,${0.3 + 0.7 * lit})` : '#2a3b4c'; ctx.fillRect(x - s * 0.62 + i * s * 0.26, y - s * 0.35, s * 0.16, s * 0.14); } ctx.restore();
 };
 P.skyline = (ctx, x0, x1, y, lit = 0, seed = 3, o = {}) => {
  const R = H.rng(seed); ctx.save(); let x = x0; while (x < x1) { const bw = R.range(40, 90), bh = R.range(80, o.maxH || 300); ctx.fillStyle = o.c || '#1b2f42'; ctx.fillRect(x, y - bh, bw - 6, bh); for (let wy = y - bh + 12; wy < y - 14; wy += 22) for (let wx = x + 8; wx < x + bw - 18; wx += 16) { const on = R() < lit * 0.9; ctx.fillStyle = on ? 'rgba(255,212,71,0.9)' : 'rgba(80,100,120,0.35)'; ctx.fillRect(wx, wy, 7, 10); } x += bw; } if (lit > 0) P.glow(ctx, (x0 + x1) / 2, y - 80, (x1 - x0) * 0.6, '255,212,71', 0.18 * lit); ctx.restore();
 };
 // Bombilla (on 0..1 = encendida, con halo y rayos) e interruptor de pared
 P.bulb = (ctx, x, y, s, on = 0) => {
  ctx.save(); if (on > 0) { P.glow(ctx, x, y, s * 3.2 * (0.8 + 0.2 * on), '255,226,140', 0.75 * on); ctx.strokeStyle = `rgba(255,226,140,${0.7 * on})`; ctx.lineWidth = s * 0.05; ctx.lineCap = 'round'; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i - 4.5) * 0.32; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * s * 0.85, y + Math.sin(a) * s * 0.85); ctx.lineTo(x + Math.cos(a) * s * 1.25, y + Math.sin(a) * s * 1.25); ctx.stroke(); } }
  ctx.fillStyle = on > 0 ? `rgba(255,${235},${170 + 40 * on},${0.55 + 0.45 * on})` : 'rgba(220,235,245,0.35)'; ctx.beginPath(); ctx.arc(x, y - s * 0.15, s * 0.62, Math.PI * 0.8, Math.PI * 2.2); ctx.lineTo(x + s * 0.28, y + s * 0.55); ctx.lineTo(x - s * 0.28, y + s * 0.55); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(245,250,255,0.8)'; ctx.lineWidth = s * 0.04; ctx.stroke();
  ctx.strokeStyle = on > 0 ? '#fff6d0' : '#8a97a4'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(x - s * 0.15, y + s * 0.4); ctx.lineTo(x - s * 0.15, y); ctx.quadraticCurveTo(x, y - s * 0.25, x + s * 0.15, y); ctx.lineTo(x + s * 0.15, y + s * 0.4); ctx.stroke();
  ctx.fillStyle = '#8a97a4'; for (let k = 0; k < 3; k++) ctx.fillRect(x - s * 0.3, y + s * (0.55 + k * 0.12), s * 0.6, s * 0.09); ctx.restore();
 };
 P.switchWall = (ctx, x, y, s, on = false) => { ctx.save(); P.rr(ctx, x - s * 0.4, y - s * 0.6, s * 0.8, s * 1.2, s * 0.1, '#eef2f6', { sy: 6 }); ctx.fillStyle = '#c9d2dc'; ctx.fillRect(x - s * 0.18, y - s * 0.35, s * 0.36, s * 0.7); ctx.fillStyle = '#ffffff'; ctx.fillRect(x - s * 0.18, on ? y - s * 0.35 : y, s * 0.36, s * 0.35); ctx.restore(); };
 // Nube (con lluvia si o.rain) y sol
 P.cloud = (ctx, x, y, s, o = {}) => {
  ctx.save(); if (o.rain) { ctx.strokeStyle = 'rgba(160,210,240,0.7)'; ctx.lineWidth = 3; const R = H.rng(o.seed || 2); for (let i = 0; i < 18; i++) { const rx = x + R.range(-s * 0.8, s * 0.8), sp = R.range(400, 600), ry = y + ((R() * s * 2 + (o.t || 0) * sp) % (s * 2.2)); ctx.beginPath(); ctx.moveTo(rx, ry); ctx.lineTo(rx - 6, ry + 22); ctx.stroke(); } }
  ctx.fillStyle = o.c || '#dfe8f0'; for (const [dx, dy, r] of [[-0.6, 0.1, 0.42], [-0.15, -0.2, 0.55], [0.4, -0.05, 0.48], [0.8, 0.15, 0.32], [0.1, 0.2, 0.45]]) { ctx.beginPath(); ctx.arc(x + dx * s, y + dy * s, r * s, 0, TAU); ctx.fill(); } ctx.restore();
 };
 P.sun = (ctx, x, y, r, t = 0) => { P.glow(ctx, x, y, r * 3, '255,212,71', 0.5); ctx.save(); ctx.strokeStyle = '#FFD447'; ctx.lineWidth = r * 0.12; ctx.lineCap = 'round'; for (let i = 0; i < 10; i++) { const a = i / 10 * TAU + t * 0.2; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 1.3, y + Math.sin(a) * r * 1.3); ctx.lineTo(x + Math.cos(a) * r * 1.65, y + Math.sin(a) * r * 1.65); ctx.stroke(); } ctx.restore(); P.circle(ctx, x, y, r, '#FFD447'); };
 // Pez (perfil), dir 1 = mira a la derecha
 P.fish = (ctx, x, y, s, dir = 1, c = '#9fd4c8') => { ctx.save(); ctx.translate(x, y); ctx.scale(dir, 1); ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.5, s * 0.22, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(-s * 0.45, 0); ctx.lineTo(-s * 0.8, -s * 0.22); ctx.lineTo(-s * 0.8, s * 0.22); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#061522'; ctx.beginPath(); ctx.arc(s * 0.28, -s * 0.05, s * 0.05, 0, TAU); ctx.fill(); ctx.restore(); };

 // ======================= v1.8 · HISTORIA ANTIGUA Y CONSTRUCCIÓN (pirámides, desierto, trabajo humano) =======================
 // Desierto: cielo cálido (o.sky [arriba, abajo]), sol, dunas en dos planos y suelo de arena. Devuelve yAt(x) del suelo.
 P.desert = (ctx, y, t, o = {}) => {
  const sk = o.sky || ['#f3c27a', '#fbe3b0'], g = ctx.createLinearGradient(0, 0, 0, y); g.addColorStop(0, sk[0]); g.addColorStop(1, sk[1]); ctx.fillStyle = g; ctx.fillRect(0, 0, W, y + 2);
  if (o.sun !== false) { const sx = o.sunX ?? 820, sy = o.sunY ?? 380; P.glow(ctx, sx, sy, 260, '255,230,170', 0.6); P.circle(ctx, sx, sy, 60, '#fff3d6'); }
  const dune = (yy, amp, c, ph) => { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-10, HH); for (let x = -10; x <= W + 10; x += 10) ctx.lineTo(x, yy + Math.sin(x * 0.006 + ph) * amp + Math.sin(x * 0.017 + ph * 2) * amp * 0.3); ctx.lineTo(W + 10, HH); ctx.closePath(); ctx.fill(); };
  dune(y - 40, 26, o.far || '#e2b674', 1.3); const yAt = (x) => y + Math.sin(x * 0.004 + 0.4) * 8;
  ctx.fillStyle = o.ground || '#d9a865'; ctx.beginPath(); ctx.moveTo(-10, HH); for (let x = -10; x <= W + 10; x += 10) ctx.lineTo(x, yAt(x)); ctx.lineTo(W + 10, HH); ctx.closePath(); ctx.fill();
  const R = H.rng(o.seed || 3); ctx.fillStyle = 'rgba(120,80,40,0.18)'; for (let i = 0; i < 80; i++) { const x = R() * W, yy = y + 10 + R() * (HH - y); ctx.fillRect(x, yy, R.range(6, 30), 2); }
  return yAt;
 };
 // Pirámide en vista 3/4 (cara izquierda iluminada, derecha en sombra) hecha por hiladas de bloques.
 // o: { built 0..1 (altura construida: pirámide truncada con plataforma), courses (nº de hiladas visibles), casing 0..1 (revestimiento
 // liso de caliza blanca), lit, shade, joints }. Devuelve { apex, at(face, u, v) } para colocar cosas sobre las caras (u: 0 base → 1 cúspide).
 P.pyramid = (ctx, x, y, w, h, o = {}) => {
  const Lb = [x - w * 0.5, y - w * 0.05], Fb = [x + w * 0.1, y + w * 0.05], Rb = [x + w * 0.5, y - w * 0.07], Bb = [Lb[0] + Rb[0] - Fb[0], Lb[1] + Rb[1] - Fb[1]], Ap = [x + w * 0.04, y - h];
  const L = (p, u) => [lerp(p[0], Ap[0], u), lerp(p[1], Ap[1], u)], ub = cl(o.built ?? 1), n = o.courses || 26;
  const lit = o.lit || '#e2c08a', shade = o.shade || '#a9814f';
  const face = (A, B, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(...A); ctx.lineTo(...B); ctx.lineTo(...L(B, ub)); ctx.lineTo(...L(A, ub)); ctx.closePath(); ctx.fill();
   if ((o.joints ?? 1) > 0) { ctx.save(); ctx.clip(); ctx.strokeStyle = 'rgba(90,60,30,0.35)'; ctx.lineWidth = Math.max(1, w / 900); for (let k = 1; k < n; k++) { const u = k / n; if (u > ub) break; const a = L(A, u), b = L(B, u); ctx.beginPath(); ctx.moveTo(...a); ctx.lineTo(...b); ctx.stroke(); const nb = Math.max(3, Math.round(22 * (1 - u))); for (let j = 0; j < nb; j++) { const v = (j + (k % 2) * 0.5) / nb, u2 = (k + 1) / n; const p0 = [lerp(a[0], b[0], v), lerp(a[1], b[1], v)], a2 = L(A, Math.min(u2, ub)), b2 = L(B, Math.min(u2, ub)); const p1 = [lerp(a2[0], b2[0], v), lerp(a2[1], b2[1], v)]; ctx.beginPath(); ctx.moveTo(...p0); ctx.lineTo(...p1); ctx.stroke(); } } ctx.restore(); } };
  ctx.save(); ctx.fillStyle = 'rgba(80,50,20,0.25)'; ctx.beginPath(); ctx.moveTo(...Fb); ctx.lineTo(...Rb); ctx.lineTo(Rb[0] + w * 0.3, Rb[1] + w * 0.08); ctx.lineTo(Fb[0] + w * 0.3, Fb[1] + w * 0.06); ctx.closePath(); ctx.fill();
  face(Lb, Fb, lit); face(Fb, Rb, shade);
  if (ub < 1) { ctx.fillStyle = o.top || '#ecd2a2'; ctx.beginPath(); ctx.moveTo(...L(Lb, ub)); ctx.lineTo(...L(Fb, ub)); ctx.lineTo(...L(Rb, ub)); ctx.lineTo(...L(Bb, ub)); ctx.closePath(); ctx.fill(); }
  const cs = o.casing || 0; if (cs > 0) { ctx.globalAlpha = cs; const g = ctx.createLinearGradient(Lb[0], 0, Fb[0], 0); g.addColorStop(0, '#fbf3e2'); g.addColorStop(1, '#efe2c6'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(...Lb); ctx.lineTo(...Fb); ctx.lineTo(...L(Fb, ub)); ctx.lineTo(...L(Lb, ub)); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#cdbb98'; ctx.beginPath(); ctx.moveTo(...Fb); ctx.lineTo(...Rb); ctx.lineTo(...L(Rb, ub)); ctx.lineTo(...L(Fb, ub)); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1; }
  ctx.strokeStyle = 'rgba(255,240,210,0.6)'; ctx.lineWidth = Math.max(1.5, w / 500); ctx.beginPath(); ctx.moveTo(...Fb); ctx.lineTo(...L(Fb, ub)); ctx.stroke();
  ctx.restore();
  return { apex: Ap, base: { L: Lb, F: Fb, R: Rb, B: Bb }, at: (f, u, v) => { const A = f === 'right' ? Fb : Lb, B2 = f === 'right' ? Rb : Fb, a = L(A, u), b = L(B2, u); return [lerp(a[0], b[0], v), lerp(a[1], b[1], v)]; } };
 };
 // Bloque de piedra en falsa perspectiva (frente + tapa + lateral), con vetas. o: { c (caliza '#d8b97f' | granito '#8a7f86'), d (profundidad) }
 P.block = (ctx, x, y, w, h, o = {}) => {
  const c = H.hex(o.c || '#d8b97f'), d = o.d ?? w * 0.25, f = (k) => H.rgba([c[0] * k, c[1] * k, c[2] * k]); ctx.save();
  ctx.fillStyle = 'rgba(60,40,20,0.25)'; ctx.fillRect(x + 6, y + h - 4, w + d * 0.8, 10);
  ctx.fillStyle = f(1.08); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + d * 0.8, y - d * 0.5); ctx.lineTo(x + w + d * 0.8, y - d * 0.5); ctx.lineTo(x + w, y); ctx.closePath(); ctx.fill();
  ctx.fillStyle = f(0.72); ctx.beginPath(); ctx.moveTo(x + w, y); ctx.lineTo(x + w + d * 0.8, y - d * 0.5); ctx.lineTo(x + w + d * 0.8, y + h - d * 0.5); ctx.lineTo(x + w, y + h); ctx.closePath(); ctx.fill();
  ctx.fillStyle = f(0.92); ctx.fillRect(x, y, w, h); const R = H.rng(o.seed || Math.round(x + y)); ctx.strokeStyle = f(0.75); ctx.lineWidth = 1.5; for (let i = 0; i < 4; i++) { const yy = y + R() * h; ctx.beginPath(); ctx.moveTo(x + R() * w * 0.3, yy); ctx.lineTo(x + w * (0.5 + R() * 0.5), yy + R.range(-6, 6)); ctx.stroke(); }
  ctx.restore();
 };
 // Trineo de madera de perfil (patines curvados al frente a la DERECHA) con un bloque encima. Devuelve el punto de amarre de la cuerda.
 P.sled = (ctx, x, y, s, o = {}) => {
  ctx.save(); ctx.strokeStyle = '#7a4f2a'; ctx.lineWidth = s * 0.06; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x - s * 0.6, y); ctx.lineTo(x + s * 0.5, y); ctx.quadraticCurveTo(x + s * 0.68, y, x + s * 0.7, y - s * 0.14); ctx.stroke();
  ctx.fillStyle = '#9a6a3a'; for (let i = 0; i < 4; i++) ctx.fillRect(x - s * 0.55 + i * s * 0.32, y - s * 0.1, s * 0.07, s * 0.1); ctx.fillRect(x - s * 0.6, y - s * 0.14, s * 1.15, s * 0.05); ctx.restore();
  if (o.block !== false) P.block(ctx, x - s * 0.5, y - s * 0.14 - s * 0.55, s * 0.9, s * 0.55, { c: o.c, seed: 7 });
  ctx.save(); ctx.strokeStyle = '#c9a46a'; ctx.lineWidth = s * 0.02; ctx.beginPath(); ctx.moveTo(x - s * 0.5, y - s * 0.4); ctx.lineTo(x + s * 0.55, y - s * 0.4); ctx.stroke(); ctx.restore();
  return [x + s * 0.7, y - s * 0.14];
 };
 // Trabajador (silueta estilizada, de perfil mirando a la derecha). o.pose: 'pull' (inclinado tirando de una cuerda), 'walk', 'pour'
 // (vierte agua con una vasija), 'stand', 'chisel'. ph = fase de la marcha (0..1 se repite). Devuelve la posición de las manos.
 P.worker = (ctx, x, y, h, ph = 0, o = {}) => {
  const pose = o.pose || 'walk', c = o.c || '#4a2f1c', lean = pose === 'pull' ? 0.42 : pose === 'pour' ? 0.12 : 0.05, sw = Math.sin(ph * TAU);
  ctx.save(); ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineCap = 'round'; ctx.lineWidth = h * 0.09;
  const hip = [x, y - h * 0.48], sh = [x + Math.sin(lean) * h * 0.32, hip[1] - Math.cos(lean) * h * 0.32], head = [sh[0] + Math.sin(lean) * h * 0.12, sh[1] - Math.cos(lean) * h * 0.12];
  const st = pose === 'stand' || pose === 'pour' || pose === 'chisel' ? 0.15 : 1; for (const s of [1, -1]) { const k = sw * s * st; ctx.beginPath(); ctx.moveTo(...hip); ctx.lineTo(x + k * h * 0.14 + h * 0.02, y - h * 0.24); ctx.lineTo(x + k * h * 0.22 - (pose === 'pull' ? h * 0.12 : 0), y); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(...hip); ctx.lineTo(...sh); ctx.stroke(); ctx.fillStyle = o.cloth || '#efe6d2'; ctx.beginPath(); ctx.moveTo(hip[0] - h * 0.08, hip[1] - h * 0.02); ctx.lineTo(hip[0] + h * 0.09, hip[1] - h * 0.02); ctx.lineTo(hip[0] + h * 0.11, hip[1] + h * 0.12); ctx.lineTo(hip[0] - h * 0.1, hip[1] + h * 0.12); ctx.closePath(); ctx.fill();
  ctx.fillStyle = c; ctx.beginPath(); ctx.arc(head[0], head[1], h * 0.075, 0, TAU); ctx.fill();
  let hand; if (pose === 'pull') hand = [sh[0] + h * 0.28, sh[1] + h * 0.12]; else if (pose === 'pour') hand = [sh[0] + h * 0.26, sh[1] + h * 0.02]; else if (pose === 'chisel') hand = [sh[0] + h * 0.22, sh[1] + h * 0.1 + Math.abs(sw) * h * 0.05]; else hand = [sh[0] + sw * h * 0.12, sh[1] + h * 0.25];
  ctx.lineWidth = h * 0.07; ctx.beginPath(); ctx.moveTo(...sh); ctx.lineTo(...hand); ctx.stroke();
  if (pose === 'pour') { ctx.fillStyle = '#b5653a'; ctx.beginPath(); ctx.ellipse(hand[0] + h * 0.06, hand[1], h * 0.09, h * 0.07, 0.9, 0, TAU); ctx.fill(); }
  ctx.restore(); return hand;
 };
 // Cuerda (trenzada) por una polilínea
 P.rope = (ctx, pts, w = 4, o = {}) => { P.strokePath(ctx, pts, w, o.c || '#b8935a'); ctx.save(); ctx.setLineDash([w * 0.8, w * 1.2]); P.strokePath(ctx, pts, w * 0.45, 'rgba(90,60,30,0.6)', { cap: 'butt' }); ctx.restore(); };
 // Rampa de construcción sobre la pirámide (esquema): 'recta' (frontal), 'zigzag', 'espiral' (envolvente), 'interna'. p 0..1 = cuánto se ha dibujado.
 P.ramp = (ctx, pyr, type, p = 1, o = {}) => {
  const c = o.c || 'rgba(160,110,60,0.92)', ub = o.top ?? 0.8; let pts = [];
  if (type === 'recta') { const a = pyr.base.L, top = pyr.at('left', ub, 0.55); pts = [[a[0] - (o.len || 260), a[1] + 30], top]; ctx.save(); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); ctx.lineTo(top[0], top[1]); ctx.lineTo(top[0], a[1] + 30); ctx.closePath(); ctx.globalAlpha *= cl(p * 1.5); ctx.fill(); ctx.restore(); return P.path(pts); }
  if (type === 'zigzag') { const N = 6; for (let i = 0; i <= N; i++) { const u = i / N * ub; pts.push(pyr.at('left', u, i % 2 ? 0.85 : 0.15)); } }
  else if (type === 'espiral') { const N = 16; for (let i = 0; i <= N; i++) { const u = i / N * ub, f = (i % 4) < 2 ? 'left' : 'right', v = (i % 2) ? 0.95 : 0.05; pts.push(pyr.at(f, u, v)); } }
  else { const N = 8; for (let i = 0; i <= N; i++) { const u = i / N * ub; pts.push(pyr.at('left', u, i % 2 ? 0.7 : 0.3)); } }
  const L = P.path(pts), part = [pts[0]]; let acc = 0; for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); if (acc + d >= L.L * p) { const q = L.at(L.L * p); part.push([q[0], q[1]]); break; } acc += d; part.push(pts[i]); }
  ctx.save(); if (type === 'interna') ctx.setLineDash([12, 10]); P.strokePath(ctx, part, o.w || 12, c); ctx.restore(); return L;
 };
 // Papiro (rollo) con signos estilizados (no es texto real). o: { rows, seed, c }
 P.papyrus = (ctx, x, y, w, h, o = {}) => {
  ctx.save(); const g = ctx.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#e6cf98'); g.addColorStop(0.5, '#f1dfb0'); g.addColorStop(1, '#dcc086'); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#c8a86c'; ctx.fillRect(x - 12, y - 6, 16, h + 12); ctx.fillRect(x + w - 4, y - 6, 16, h + 12);
  const R = H.rng(o.seed || 4); ctx.fillStyle = o.c || '#4a3220'; const rows = o.rows || 6; for (let r = 0; r < rows; r++) { const yy = y + 20 + r * (h - 30) / rows; for (let xx = x + 20; xx < x + w - 24; xx += R.range(16, 26)) { const k = R(); if (k < 0.3) ctx.fillRect(xx, yy, 10, 3); else if (k < 0.55) { ctx.beginPath(); ctx.arc(xx + 5, yy + 2, 4, 0, TAU); ctx.fill(); } else if (k < 0.8) ctx.fillRect(xx + 3, yy - 6, 3, 12); else { ctx.beginPath(); ctx.moveTo(xx, yy + 4); ctx.lineTo(xx + 5, yy - 6); ctx.lineTo(xx + 10, yy + 4); ctx.fill(); } } }
  ctx.restore();
 };
 // Herramientas: 'cincel' (cobre), 'mazo', 'codo' (vara de medir), 'plomada' (nivel en A con plomada), 'escuadra', 'sierra'
 P.tool = (ctx, kind, x, y, s, rot = 0) => {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.lineCap = 'round';
  if (kind === 'cincel') { ctx.fillStyle = '#c47a3a'; ctx.fillRect(-s * 0.06, -s * 0.5, s * 0.12, s * 0.85); ctx.beginPath(); ctx.moveTo(-s * 0.06, s * 0.35); ctx.lineTo(s * 0.06, s * 0.35); ctx.lineTo(0, s * 0.5); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(-s * 0.04, -s * 0.48, s * 0.03, s * 0.8); }
  else if (kind === 'mazo') { ctx.fillStyle = '#8a5a32'; ctx.fillRect(-s * 0.04, -s * 0.1, s * 0.08, s * 0.6); ctx.beginPath(); ctx.ellipse(0, -s * 0.25, s * 0.18, s * 0.22, 0, 0, TAU); ctx.fill(); }
  else if (kind === 'codo') { ctx.fillStyle = '#6b4a2b'; ctx.fillRect(-s * 0.6, -s * 0.05, s * 1.2, s * 0.1); ctx.fillStyle = '#e6cf98'; for (let i = 0; i <= 7; i++) ctx.fillRect(-s * 0.6 + i * s * 1.2 / 7 - 1, -s * 0.05, 2, s * 0.06); }
  else if (kind === 'plomada') { ctx.strokeStyle = '#6b4a2b'; ctx.lineWidth = s * 0.07; ctx.beginPath(); ctx.moveTo(-s * 0.4, s * 0.4); ctx.lineTo(0, -s * 0.45); ctx.lineTo(s * 0.4, s * 0.4); ctx.moveTo(-s * 0.2, 0); ctx.lineTo(s * 0.2, 0); ctx.stroke(); ctx.strokeStyle = '#e6cf98'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, -s * 0.45); ctx.lineTo(0, s * 0.05); ctx.stroke(); ctx.fillStyle = '#c47a3a'; ctx.beginPath(); ctx.arc(0, s * 0.1, s * 0.06, 0, TAU); ctx.fill(); }
  else if (kind === 'escuadra') { ctx.strokeStyle = '#6b4a2b'; ctx.lineWidth = s * 0.1; ctx.beginPath(); ctx.moveTo(-s * 0.4, -s * 0.4); ctx.lineTo(-s * 0.4, s * 0.4); ctx.lineTo(s * 0.4, s * 0.4); ctx.stroke(); }
  else if (kind === 'sierra') { ctx.fillStyle = '#c47a3a'; ctx.beginPath(); ctx.moveTo(-s * 0.5, -s * 0.08); ctx.lineTo(s * 0.4, -s * 0.08); for (let i = 0; i < 10; i++) { ctx.lineTo(s * 0.4 - i * s * 0.09 - s * 0.045, s * 0.06); ctx.lineTo(s * 0.4 - (i + 1) * s * 0.09, -s * 0.0); } ctx.closePath(); ctx.fill(); ctx.fillStyle = '#6b4a2b'; ctx.fillRect(s * 0.38, -s * 0.12, s * 0.2, s * 0.16); }
  ctx.restore();
 };
 // Palmera (de perfil) que se mece con t
 P.palm = (ctx, x, y, h, t = 0) => {
  ctx.save(); const sw = Math.sin(t * 1.2) * h * 0.02, tx = x + h * 0.08 + sw, ty = y - h; ctx.strokeStyle = '#7a5a3a'; ctx.lineWidth = h * 0.05; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + h * 0.1, y - h * 0.5, tx, ty); ctx.stroke();
  ctx.strokeStyle = '#3d6b3a'; ctx.lineWidth = h * 0.035; for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * 0.55 + Math.sin(t + i) * 0.04; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.quadraticCurveTo(tx + Math.cos(a) * h * 0.25, ty + Math.sin(a) * h * 0.2 - h * 0.05, tx + Math.cos(a) * h * 0.38, ty + Math.sin(a) * h * 0.25 + h * 0.12); ctx.stroke(); } ctx.restore();
 };
 // Signo de interrogación flotante (dudas, hipótesis abiertas)
 P.qmark = (ctx, x, y, s, t = 0, c = '#FFD447') => { ctx.save(); ctx.translate(x, y + Math.sin(t * 2 + x) * s * 0.08); ctx.rotate(Math.sin(t + y) * 0.1); ctx.font = `800 ${s}px Fredoka`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillText('?', 3, 4); ctx.fillStyle = c; ctx.fillText('?', 0, 0); ctx.restore(); };

 // ======================= v1.9 · FLOTACIÓN Y BARCOS (hidrostática, ingeniería naval, puertos) =======================
 // Mar de perfil completo: cielo (o.sky), sol, agua bajo la superficie con cáusticas cerca de la superficie y oleaje.
 // o: { x0, x1 (ancho del mundo), bottom, depth (0..1 oscuridad del fondo), sun [x, y], caustics }
 P.seaProfile = (ctx, y, t, o = {}) => {
  const x0 = o.x0 ?? -600, x1 = o.x1 ?? W + 600, bot = o.bottom ?? HH + 600, sk = o.sky || ['#0e3554', '#8cc6e6'];
  const g = ctx.createLinearGradient(0, y - 1400, 0, y); g.addColorStop(0, sk[0]); g.addColorStop(1, sk[1]); ctx.fillStyle = g; ctx.fillRect(x0, y - 2600, x1 - x0, 2600);
  if (o.sun) { P.glow(ctx, o.sun[0], o.sun[1], 260, '255,236,190', 0.55); P.circle(ctx, o.sun[0], o.sun[1], 48, '#fff4d8'); }
  P.ocean(ctx, t, o.depth ?? 0.5, { x: x0, y, w: x1 - x0, h: bot - y, snow: o.snow ?? 70, rays: 1 });
  if (o.caustics !== false) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(160,230,255,0.10)'; ctx.lineWidth = 3; for (let k = 0; k < 7; k++) { ctx.beginPath(); for (let x = x0; x <= x1; x += 16) { const yy = y + 30 + k * 26 + Math.sin(x * 0.02 + t * 1.3 + k) * 8 + Math.sin(x * 0.047 - t * 0.9 + k * 2) * 5; x === x0 ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); } ctx.stroke(); } ctx.restore(); }
  return P.waves(ctx, y, t, { x: x0, w: x1 - x0, amp: o.amp ?? 6 });
 };
 // Velo de agua sobre lo que está sumergido (se dibuja DESPUÉS del objeto): tiñe de azul y oscurece con la profundidad
 P.underwater = (ctx, y, t, o = {}) => { const x0 = o.x0 ?? -600, x1 = o.x1 ?? W + 600, bot = o.bottom ?? HH + 600; ctx.save(); const g = ctx.createLinearGradient(0, y, 0, y + 900); g.addColorStop(0, `rgba(19,120,168,${o.a0 ?? 0.22})`); g.addColorStop(1, `rgba(3,24,39,${o.a1 ?? 0.6})`); ctx.fillStyle = g; ctx.fillRect(x0, y + 2, x1 - x0, bot - y); ctx.restore(); P.waves(ctx, y, t, { x: x0, w: x1 - x0, amp: o.amp ?? 6, c: 'rgba(230,248,255,0.55)' }); };
 // Contenedor (caja con nervios) y pila de contenedores
 const CONT = ['#B7473C', '#2f6f9f', '#3f8f7a', '#d6a33a', '#7d8a99', '#8e4f7a', '#c8653a', '#4a6b8a'];
 P.container = (ctx, x, y, w, h, c) => { ctx.save(); ctx.fillStyle = c; ctx.fillRect(x, y, w, h); ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 1; for (let k = 1; k < 6; k++) { ctx.beginPath(); ctx.moveTo(x + w * k / 6, y + 1); ctx.lineTo(x + w * k / 6, y + h - 1); ctx.stroke(); } ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); ctx.restore(); };
 // Portacontenedores de perfil (proa a la DERECHA). y = línea de flotación; draft = calado en px (cuánto está bajo el agua).
 // o: { H (puntal), rows (pisos de contenedores), cut 0..1 (corte longitudinal: muestra mamparos, cubiertas y espacios con aire),
 //      flood [0..1 por compartimento] (agua dentro), comps (nº de compartimentos), extra (contenedores añadidos), plimsoll, trim (rad) }
 // Devuelve { x0, x1, deck, keel, bay(i) → [x, y] de la pila i, comps: [[xa, xb]…] }
 P.cargoShip = (ctx, x, y, L, draft, t, o = {}) => {
  const Hh = o.H ?? L * 0.09, keel = y + draft, deck = keel - Hh, x0 = x - L / 2, x1 = x + L / 2, bob = Math.sin(t * 0.9) * 2;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.trim || 0); ctx.translate(-x, -y + bob);
  const hullPts = [[x0, deck - Hh * 0.05], [x1 - L * 0.04, deck], [x1 + L * 0.01, deck - Hh * 0.12], [x1 - L * 0.005, keel - Hh * 0.45], [x1 + L * 0.012, keel - Hh * 0.28], [x1 - L * 0.02, keel - Hh * 0.05], [x1 - L * 0.08, keel], [x0 + L * 0.07, keel], [x0 + L * 0.01, keel - Hh * 0.35], [x0, deck - Hh * 0.05]];
  const poly = (pts) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); };
  // casco: obra muerta oscura y obra viva roja (antiincrustante) por debajo de la línea de flotación de diseño
  const dwl = keel - (o.design ?? draft) ; ctx.save(); poly(hullPts); ctx.clip(); ctx.fillStyle = '#26394a'; ctx.fillRect(x0 - 20, deck - Hh, L + 40, Hh * 2); ctx.fillStyle = '#B7473C'; ctx.fillRect(x0 - 20, dwl, L + 40, Hh * 2); ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(x0 - 20, deck, L + 40, Hh * 0.18);
  // corte longitudinal: interior con mamparos y cubiertas
  const nc = o.comps || 7, comps = []; for (let i = 0; i < nc; i++) comps.push([x0 + L * 0.1 + i * L * 0.8 / nc, x0 + L * 0.1 + (i + 1) * L * 0.8 / nc]);
  const cut = o.cut || 0; if (cut > 0) { ctx.globalAlpha = cut; const th = Math.max(4, Hh * 0.06); ctx.fillStyle = '#0d2233'; ctx.fillRect(x0 + th, deck + th, L - 2 * th, Hh - 2 * th); const ag = ctx.createLinearGradient(0, deck, 0, keel); ag.addColorStop(0, 'rgba(244,250,255,0.22)'); ag.addColorStop(1, 'rgba(57,217,255,0.12)'); ctx.fillStyle = ag; ctx.fillRect(x0 + th, deck + th, L - 2 * th, Hh - 2 * th);
   ctx.fillStyle = '#A9C2D1'; for (const [a] of comps) ctx.fillRect(a - th / 2, deck, th, Hh); ctx.fillRect(comps[nc - 1][1] - th / 2, deck, th, Hh); ctx.fillRect(x0, keel - Hh * 0.14, L, th * 0.8); ctx.fillRect(x0, deck + Hh * 0.45, L * 0.1, th * 0.6);
   (o.flood || []).forEach((f, i) => { if (!f || !comps[i]) return; const [a, b] = comps[i], top = lerp(keel - th, deck + th, cl(f)); const wg = ctx.createLinearGradient(0, top, 0, keel); wg.addColorStop(0, 'rgba(57,217,255,0.85)'); wg.addColorStop(1, 'rgba(19,120,168,0.95)'); ctx.fillStyle = wg; ctx.fillRect(a + th / 2, top, b - a - th, keel - th - top); ctx.strokeStyle = 'rgba(244,250,255,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); for (let xx = a + th; xx < b - th; xx += 6) { const yy = top + Math.sin(xx * 0.1 + t * 5) * 2; xx === a + th ? ctx.moveTo(xx, yy) : ctx.lineTo(xx, yy); } ctx.stroke(); });
   ctx.globalAlpha = 1; }
  if (o.disp) { ctx.fillStyle = `rgba(57,217,255,${0.4 * o.disp})`; ctx.fillRect(x0 - 20, y - bob, L + 40, Hh * 3); ctx.strokeStyle = `rgba(57,217,255,${o.disp})`; ctx.lineWidth = 4; ctx.setLineDash([12, 8]); ctx.beginPath(); ctx.moveTo(x0 - 20, y - bob); ctx.lineTo(x1 + 20, y - bob); ctx.stroke(); ctx.setLineDash([]); }
  ctx.restore();
  ctx.strokeStyle = '#A9C2D1'; ctx.lineWidth = Math.max(2, L / 500); poly(hullPts); ctx.stroke();
  // marca Plimsoll (línea de carga) en el centro del costado
  if (o.plimsoll) { const px = x - L * 0.05, py = keel - (o.plimsollDraft ?? draft); ctx.save(); ctx.strokeStyle = '#FFD447'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(px, py, Hh * 0.13, 0, TAU); ctx.moveTo(px - Hh * 0.22, py); ctx.lineTo(px + Hh * 0.22, py); ctx.stroke(); ctx.restore(); }
  // superestructura (habilitación y puente) cerca de popa
  const sx = x0 + L * 0.13, sw = L * 0.06; ctx.fillStyle = '#e9eef3'; ctx.fillRect(sx, deck - Hh * 1.25, sw, Hh * 1.25); ctx.fillStyle = '#c9d3dc'; ctx.fillRect(sx - sw * 0.25, deck - Hh * 1.32, sw * 1.5, Hh * 0.1); ctx.fillStyle = '#16283a'; for (let r = 0; r < 5; r++) for (let c2 = 0; c2 < 3; c2++) ctx.fillRect(sx + sw * 0.12 + c2 * sw * 0.29, deck - Hh * 1.18 + r * Hh * 0.22, sw * 0.18, Hh * 0.09); ctx.fillStyle = '#B7473C'; ctx.fillRect(sx - L * 0.035, deck - Hh * 1.0, L * 0.022, Hh * 1.0);
  // pilas de contenedores sobre cubierta
  const rows = o.rows ?? 5, bays = Math.floor((L * 0.66) / (L * 0.04)), bw = L * 0.04, ch = Hh * 0.26; const R = H.rng(o.seed || 11);
  const bay = (i) => [x0 + L * 0.22 + i * bw, deck];
  for (let i = 0; i < bays; i++) { const [bx] = bay(i); const n = rows - (i < 2 || i > bays - 3 ? 1 : 0) + (o.extraBay && o.extraBay[i] ? o.extraBay[i] : 0); for (let r = 0; r < n; r++) P.container(ctx, bx + 1, deck - (r + 1) * ch, bw - 2, ch - 1, CONT[Math.floor(R() * CONT.length)]); }
  ctx.restore();
  return { x0, x1, deck: deck + bob, keel: keel + bob, bay: (i) => { const [bx] = bay(i); return [bx + bw / 2, deck + bob]; }, bw, ch, bays, comps };
 };
 // Sección transversal del casco (forma en U) a escala de diagrama: paredes y doble fondo de acero, interior con aire
 // (luz suave) y contenedores. sink = cuánto está bajo el agua (px). Muestra el volumen desplazado (cian) si o.disp > 0.
 // o: { disp 0..1, sep 0..1 (separa el volumen desplazado a un lado), cargo (pisos de contenedores en bodega), flood 0..1 }
 // Devuelve { bottom, top, wl (y de la línea de agua en el casco), cob [x, y] (centro de empuje), area (px² sumergidos) }
 P.hullSection = (ctx, cx, wl, w, h, sink, t, o = {}) => {
  const bottom = wl + sink, top = bottom - h, r = w * 0.16, x0 = cx - w / 2, x1 = cx + w / 2;
  const shape = (pad = 0) => { ctx.beginPath(); ctx.moveTo(x0 - pad, top); ctx.lineTo(x0 - pad, bottom - r); ctx.quadraticCurveTo(x0 - pad, bottom + pad, x0 + r, bottom + pad); ctx.lineTo(x1 - r, bottom + pad); ctx.quadraticCurveTo(x1 + pad, bottom + pad, x1 + pad, bottom - r); ctx.lineTo(x1 + pad, top); };
  const sub = Math.max(0, Math.min(h, sink)), area = sub * w;
  // volumen desplazado (cian), en su sitio o separado hacia un lado
  const dA = o.disp || 0; if (dA > 0) { const dx = (o.sep || 0) * (o.sepX ?? 0), dy = (o.sep || 0) * (o.sepY ?? h * 0.75); ctx.save(); ctx.translate(dx, dy); ctx.beginPath(); ctx.rect(x0 - 4, wl, w + 8, sub + 6); ctx.clip(); shape(4); ctx.closePath(); ctx.fillStyle = `rgba(57,217,255,${0.42 * dA})`; ctx.fill(); ctx.strokeStyle = `rgba(57,217,255,${0.95 * dA})`; ctx.lineWidth = 4; ctx.setLineDash([12, 8]); ctx.stroke(); ctx.restore(); }
  // casco
  ctx.save(); shape(0); ctx.lineTo(x1, top); ctx.closePath(); const sg = ctx.createLinearGradient(x0, 0, x1, 0); sg.addColorStop(0, '#5d7a8f'); sg.addColorStop(0.5, '#A9C2D1'); sg.addColorStop(1, '#3D5669'); ctx.fillStyle = sg; ctx.fill(); ctx.clip();
  const th = Math.max(8, w * 0.035); ctx.fillStyle = '#0b2131'; ctx.beginPath(); ctx.moveTo(x0 + th, top - 2); ctx.lineTo(x0 + th, bottom - r - th * 0.4); ctx.quadraticCurveTo(x0 + th, bottom - th * 1.6, x0 + r, bottom - th * 1.6); ctx.lineTo(x1 - r, bottom - th * 1.6); ctx.quadraticCurveTo(x1 - th, bottom - th * 1.6, x1 - th, bottom - r - th * 0.4); ctx.lineTo(x1 - th, top - 2); ctx.closePath(); ctx.fill();
  const ag = ctx.createRadialGradient(cx, bottom - h * 0.45, 10, cx, bottom - h * 0.45, w * 0.6); ag.addColorStop(0, 'rgba(244,250,255,0.28)'); ag.addColorStop(1, 'rgba(244,250,255,0.04)'); ctx.fillStyle = ag; ctx.fillRect(x0, top, w, h);
  ctx.fillStyle = '#A9C2D1'; ctx.fillRect(x0, bottom - th * 3.2, w, th * 0.5); // doble fondo
  if (o.flood) { const fy = lerp(bottom - th * 1.6, top + th, cl(o.flood)); ctx.fillStyle = 'rgba(19,120,168,0.92)'; ctx.fillRect(x0 + th, fy, w - 2 * th, bottom - fy); }
  const cg = o.cargo || 0, cw = (w - 2 * th - 20) / 6, chh = cw * 0.45; const R = H.rng(5); for (let r2 = 0; r2 < cg; r2++) for (let k = 0; k < 6; k++) P.container(ctx, x0 + th + 10 + k * cw, bottom - th * 3.2 - (r2 + 1) * chh, cw - 3, chh - 2, CONT[Math.floor(R() * CONT.length)]);
  ctx.restore();
  ctx.fillStyle = '#B7473C'; ctx.save(); shape(0); ctx.lineTo(x1, top); ctx.closePath(); ctx.clip(); ctx.globalAlpha = 0.9; ctx.beginPath(); shape(0); ctx.lineTo(x1, top); ctx.closePath(); ctx.restore();
  ctx.strokeStyle = '#d6e3ec'; ctx.lineWidth = 3; shape(0); ctx.stroke();
  return { bottom, top, wl, cob: [cx, wl + sub / 2], area, x0, x1 };
 };
 // Flecha de fuerza vertical (o horizontal) gruesa con etiqueta: dir 1 = arriba, -1 = abajo. len en px (∝ magnitud).
 P.forceArrow = (ctx, x, y, len, dir, c, label, o = {}) => {
  if (len <= 2) return; const w = o.w || 22, hw = w * 1.9, hl = Math.min(len * 0.45, w * 2.2), ey = y - dir * len; ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 12; ctx.fillStyle = c;
  ctx.beginPath(); ctx.moveTo(x - w / 2, y); ctx.lineTo(x - w / 2, ey + dir * hl); ctx.lineTo(x - hw / 2, ey + dir * hl); ctx.lineTo(x, ey); ctx.lineTo(x + hw / 2, ey + dir * hl); ctx.lineTo(x + w / 2, ey + dir * hl); ctx.lineTo(x + w / 2, y); ctx.closePath(); ctx.fill(); ctx.restore();
  if (label) { ctx.save(); ctx.font = `800 ${o.px || 34}px Nunito`; ctx.textAlign = o.align || 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = c; ctx.shadowColor = 'rgba(0,0,0,0.9)'; ctx.shadowBlur = 10; ctx.fillText(label, x + (o.align === 'right' ? -w * 1.4 : w * 1.4), (y + ey) / 2); ctx.restore(); }
 };
 // Flechas de presión normales a una superficie sumergida (pts en orden), longitud ∝ profundidad bajo y0.
 P.pressureArrows = (ctx, pts, y0, t, o = {}) => {
  const a = o.a ?? 1; if (a <= 0) return; const k = o.k || 0.25, step = o.step || 46, c = o.c || '57,217,255'; const L = P.path(pts); ctx.save(); ctx.globalAlpha *= a; ctx.strokeStyle = `rgba(${c},0.95)`; ctx.fillStyle = `rgba(${c},0.95)`; ctx.lineWidth = 4; ctx.lineCap = 'round';
  for (let s = step / 2; s < L.L; s += step) { const [x, y, ang] = L.at(s); const d = y - y0; if (d <= 2) continue; const nx = Math.sin(ang), ny = -Math.cos(ang), len = (10 + d * k) * (0.92 + 0.08 * Math.sin(t * 4 + s)); const sx = x + nx * (len + 8), sy = y + ny * (len + 8), ex = x + nx * 8, ey = y + ny * 8; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke(); ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex + nx * 12 - ny * 7, ey + ny * 12 + nx * 7); ctx.lineTo(ex + nx * 12 + ny * 7, ey + ny * 12 - nx * 7); ctx.closePath(); ctx.fill(); }
  ctx.restore();
 };
 // Salpicadura determinista (corona de gotas + anillo) en (x, y) desde t0. o: { s (tamaño), c }
 P.splash = (ctx, x, y, t, t0, o = {}) => {
  const u = t - t0; if (u < 0 || u > 1.6) return; const s = o.s || 120, R = H.rng(o.seed || 9); ctx.save();
  ctx.strokeStyle = `rgba(244,250,255,${0.8 * (1 - u / 1.6)})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(x, y, s * (0.4 + u * 1.6), s * 0.12 * (0.4 + u), 0, 0, TAU); ctx.stroke();
  for (let i = 0; i < 26; i++) { const ang = -Math.PI / 2 + R.range(-1.2, 1.2), v = R.range(0.6, 1.4) * s * 3.2, gx = x + Math.cos(ang) * v * u * 0.6, gy = y + Math.sin(ang) * v * u + 0.5 * 1800 * u * u; if (gy > y + 4) continue; ctx.fillStyle = `rgba(220,245,255,${0.9 * (1 - u / 1.6)})`; ctx.beginPath(); ctx.arc(gx, gy, R.range(3, 8), 0, TAU); ctx.fill(); }
  ctx.restore();
 };
 // Grúa portuaria de muelle (pórtico) de perfil, con el brazo hacia la DERECHA. trolley 0..1 recorre el brazo; hoist = bajada en px.
 // Devuelve [x, y] del spreader (donde cuelga el contenedor).
 P.gantryCrane = (ctx, x, y, h, trolley = 0.5, hoist = 100, o = {}) => {
  const c = o.c || '#d6a33a', reach = h * 1.1, by = y - h; ctx.save(); ctx.strokeStyle = c; ctx.lineWidth = Math.max(3, h * 0.025); ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(x - h * 0.2, y); ctx.lineTo(x - h * 0.16, by); ctx.moveTo(x + h * 0.2, y); ctx.lineTo(x + h * 0.16, by); ctx.moveTo(x - h * 0.19, y - h * 0.45); ctx.lineTo(x + h * 0.19, y - h * 0.45); ctx.moveTo(x - h * 0.19, y - h * 0.45); ctx.lineTo(x + h * 0.17, by + h * 0.02); ctx.stroke();
  ctx.fillStyle = c; ctx.fillRect(x - h * 0.5, by - h * 0.05, reach + h * 0.5, h * 0.05); ctx.beginPath(); ctx.moveTo(x, by - h * 0.05); ctx.lineTo(x, by - h * 0.3); ctx.lineTo(x + reach * 0.75, by - h * 0.05); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x, by - h * 0.3); ctx.lineTo(x - h * 0.45, by - h * 0.05); ctx.stroke();
  ctx.fillStyle = '#e9eef3'; ctx.fillRect(x - h * 0.08, by + h * 0.02, h * 0.1, h * 0.07);
  const tx = x + h * 0.1 + trolley * (reach - h * 0.15); ctx.fillStyle = '#3D5669'; ctx.fillRect(tx - h * 0.04, by, h * 0.08, h * 0.03); ctx.strokeStyle = '#3D5669'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tx - h * 0.03, by + h * 0.03); ctx.lineTo(tx - h * 0.03, by + hoist); ctx.moveTo(tx + h * 0.03, by + h * 0.03); ctx.lineTo(tx + h * 0.03, by + hoist); ctx.stroke(); ctx.fillStyle = '#FFD447'; ctx.fillRect(tx - h * 0.06, by + hoist, h * 0.12, h * 0.015);
  ctx.restore(); return [tx, by + hoist + h * 0.015];
 };
 // Vaso de laboratorio (o recipiente antiguo) con agua y rebosadero. level 0..1; obj(ctx) dibuja algo dentro; o: { spout, overflow 0..1 }
 P.beaker = (ctx, x, y, w, h, level, t, o = {}) => {
  ctx.save(); const wl = y + h - h * level; P.waterBody(ctx, [[x + 6, wl], [x + w - 6, wl], [x + w - 6, y + h - 6], [x + 6, y + h - 6]], t, { surf: [x + 6, x + w - 6, wl], top: wl, bottom: y + h }); if (o.obj) o.obj(wl);
  ctx.strokeStyle = o.c || 'rgba(230,240,250,0.9)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + h); ctx.lineTo(x + w, y + h); ctx.lineTo(x + w, y); if (o.spout) { ctx.moveTo(x + w, y + h * 0.12); ctx.lineTo(x + w + w * 0.22, y + h * 0.2); } ctx.stroke();
  if (o.spout && (o.overflow || 0) > 0) { ctx.strokeStyle = 'rgba(57,217,255,0.9)'; ctx.lineWidth = 6; ctx.lineCap = 'round'; for (let k = 0; k < 3; k++) { const u = (t * 2 + k / 3) % 1; ctx.beginPath(); ctx.moveTo(x + w + w * 0.2, y + h * 0.2 + u * h * 0.5); ctx.lineTo(x + w + w * 0.21, y + h * 0.2 + u * h * 0.5 + 16); ctx.stroke(); } }
  ctx.restore(); return wl;
 };
 // Figura clásica estilizada (túnica griega, de perfil mirando a la derecha) — referencia histórica sin dramatizar
 P.greek = (ctx, x, y, h, o = {}) => {
  ctx.save(); ctx.fillStyle = o.c || '#e9e2d0'; ctx.beginPath(); ctx.moveTo(x - h * 0.16, y); ctx.lineTo(x - h * 0.12, y - h * 0.62); ctx.quadraticCurveTo(x, y - h * 0.72, x + h * 0.12, y - h * 0.62); ctx.lineTo(x + h * 0.18, y); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(120,100,70,0.5)'; ctx.lineWidth = 2; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x - h * 0.1 + k * h * 0.06, y - h * 0.58); ctx.lineTo(x - h * 0.12 + k * h * 0.08, y); ctx.stroke(); }
  ctx.fillStyle = o.skin || '#c08a5a'; ctx.beginPath(); ctx.arc(x + h * 0.02, y - h * 0.8, h * 0.1, 0, TAU); ctx.fill(); ctx.fillStyle = '#d9d9d9'; ctx.beginPath(); ctx.ellipse(x + h * 0.06, y - h * 0.72, h * 0.06, h * 0.07, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = o.skin || '#c08a5a'; ctx.lineWidth = h * 0.05; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x + h * 0.08, y - h * 0.58); ctx.lineTo(x + h * 0.26, y - h * (0.5 + (o.point || 0) * 0.15)); ctx.stroke(); ctx.restore();
 };
 // Columna clásica (fondos históricos)
 P.column = (ctx, x, y, h, w = 60, c = '#e9e2d0') => { ctx.save(); ctx.fillStyle = c; ctx.fillRect(x - w / 2, y - h, w, h); ctx.fillRect(x - w * 0.7, y - h - w * 0.25, w * 1.4, w * 0.25); ctx.fillRect(x - w * 0.7, y - w * 0.2, w * 1.4, w * 0.2); ctx.strokeStyle = 'rgba(120,100,70,0.35)'; ctx.lineWidth = 2; for (let k = 1; k < 5; k++) { ctx.beginPath(); ctx.moveTo(x - w / 2 + k * w / 5, y - h); ctx.lineTo(x - w / 2 + k * w / 5, y - w * 0.2); ctx.stroke(); } ctx.restore(); };

 // ======================= v1.10 · ESPACIO Y RELATIVIDAD (galaxias, naves, relojes, espacio-tiempo) =======================
 // Física relativista de aceleración propia constante (unidades: años y años luz; c = 1 al/año; 1 g ≈ 1,0323 al/año²).
 // REL.trip(D, a) → { tauTot, tTot, at(tauFrac) → { tau, t, x, beta, gamma, eta } } para ida acelerando la 1.ª mitad y frenando la 2.ª.
 P.REL = (() => {
  const G1 = 9.80665 * (365.25 * 86400) ** 2 / 9.4607304725808e15; // 1 g en al/año² ≈ 1,0323
  const trip = (D, a = G1) => { const tauH = Math.acosh(1 + a * D / 2) / a, tauTot = 2 * tauH, tH = Math.sinh(a * tauH) / a, tTot = 2 * tH;
   const at = (f) => { const tau = cl(f) * tauTot; let t, x, eta; if (tau <= tauH) { eta = a * tau; t = Math.sinh(eta) / a; x = (Math.cosh(eta) - 1) / a; } else { const r = tauTot - tau; eta = a * r; t = tTot - Math.sinh(eta) / a; x = D - (Math.cosh(eta) - 1) / a; } return { tau, t, x, eta, beta: Math.tanh(eta), gamma: Math.cosh(eta), oneMinusBeta: 2 / (Math.exp(2 * eta) + 1) }; };
   return { D, a, tauH, tauTot, tTot, at }; };
  return { G1, trip, gammaOf: (beta) => 1 / Math.sqrt(1 - beta * beta) };
 })();
 // v/c como texto con los nueves necesarios (nunca llega a 1): oneMinus = 1 − v/c
 P.betaText = (oneMinus) => { if (oneMinus >= 0.1) return (1 - oneMinus).toFixed(3).replace('.', ',') + ' c'; const n = Math.min(14, Math.floor(-Math.log10(oneMinus))); const digits = 1 - oneMinus; let s = '0,' + '9'.repeat(n); const rest = Math.floor((digits * 10 ** (n + 1)) % 10); return s + rest + ' c'; };
 // Campo de estrellas «hacia delante» con aberración relativista ESTILIZADA: proyección estereográfica cuyo radio se escala por e^(−η)
 // (las estrellas se agrupan al frente y se azulan; detrás se enrojecen). o: { n, eta (rapidez visual), cx, cy, F, drift, seed, a }
 let STARS3 = null;
 P.starfield = (ctx, t, o = {}) => {
  const n = o.n || 900; if (!STARS3 || STARS3.n !== n) { const R = H.rng(o.seed || 42), arr = []; for (let i = 0; i < n; i++) { const z = R() * 2 - 1, ph = R() * TAU, m = R(); arr.push([Math.acos(z), ph, Math.pow(m, 3), R()]); } STARS3 = { n, arr }; }
  const cx = o.cx ?? W / 2, cy = o.cy ?? HH * 0.42, F = o.F || 520, k = Math.exp(-(o.eta || 0)), a0 = o.a ?? 1, dr = (o.drift || 0) * t;
  ctx.save(); for (const [th, ph0, m, tw] of STARS3.arr) { const r = F * Math.tan(Math.min(th, 3.05) / 2) * k, ph = ph0 + dr * 0.02; const x = cx + Math.cos(ph) * r, y = cy + Math.sin(ph) * r; if (x < -10 || x > W + 10 || y < -10 || y > HH + 10) continue;
   const fwd = Math.cos(2 * Math.atan(Math.tan(th / 2) * k)), dop = (o.eta || 0) > 0 ? cl(0.5 + 0.5 * fwd * Math.tanh(o.eta)) : 0.5; const col = dop > 0.5 ? [lerp(255, 170, (dop - 0.5) * 2), lerp(250, 205, (dop - 0.5) * 2), 255] : [255, lerp(200, 250, dop * 2), lerp(170, 240, dop * 2)];
   const b = (0.35 + 0.65 * m) * (0.8 + 0.2 * Math.sin(t * 2 + tw * 9)) * a0 * (1 + ((o.eta || 0) > 0 ? cl(fwd) * 0.6 : 0)); ctx.fillStyle = `rgba(${col[0] | 0},${col[1] | 0},${col[2] | 0},${cl(b)})`; const s = 0.8 + m * 2.2; ctx.fillRect(x - s / 2, y - s / 2, s, s); if (m > 0.85) P.glow(ctx, x, y, s * 5, `${col[0] | 0},${col[1] | 0},${col[2] | 0}`, 0.35 * b); }
  ctx.restore();
 };
 // Fondo de espacio profundo (degradado + neblina tenue) — sin nebulosas exageradas
 P.space = (ctx, o = {}) => { const g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, o.top || '#02040D'); g.addColorStop(1, o.bot || '#081B42'); ctx.fillStyle = g; ctx.fillRect(-2000, -2000, W + 4000, HH + 4000); if (o.haze !== false) { P.glow(ctx, W * 0.7, HH * 0.3, 700, '87,52,166', 0.12); P.glow(ctx, W * 0.2, HH * 0.75, 600, '37,139,255', 0.08); } };
 // Galaxia espiral (partículas en brazos logarítmicos + bulbo), pre-renderizada en caché. Dibujo: posición, radio, ángulo de giro, inclinación.
 // o: { arms, tilt (0..1: 1 = de frente), rot, seed, core ('255,200,107'), arm ('140,180,255'), dust }
 const GAL = {};
 P.galaxy = (ctx, x, y, r, o = {}) => {
  const key = [o.seed || 1, o.arms || 2, o.core || '', o.arm || '', o.dust ?? 1].join('|'); if (!GAL[key]) { const S = 900, c = H.layer(S, S), g = c.getContext('2d'), R = H.rng(o.seed || 1), arms = o.arms || 2; g.globalCompositeOperation = 'lighter';
   const core = o.core || '255,200,107', arm = o.arm || '140,180,255';
   const bg = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S * 0.5); bg.addColorStop(0, `rgba(${core},0.9)`); bg.addColorStop(0.08, `rgba(${core},0.55)`); bg.addColorStop(0.3, `rgba(${arm},0.12)`); bg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = bg; g.fillRect(0, 0, S, S);
   for (let i = 0; i < 26000; i++) { const k = Math.floor(R() * arms), u = Math.pow(R(), 0.7), th = u * 4.2 + k * TAU / arms + R.gauss() * 0.28 * (1 - u * 0.5), rr = (0.05 + u * 0.45) * S + R.gauss() * 10; const px = S / 2 + Math.cos(th) * rr, py = S / 2 + Math.sin(th) * rr, col = R() < 0.25 + 0.6 * (1 - u) ? core : arm; g.fillStyle = `rgba(${col},${R.range(0.05, 0.28)})`; const s = R.range(0.8, 2.6); g.fillRect(px, py, s, s); }
   if ((o.dust ?? 1) > 0) { g.globalCompositeOperation = 'source-over'; for (let i = 0; i < 2500; i++) { const k = Math.floor(R() * arms), u = R(), th = u * 4.2 + k * TAU / arms + 0.35 + R.gauss() * 0.12, rr = (0.08 + u * 0.4) * S; g.fillStyle = `rgba(10,6,18,${R.range(0.05, 0.18)})`; g.beginPath(); g.arc(S / 2 + Math.cos(th) * rr, S / 2 + Math.sin(th) * rr, R.range(2, 6), 0, TAU); g.fill(); } }
   GAL[key] = c; }
  const im = GAL[key]; ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.scale(1, o.tilt ?? 1); ctx.globalAlpha *= o.a ?? 1; ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(im, -r, -r, r * 2, r * 2); ctx.restore();
 };
 // Nave interestelar de perfil (proa a la DERECHA): casco, anillo habitable, depósitos, escudo frontal y tobera con chorro (thrust 0..1).
 // ang: rotación (π = proa a la izquierda, p. ej. para frenar). o: { cut (muestra el interior por zonas), labels }
 P.spaceship = (ctx, x, y, s, ang = 0, t = 0, o = {}) => {
  const th = o.thrust ?? 0; ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  if (th > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const L = s * (0.9 + 1.6 * th) * (0.95 + 0.05 * Math.sin(t * 30)); const g = ctx.createLinearGradient(-s * 0.95, 0, -s * 0.95 - L, 0); g.addColorStop(0, `rgba(230,255,255,${0.95 * th})`); g.addColorStop(0.25, `rgba(105,243,255,${0.7 * th})`); g.addColorStop(1, 'rgba(37,139,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-s * 0.95, -s * 0.09); ctx.lineTo(-s * 0.95 - L, -s * 0.02); ctx.lineTo(-s * 0.95 - L, s * 0.02); ctx.lineTo(-s * 0.95, s * 0.09); ctx.closePath(); ctx.fill(); P.glow(ctx, -s * 0.97, 0, s * 0.35, '105,243,255', 0.8 * th); ctx.restore(); }
  const hull = ctx.createLinearGradient(0, -s * 0.12, 0, s * 0.12); hull.addColorStop(0, '#dfe8f2'); hull.addColorStop(0.5, '#8ea3b8'); hull.addColorStop(1, '#3b4b5e');
  ctx.fillStyle = '#3b4b5e'; ctx.beginPath(); ctx.moveTo(-s * 0.95, -s * 0.12); ctx.lineTo(-s * 0.78, -s * 0.06); ctx.lineTo(-s * 0.78, s * 0.06); ctx.lineTo(-s * 0.95, s * 0.12); ctx.closePath(); ctx.fill();
  ctx.fillStyle = hull; ctx.beginPath(); ctx.moveTo(-s * 0.8, -s * 0.06); ctx.lineTo(s * 0.62, -s * 0.06); ctx.quadraticCurveTo(s * 0.98, -s * 0.05, s * 1.0, 0); ctx.quadraticCurveTo(s * 0.98, s * 0.05, s * 0.62, s * 0.06); ctx.lineTo(-s * 0.8, s * 0.06); ctx.closePath(); ctx.fill();
  for (const dx of [-0.6, -0.42, -0.24]) { ctx.fillStyle = '#6f8296'; ctx.beginPath(); ctx.ellipse(s * dx, 0, s * 0.08, s * 0.1, 0, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#cfdbe6'; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.ellipse(s * 0.15, 0, s * 0.05, s * 0.26, 0, 0, TAU); ctx.stroke(); ctx.lineWidth = s * 0.012; for (const sgn of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * 0.15, sgn * s * 0.06); ctx.lineTo(s * 0.15, sgn * s * 0.25); ctx.stroke(); }
  ctx.fillStyle = '#c9d6e2'; ctx.beginPath(); ctx.ellipse(s * 0.93, 0, s * 0.05, s * 0.14, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(54,217,255,0.9)'; for (let i = 0; i < 6; i++) ctx.fillRect(s * (0.35 + i * 0.04), -s * 0.035, s * 0.018, s * 0.012);
  if ((o.cut || 0) > 0) { ctx.globalAlpha = o.cut; const zones = [[-0.95, -0.78, '#69F3FF'], [-0.7, -0.16, '#FFC86B'], [0.05, 0.26, '#46E6D2'], [0.86, 1.0, '#FF695F']]; zones.forEach(([a, b, c2]) => { ctx.fillStyle = H.rgba(H.hex(c2), 0.45); ctx.fillRect(s * a, -s * 0.07, s * (b - a), s * 0.14); }); ctx.globalAlpha = 1; }
  ctx.restore();
 };
 // Reloj de misión (panel): etiqueta, valor grande y barra de progreso. o: { sub, prog 0..1, w, px }
 P.missionClock = (ctx, x, y, label, value, color, o = {}) => {
  const w = o.w || 440, h = o.h || 150, px = o.px || 58; ctx.save(); P.rr(ctx, x - w / 2, y - h / 2, w, h, 22, 'rgba(2,4,13,0.82)'); ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, 22); ctx.stroke();
  ctx.fillStyle = color; ctx.font = '700 22px "IBM Plex Mono"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, x, y - h * 0.3); ctx.font = `700 ${px}px "Space Grotesk"`; ctx.fillStyle = '#F6FAFF'; ctx.fillText(value, x, y + h * 0.04);
  if (o.sub) { ctx.font = '600 18px "IBM Plex Mono"'; ctx.fillStyle = 'rgba(246,250,255,0.7)'; ctx.fillText(o.sub, x, y + h * 0.33); }
  if (o.prog != null) { ctx.fillStyle = 'rgba(246,250,255,0.15)'; ctx.fillRect(x - w / 2 + 20, y + h / 2 - 14, w - 40, 5); ctx.fillStyle = color; ctx.fillRect(x - w / 2 + 20, y + h / 2 - 14, (w - 40) * cl(o.prog), 5); }
  ctx.restore();
 };
 // Velocímetro en fracción de c: aguja que se acerca a c sin tocarla (escala logarítmica en 1 − v/c). o: { label }
 P.speedGauge = (ctx, x, y, r, oneMinus, o = {}) => {
  const p = cl(Math.log10(Math.max(1e-14, Math.min(1, oneMinus))) / -14); ctx.save(); ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(246,250,255,0.15)'; ctx.lineWidth = r * 0.12; ctx.beginPath(); ctx.arc(x, y, r, Math.PI * 0.8, Math.PI * 2.2); ctx.stroke();
  ctx.strokeStyle = '#36D9FF'; ctx.beginPath(); ctx.arc(x, y, r, Math.PI * 0.8, Math.PI * 0.8 + Math.PI * 1.4 * p * 0.985); ctx.stroke();
  ctx.strokeStyle = '#FF695F'; ctx.lineWidth = r * 0.05; const ea = Math.PI * 2.2; ctx.beginPath(); ctx.moveTo(x + Math.cos(ea) * r * 0.82, y + Math.sin(ea) * r * 0.82); ctx.lineTo(x + Math.cos(ea) * r * 1.18, y + Math.sin(ea) * r * 1.18); ctx.stroke();
  ctx.fillStyle = '#FF695F'; ctx.font = `700 ${r * 0.16}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('c', x + Math.cos(ea) * r * 1.32, y + Math.sin(ea) * r * 1.32);
  const bt = P.betaText(oneMinus), fs = Math.min(r * 0.2, (r * 1.55) / (bt.length * 0.56)); ctx.fillStyle = '#F6FAFF'; ctx.font = `700 ${fs}px "Space Grotesk"`; ctx.fillText(bt, x, y + r * 0.05); ctx.font = `600 ${r * 0.11}px "IBM Plex Mono"`; ctx.fillStyle = 'rgba(246,250,255,0.75)'; ctx.fillText(o.label || 'velocidad / c', x, y + r * 0.35); ctx.restore();
 };
 // Diagrama de espacio-tiempo (Minkowski): x horizontal, t hacia arriba, conos de luz a 45°, líneas de universo con marcas de tiempo propio.
 // lines: [{ pts: [[x, t]…] (unidades del diagrama 0..1), c, ticks: [[x, t]…], label }]. Devuelve map(x, t) → [px, py].
 P.spacetime = (ctx, x, y, w, h, lines = [], o = {}) => {
  const map = (u, v) => [x + u * w, y + h - v * h]; ctx.save(); P.rr(ctx, x - 20, y - 20, w + 40, h + 40, 20, 'rgba(2,4,13,0.75)');
  ctx.strokeStyle = 'rgba(246,250,255,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(...map(0, 0)); ctx.lineTo(...map(1, 0)); ctx.moveTo(...map(0, 0)); ctx.lineTo(...map(0, 1)); ctx.stroke();
  ctx.fillStyle = 'rgba(246,250,255,0.75)'; ctx.font = '600 20px "IBM Plex Mono"'; ctx.textAlign = 'left'; ctx.fillText(o.xLabel || 'distancia →', x + w - 150, y + h + 4 + 22); ctx.save(); ctx.translate(x - 8, y + 10); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'right'; ctx.fillText(o.tLabel || 'tiempo (Tierra) →', 0, 0); ctx.restore();
  if (o.light !== false) { ctx.setLineDash([8, 8]); ctx.strokeStyle = 'rgba(255,212,71,0.6)'; ctx.beginPath(); ctx.moveTo(...map(0, 0)); ctx.lineTo(...map(Math.min(1, h / w), Math.min(1, w / h))); ctx.stroke(); ctx.setLineDash([]); }
  for (const L of lines) { if (!L.pts || L.pts.length < 2) continue; P.strokePath(ctx, L.pts.map((p) => map(p[0], p[1])), o.lw || 5, L.c); for (const tk of L.ticks || []) { const [px, py] = map(tk[0], tk[1]); P.circle(ctx, px, py, 6, L.c); } if (L.label) { const [lx, ly] = map(...L.pts[L.pts.length - 1]); ctx.fillStyle = L.c; ctx.font = '800 24px Nunito'; ctx.textAlign = 'center'; ctx.fillText(L.label, lx, ly - 16); } }
  ctx.restore(); return map;
 };
 // Cabina vista desde atrás del astronauta: ventana panorámica (view(x, y, w, h) dibuja el exterior), consolas y silueta.
 P.cockpit = (ctx, t, view, o = {}) => {
  const wx = 90, wy = o.wy ?? 360, ww = W - 180, wh = o.wh ?? 700; ctx.save(); ctx.fillStyle = '#0b1424'; ctx.fillRect(0, 0, W, HH);
  ctx.save(); ctx.beginPath(); ctx.roundRect(wx, wy, ww, wh, 60); ctx.clip(); view(wx, wy, ww, wh); const gl = ctx.createLinearGradient(wx, wy, wx + ww, wy + wh); gl.addColorStop(0, 'rgba(255,255,255,0.06)'); gl.addColorStop(0.5, 'rgba(255,255,255,0)'); gl.addColorStop(1, 'rgba(255,255,255,0.04)'); ctx.fillStyle = gl; ctx.fillRect(wx, wy, ww, wh); ctx.restore();
  ctx.strokeStyle = '#3d4f66'; ctx.lineWidth = 26; ctx.beginPath(); ctx.roundRect(wx, wy, ww, wh, 60); ctx.stroke(); ctx.strokeStyle = '#5c7088'; ctx.lineWidth = 4; ctx.stroke();
  const cy = wy + wh + 40; const cg = ctx.createLinearGradient(0, cy, 0, HH); cg.addColorStop(0, '#1b2a40'); cg.addColorStop(1, '#070d18'); ctx.fillStyle = cg; ctx.beginPath(); ctx.moveTo(0, cy + 60); ctx.quadraticCurveTo(W / 2, cy - 30, W, cy + 60); ctx.lineTo(W, HH); ctx.lineTo(0, HH); ctx.closePath(); ctx.fill();
  const R = H.rng(12); for (let i = 0; i < 14; i++) { const x = 90 + i * 66, on = Math.sin(t * (1 + R() * 3) + i) > 0; ctx.fillStyle = on ? ['#36D9FF', '#46E6D2', '#FFC86B'][i % 3] : 'rgba(246,250,255,0.15)'; ctx.fillRect(x, cy + 70 + (i % 2) * 18, 30, 8); }
  if (o.pilot !== false) { const px = W / 2 + (o.pilotX || 0), py = cy + 230; ctx.fillStyle = '#05080f'; ctx.beginPath(); ctx.ellipse(px, py - 150, 70, 78, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(px - 190, py + 200); ctx.quadraticCurveTo(px - 170, py - 60, px, py - 70); ctx.quadraticCurveTo(px + 170, py - 60, px + 190, py + 200); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(105,243,255,0.35)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(px, py - 150, 74, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); }
  ctx.restore(); return { wx, wy, ww, wh };
 };
 // Silueta de científico (perfil, pelo alborotado) para referencias históricas breves (sin parecido fotográfico)
 P.scientist = (ctx, x, y, h, o = {}) => {
  ctx.save(); ctx.fillStyle = o.c || '#F6FAFF'; ctx.globalAlpha *= o.a ?? 1; ctx.beginPath(); ctx.ellipse(x, y - h * 0.78, h * 0.11, h * 0.13, 0, 0, TAU); ctx.fill(); const R = H.rng(3); for (let i = 0; i < 26; i++) { const a = -Math.PI * 0.95 + R() * Math.PI * 1.15, rr = h * R.range(0.12, 0.2); ctx.beginPath(); ctx.arc(x - h * 0.02 + Math.cos(a) * rr, y - h * 0.8 + Math.sin(a) * rr * 0.85, h * R.range(0.02, 0.04), 0, TAU); ctx.fill(); }
  ctx.beginPath(); ctx.moveTo(x - h * 0.1, y - h * 0.66); ctx.quadraticCurveTo(x - h * 0.26, y - h * 0.5, x - h * 0.24, y); ctx.lineTo(x + h * 0.24, y); ctx.quadraticCurveTo(x + h * 0.26, y - h * 0.5, x + h * 0.1, y - h * 0.66); ctx.closePath(); ctx.fill(); ctx.restore();
 };

 // ======================= v1.11 · MALLA 3D, NAVE CINEMATOGRÁFICA, ESPACIO PROFUNDO Y GRÁFICAS CIENTÍFICAS =======================
 // Motor 3D mínimo para Canvas: mallas de caras (polígonos) con sombreado lambert + luz de contorno, orden por profundidad (pintor)
 // y descarte de caras traseras. Ejes del objeto: +x hacia delante, +y arriba, +z hacia la cámara. Rotaciones: yaw (eje y), pitch (eje z), roll (eje x).
 P.M3 = (() => {
  const rot = (v, yaw, pitch, roll) => { let [x, y, z] = v; let c = Math.cos(roll), s = Math.sin(roll); [y, z] = [y * c - z * s, y * s + z * c]; c = Math.cos(pitch); s = Math.sin(pitch); [x, y] = [x * c - y * s, x * s + y * c]; c = Math.cos(yaw); s = Math.sin(yaw); [x, z] = [x * c + z * s, -x * s + z * c]; return [x, y, z]; };
  // loft: estaciones [[x, ry, rz]] con «sides» lados → caras; color base; caps cierra los extremos
  const loft = (st, sides, col, o = {}) => { const ring = st.map(([x, ry, rz]) => { const r = []; for (let k = 0; k < sides; k++) { const a = (k + 0.5) / sides * TAU + (o.rot || 0); r.push([x, Math.cos(a) * ry + (o.oy || 0), Math.sin(a) * rz + (o.oz || 0)]); } return r; }); const F = [];
   for (let i = 0; i < st.length - 1; i++) for (let k = 0; k < sides; k++) { const k2 = (k + 1) % sides; F.push({ v: [ring[i][k], ring[i + 1][k], ring[i + 1][k2], ring[i][k2]], c: (o.bands && i % o.bands === 0) ? (o.c2 || col) : col, line: o.line, tag: o.tag }); }
   if (o.caps !== false) { F.push({ v: ring[0].slice().reverse(), c: o.capC || col, tag: o.tag, cap: 'back' }); F.push({ v: ring[st.length - 1].slice(), c: o.capC2 || o.capC || col, tag: o.tag, cap: 'front' }); } return F; };
  const box = (cx, cy, cz, sx, sy, sz, col, tag, two) => { const p = (a, b, c) => [cx + a * sx, cy + b * sy, cz + c * sz]; const V = [p(-1, -1, -1), p(1, -1, -1), p(1, 1, -1), p(-1, 1, -1), p(-1, -1, 1), p(1, -1, 1), p(1, 1, 1), p(-1, 1, 1)]; const q = (a, b, c, d) => ({ v: [V[a], V[b], V[c], V[d]], c: col, tag, two }); return [q(0, 3, 2, 1), q(4, 5, 6, 7), q(0, 1, 5, 4), q(2, 3, 7, 6), q(1, 2, 6, 5), q(0, 4, 7, 3)]; };
  // dibuja: o = { x, y, s (px por unidad), yaw, pitch, roll, light [x,y,z], persp (0 = ortográfica), xf(v, face) transformación previa por cara }
  const draw = (ctx, faces, o) => { const L = o.light || [-0.45, 0.55, 0.7], ln = Math.hypot(...L), Ln = L.map((q) => q / ln), d = o.persp ?? 6, out = [];
   for (const f of faces) { const vs = f.v.map((v) => rot(o.xf ? o.xf(v, f) : v, o.yaw || 0, o.pitch || 0, o.roll || 0)); const a = vs[0], b = vs[1], c = vs[2]; const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], w = [c[0] - a[0], c[1] - a[1], c[2] - a[2]]; let n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]]; const nl = Math.hypot(...n) || 1; n = n.map((q) => q / nl);
    if (!f.two && n[2] < 0) continue; if (f.two && n[2] < 0) n = n.map((q) => -q); const zc = vs.reduce((s2, v) => s2 + v[2], 0) / vs.length;
    const pts = vs.map(([x, y, z]) => { const k = d ? d / (d - z) : 1; return [o.x + x * o.s * k, o.y - y * o.s * k]; });
    const lam = Math.max(0, n[0] * Ln[0] + n[1] * Ln[1] + n[2] * Ln[2]), rim = Math.pow(1 - Math.abs(n[2]), 3); out.push({ pts, z: zc, lam, rim, f }); }
   out.sort((p, q) => p.z - q.z);
   for (const it of out) { const base = H.hex(it.f.c), amb = it.f.emit ? 1 : 0.32, k = amb + (it.f.emit ? 0 : 0.78 * it.lam), sp = Math.pow(it.lam, 18) * 0.5; const col = [base[0] * k + 255 * sp + 90 * it.rim * 0.35, base[1] * k + 255 * sp + 150 * it.rim * 0.35, base[2] * k + 255 * sp + 255 * it.rim * 0.35].map((q) => Math.min(255, q | 0));
    ctx.fillStyle = `rgb(${col[0]},${col[1]},${col[2]})`; ctx.beginPath(); it.pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); ctx.strokeStyle = it.f.line ? `rgba(10,16,24,${it.f.line})` : ctx.fillStyle; ctx.lineWidth = it.f.line ? 1 : 0.8; ctx.stroke(); }
   return out; };
  const project = (v, o) => { const [x, y, z] = rot(v, o.yaw || 0, o.pitch || 0, o.roll || 0), d = o.persp ?? 6, k = d ? d / (d - z) : 1; return [o.x + x * o.s * k, o.y - y * o.s * k, z]; };
  return { rot, loft, box, draw, project };
 })();
 // NAVE INTERESTELAR «ASOMBROTECA» (diseño original): escudo frontal lenticular contra polvo, espina de titanio, anillo habitable giratorio
 // con radios, depósitos blancos, radiadores térmicos, bloque de propulsión con 3 toberas y chorro de partículas. Unidades: largo 2 (x −1…+1).
 // P.starship(ctx, x, y, s, t, { yaw, pitch, roll, thrust 0..1, light, ring (giro), persp, glow }) — s = px por unidad (la nave mide 2s).
 let SHIP = null;
 const buildShip = () => { const M = P.M3, F = [];
  const TI = '#5d6b78', TI2 = '#46525e', WH = '#d8e1e9', DK = '#2c343d';
  F.push(...M.loft([[0.84, 0.03, 0.03], [0.9, 0.2, 0.2], [0.93, 0.21, 0.21], [0.97, 0.1, 0.1], [1.0, 0.035, 0.035]], 24, '#c9d4de', { line: 0.05, tag: 'shield' }));
  F.push(...M.loft([[1.0, 0.02, 0.02], [1.12, 0.004, 0.004]], 6, '#9aa7b4', { tag: 'probe' }));
  F.push(...M.loft([[-0.62, 0.07, 0.07], [-0.4, 0.075, 0.075], [-0.1, 0.07, 0.07], [0.15, 0.06, 0.06], [0.45, 0.055, 0.055], [0.7, 0.05, 0.05], [0.86, 0.04, 0.04]], 10, TI, { bands: 2, c2: TI2, line: 0.35, tag: 'spine' }));
  F.push(...M.loft([[0.48, 0.09, 0.09], [0.52, 0.13, 0.13], [0.66, 0.13, 0.13], [0.7, 0.09, 0.09]], 12, WH, { line: 0.3, tag: 'cmd' }));
  F.push(...M.loft([[-0.14, 0.05, 0.05], [-0.08, 0.095, 0.085], [0.12, 0.1, 0.09], [0.38, 0.085, 0.075], [0.47, 0.06, 0.055]], 8, '#4f5d6a', { line: 0.45, bands: 2, c2: '#66778a', tag: 'fairing' }));
  for (let k = 0; k < 4; k++) { const a = k / 4 * TAU + Math.PI / 4, oy = Math.cos(a) * 0.14, oz = Math.sin(a) * 0.14; F.push(...M.loft([[-0.5, 0.0, 0.0], [-0.47, 0.055, 0.055], [-0.12, 0.055, 0.055], [-0.09, 0.0, 0.0]], 10, WH, { oy, oz, line: 0.2, tag: 'tank', bands: 3, c2: '#b9c6d2' })); }
  // anillo habitable (toro) + radios — marcado «spin» para girar sobre el eje x
  const R0 = 0.3, r0 = 0.04, NU = 32, NV = 6, xr = 0.25; const tor = (u, v) => [xr + Math.cos(v) * r0, (R0 + Math.sin(v) * r0) * Math.cos(u), (R0 + Math.sin(v) * r0) * Math.sin(u)];
  for (let i = 0; i < NU; i++) for (let j = 0; j < NV; j++) { const u0 = i / NU * TAU, u1 = (i + 1) / NU * TAU, v0 = j / NV * TAU, v1 = (j + 1) / NV * TAU; F.push({ v: [tor(u0, v0), tor(u0, v1), tor(u1, v1), tor(u1, v0)], c: i % 4 === 0 ? '#9fb2c2' : WH, spin: true, line: i % 4 === 0 ? 0.3 : 0, tag: 'ring' }); }
  for (let k = 0; k < 4; k++) { const a = k / 4 * TAU; const ca = Math.cos(a), sa = Math.sin(a), w = 0.012; F.push({ v: [[xr - w, 0.06 * ca, 0.06 * sa], [xr - w, (R0 - 0.03) * ca, (R0 - 0.03) * sa], [xr + w, (R0 - 0.03) * ca, (R0 - 0.03) * sa], [xr + w, 0.06 * ca, 0.06 * sa]], c: '#8ea0b0', two: true, spin: true, tag: 'spoke' }); }
  // radiadores (dos pares, finos, ligeramente en V)
  for (const sg of [1, -1]) { const y0 = 0.07 * sg, y1 = 0.42 * sg; F.push({ v: [[-0.42, y0, 0.0], [-0.02, y0, 0.0], [-0.08, y1, 0.06], [-0.38, y1, 0.06]], c: '#3a4652', two: true, line: 0.5, tag: 'rad' }); for (let i = 1; i < 6; i++) { const x0 = -0.42 + i * 0.066; F.push({ v: [[x0 - 0.004, y0, 0.001], [x0 + 0.004, y0, 0.001], [x0 + 0.004 - 0.01, y1, 0.061], [x0 - 0.004 - 0.01, y1, 0.061]], c: '#ff9a5a', two: true, emit: true, tag: 'radline' }); } }
  // bloque de propulsión y 3 toberas
  F.push(...M.loft([[-0.78, 0.15, 0.15], [-0.74, 0.17, 0.17], [-0.6, 0.16, 0.16], [-0.56, 0.1, 0.1]], 12, TI2, { line: 0.4, tag: 'engblock', bands: 1, c2: DK }));
  for (let k = 0; k < 3; k++) { const a = k / 3 * TAU + Math.PI / 2, oy = Math.cos(a) * 0.085, oz = Math.sin(a) * 0.085; F.push(...M.loft([[-0.78, 0.045, 0.045], [-0.86, 0.06, 0.06], [-0.93, 0.08, 0.08]], 12, '#7b8794', { oy, oz, caps: false, line: 0.3, tag: 'bell' })); F.push(...M.loft([[-0.93, 0.075, 0.075], [-0.931, 0.0, 0.0]], 12, '#bff8ff', { oy, oz, caps: false, tag: 'core', two: true }).map((f) => ({ ...f, emit: true, two: true }))); }
  // franjas de acento cian (emisivas) en el módulo de mando
  F.push(...M.loft([[0.585, 0.132, 0.132], [0.595, 0.132, 0.132]], 12, '#46E6D2', { caps: false, tag: 'accent' }).map((f) => ({ ...f, emit: true })));
  return F; };
 P.starship = (ctx, x, y, s, t, o = {}) => {
  if (!SHIP) SHIP = buildShip(); const ringA = (o.ring ?? t * 0.35), cr = Math.cos(ringA), sr = Math.sin(ringA);
  const view = { x, y, s, yaw: o.yaw || 0, pitch: o.pitch || 0, roll: o.roll || 0, light: o.light, persp: o.persp ?? 5, xf: (v, f) => (f.spin ? [v[0], v[1] * cr - v[2] * sr, v[1] * sr + v[2] * cr] : v) };
  const th = o.thrust ?? 0;
  // chorro: partículas deterministas detrás de cada tobera (se dibujan antes si la cola está hacia atrás, después si apunta a cámara)
  const plume = () => { if (th <= 0) return; ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (let k = 0; k < 3; k++) { const a = k / 3 * TAU + Math.PI / 2, oy = Math.cos(a) * 0.085, oz = Math.sin(a) * 0.085; const ex = P.M3.project([-0.95, oy, oz], view); P.glow(ctx, ex[0], ex[1], s * 0.22 * (0.8 + 0.4 * th), '105,243,255', 0.85 * th); const R = H.rng(77 + k); for (let i = 0; i < 70; i++) { const u = ((t * (1.6 + R() * 0.8) + R()) % 1), len = 0.25 + 1.4 * th, px = -0.95 - u * len, sp = 0.008 + u * 0.035 * (0.4 + 0.6 * th); const p = P.M3.project([px, oy + R.gauss() * sp, oz + R.gauss() * sp], view); const a2 = th * (1 - u) * 0.6; ctx.fillStyle = `rgba(${lerp(230, 60, u) | 0},${lerp(255, 160, u) | 0},255,${a2})`; const rr = s * (0.004 + 0.008 * (1 - u)); ctx.beginPath(); ctx.arc(p[0], p[1], rr, 0, TAU); ctx.fill(); } const tail = P.M3.project([-0.95 - (0.6 + 1.2 * th), oy, oz], view); const g = ctx.createLinearGradient(ex[0], ex[1], tail[0], tail[1]); g.addColorStop(0, `rgba(200,255,255,${0.55 * th})`); g.addColorStop(1, 'rgba(37,139,255,0)'); ctx.strokeStyle = g; ctx.lineWidth = s * 0.09 * (0.6 + 0.4 * th); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(ex[0], ex[1]); ctx.lineTo(tail[0], tail[1]); ctx.stroke(); } ctx.restore(); };
  const tailZ = P.M3.project([-1.3, 0, 0], view)[2]; if (tailZ < 0) plume();
  if (o.glow !== false) P.glow(ctx, x, y, s * 1.3, '40,90,180', 0.12);
  P.M3.draw(ctx, SHIP, view);
  if (tailZ >= 0) plume();
  // luces de navegación: roja (babor), verde (estribor), blanca intermitente en la proa
  const nav = [[[-0.38, 0.42, 0.06], '255,80,70', 0.9], [[-0.38, -0.42, 0.06], '70,255,140', 0.9], [[1.12, 0, 0], '255,255,255', (Math.sin(t * 6) > 0.6 ? 1 : 0.15)]]; ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (const [v, c, a] of nav) { const p = P.M3.project(v, view); P.glow(ctx, p[0], p[1], s * 0.05, c, a); } ctx.restore();
 };
 // ESPACIO PROFUNDO con paralaje: degradado azul-violeta-negro, nebulosa tenue en caché, 3 capas de estrellas que se desplazan distinto
 // con la cámara (o.px, o.py en px de «mundo»), polvo cercano opcional y estelas de movimiento ESTILIZADAS (o.streak 0..1, o.dir rad).
 let NEB = null, DSTAR = null;
 P.deepSpace = (ctx, t, o = {}) => {
  const g = ctx.createLinearGradient(0, 0, W * 0.3, HH); g.addColorStop(0, o.top || '#03050f'); g.addColorStop(0.55, o.mid || '#070d26'); g.addColorStop(1, o.bot || '#0a0a1f'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH);
  if (!NEB) { const S = 240, c = H.layer(S, S * 1.8 | 0), q = c.getContext('2d'), nz = H.makeNoise(19), img = q.createImageData(S, S * 1.8 | 0); for (let j = 0; j < c.height; j++) for (let i = 0; i < S; i++) { const v = nz.fbm3(i * 0.012, j * 0.012, 0.3, 5), w2 = nz.fbm3(i * 0.02 + 5, j * 0.02, 1.7, 4), k = (j * S + i) * 4, a = Math.max(0, v - 0.05) * 1.9, b = Math.max(0, w2 + 0.1) * 0.9; img.data[k] = 70 * a + 20 * b; img.data[k + 1] = 40 * a + 50 * b; img.data[k + 2] = 140 * a + 110 * b; img.data[k + 3] = Math.min(255, 255 * (0.55 * a + 0.35 * b)); } q.putImageData(img, 0, 0); NEB = c; }
  ctx.save(); ctx.globalAlpha = o.neb ?? 0.55; ctx.globalCompositeOperation = 'lighter'; ctx.imageSmoothingEnabled = true; const nx = -((o.px || 0) * 0.05) % 200, ny = -((o.py || 0) * 0.05) % 200; ctx.drawImage(NEB, nx - 100, ny - 100, W + 200, HH + 200); ctx.restore();
  if (!DSTAR) { const R = H.rng(23), L = []; for (const [n, z, s0, s1] of [[520, 0.08, 0.6, 1.4], [220, 0.25, 1.0, 2.2], [70, 0.6, 1.6, 3.4]]) { const arr = []; for (let i = 0; i < n; i++) arr.push([R() * W, R() * HH, R.range(s0, s1), R(), R()]); L.push({ z, arr }); } DSTAR = L; }
  const st = o.streak || 0, dir = o.dir ?? Math.PI / 2; ctx.save();
  for (const { z, arr } of DSTAR) { const ox = ((-(o.px || 0) * z) % W + W) % W, oy = ((-(o.py || 0) * z) % HH + HH) % HH; for (const [sx, sy, r, tw, hue] of arr) { const x = (sx + ox) % W, y = (sy + oy) % HH, b = 0.45 + 0.5 * Math.sin(t * 1.3 + tw * 9); const col = hue < 0.15 ? '255,214,170' : hue < 0.3 ? '170,200,255' : '246,250,255';
    if (st > 0 && z > 0.2) { const L2 = st * 120 * z; ctx.strokeStyle = `rgba(${col},${0.7 * b})`; ctx.lineWidth = r * 0.8; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - Math.cos(dir) * L2, y - Math.sin(dir) * L2); ctx.stroke(); }
    ctx.fillStyle = `rgba(${col},${b})`; ctx.fillRect(x - r / 2, y - r / 2, r, r); if (r > 2.6) P.glow(ctx, x, y, r * 5, col, 0.35 * b); } }
  ctx.restore();
 };
 // GALAXIA HD: ~90.000 partículas con color por radio, cúmulos rosados (regiones HII), carriles de polvo, halo y bloom (en caché).
 const GALHD = {};
 P.galaxyHD = (ctx, x, y, r, o = {}) => {
  const key = (o.seed || 1) + '|' + (o.arms || 2); if (!GALHD[key]) { const S = 1400, c = H.layer(S, S), g = c.getContext('2d'), R = H.rng(o.seed || 1), arms = o.arms || 2, C0 = S / 2;
   g.globalCompositeOperation = 'lighter';
   const halo = g.createRadialGradient(C0, C0, 0, C0, C0, S * 0.5); halo.addColorStop(0, 'rgba(255,236,200,0.8)'); halo.addColorStop(0.05, 'rgba(255,214,160,0.45)'); halo.addColorStop(0.18, 'rgba(200,190,230,0.16)'); halo.addColorStop(0.45, 'rgba(110,140,220,0.05)'); halo.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = halo; g.fillRect(0, 0, S, S);
   const star = (px, py, u, al, s2) => { const warm = cl(1 - u * 1.6); g.fillStyle = `rgba(${lerp(165, 255, warm) | 0},${lerp(190, 224, warm) | 0},${lerp(255, 178, warm) | 0},${al})`; g.fillRect(px, py, s2, s2); };
   for (let i = 0; i < 120000; i++) { const m = R(); let rr, th; if (m < 0.36) { rr = Math.min(0.5, -Math.log(1 - R() * 0.97) * 0.11) * S; th = R() * TAU; star(C0 + Math.cos(th) * rr, C0 + Math.sin(th) * rr, rr / (0.5 * S), R.range(0.03, 0.12), R.range(0.7, 1.8)); } else if (m < 0.9) { const k = Math.floor(R() * arms), u = Math.pow(R(), 0.95); rr = (0.05 + u * 0.43) * S + R.gauss() * S * 0.025 * (0.6 + u); th = u * 3.8 + k * TAU / arms + R.gauss() * 0.3 * (0.7 + 0.5 * u); star(C0 + Math.cos(th) * rr, C0 + Math.sin(th) * rr, u, R.range(0.1, 0.34), R.range(0.8, 2.4)); } else { rr = Math.abs(R.gauss()) * 0.045 * S; th = R() * TAU; star(C0 + Math.cos(th) * rr, C0 + Math.sin(th) * rr * 0.85, 0, R.range(0.08, 0.3), R.range(0.8, 2)); } }
   for (let i = 0; i < 160; i++) { const k = Math.floor(R() * arms), u = 0.12 + Math.pow(R(), 1.2) * 0.7, th = u * 3.8 + k * TAU / arms + R.gauss() * 0.12, rr = (0.05 + u * 0.43) * S; const px = C0 + Math.cos(th) * rr, py = C0 + Math.sin(th) * rr, rad = R.range(3, 9); const hg = g.createRadialGradient(px, py, 0, px, py, rad); hg.addColorStop(0, 'rgba(255,150,200,0.35)'); hg.addColorStop(1, 'rgba(255,140,190,0)'); g.fillStyle = hg; g.fillRect(px - rad, py - rad, rad * 2, rad * 2); }
   g.globalCompositeOperation = 'source-over'; for (let i = 0; i < 5200; i++) { const k = Math.floor(R() * arms), u = R(), th = u * 3.8 + k * TAU / arms - 0.25 + R.gauss() * 0.08, rr = (0.06 + u * 0.42) * S; g.fillStyle = `rgba(8,5,14,${R.range(0.04, 0.14)})`; g.beginPath(); g.arc(C0 + Math.cos(th) * rr, C0 + Math.sin(th) * rr, R.range(2, 7), 0, TAU); g.fill(); }
   const b = H.layer(S, S), bg = b.getContext('2d'); bg.filter = 'blur(18px)'; bg.drawImage(c, 0, 0); g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.55; g.drawImage(b, 0, 0); g.globalAlpha = 1; GALHD[key] = c; }
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.scale(1, o.tilt ?? 1); ctx.rotate(o.spin || 0); ctx.globalAlpha *= o.a ?? 1; ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(GALHD[key], -r, -r, r * 2, r * 2); ctx.restore();
 };
 // RELOJ HOLOGRÁFICO: anillo con 60 marcas, arco de segundero que barre con el tiempo LOCAL, valor digital grande y etiqueta.
 P.holoClock = (ctx, x, y, r, secs, color, label, value, o = {}) => {
  const rgb = H.hex(color).join(','); ctx.save(); P.glow(ctx, x, y, r * 1.5, rgb, 0.18); ctx.fillStyle = 'rgba(3,6,16,0.82)'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  ctx.strokeStyle = `rgba(${rgb},0.9)`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); for (let k = 0; k < 60; k++) { const a = k / 60 * TAU - Math.PI / 2, l = k % 5 ? 0.06 : 0.12; ctx.lineWidth = k % 5 ? 2 : 4; ctx.strokeStyle = `rgba(${rgb},${k % 5 ? 0.45 : 0.9})`; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.9, y + Math.sin(a) * r * 0.9); ctx.lineTo(x + Math.cos(a) * r * (0.9 - l), y + Math.sin(a) * r * (0.9 - l)); ctx.stroke(); }
  const sa = ((secs % 60) / 60) * TAU; ctx.strokeStyle = color; ctx.lineWidth = r * 0.06; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(x, y, r * 0.97, -Math.PI / 2, -Math.PI / 2 + sa); ctx.stroke(); const hx = x + Math.cos(sa - Math.PI / 2) * r * 0.97, hy = y + Math.sin(sa - Math.PI / 2) * r * 0.97; P.glow(ctx, hx, hy, r * 0.12, rgb, 0.9);
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = color; ctx.font = `700 ${r * 0.13}px "IBM Plex Mono"`; ctx.fillText(label, x, y - r * 0.38); ctx.fillStyle = '#F6FAFF'; const fs = Math.min(r * 0.34, r * 1.6 / Math.max(4, value.length * 0.6)); ctx.font = `700 ${fs}px "Space Grotesk"`; ctx.fillText(value, x, y + r * 0.02); if (o.sub) { ctx.font = `600 ${r * 0.1}px "IBM Plex Mono"`; ctx.fillStyle = 'rgba(246,250,255,0.75)'; ctx.fillText(o.sub, x, y + r * 0.36); }
  ctx.restore();
 };
 // GRÁFICA CIENTÍFICA genérica (ejes con etiquetas grandes, rejilla, curvas con brillo que se dibujan con p 0..1, escala log en Y opcional).
 // series: [{ f(u) → [xv, yv] (u 0..1), c, w, label, dash }]. o: { xr [min,max], yr [min,max], logY, xLabel, yLabel, xTicks [[v, txt]], yTicks [[v, txt]], p }
 P.chart = (ctx, x, y, w, h, series, o = {}) => {
  const [x0, x1] = o.xr || [0, 1], [y0, y1] = o.yr || [0, 1], ly = (v) => (o.logY ? Math.log10(Math.max(v, 1e-12)) : v), Y0 = ly(y0), Y1 = ly(y1);
  const map = (xv, yv) => [x + (xv - x0) / (x1 - x0) * w, y + h - (ly(yv) - Y0) / (Y1 - Y0) * h]; ctx.save(); const a = o.a ?? 1; ctx.globalAlpha *= a;
  P.rr(ctx, x - 70, y - 40, w + 110, h + 130, 26, 'rgba(3,6,16,0.82)'); ctx.strokeStyle = 'rgba(54,217,255,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(x - 70, y - 40, w + 110, h + 130, 26); ctx.stroke();
  ctx.strokeStyle = 'rgba(246,250,255,0.1)'; ctx.lineWidth = 1.5; ctx.font = '600 22px "IBM Plex Mono"'; ctx.fillStyle = 'rgba(246,250,255,0.8)'; ctx.textBaseline = 'middle';
  for (const [v, s] of o.yTicks || []) { const [, py] = map(x0, v); ctx.beginPath(); ctx.moveTo(x, py); ctx.lineTo(x + w, py); ctx.stroke(); ctx.textAlign = 'right'; ctx.fillText(s, x - 10, py); }
  for (const [v, s] of o.xTicks || []) { const [px] = map(v, y0); ctx.beginPath(); ctx.moveTo(px, y); ctx.lineTo(px, y + h); ctx.stroke(); ctx.textAlign = 'center'; ctx.fillText(s, px, y + h + 26); }
  ctx.strokeStyle = 'rgba(246,250,255,0.75)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + h); ctx.lineTo(x + w, y + h); ctx.stroke();
  ctx.font = '700 24px "Space Grotesk"'; ctx.fillStyle = '#F6FAFF'; ctx.textAlign = 'center'; ctx.fillText(o.xLabel || '', x + w / 2, y + h + 66); ctx.save(); ctx.translate(x - 58, y + h / 2); ctx.rotate(-Math.PI / 2); ctx.fillText(o.yLabel || '', 0, -0); ctx.restore();
  const p = o.p ?? 1; for (const S of series) { const n = 160, pts = []; for (let i = 0; i <= n * p; i++) { const [xv, yv] = S.f(i / n); pts.push(map(xv, yv)); } if (pts.length < 2) continue; if (S.dash) ctx.setLineDash(S.dash); P.strokePath(ctx, pts, (S.w || 5) * 3, H.rgba(H.hex(S.c), 0.18)); P.strokePath(ctx, pts, S.w || 5, S.c); ctx.setLineDash([]); const e = pts[pts.length - 1]; P.glow(ctx, e[0], e[1], 24, H.hex(S.c).join(','), 0.9); if (S.label && p > 0.98) { ctx.font = '800 26px Nunito'; ctx.fillStyle = S.c; ctx.textAlign = S.al || 'right'; ctx.fillText(S.label, e[0] + (S.dx || -10), e[1] + (S.dy || -24)); } }
  ctx.restore(); return map;
 };

 // ======================= v1.12 · ANDES, MAMPOSTERÍA, TERRAZAS, DRENAJE Y AGUA (ingeniería histórica en montaña) =======================
 // Paisaje de montaña por capas con perspectiva atmosférica (lejos = más azulado y claro). o: { sky [arriba, abajo], sun [x, y], layers, seed, base }
 P.andes = (ctx, t, o = {}) => {
  const sk = o.sky || ['#5d8fb0', '#c9dbe2'], g = ctx.createLinearGradient(0, 0, 0, HH * 0.7); g.addColorStop(0, sk[0]); g.addColorStop(1, sk[1]); ctx.fillStyle = g; ctx.fillRect(-400, -400, W + 800, HH + 800);
  if (o.sun) { P.glow(ctx, o.sun[0], o.sun[1], 420, '255,236,200', 0.55); P.circle(ctx, o.sun[0], o.sun[1], 46, '#fff6e4'); }
  const nz = H.makeNoise(o.seed || 5), L = o.layers || [['#9db3bd', 620, 260, 0.003], ['#7d9a95', 760, 300, 0.004], ['#5f7f68', 920, 320, 0.005]];
  L.forEach(([c, y, amp, fq], i) => { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-400, HH + 400); for (let x = -400; x <= W + 400; x += 12) { const v = nz.fbm2(x * fq + i * 7.3, i * 3.1, 4); ctx.lineTo(x, y - Math.abs(v) * amp * 1.6 - (o.peaks ? Math.max(0, 1 - Math.abs(x - o.peaks[i % o.peaks.length]) / 220) * amp * 0.7 : 0)); } ctx.lineTo(W + 400, HH + 400); ctx.closePath(); ctx.fill(); });
 };
 // Banda de niebla que deriva (nubes bajas entre montañas). o: { a, seed, speed }
 let FOGC = null;
 P.fog = (ctx, y, h, t, o = {}) => {
  if (!FOGC) { const S = 256, c = H.layer(S * 2, S / 2), q = c.getContext('2d'), nz = H.makeNoise(41), img = q.createImageData(S * 2, S / 2); for (let j = 0; j < S / 2; j++) for (let i = 0; i < S * 2; i++) { const v = nz.fbm2(i * 0.02, j * 0.05, 4), fall = Math.sin(j / (S / 2) * Math.PI), k = (j * S * 2 + i) * 4, a = Math.max(0, (v + 0.35)) * fall; img.data[k] = 236; img.data[k + 1] = 242; img.data[k + 2] = 236; img.data[k + 3] = Math.min(255, a * 300); } q.putImageData(img, 0, 0); FOGC = c; }
  const a = o.a ?? 0.8; if (a <= 0) return; const off = ((t * (o.speed ?? 18) + (o.seed || 0) * 137) % (W * 2)); ctx.save(); ctx.globalAlpha *= a; for (let k = -1; k <= 1; k++) ctx.drawImage(FOGC, -off + k * W * 2, y, W * 2, h); ctx.restore();
 };
 // Lluvia en diagonal sobre un área. o: { x, y, w, h, a, n, ang, seed }
 P.rainSheet = (ctx, t, o = {}) => { const a = o.a ?? 1; if (a <= 0) return; const x0 = o.x ?? 0, y0 = o.y ?? 0, w = o.w ?? W, h = o.h ?? HH, n = o.n || 220, ang = o.ang ?? 0.18, R = H.rng(o.seed || 3); ctx.save(); ctx.strokeStyle = `rgba(210,232,245,${0.55 * a})`; ctx.lineWidth = 2; ctx.lineCap = 'round'; for (let i = 0; i < n; i++) { const sp = R.range(1100, 1700), L = R.range(22, 40), x = x0 + ((R() * w + t * sp * Math.sin(ang)) % w), y = y0 + ((R() * h + t * sp) % h); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - Math.sin(ang) * L, y - L); ctx.stroke(); } ctx.restore(); };
 // Relleno de granito (motas claras y oscuras) para cualquier polígono
 P.granite = (ctx, pts, o = {}) => {
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  ctx.save(); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); const g = ctx.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, o.c1 || '#c3c8bd'); g.addColorStop(1, o.c2 || '#858d86'); ctx.fillStyle = g; ctx.fill(); ctx.clip();
  const R = H.rng(o.seed || Math.round(x0 * 7 + y0)); const n = Math.min(160, ((x1 - x0) * (y1 - y0)) / 220); for (let i = 0; i < n; i++) { ctx.fillStyle = R() < 0.5 ? 'rgba(40,45,42,0.25)' : 'rgba(255,255,250,0.28)'; ctx.fillRect(x0 + R() * (x1 - x0), y0 + R() * (y1 - y0), R.range(1, 3), R.range(1, 3)); }
  ctx.restore();
  if (o.bevel !== false) { ctx.save(); ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(255,255,250,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(pts[pts.length - 1][0], pts[pts.length - 1][1]); for (let i = 0; i < Math.ceil(pts.length / 2); i++) ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke(); ctx.strokeStyle = 'rgba(30,34,32,0.55)'; ctx.lineWidth = o.joint ?? 2; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke(); ctx.restore(); }
 };
 // Muro de piedra. o.style: 'poligonal' (bloques irregulares que comparten vértices → encajan sin huecos), 'sillar' (hiladas rectangulares
 // finas), 'rustica' (piedras de campo con juntas de barro). o: { seed, rows, cols, skip (índice de bloque que NO se dibuja: hueco), gap }
 // Devuelve la lista de bloques (polígonos) para animar uno de ellos o hacer zoom a una junta.
 P.stoneWall = (ctx, x, y, w, h, o = {}) => {
  const st = o.style || 'poligonal', R = H.rng(o.seed || 9), cells = [];
  if (st === 'rustica') { ctx.save(); ctx.fillStyle = o.mortar || '#6b5a44'; ctx.fillRect(x, y, w, h); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); const rows = o.rows || Math.round(h / 36); for (let r = 0; r < rows; r++) { let cx = x - R() * 30; const rh = h / rows; while (cx < x + w) { const sw = R.range(rh * 0.9, rh * 2), pts = []; for (let k = 0; k < 7; k++) { const a = k / 7 * TAU, rx = sw / 2 - 3, ry = rh / 2 - 3; pts.push([cx + sw / 2 + Math.cos(a) * rx * R.range(0.8, 1.05), y + r * rh + rh / 2 + Math.sin(a) * ry * R.range(0.8, 1.05)]); } P.granite(ctx, pts, { seed: cells.length + 3, c1: '#b6bbb1', c2: '#7c847d', joint: 1 }); cells.push(pts); cx += sw + R.range(2, 6); } } ctx.restore(); return cells; }
  if (st === 'sillar') { const rows = o.rows || 5, rh = h / rows; for (let r = 0; r < rows; r++) { let cx = x - (r % 2) * R.range(10, 40); while (cx < x + w) { const bw = R.range(rh * 1.4, rh * 2.6), x2 = Math.min(x + w, cx + bw), x1 = Math.max(x, cx); const pts = [[x1, y + r * rh], [x2, y + r * rh], [x2, y + (r + 1) * rh], [x1, y + (r + 1) * rh]]; cells.push(pts); cx += bw; } } }
  else { const nx = o.cols || 5, ny = o.rows || 4, nodes = []; for (let j = 0; j <= ny; j++) { nodes.push([]); for (let i = 0; i <= nx; i++) { const ex = i === 0 || i === nx, ey = j === 0 || j === ny; nodes[j].push([x + i * w / nx + (ex ? 0 : R.range(-0.28, 0.28) * w / nx), y + j * h / ny + (ey ? 0 : R.range(-0.25, 0.25) * h / ny)]); } }
   for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const a = nodes[j][i], b = nodes[j][i + 1], c2 = nodes[j + 1][i + 1], d = nodes[j + 1][i], pts = [a]; if (R() < 0.5 && i < nx - 1) { const m = [lerp(b[0], c2[0], 0.45) + R.range(-8, 8), lerp(b[1], c2[1], 0.45)]; pts.push(b, m, c2); } else pts.push(b, c2); pts.push(d); cells.push(pts); } }
  cells.forEach((pts, k) => { if (k === o.skip) return; const gp = o.gap || 0; let q = pts; if (gp) { const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length, cy = pts.reduce((s, p) => s + p[1], 0) / pts.length; q = pts.map(([px, py]) => [cx + (px - cx) * (1 - gp), cy + (py - cy) * (1 - gp)]); } P.granite(ctx, q, { seed: k * 13 + 1, joint: st === 'poligonal' ? 1.4 : 2 }); });
  return cells;
 };
 // TERRAZAS en corte (de abajo-izquierda a arriba-derecha sobre una ladera). Cada terraza: muro de contención y relleno por capas
 // (de abajo arriba: piedras grandes → grava → arena → suelo cultivable). o: { build 0..1, cut 0..1 (muestra capas), water 0..1
 // (gotas que se infiltran y salen al pie del muro), crops, seed }. Devuelve { tops: [[x0, x1, y]…], walls: [[x, yBase, yTop]…] }.
 P.terraces = (ctx, x0, y0, sw, sh, n, t, o = {}) => {
  const b = o.build ?? 1, cut = o.cut ?? 0, tops = [], walls = [], wt = sw * 0.09;
  // roca y subsuelo bajo la ladera original
  ctx.save(); ctx.fillStyle = '#5a4a3a'; ctx.beginPath(); ctx.moveTo(x0 - 400, y0 + 900); ctx.lineTo(x0 - 400, y0 + 40); ctx.lineTo(x0, y0); ctx.lineTo(x0 + n * sw, y0 - n * sh); ctx.lineTo(x0 + n * sw + 600, y0 - n * sh - 120); ctx.lineTo(x0 + n * sw + 600, y0 + 900); ctx.closePath(); ctx.fill();
  const Rr = H.rng(o.seed || 4); ctx.fillStyle = 'rgba(133,141,134,0.5)'; for (let i = 0; i < 60; i++) { const px = x0 - 300 + Rr() * (n * sw + 800), py = y0 + 40 + Rr() * 600 - (px - x0) * sh / sw * 0.9; ctx.beginPath(); ctx.ellipse(px, py, Rr.range(8, 22), Rr.range(5, 12), Rr() * 3, 0, TAU); ctx.fill(); } ctx.restore();
  for (let i = 0; i < n; i++) { const p = cl((b * n - i) * 1.2); if (p <= 0) break; const xi = x0 + i * sw, base = y0 - i * sh, top = y0 - (i + 1) * sh, xn = xi + sw;
   walls.push([xi, base, top]); tops.push([xi, xn, top]);
   const tri = [[xi + wt, top], [xn, top], [xi + wt, base]];
   ctx.save(); ctx.globalAlpha *= p; ctx.beginPath(); tri.forEach((q, k) => (k ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.clip();
   const layers = [[0, 0.16, '#5b4330', 'suelo'], [0.16, 0.3, '#c7b18a', 'arena'], [0.3, 0.55, '#a6a79b', 'grava'], [0.55, 1.01, '#7c7f78', 'piedras']];
   if (cut > 0) { for (const [d0, d1, c] of layers) { ctx.fillStyle = c; ctx.fillRect(xi, top + d0 * sh, sw, (d1 - d0) * sh + 1); } const R = H.rng(i * 31 + 7); for (let k = 0; k < 90; k++) { const px = xi + R() * sw, py = top + (0.3 + R() * 0.25) * sh; ctx.fillStyle = 'rgba(80,82,76,0.6)'; ctx.beginPath(); ctx.arc(px, py, R.range(2, 4.5), 0, TAU); ctx.fill(); } for (let k = 0; k < 26; k++) { const px = xi + R() * sw, py = top + (0.58 + R() * 0.4) * sh; P.granite(ctx, [[px - 14, py - 8], [px + 12, py - 10], [px + 16, py + 8], [px - 10, py + 10]], { seed: k + i * 50, bevel: false }); } for (let k = 0; k < 60; k++) { ctx.fillStyle = 'rgba(150,130,95,0.6)'; ctx.fillRect(xi + R() * sw, top + (0.17 + R() * 0.12) * sh, 2, 2); } }
   ctx.fillStyle = `rgba(88,115,72,${1 - cut})`; ctx.fillRect(xi, top, sw, sh);
   if ((o.water || 0) > 0 && cut > 0.3) { const R = H.rng(i * 7 + 2); ctx.globalCompositeOperation = 'source-over'; for (let k = 0; k < 18; k++) { const u = ((t * 0.35 + R()) % 1), dx = R() * sw * 0.8, px = xn - dx - u * sw * 0.15, py = top + u * (base - top - 6) * (1 - dx / sw * 0.2); if (px < xi + wt) continue; ctx.fillStyle = `rgba(55,185,217,${0.9 * o.water})`; ctx.beginPath(); ctx.ellipse(px, py, 3.5, 5.5, 0, 0, TAU); ctx.fill(); } }
   ctx.restore();
   // superficie: cultivo
   ctx.save(); ctx.globalAlpha *= p; ctx.fillStyle = '#87a46b'; ctx.fillRect(xi, top - 6, sw, 8); if (o.crops !== false) { const R = H.rng(i + 90); ctx.strokeStyle = '#587348'; ctx.lineWidth = 3; for (let x = xi + wt + 10; x < xn - 6; x += 16) { const hh = R.range(10, 22); ctx.beginPath(); ctx.moveTo(x, top - 4); ctx.lineTo(x + R.range(-3, 3), top - 4 - hh); ctx.stroke(); } } ctx.restore();
   // muro de contención (piedra) con ligera inclinación
   ctx.save(); ctx.globalAlpha *= p; ctx.beginPath(); ctx.moveTo(xi - wt * 0.3, base); ctx.lineTo(xi + wt * 0.2, top); ctx.lineTo(xi + wt, top); ctx.lineTo(xi + wt, base); ctx.closePath(); ctx.clip(); P.stoneWall(ctx, xi - wt * 0.4, top, wt * 1.5, sh, { style: 'rustica', seed: i + 3, rows: Math.round(sh / 26) }); ctx.restore();
   // salida del agua al pie del muro
   if ((o.water || 0) > 0) { const R = H.rng(i + 5); for (let k = 0; k < 6; k++) { const u = (t * 0.9 + R()) % 1; ctx.fillStyle = `rgba(122,230,242,${o.water * (1 - u)})`; ctx.beginPath(); ctx.arc(xi - u * 26, base - 8 + u * u * 30, 4, 0, TAU); ctx.fill(); } }
  }
  return { tops, walls };
 };
 // CORTE DETALLADO DE UNA TERRAZA (diagrama grande): muro de contención a la izquierda, relleno por capas horizontales (suelo, arena,
 // grava, piedras), ladera natural (roca) debajo en diagonal, gotas que se infiltran y salen por el pie del muro.
 // o: { layers [[nombre, fracción, color]…], water 0..1, rain 0..1, labels 0..1 (fracción de capas rotuladas), reveal 0..1 }
 P.terraceCut = (ctx, x, y, w, h, t, o = {}) => {
  const L = o.layers || [['SUELO CULTIVABLE', 0.16, '#5b4330'], ['ARENA', 0.14, '#c7b18a'], ['GRAVA', 0.26, '#a6a79b'], ['PIEDRAS', 0.44, '#7c7f78']], wt = w * 0.13, rv = o.reveal ?? 1;
  const bed = (xx) => y + h + 40 - (xx - x) / w * h * 0.55; // roca natural (ladera) bajo el relleno
  ctx.save(); ctx.beginPath(); ctx.rect(x - 60, y - 40, w + 120, h + 400); ctx.clip();
  ctx.fillStyle = '#4a3c30'; ctx.beginPath(); ctx.moveTo(x - 60, y + h + 400); ctx.lineTo(x - 60, bed(x - 60)); ctx.lineTo(x + w + 60, bed(x + w + 60)); ctx.lineTo(x + w + 60, y + h + 400); ctx.closePath(); ctx.fill();
  const Rb = H.rng(3); for (let i = 0; i < 30; i++) { const px = x + Rb() * w, py = bed(px) + 20 + Rb() * 200; ctx.fillStyle = 'rgba(133,141,134,0.45)'; ctx.beginPath(); ctx.ellipse(px, py, Rb.range(10, 30), Rb.range(6, 14), 0, 0, TAU); ctx.fill(); }
  // relleno por capas (por encima de la roca)
  ctx.save(); ctx.beginPath(); ctx.moveTo(x + wt, y); ctx.lineTo(x + w + 60, y); ctx.lineTo(x + w + 60, bed(x + w + 60)); ctx.lineTo(x + wt, bed(x + wt)); ctx.closePath(); ctx.clip();
  let yy = y; const R = H.rng(o.seed || 12); L.forEach(([s, f, c], k) => { const lh = f * h; const a = cl(rv * L.length - k); ctx.globalAlpha = a; ctx.fillStyle = c; ctx.fillRect(x, yy, w + 60, lh + 1);
   if (s === 'GRAVA') for (let i = 0; i < 260; i++) { ctx.fillStyle = R() < 0.5 ? 'rgba(80,82,76,0.6)' : 'rgba(220,222,214,0.6)'; ctx.beginPath(); ctx.arc(x + R() * (w + 40), yy + R() * lh, R.range(2.5, 6), 0, TAU); ctx.fill(); }
   if (s === 'ARENA') for (let i = 0; i < 400; i++) { ctx.fillStyle = 'rgba(140,118,84,0.55)'; ctx.fillRect(x + R() * (w + 40), yy + R() * lh, 2, 2); }
   if (s === 'PIEDRAS') for (let i = 0; i < 34; i++) { const px = x + wt + R() * w, py = yy + 20 + R() * (lh - 30), sz = R.range(26, 48); P.granite(ctx, [[px - sz, py - sz * 0.6], [px + sz * 0.8, py - sz * 0.7], [px + sz, py + sz * 0.5], [px - sz * 0.7, py + sz * 0.6]], { seed: i + 3, bevel: false, c1: '#a8ada4', c2: '#6f766f' }); }
   if (s.startsWith('SUELO')) { for (let i = 0; i < 200; i++) { ctx.fillStyle = 'rgba(40,28,18,0.5)'; ctx.fillRect(x + R() * (w + 40), yy + R() * lh, 3, 2); } }
   yy += lh; }); ctx.globalAlpha = 1;
  // agua que se infiltra (rápida en grava/piedras, más lenta arriba) y sale por la base del muro
  const wa = o.water || 0; if (wa > 0) { const Rw = H.rng(8); for (let i = 0; i < 70; i++) { const u = ((t * Rw.range(0.18, 0.3) + Rw()) % 1), px0 = x + wt + 40 + Rw() * (w - wt - 60); const py = y + u * h * 1.05, px = px0 - Math.max(0, u - 0.75) * 4 * (px0 - x - wt) * 0.9; const yb = bed(px); if (py > yb - 6) continue; ctx.fillStyle = `rgba(55,185,217,${0.9 * wa})`; ctx.beginPath(); ctx.ellipse(px, py, 4, 6.5, 0, 0, TAU); ctx.fill(); }
   ctx.save(); ctx.globalAlpha = wa; ctx.setLineDash([12, 12]); ctx.lineDashOffset = t * 50; ctx.strokeStyle = 'rgba(122,230,242,0.9)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(x + w, bed(x + w) - 14); ctx.lineTo(x + wt, bed(x + wt) - 14); ctx.stroke(); ctx.restore(); }
  ctx.restore();
  // superficie: cultivo
  ctx.fillStyle = '#87a46b'; ctx.fillRect(x + wt, y - 10, w + 60, 12); const Rc = H.rng(90); ctx.strokeStyle = '#587348'; ctx.lineWidth = 4; for (let xx2 = x + wt + 14; xx2 < x + w + 50; xx2 += 22) { const hh = Rc.range(18, 40); ctx.beginPath(); ctx.moveTo(xx2, y - 8); ctx.lineTo(xx2 + Rc.range(-4, 4), y - 8 - hh); ctx.stroke(); }
  // muro de contención
  ctx.save(); ctx.beginPath(); ctx.moveTo(x - wt * 0.25, bed(x)); ctx.lineTo(x + wt * 0.15, y - 12); ctx.lineTo(x + wt, y - 12); ctx.lineTo(x + wt, bed(x + wt)); ctx.closePath(); ctx.clip(); P.stoneWall(ctx, x - wt * 0.4, y - 14, wt * 1.5, bed(x) - y + 20, { style: 'rustica', seed: 6, rows: Math.round(h / 46) }); ctx.restore();
  // salida del agua al pie del muro
  if (wa > 0) { const ox = x - wt * 0.1, oy = bed(x + wt) - 16; ctx.fillStyle = '#2b2620'; ctx.fillRect(ox, oy - 10, wt * 0.9, 20); const Rs = H.rng(5); for (let k = 0; k < 14; k++) { const u = (t * 0.8 + Rs()) % 1; ctx.fillStyle = `rgba(122,230,242,${wa * (1 - u)})`; ctx.beginPath(); ctx.arc(ox - u * 80, oy + u * u * 160, 5, 0, TAU); ctx.fill(); } }
  ctx.restore();
  // rótulos dentro de cada capa
  const lb = o.labels ?? 0; if (lb > 0) { let y2 = y; L.forEach(([s, f, c], k) => { const a = cl(lb * L.length - k); if (a > 0) { ctx.save(); ctx.globalAlpha = a; ctx.font = '800 34px Nunito'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; const tw = ctx.measureText(s).width; P.rr(ctx, x + wt + 30, y2 + f * h / 2 - 26, tw + 30, 52, 26, 'rgba(17,26,25,0.75)'); ctx.fillStyle = '#F4F7F3'; ctx.fillText(s, x + wt + 45, y2 + f * h / 2 + 1); ctx.restore(); } y2 += f * h; }); }
  return { bed, wt };
 };
 // Canal de piedra (en planta o perfil) con agua que fluye por una polilínea. o: { fill 0..1, speed, w }
 P.channel = (ctx, pts, t, o = {}) => {
  const w = o.w || 22, L = P.path(pts); P.strokePath(ctx, pts, w + 14, '#858d86', { cap: 'butt' }); P.strokePath(ctx, pts, w + 14, 'rgba(30,34,32,0.25)', { cap: 'butt', a: 0.4 }); P.strokePath(ctx, pts, w, '#3c4a46', { cap: 'butt' });
  const f = cl(o.fill ?? 1); if (f <= 0) return L; const part = [pts[0]]; let acc = 0; for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); if (acc + d >= L.L * f) { const q = L.at(L.L * f); part.push([q[0], q[1]]); break; } acc += d; part.push(pts[i]); }
  P.strokePath(ctx, part, w * 0.8, '#37b9d9', { cap: 'butt' }); ctx.save(); ctx.setLineDash([14, 22]); ctx.lineDashOffset = -t * (o.speed || 90); P.strokePath(ctx, part, w * 0.25, 'rgba(244,247,243,0.75)', { cap: 'round' }); ctx.restore(); return L;
 };
 // Fuente inca (bloque tallado con caño, chorro parabólico y pila). on 0..1
 P.incaFountain = (ctx, x, y, s, t, on = 1) => {
  P.granite(ctx, [[x - s * 0.5, y - s * 0.9], [x + s * 0.5, y - s * 0.9], [x + s * 0.5, y], [x - s * 0.5, y]], { seed: Math.round(x) });
  ctx.fillStyle = '#3c4a46'; ctx.fillRect(x - s * 0.06, y - s * 0.95, s * 0.12, s * 0.1);
  P.granite(ctx, [[x - s * 0.45, y + s * 0.02], [x + s * 0.45, y + s * 0.02], [x + s * 0.4, y + s * 0.32], [x - s * 0.4, y + s * 0.32]], { seed: Math.round(x) + 9 }); ctx.fillStyle = 'rgba(55,185,217,0.85)'; ctx.fillRect(x - s * 0.36, y + s * 0.08, s * 0.72, s * 0.14);
  if (on > 0) { ctx.save(); ctx.strokeStyle = `rgba(122,230,242,${0.9 * on})`; ctx.lineWidth = s * 0.07; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y - s * 0.88); ctx.quadraticCurveTo(x + s * 0.08, y - s * 0.6, x + s * 0.05, y + s * 0.1); ctx.stroke(); for (let k = 0; k < 3; k++) { const u = (t * 1.5 + k / 3) % 1; ctx.strokeStyle = `rgba(244,247,243,${0.7 * (1 - u) * on})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x + s * 0.05, y + s * 0.12, s * 0.06 + u * s * 0.25, s * 0.02 + u * s * 0.05, 0, 0, TAU); ctx.stroke(); } ctx.restore(); }
 };
 // CIUDADELA DE MONTAÑA (inspirada en Machu Picchu, estilizada y no a escala). El perfil superior del terreno se CONSTRUYE a partir de
 // las plataformas: cada tramo es una superficie horizontal sostenida por un muro de contención de piedra, así que todo edificio apoya
 // por construcción sobre una plataforma. Huayna Picchu se dibuja detrás y separado (más claro por la perspectiva atmosférica).
 // o.age 0 = reconstrucción (techos de paja) → 1 = estado actual (sin techos, pasto); o.canal 0..1; o.glow { walls, drain, water }.
 // Devuelve { plats: [{x0, x1, y, urban}], ground(x) } en coordenadas de dibujo, para colocar personas u objetos SOBRE el terreno.
 P.citadel = (ctx, cx, cy, s, t, o = {}) => {
  const age = o.age ?? 1, gl = o.glow || {}, X = (u) => cx + u * s, Y = (v) => cy + v * s;
  // plataformas [x0, x1, y, tipo] en unidades de s (y crece hacia abajo)
  const P0 = [];
  for (let i = 0; i < 16; i++) P0.push([-1.62 + i * 0.075, -1.62 + (i + 1) * 0.075, 1.02 - i * 0.068, 'agri']);
  P0.push([-0.42, -0.25, -0.09, 'urb'], [-0.25, -0.1, -0.16, 'urb'], [-0.1, 0.04, -0.22, 'urb'], [0.04, 0.34, 0.03, 'plaza'], [0.34, 0.5, -0.05, 'urb'], [0.5, 0.67, -0.11, 'urb'], [0.67, 0.83, -0.05, 'urb'], [0.83, 0.98, 0.02, 'urb'], [0.98, 1.12, 0.1, 'urb']);
  for (let i = 0; i < 8; i++) P0.push([1.12 + i * 0.075, 1.12 + (i + 1) * 0.075, 0.2 + i * 0.09, 'agri']);
  const plats = P0.map(([a, b, y, k]) => ({ x0: X(a), x1: X(b), y: Y(y), kind: k }));
  const ground = (x) => { for (const p of plats) if (x >= p.x0 && x <= p.x1) return p.y; return x < plats[0].x0 ? Y(1.3) : Y(1.2); };
  // Huayna Picchu y Huchuy Picchu (detrás, más claros)
  ctx.save(); const hg = ctx.createLinearGradient(0, Y(-1.35), 0, Y(0.4)); hg.addColorStop(0, '#6d8b78'); hg.addColorStop(1, '#4b6857'); ctx.fillStyle = hg; ctx.beginPath(); ctx.moveTo(X(-0.05), Y(0.6)); ctx.bezierCurveTo(X(0.18), Y(-0.2), X(0.3), Y(-1.2), X(0.56), Y(-1.33)); ctx.bezierCurveTo(X(0.82), Y(-1.25), X(0.98), Y(-0.4), X(1.35), Y(0.6)); ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(40,60,48,0.35)'; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.moveTo(X(0.42 + k * 0.06), Y(-1.1 + k * 0.12)); ctx.lineTo(X(0.47 + k * 0.07), Y(-0.6 + k * 0.1)); ctx.lineTo(X(0.44 + k * 0.06), Y(-0.55 + k * 0.1)); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#5a7a66'; ctx.beginPath(); ctx.moveTo(X(-0.2), Y(0.5)); ctx.quadraticCurveTo(X(0.05), Y(-0.38), X(0.2), Y(-0.36)); ctx.quadraticCurveTo(X(0.32), Y(-0.2), X(0.42), Y(0.5)); ctx.closePath(); ctx.fill(); ctx.restore();
  P.fog(ctx, Y(-0.3), s * 0.5, t, { a: 0.35 * (o.fogA ?? 1), seed: 7, speed: 10 });
  // masa del cerro (la cresta): su borde superior ES el perfil de las plataformas
  ctx.save(); const mg = ctx.createLinearGradient(0, Y(-0.2), 0, Y(2)); mg.addColorStop(0, '#587348'); mg.addColorStop(0.5, '#3e5640'); mg.addColorStop(1, '#2a3b30'); ctx.fillStyle = mg; ctx.beginPath(); ctx.moveTo(X(-2.2), Y(3)); ctx.lineTo(X(-2.2), Y(1.45)); ctx.lineTo(plats[0].x0, Y(1.3)); for (const p of plats) { ctx.lineTo(p.x0, p.y); ctx.lineTo(p.x1, p.y); } ctx.lineTo(X(1.9), Y(1.15)); ctx.lineTo(X(2.4), Y(1.6)); ctx.lineTo(X(2.4), Y(3)); ctx.closePath(); ctx.fill();
  // terrazas frontales que bajan por la ladera bajo la ciudad (muros de piedra + franja de cultivo), recortadas a la masa
  ctx.save(); ctx.clip(); const Rf = H.rng(91), rows = o.frontRows ?? 5; for (let r = 0; r < rows; r++) { const yy = Y(0.24 + r * 0.16), hw = s * 0.024; let xa = X(-1.45 + Rf() * 0.3);
   while (xa < X(1.7)) { const xb = Math.min(X(1.75), xa + s * Rf.range(0.3, 0.62)), dy = s * Rf.range(-0.02, 0.02);
    ctx.fillStyle = 'rgba(30,45,34,0.35)'; ctx.fillRect(xa, yy + dy + hw, xb - xa, s * 0.012);
    P.granite(ctx, [[xa, yy + dy], [xb, yy + dy], [xb, yy + dy + hw], [xa, yy + dy + hw]], { seed: 300 + r * 9 + Math.round(xa), c1: '#9aa096', c2: '#6c736c', joint: 1, bevel: false });
    ctx.fillStyle = r % 2 ? '#6f8f58' : '#678a52'; ctx.fillRect(xa, yy + dy - s * 0.01, xb - xa, s * 0.01);
    xa = xb + s * Rf.range(0.18, 0.4); } }
  ctx.restore();
  const R0 = H.rng(17); for (let i = 0; i < 26; i++) { const u = R0.range(-1.6, 1.8), x = X(u), y = ground(x) + s * R0.range(0.25, 1.1); ctx.fillStyle = 'rgba(133,141,134,0.35)'; ctx.beginPath(); ctx.ellipse(x, y, s * R0.range(0.03, 0.08), s * R0.range(0.015, 0.035), -0.3, 0, TAU); ctx.fill(); } ctx.restore();
  // muros de contención (frentes de cada desnivel) y superficies superiores con espesor
  const d = s * 0.022; plats.forEach((p, i) => {
   const below = i === 0 ? Y(1.3) : Math.max(plats[i - 1].y, p.y); const prev = plats[i - 1]; const wallH = (prev ? Math.max(0, prev.y - p.y) : 0);
   // superficie (franja con profundidad aparente)
   ctx.fillStyle = p.kind === 'plaza' ? '#7fa060' : p.kind === 'agri' ? (age < 0.5 ? '#87a46b' : '#7fa060') : (age > 0.6 ? '#8aa86e' : '#a89a7c'); ctx.fillRect(p.x0, p.y - d * 0.9, p.x1 - p.x0, d * 0.9);
   // muro hacia la izquierda (cuando la plataforma está más alta que la anterior)
   if (prev && prev.y > p.y) { const wx = p.x0 - (p.kind === 'agri' ? s * 0.012 : s * 0.018); const pts = [[wx, p.y - d * 0.9], [p.x0 + s * 0.004, p.y - d * 0.9], [p.x0 + s * 0.004, prev.y], [wx - s * 0.006, prev.y]]; P.granite(ctx, pts, { seed: i * 7 + 3, c1: '#b8bdb2', c2: '#7c847d', joint: 1 }); if (gl.walls) { ctx.strokeStyle = `rgba(212,172,100,${gl.walls})`; ctx.lineWidth = 3; ctx.strokeRect(wx, p.y - d, p.x0 - wx, prev.y - p.y + d); } }
   // muro hacia la derecha (plataforma más alta que la siguiente)
   const nx = plats[i + 1]; if (nx && nx.y > p.y) { const pts = [[p.x1 - s * 0.004, p.y - d * 0.9], [p.x1 + s * 0.014, p.y - d * 0.9], [p.x1 + s * 0.02, nx.y], [p.x1 - s * 0.004, nx.y]]; P.granite(ctx, pts, { seed: i * 11 + 5, c1: '#a9aea4', c2: '#6f766f', joint: 1 }); if (gl.walls) { ctx.strokeStyle = `rgba(212,172,100,${gl.walls})`; ctx.lineWidth = 3; ctx.strokeRect(p.x1 - 2, p.y - d, s * 0.02, nx.y - p.y + d); } }
   // drenaje bajo la superficie (resaltado)
   if (gl.drain) { ctx.save(); ctx.setLineDash([8, 8]); ctx.lineDashOffset = -t * 30; ctx.strokeStyle = `rgba(55,185,217,${gl.drain})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(p.x0 + 6, p.y + s * 0.03); ctx.lineTo(p.x1 - 6, p.y + s * 0.03); ctx.stroke(); ctx.restore(); }
  });
  // escalinatas entre la plaza y los sectores
  ctx.save(); ctx.strokeStyle = 'rgba(220,214,190,0.8)'; ctx.lineWidth = 2; const st = (xa, ya, xb, yb) => { for (let k = 0; k <= 6; k++) { const u = k / 6, x = lerp(xa, xb, u), y = lerp(ya, yb, u); ctx.beginPath(); ctx.moveTo(x - s * 0.012, y); ctx.lineTo(x + s * 0.012, y); ctx.stroke(); } }; st(X(0.05), Y(0.05), X(0.0), Y(-0.06)); st(X(0.35), Y(0.05), X(0.39), Y(-0.02)); ctx.restore();
  // edificios: apoyados en las plataformas urbanas (base = superficie de la plataforma)
  const R = H.rng(o.seed || 21); const BACK = s * 0.04; for (const row of [0, 1]) plats.forEach((p, i) => { if (p.kind !== 'urb') return; const sc = row === 0 ? 0.85 : 1;
   if (row === 0) { const bx0 = p.x0 + s * 0.01, bx1 = p.x1 - s * 0.01, by = p.y - d * 0.9 - BACK; P.granite(ctx, [[bx0, by], [bx1, by], [bx1, p.y - d * 0.9], [bx0, p.y - d * 0.9]], { seed: i * 5 + 1, c1: '#b2b7ac', c2: '#7c847d', joint: 1 }); ctx.fillStyle = age > 0.6 ? '#8aa86e' : '#a89a7c'; ctx.fillRect(bx0, by - d * 0.6, bx1 - bx0, d * 0.6); }
   let x = p.x0 + s * (row === 0 ? 0.03 : 0.014); while (x < p.x1 - s * 0.05) { const bw = Math.min(s * R.range(0.05, 0.08) * sc, p.x1 - s * 0.014 - x), bh = s * R.range(0.06, 0.08) * sc, base = row === 0 ? p.y - d * 0.9 - BACK - d * 0.3 : p.y - d * 0.2; if (bw < s * 0.04) break; const ruin = age > 0.5 && R() < 0.3 ? R.range(0.55, 0.8) : 1, ht = bh * ruin, top = base - ht, dd = s * 0.02;
    ctx.fillStyle = 'rgba(20,30,25,0.35)'; ctx.fillRect(x - 2, base - 2, bw + dd + 4, 5); // sombra de contacto
    P.granite(ctx, [[x + bw, top], [x + bw + dd, top - dd * 0.55], [x + bw + dd, base - dd * 0.55], [x + bw, base]], { seed: Math.round(x) + 1, c1: '#8f968e', c2: '#656d66', bevel: false });
    P.granite(ctx, [[x, top], [x + bw, top], [x + bw, base], [x, base]], { seed: Math.round(x + base), c1: '#c8c4b0', c2: '#9a9a8c', joint: 1 });
    ctx.strokeStyle = 'rgba(60,62,55,0.35)'; ctx.lineWidth = 1; for (let k = 1; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x, top + k * ht / 4); ctx.lineTo(x + bw, top + k * ht / 4); ctx.stroke(); }
    const dw = bw * 0.2, dh = ht * 0.62; ctx.fillStyle = '#2c3530'; ctx.beginPath(); ctx.moveTo(x + bw * 0.4, base); ctx.lineTo(x + bw * 0.4 + dw * 0.14, base - dh); ctx.lineTo(x + bw * 0.4 + dw * 0.86, base - dh); ctx.lineTo(x + bw * 0.4 + dw, base); ctx.closePath(); ctx.fill(); if (ruin === 1 && bw > s * 0.1) { ctx.beginPath(); ctx.moveTo(x + bw * 0.12, top + ht * 0.55); ctx.lineTo(x + bw * 0.14, top + ht * 0.3); ctx.lineTo(x + bw * 0.22, top + ht * 0.3); ctx.lineTo(x + bw * 0.24, top + ht * 0.55); ctx.closePath(); ctx.fill(); }
    if (ruin === 1) { P.granite(ctx, [[x + bw, top], [x + bw + dd * 0.5, top - bh * 0.5 - dd * 0.3], [x + bw + dd, top - dd * 0.55]], { seed: Math.round(x) + 9, c1: '#a9aea4', c2: '#7c847d', bevel: false }); }
    if (age < 1 && ruin === 1) { ctx.save(); ctx.globalAlpha *= 1 - age; ctx.fillStyle = '#a07f48'; ctx.beginPath(); ctx.moveTo(x - s * 0.01, top + 1); ctx.lineTo(x + bw * 0.12, top - bh * 0.55); ctx.lineTo(x + bw + dd * 0.5, top - bh * 0.55 - dd * 0.3); ctx.lineTo(x + bw + dd + s * 0.006, top - dd * 0.55); ctx.lineTo(x + bw + s * 0.01, top + 1); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(90,66,32,0.55)'; for (let q = 1; q < 7; q++) { ctx.beginPath(); ctx.moveTo(x + q * bw / 7, top + 1); ctx.lineTo(x + bw * 0.12 + q * (bw * 0.88 + dd * 0.5) / 7, top - bh * 0.55); ctx.stroke(); } ctx.restore(); }
    if (age > 0.6) { ctx.fillStyle = `rgba(110,140,80,${(age - 0.6) * 1.5})`; ctx.fillRect(x, base - 3, bw, 3); }
    if (gl.walls) { ctx.strokeStyle = `rgba(212,172,100,${gl.walls})`; ctx.lineWidth = 2; ctx.strokeRect(x, top, bw, base - top); }
    x += bw + dd + s * R.range(0.012, 0.025); } });
  // árboles y arbustos en las laderas (vegetación moderada)
  const Rt = H.rng(55); for (let i = 0; i < 22; i++) { const u = Rt() < 0.5 ? Rt.range(-1.6, -0.5) : Rt.range(1.15, 1.75), x = X(u), y = ground(x) + s * Rt.range(0.12, 0.6); ctx.fillStyle = Rt() < 0.5 ? '#3d5a3f' : '#4f6e48'; ctx.beginPath(); ctx.arc(x, y, s * Rt.range(0.02, 0.04), 0, TAU); ctx.arc(x + s * 0.025, y + s * 0.01, s * Rt.range(0.018, 0.03), 0, TAU); ctx.fill(); }
  // canal de abastecimiento: desde la ladera de la derecha, bajando suavemente hasta el sector urbano (y fuentes)
  if ((o.canal ?? 0) > 0) { const pts = [[X(-0.11), Y(-0.235) - d * 0.5], [X(0.035), Y(-0.235) - d * 0.5], [X(0.05), Y(-0.12)], [X(0.065), Y(0.0)], [X(0.07), Y(0.03) - d * 0.5], [X(0.2), Y(0.03) - d * 0.5]]; ctx.save(); ctx.globalAlpha *= o.canal; P.strokePath(ctx, pts, 9, '#858d86'); ctx.setLineDash([10, 10]); ctx.lineDashOffset = -t * 40; P.strokePath(ctx, pts, 4, gl.water ? `rgba(122,230,242,${0.6 + 0.4 * gl.water})` : '#37b9d9'); ctx.setLineDash([]); for (let k = 0; k < 4; k++) { const y = lerp(Y(-0.2), Y(0.0), k / 3), x = lerp(X(0.04), X(0.065), k / 3); P.circle(ctx, x + s * 0.02, y, s * 0.012, '#7AE6F2'); } ctx.restore(); }
  return { plats, ground };
 };
 // ================= v1.13 · NAVEGACIÓN NÓRDICA (episodio «Vikingos en América») =================
 // Mar cinematográfico por filas en perspectiva. o: { hor, sky:[arriba, horizonte], sun:[x,y], sunA, clouds, mood
 // ('calma'|'fresco'|'tormenta'), amp, fogA, seed, x0, x1, part ('back'|'front'), split (y), flow (px/s: el mar pasa junto al barco), crest, flash (relámpago 0..1) }.
 // Devuelve { waveY(x, yBase), float(x, yBase, len) → {y, ang} } para posar barcos sobre el agua.
 const SEA_ROWS = 30;
 const seaRow = (o, z) => { const amp = (o.amp ?? 1) * (o.mood === 'tormenta' ? 1.8 : o.mood === 'calma' ? 0.55 : 1); return { A: amp * (2 + 46 * z * z), L: 90 + 760 * z, w: 1.1 + 0.4 * (1 - z) }; };
 P.seaWave = (o, x, yb, t) => { const hor = o.hor ?? 760, bot = o.bottom ?? HH + 400, z = cl(Math.pow(Math.max(0, yb - hor) / (bot - hor), 1 / 1.7)); const r = seaRow(o, z), k = TAU / r.L, ph = (o.seed || 0) * 1.7 + z * 37;
  x += t * (o.flow || 0) * (0.3 + z); return yb + r.A * (Math.sin(k * x - r.w * t * 1.6 + ph) * 0.7 + Math.sin(k * 2.3 * x + r.w * t * 1.1 + ph * 2) * 0.3); };
 P.seaHD = (ctx, t, o = {}) => {
  const hor = o.hor ?? 760, bot = o.bottom ?? HH + 400, x0 = o.x0 ?? -600, x1 = o.x1 ?? W + 600, part = o.part, split = o.split ?? 1e9, storm = o.mood === 'tormenta';
  const deep = o.deep || (storm ? '#0c2230' : '#102C3A'), lit = o.lit || (storm ? '#3b5866' : '#2D6274'), foam = o.foam || '#DCE8E9';
  if (part !== 'front') {
   const sky = o.sky || (storm ? ['#3c4d58', '#647C8B'] : ['#5f8aa0', '#A7C8D4']); const g = ctx.createLinearGradient(0, hor - 1400, 0, hor); g.addColorStop(0, sky[0]); g.addColorStop(1, sky[1]); ctx.fillStyle = g; ctx.fillRect(x0, hor - 3000, x1 - x0, 3000 + 2);
   if (o.sun) { const sa = o.sunA ?? 1; P.glow(ctx, o.sun[0], o.sun[1], 520, '255,228,190', 0.45 * sa); P.glow(ctx, o.sun[0], o.sun[1], 120, '255,245,225', 0.9 * sa); }
   const R = H.rng(o.seed || 5), nc = o.clouds ?? 9; for (let i = 0; i < nc; i++) { const cy = hor - R.range(120, 900), cs = R.range(140, 340) * (1 - (hor - cy) / 1600 * 0.3), cx = x0 + ((R() * (x1 - x0) + t * R.range(4, 12)) % (x1 - x0)); ctx.save(); ctx.globalAlpha *= (storm ? 0.8 : 0.55) * R.range(0.6, 1); const top = storm ? '98,112,122' : '246,250,251', bt = storm ? '52,64,72' : '170,192,204'; for (let q = 0; q < 9; q++) { const px = cx + (q - 4) * cs * 0.24 + R.range(-0.08, 0.08) * cs, py = cy - Math.sin((q + 0.5) / 9 * Math.PI) * cs * 0.2, pr = cs * R.range(0.18, 0.3); const cg = ctx.createRadialGradient(px, py - pr * 0.3, pr * 0.1, px, py, pr); cg.addColorStop(0, `rgba(${top},0.95)`); cg.addColorStop(0.7, `rgba(${top},0.6)`); cg.addColorStop(1, `rgba(${top},0)`); ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(px, py, pr, 0, TAU); ctx.fill(); } const bg2 = ctx.createLinearGradient(0, cy - cs * 0.05, 0, cy + cs * 0.12); bg2.addColorStop(0, `rgba(${bt},0)`); bg2.addColorStop(1, `rgba(${bt},0.35)`); ctx.fillStyle = bg2; ctx.beginPath(); ctx.ellipse(cx, cy + cs * 0.03, cs * 1.0, cs * 0.1, 0, 0, TAU); ctx.fill(); ctx.restore(); }
   // brillo del sol en el agua cerca del horizonte
   const sg = ctx.createLinearGradient(0, hor, 0, bot); sg.addColorStop(0, lit); sg.addColorStop(0.35, deep); sg.addColorStop(1, '#081822'); ctx.fillStyle = sg; ctx.fillRect(x0, hor, x1 - x0, bot - hor + 400);
   ctx.fillStyle = 'rgba(220,232,233,0.25)'; ctx.fillRect(x0, hor - 2, x1 - x0, 4);
   if ((o.flash || 0) > 0) { ctx.fillStyle = `rgba(235,242,255,${0.55 * o.flash})`; ctx.fillRect(x0, hor - 3000, x1 - x0, 3000 + (bot - hor)); }
  }
  const R2 = H.rng((o.seed || 5) + 11);
  for (let r = 0; r <= SEA_ROWS; r++) {
   const z = r / SEA_ROWS, yr = hor + (bot - hor) * Math.pow(z, 1.7); if (r === 0) continue; if (part === 'back' && yr >= split) break; if (part === 'front' && yr < split) continue;
   const rw = seaRow(o, z), step = Math.max(6, rw.L / 18); const yAt = (x) => P.seaWave(o, x, yr, t);
   const mix = (a, b, u) => { const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16); const ch = (s) => Math.round(lerp((pa >> s) & 255, (pb >> s) & 255, u)); return `rgb(${ch(16)},${ch(8)},${ch(0)})`; };
   ctx.beginPath(); ctx.moveTo(x0, bot + 400); for (let x = x0; x <= x1 + step; x += step) ctx.lineTo(x, yAt(x)); ctx.lineTo(x1, bot + 400); ctx.closePath(); { const rg = ctx.createLinearGradient(0, yr - rw.A, 0, yr + rw.A + (bot - hor) * 0.06 * (0.3 + z)); rg.addColorStop(0, mix(o.crest || '#4f8796', lit, cl(0.3 + z * 0.8))); rg.addColorStop(0.45, mix(lit, deep, cl(z * 1.1))); rg.addColorStop(1, mix(lit, deep, cl(z * 1.25 + 0.2))); ctx.fillStyle = rg; } ctx.fill();
   if (o.sun && (o.sunA ?? 1) > 0.05) { const sxp = o.sun[0], spread = 40 + 520 * z, ga = (o.sunA ?? 1) * (storm ? 0.25 : 0.7) * (1 - z * 0.6); ctx.fillStyle = 'rgba(255,240,215,1)'; for (let q = 0; q < 10; q++) { const gx = sxp + (R2() - 0.5) * spread * 2, sh2 = Math.sin(t * 2.5 + q * 1.7 + r); if (sh2 < 0.2) continue; ctx.globalAlpha = ga * sh2 * (1 - Math.abs(gx - sxp) / (spread * 1.1)); if (ctx.globalAlpha <= 0) continue; ctx.beginPath(); ctx.ellipse(gx, yAt(gx) + 2, 6 + 30 * z, 1 + 2.5 * z, 0, 0, TAU); ctx.fill(); } ctx.globalAlpha = 1; }
   ctx.save(); ctx.strokeStyle = `rgba(200,225,230,${0.06 + 0.12 * (1 - z)})`; ctx.lineWidth = 1 + 2 * z; ctx.beginPath(); for (let x = x0; x <= x1 + step; x += step) (x === x0 ? ctx.moveTo(x, yAt(x)) : ctx.lineTo(x, yAt(x))); ctx.stroke(); ctx.restore();
   // espuma en las crestas
   const fa = (storm ? 0.9 : o.mood === 'calma' ? 0.25 : 0.55) * (0.4 + z); const kk = TAU / rw.L, ph = (o.seed || 0) * 1.7 + z * 37; ctx.fillStyle = foam;
   for (let x = x0; x <= x1; x += step) { const s1 = Math.sin(kk * (x + t * (o.flow || 0) * (0.3 + z)) - rw.w * t * 1.6 + ph); if (s1 > 0.82) { const fy = yAt(x); ctx.globalAlpha = fa * (s1 - 0.82) * 5; ctx.beginPath(); ctx.ellipse(x, fy + 1, step * 0.9, 1.5 + 5 * z, 0, 0, TAU); ctx.fill(); } }
   ctx.globalAlpha = 1;
   if (z > 0.25 && R2() < 0.9) { ctx.save(); ctx.globalAlpha = 0.12 * z; ctx.fillStyle = '#9fc4cc'; for (let q = 0; q < 6; q++) { const sx = x0 + ((R2() * (x1 - x0) + t * 20 * z) % (x1 - x0)); ctx.fillRect(sx, yAt(sx) + 8 + R2() * 20 * z, 40 + 120 * z, 2 + 2 * z); } ctx.restore(); }
  }
  if (part !== 'back' && (o.fogA ?? 0) > 0) P.fog(ctx, hor - 220, 420, t, { a: o.fogA, seed: 4, speed: 14 });
  return { waveY: (x, yb) => P.seaWave(o, x, yb, t), float: (x, yb, len) => { const a = P.seaWave(o, x - len / 2, yb, t), b = P.seaWave(o, x + len / 2, yb, t), m = P.seaWave(o, x, yb, t); return { y: (a + b + m * 2) / 4, ang: Math.atan2(b - a, len) * 0.8 }; } };
 };
 // Knarr nórdico (barco mercante oceánico) de perfil, casco trincado (tablas superpuestas con remaches).
 // (x, y) = centro en la línea de flotación; s = eslora en px. o: { ang, sail (0 recogida → 1 izada), billow (0..1 viento),
 // reef, oars (0..1), oarN, oarPhase, xray (0..1: casco transparente, se ven quilla, cuadernas y bancos), flex (−1..1, sutil),
 // crew, flip, wake (0..1), spray, stripes, glow:{keel, planks, mast, sail, oars} }. Devuelve puntos clave en coordenadas de lienzo.
 P.knarr = (ctx, x, y, s, t, o = {}) => {
  // v1.13.1: casco con volumen (cara interior de la borda opuesta, cuadernas y bancos visibles), tracas con vetas y
  // variaciones de tono, remaches, juntas de empalme, quilla marcada, timón lateral con caña y soporte, jarcia con
  // obenques y vigotas, braza y escotas tensas; balanceo (roll) y vela que respira con el viento.
  const ang = o.ang || 0, fl = o.flip ? -1 : 1, L = s / 2, fb = s * 0.088, dr = s * 0.05, xr = o.xray || 0, flex = (o.flex || 0) * s * 0.006, gl = o.glow || {}, roll = o.roll || 0;
  const sheer = (u) => -(fb + s * 0.07 * Math.pow(Math.abs(u), 4.2)) + flex * (1 - u * u);
  const keel = (u) => dr * (1 - Math.pow(Math.abs(u), 5)) + flex * (1 - u * u);
  const dep = s * (0.03 + 0.012 * roll); // profundidad aparente de la borda (cara interior de la banda opuesta)
  const farS = (u) => sheer(u) - dep * (1 - Math.pow(Math.abs(u), 6));
  const P2 = (lx, ly) => { const c = Math.cos(ang), si = Math.sin(ang); return [x + (lx * fl) * c - ly * si, y + (lx * fl) * si + ly * c]; };
  const R = H.rng(o.seed || 41), seg = 56, N = 8, line = (f, u) => lerp(keel(u), sheer(u), f);
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.scale(fl, 1);
  // sombra/oscurecimiento del agua bajo el casco
  ctx.save(); ctx.globalAlpha *= 0.35; const sg0 = ctx.createRadialGradient(0, dr, 0, 0, dr, L * 1.1); sg0.addColorStop(0, 'rgba(5,15,22,0.9)'); sg0.addColorStop(1, 'rgba(5,15,22,0)'); ctx.fillStyle = sg0; ctx.beginPath(); ctx.ellipse(0, dr * 0.6, L * 1.15, s * 0.06, 0, 0, TAU); ctx.fill(); ctx.restore();
  // --- cara interior de la banda opuesta (da profundidad a la borda) ---
  ctx.save(); ctx.globalAlpha *= 1 - xr * 0.6;
  ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, farS(u)); } for (let k = seg; k >= 0; k--) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, sheer(u)); } ctx.closePath();
  const ig = ctx.createLinearGradient(0, -fb - dep, 0, -fb); ig.addColorStop(0, '#8a603e'); ig.addColorStop(1, '#4e3322'); ctx.fillStyle = ig; ctx.fill();
  ctx.strokeStyle = 'rgba(40,25,14,0.55)'; ctx.lineWidth = Math.max(1, s * 0.002); for (let i = 1; i < 3; i++) { ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -0.97 + 1.94 * k / seg; ctx.lineTo(L * u, lerp(farS(u), sheer(u), i / 3)); } ctx.stroke(); }
  ctx.fillStyle = 'rgba(60,38,22,0.75)'; for (let i = -7; i <= 7; i++) { const u = i / 8.2; ctx.fillRect(L * u - s * 0.004, farS(u) + 1, s * 0.008, sheer(u) - farS(u)); }
  // bancos y carga
  ctx.fillStyle = '#6d4a30'; for (const u of [-0.62, -0.35, 0.36, 0.62]) ctx.fillRect(L * u - s * 0.035, sheer(u) - dep * 0.35, s * 0.07, s * 0.008);
  if (o.cargo !== false) { const cu = -0.05; ctx.fillStyle = '#7a5a3a'; ctx.fillRect(L * (cu - 0.2), sheer(cu) - dep * 0.9, s * 0.09, dep * 0.9); ctx.fillStyle = '#8b6a45'; ctx.fillRect(L * (cu + 0.12), sheer(cu) - dep * 0.75, s * 0.07, dep * 0.75); ctx.strokeStyle = 'rgba(35,22,12,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(L * (cu - 0.2), sheer(cu) - dep * 0.9, s * 0.09, dep * 0.9); }
  ctx.strokeStyle = '#3e2718'; ctx.lineWidth = s * 0.006; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, farS(u)); } ctx.stroke();
  ctx.restore();
  // --- remo de gobierno (detrás del casco: banda de estribor lejana si flip; aquí siempre en la aleta de estribor) ---
  const rudder = () => { const u0 = -0.84, bx = L * u0, by = sheer(u0); ctx.save(); ctx.globalAlpha *= 1 - xr * 0.5; ctx.strokeStyle = '#4a2f1f'; ctx.lineCap = 'round'; ctx.lineWidth = s * 0.014; ctx.beginPath(); ctx.moveTo(bx + s * 0.01, by - s * 0.05); ctx.lineTo(bx - s * 0.03, dr * 1.7); ctx.stroke();
   ctx.fillStyle = '#5D3D29'; ctx.beginPath(); ctx.moveTo(bx - s * 0.012, dr * 0.6); ctx.quadraticCurveTo(bx - s * 0.055, dr * 1.4, bx - s * 0.038, dr * 2.2); ctx.lineTo(bx - s * 0.018, dr * 2.1); ctx.quadraticCurveTo(bx - s * 0.01, dr * 1.2, bx + s * 0.004, dr * 0.6); ctx.closePath(); ctx.fill();
   ctx.strokeStyle = '#3a2416'; ctx.lineWidth = s * 0.006; ctx.beginPath(); ctx.moveTo(bx + s * 0.01, by - s * 0.045); ctx.lineTo(bx + s * 0.09, by - s * 0.06); ctx.stroke(); // caña
   ctx.fillStyle = '#3a2416'; ctx.beginPath(); ctx.ellipse(bx, by + s * 0.018, s * 0.012, s * 0.016, 0, 0, TAU); ctx.fill(); ctx.restore(); }; // soporte (tojo)
  // remos (pocos: el knarr navegaba sobre todo a vela), por la banda cercana
  const oa = o.oars || 0, on = o.oarN ?? 4; const oarTips = [];
  const drawOars = () => { if (oa <= 0) return; ctx.save(); ctx.globalAlpha *= oa; for (let i = 0; i < on; i++) { const u = i < on / 2 ? 0.5 + i * 0.13 : -0.48 - (i - on / 2) * 0.13, ph = (o.oarPhase || 0) * TAU - i * 0.2, sw = Math.sin(ph), lift = Math.max(0, Math.cos(ph)); const px = L * u, py = sheer(u) + s * 0.02; const ex = px - sw * s * 0.13, ey = dr * 0.7 - lift * s * 0.05; oarTips.push(P2(ex, ey));
    ctx.strokeStyle = gl.oars ? `rgba(255,212,71,${0.6 + 0.4 * gl.oars})` : '#8a6a46'; ctx.lineWidth = s * 0.008; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(px + sw * s * 0.05, py - s * 0.05); ctx.lineTo(ex, ey); ctx.stroke(); ctx.fillStyle = gl.oars ? '#FFD447' : '#8a6a46'; ctx.beginPath(); ctx.ellipse(ex, ey, s * 0.008, s * 0.026, -0.4 - sw * 0.3, 0, TAU); ctx.fill(); } ctx.restore(); };
  // --- casco (banda cercana): tracas superpuestas de abajo arriba con vetas y tonos variables ---
  ctx.save(); ctx.globalAlpha *= 1 - xr * 0.75;
  const tones = []; for (let i = 0; i < N; i++) tones.push(R.range(-14, 14));
  const shade = (base, d) => { const c = parseInt(base.slice(1), 16), f = (v) => Math.max(0, Math.min(255, v + d)); return `rgb(${f(c >> 16)},${f((c >> 8) & 255)},${f(c & 255)})`; };
  for (let i = 0; i < N; i++) { const f0 = i / N, f1 = (i + 1) / N + 0.022;
   ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(f1, u)); } for (let k = seg; k >= 0; k--) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(f0, u)); } ctx.closePath();
   const lit = 0.35 + 0.65 * (i / (N - 1)); const g = ctx.createLinearGradient(0, line(f1, 0), 0, line(f0, 0)); g.addColorStop(0, shade('#a4774f', tones[i] + 18 * lit)); g.addColorStop(0.8, shade('#7b5436', tones[i] - 10 + 10 * lit)); g.addColorStop(1, shade('#4a2f1f', tones[i])); ctx.fillStyle = g; ctx.fill();
   // vetas
   ctx.save(); ctx.clip(); ctx.strokeStyle = 'rgba(55,33,18,0.22)'; ctx.lineWidth = Math.max(0.8, s * 0.0013); for (let q = 0; q < 3; q++) { const fq = lerp(f0, f1, 0.25 + q * 0.22), ph = R.range(0, 6); ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(fq, u) + Math.sin(u * 9 + ph) * s * 0.0015); } ctx.stroke(); }
   ctx.strokeStyle = 'rgba(35,20,10,0.55)'; ctx.lineWidth = Math.max(1, s * 0.002); for (const uj of [-0.55 + i * 0.13, 0.2 + ((i * 0.37) % 0.5)]) { const u = uj > 0.95 ? uj - 1.6 : uj; ctx.beginPath(); ctx.moveTo(L * u, line(f0, u)); ctx.lineTo(L * u + s * 0.012, line(f1, u)); ctx.stroke(); } ctx.restore();
   // sombra que proyecta la traca superior sobre la inferior (solape) y luz en el canto
   ctx.strokeStyle = 'rgba(25,14,6,0.6)'; ctx.lineWidth = Math.max(1.2, s * 0.004); ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(f0, u) - 1); } ctx.stroke();
   ctx.strokeStyle = 'rgba(255,228,190,0.22)'; ctx.lineWidth = Math.max(1, s * 0.002); ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(f1, u) + s * 0.003); } ctx.stroke();
   if (s > 220) { ctx.fillStyle = gl.rivets ? '#FFD447' : 'rgba(45,32,24,0.85)'; const nR = Math.round(s / 26); for (let k = 1; k < nR; k++) { const u = -0.96 + 1.92 * k / nR; ctx.beginPath(); ctx.arc(L * u, line(f0, u) - s * 0.006, Math.max(1, s * 0.0026), 0, TAU); ctx.fill(); } }
   if (gl.planks) { ctx.strokeStyle = `rgba(255,212,71,${gl.planks})`; ctx.lineWidth = 3; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, line(f0, u)); } ctx.stroke(); }
  }
  // oscurecimiento junto a la línea de flotación y brillo del sol en la parte alta
  ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, keel(u)); } for (let k = seg; k >= 0; k--) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, sheer(u)); } ctx.closePath(); ctx.save(); ctx.clip(); const ag = ctx.createLinearGradient(0, -fb, 0, dr); ag.addColorStop(0, 'rgba(255,235,200,0.10)'); ag.addColorStop(0.55, 'rgba(0,0,0,0)'); ag.addColorStop(1, 'rgba(8,16,22,0.55)'); ctx.fillStyle = ag; ctx.fillRect(-L * 1.1, -fb * 2, s * 1.1, fb * 2 + dr * 2); ctx.restore();
  // quilla
  ctx.strokeStyle = '#3a2416'; ctx.lineWidth = s * 0.012; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -0.97 + 1.94 * k / seg; ctx.lineTo(L * u, keel(u) + s * 0.004); } ctx.stroke();
  // roda y codaste
  ctx.strokeStyle = '#4a2f1f'; ctx.lineWidth = s * 0.017; ctx.lineCap = 'round'; for (const sd of [1, -1]) { ctx.beginPath(); ctx.moveTo(L * sd * 0.96, keel(0.96)); ctx.bezierCurveTo(L * sd * 1.06, keel(1) - s * 0.02, L * sd * 1.07, sheer(1), L * sd * 1.04, sheer(1) - s * 0.035); ctx.stroke(); ctx.strokeStyle = 'rgba(255,228,190,0.25)'; ctx.lineWidth = s * 0.004; ctx.stroke(); ctx.strokeStyle = '#4a2f1f'; ctx.lineWidth = s * 0.017; }
  // regala (borda cercana) con brillo
  ctx.strokeStyle = '#3e2718'; ctx.lineWidth = s * 0.01; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, sheer(u)); } ctx.stroke(); ctx.strokeStyle = 'rgba(255,230,195,0.35)'; ctx.lineWidth = s * 0.0025; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -1 + 2 * k / seg; ctx.lineTo(L * u, sheer(u) - s * 0.004); } ctx.stroke();
  ctx.restore();
  rudder(); drawOars();
  // estructura interna (rayos X)
  if (xr > 0) { ctx.save(); ctx.globalAlpha *= xr;
   ctx.strokeStyle = gl.keel ? `rgba(255,212,71,${0.7 + 0.3 * gl.keel})` : '#c9925a'; ctx.lineWidth = s * 0.018; ctx.beginPath(); for (let k = 0; k <= seg; k++) { const u = -0.98 + 1.96 * k / seg; ctx.lineTo(L * u, keel(u) - s * 0.006); } ctx.stroke();
   ctx.strokeStyle = gl.ribs ? `rgba(255,212,71,${0.7 + 0.3 * gl.ribs})` : '#d9a46b'; ctx.lineWidth = s * 0.008; for (let i = -6; i <= 6; i++) { const u = i / 7.2; ctx.beginPath(); ctx.moveTo(L * u, keel(u) - s * 0.01); ctx.quadraticCurveTo(L * u * 1.02, (keel(u) + sheer(u)) / 2, L * u, sheer(u) + s * 0.006); ctx.stroke(); }
   ctx.strokeStyle = '#b07a48'; ctx.lineWidth = s * 0.007; for (let i = -3; i <= 3; i++) { const u = i / 4.2; ctx.beginPath(); ctx.moveTo(L * u - s * 0.02, line(0.62, u)); ctx.lineTo(L * u + s * 0.02, line(0.62, u)); ctx.stroke(); }
   ctx.fillStyle = '#8b5a33'; ctx.fillRect(L * 0.05 - s * 0.03, keel(0.05) - s * 0.03, s * 0.06, s * 0.025);
   ctx.restore(); }
  // --- mástil, verga, vela cuadrada y jarcia ---
  const lean = roll * s * 0.03, mx = L * 0.06, mTop = -s * 0.6, yardY = mTop + s * 0.045, sail = o.sail ?? 1, gust = 1 + 0.05 * Math.sin(t * 1.7) + 0.03 * Math.sin(t * 4.3), bil = cl((o.billow ?? 0.7) * gust, 0, 1.1), yw = s * 0.33;
  const MX = (yy) => mx + lean * (yy / mTop); // el mástil se inclina con el balanceo
  ctx.save(); ctx.lineCap = 'round';
  // obenques con vigotas (banda cercana) y estay de proa / popa
  ctx.strokeStyle = 'rgba(158,131,94,0.95)'; ctx.lineWidth = Math.max(1.2, s * 0.0035); ctx.beginPath(); ctx.moveTo(MX(mTop), mTop + s * 0.01); ctx.lineTo(L * 1.02, sheer(1) - s * 0.03); ctx.moveTo(MX(mTop), mTop + s * 0.01); ctx.lineTo(-L * 1.0, sheer(-1) - s * 0.03); ctx.stroke();
  for (const du of [0.16, 0.24, -0.14, -0.22]) { const u = 0.06 + du, bx = L * u, by = sheer(u); ctx.beginPath(); ctx.moveTo(MX(mTop + s * 0.04), mTop + s * 0.04); ctx.lineTo(bx, by - s * 0.03); ctx.stroke(); ctx.fillStyle = '#4a2f1f'; ctx.beginPath(); ctx.arc(bx, by - s * 0.03, Math.max(2, s * 0.005), 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(bx, by - s * 0.03); ctx.lineTo(bx, by); ctx.stroke(); }
  ctx.strokeStyle = gl.mast ? `rgba(255,212,71,${0.6 + 0.4 * gl.mast})` : '#5D3D29'; ctx.lineWidth = s * 0.017; ctx.beginPath(); ctx.moveTo(mx, sheer(0.06) + s * 0.01); ctx.lineTo(MX(mTop), mTop); ctx.stroke(); ctx.strokeStyle = 'rgba(255,228,190,0.25)'; ctx.lineWidth = s * 0.004; ctx.beginPath(); ctx.moveTo(mx - s * 0.004, sheer(0.06)); ctx.lineTo(MX(mTop) - s * 0.004, mTop); ctx.stroke();
  const sh = s * 0.37 * sail, bel = bil * s * 0.055 * sail, ymx = MX(yardY);
  ctx.lineWidth = s * 0.012; ctx.strokeStyle = '#4a3020'; ctx.beginPath(); ctx.moveTo(ymx - yw, yardY + s * 0.006); ctx.quadraticCurveTo(ymx, yardY - s * 0.004, ymx + yw, yardY + s * 0.006); ctx.stroke();
  if (sail > 0.02) { const top = yardY, b = yardY + sh, flap = Math.sin(t * 6) * s * 0.003 * (1 - Math.min(1, bil));
   const shape = () => { ctx.beginPath(); ctx.moveTo(ymx - yw, top); ctx.lineTo(ymx + yw, top); ctx.bezierCurveTo(ymx + yw + bel * 0.7, top + sh * 0.35, ymx + yw + bel * 0.5, top + sh * 0.75, ymx + yw * 0.95 + flap, b); ctx.quadraticCurveTo(ymx, b + bel * 0.55, ymx - yw * 0.95 - flap, b); ctx.bezierCurveTo(ymx - yw - bel * 0.5, top + sh * 0.75, ymx - yw - bel * 0.7, top + sh * 0.35, ymx - yw, top); ctx.closePath(); };
   ctx.save(); shape(); ctx.clip(); const sgr = ctx.createLinearGradient(ymx - yw, 0, ymx + yw, 0); sgr.addColorStop(0, '#a8946f'); sgr.addColorStop(0.4, '#ded0b0'); sgr.addColorStop(0.7, '#d2c19f'); sgr.addColorStop(1, '#a8946f'); ctx.fillStyle = sgr; ctx.fillRect(ymx - yw * 1.4, top - 4, yw * 2.8, sh + bel + 10);
   if (o.stripes !== false) { ctx.fillStyle = 'rgba(143,59,42,0.86)'; for (let i = -2; i <= 2; i += 2) { const cx0 = ymx + i * yw * 0.33; ctx.beginPath(); ctx.moveTo(cx0 - yw * 0.1, top - 4); ctx.lineTo(cx0 + yw * 0.1, top - 4); ctx.quadraticCurveTo(cx0 + yw * 0.1 + i * bel * 0.12, top + sh * 0.5, cx0 + yw * 0.1 + i * bel * 0.05, b + bel); ctx.lineTo(cx0 - yw * 0.1 + i * bel * 0.05, b + bel); ctx.quadraticCurveTo(cx0 - yw * 0.1 + i * bel * 0.12, top + sh * 0.5, cx0 - yw * 0.1, top - 4); ctx.closePath(); ctx.fill(); } }
   const vg = ctx.createLinearGradient(0, top, 0, b + bel); vg.addColorStop(0, 'rgba(255,245,225,0.18)'); vg.addColorStop(0.5, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(60,40,25,0.28)'); ctx.fillStyle = vg; ctx.fillRect(ymx - yw * 1.4, top - 4, yw * 2.8, sh + bel + 10);
   ctx.strokeStyle = 'rgba(80,60,40,0.22)'; ctx.lineWidth = 1; for (let k = 1; k < 7; k++) { ctx.beginPath(); ctx.moveTo(ymx - yw * 1.2, top + sh * k / 7); ctx.quadraticCurveTo(ymx, top + sh * k / 7 + bel * 0.45 * Math.sin(Math.PI * k / 7), ymx + yw * 1.2, top + sh * k / 7); ctx.stroke(); }
   ctx.restore(); shape(); ctx.strokeStyle = gl.sail ? `rgba(255,212,71,${0.6 + 0.4 * gl.sail})` : 'rgba(90,70,45,0.75)'; ctx.lineWidth = gl.sail ? 5 : Math.max(1.5, s * 0.003); ctx.stroke();
   // escotas y brazas tensas
   ctx.strokeStyle = 'rgba(158,131,94,0.95)'; ctx.lineWidth = Math.max(1.2, s * 0.0035); ctx.beginPath(); ctx.moveTo(ymx + yw * 0.95, b); ctx.lineTo(L * 0.66, sheer(0.66)); ctx.moveTo(ymx - yw * 0.95, b); ctx.lineTo(-L * 0.62, sheer(-0.62)); ctx.moveTo(ymx - yw, top); ctx.lineTo(-L * 0.9, sheer(-0.9) - s * 0.02); ctx.stroke();
  } else { ctx.fillStyle = '#c4b190'; ctx.beginPath(); ctx.ellipse(ymx, yardY + s * 0.01, yw * 0.95, s * 0.014, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(90,70,45,0.6)'; ctx.lineWidth = 1.5; for (let k = -4; k <= 4; k++) { ctx.beginPath(); ctx.moveTo(ymx + k * yw * 0.2, yardY); ctx.lineTo(ymx + k * yw * 0.2 + 3, yardY + s * 0.022); ctx.stroke(); } }
  ctx.restore();
  // tripulación (ropa de lana; sin cascos con cuernos) de pie tras la borda
  const cr = o.crew ?? 4; for (let i = 0; i < cr; i++) { const u = [-0.66, -0.4, 0.34, 0.58, -0.16, 0.46][i % 6], cx = L * u, cy = sheer(u) + s * 0.004, hh = s * 0.08; ctx.fillStyle = ['#6b4a35', '#4f5d4a', '#7a5a3a', '#55606a'][i % 4]; ctx.beginPath(); ctx.moveTo(cx - hh * 0.2, cy); ctx.quadraticCurveTo(cx - hh * 0.22, cy - hh * 0.55, cx - hh * 0.1, cy - hh * 0.66); ctx.lineTo(cx + hh * 0.1, cy - hh * 0.66); ctx.quadraticCurveTo(cx + hh * 0.22, cy - hh * 0.55, cx + hh * 0.2, cy); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#d2ab85'; ctx.beginPath(); ctx.arc(cx, cy - hh * 0.8, hh * 0.13, 0, TAU); ctx.fill(); ctx.fillStyle = '#5a4030'; ctx.beginPath(); ctx.arc(cx, cy - hh * 0.84, hh * 0.135, Math.PI * 1.05, Math.PI * 1.95); ctx.fill(); ctx.fillStyle = '#6a4a32'; ctx.beginPath(); ctx.ellipse(cx + hh * 0.03, cy - hh * 0.7, hh * 0.08, hh * 0.06, 0, 0, Math.PI); ctx.fill(); }
  ctx.restore();
  const wl = []; for (let k = 0; k <= 16; k++) { const u = -0.98 + 1.96 * k / 16; wl.push(P2(L * u, -s * 0.002)); }
  return { s, ang, flip: fl, bow: P2(L * 1.05, sheer(1) - s * 0.035), stern: P2(-L * 1.05, sheer(-1) - s * 0.035), bowWL: P2(L * 0.99, 0), sternWL: P2(-L * 0.97, 0), mastTop: P2(mx + lean, mTop), mastFoot: P2(mx, sheer(0.06)), sailC: P2(ymx, yardY + sh / 2), sailL: P2(ymx - yw, yardY), sailR: P2(ymx + yw, yardY), keelC: P2(0, keel(0)), hull: (u, f) => P2(L * u, lerp(keel(u), sheer(u), f)), oar: oarTips[0] || P2(L * 0.55, dr * 0.6), oarTips, wl };
 };
 // Agua alrededor del knarr (se dibuja DESPUÉS del mar delantero): espuma en la línea de flotación, bigote de proa,
 // estela, reflejo oscuro y destellos. o: { speed (0..1), spray (0..1) }
 P.knarrWater = (ctx, K, t, o = {}) => { if (!K) return; const s = K.s, sp = o.speed ?? 0.6, R = H.rng(5);
  ctx.save();
  // reflejo / sombra del casco sobre el agua
  ctx.globalAlpha = 0.28; ctx.fillStyle = '#081620'; ctx.beginPath(); K.wl.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1] + s * 0.012) : ctx.moveTo(p[0], p[1] + s * 0.012))); for (let i = K.wl.length - 1; i >= 0; i--) { const p = K.wl[i], u = i / (K.wl.length - 1); ctx.lineTo(p[0], p[1] + s * (0.03 + 0.03 * Math.sin(u * Math.PI))); } ctx.closePath(); ctx.fill();
  // espuma pegada al casco
  ctx.globalAlpha = 0.85; ctx.strokeStyle = '#eef5f5'; ctx.lineCap = 'round'; K.wl.forEach((p, i) => { if (i === 0) return; const q = K.wl[i - 1], w = 0.3 + 0.7 * Math.abs(Math.sin(t * 2.2 + i * 1.3)); ctx.lineWidth = Math.max(1.5, s * 0.006 * w); ctx.beginPath(); ctx.moveTo(q[0], q[1] + Math.sin(t * 3 + i) * 1.5); ctx.lineTo(p[0], p[1] + Math.sin(t * 3 + i + 1) * 1.5); ctx.stroke(); });
  // bigote de proa y salpicaduras
  const bw = K.bowWL, dir = K.flip; ctx.fillStyle = '#f4fafa'; for (let i = 0; i < 14; i++) { const u = (t * (1.2 + sp) + i / 14) % 1, a = (1 - u) * 0.8 * (0.4 + sp); ctx.globalAlpha = a; ctx.beginPath(); ctx.ellipse(bw[0] - dir * u * s * 0.25, bw[1] + u * s * 0.03 - Math.sin(u * Math.PI) * s * 0.03 * (o.spray ?? sp), s * 0.02 * (1 - u * 0.5), s * 0.006, 0, 0, TAU); ctx.fill(); }
  // estela tras la popa
  const st = K.sternWL; for (let i = 0; i < 18; i++) { const u = i / 17, a = (1 - u) * 0.55 * sp; ctx.globalAlpha = a; const xx = st[0] - dir * u * s * 1.1, sp2 = s * 0.02 * (1 + u * 3); ctx.beginPath(); ctx.ellipse(xx + Math.sin(t * 2 + i) * 4, st[1] + u * s * 0.025, sp2, s * 0.005 * (1 + u), 0, 0, TAU); ctx.fill(); }
  ctx.restore(); };
 // Corte transversal del casco trincado: quilla, tracas que se solapan, remaches, cuaderna y bao.
 // o: { flex (−1..1), explode (0..1 separa las tablas para ver el solape), assemble (0..n: las tablas entran una a una),
 // rivets (0..n: aparecen los remaches), glow:{overlap, rivets, keel, rib}, n }
 P.clinkerSection = (ctx, cx, cy, w, h, t, o = {}) => {
  const n = o.n || 7, ex = o.explode || 0, fl = o.flex || 0, gl = o.glow || {}, pts = { overlaps: [] };
  const curve = (u) => { const a = u * Math.PI * 0.5; return [Math.sin(a) * w * 0.5, -h * 0.05 - (1 - Math.cos(a)) * h * 0.95 + (u > 0.6 ? 0 : 0)]; };
  ctx.save(); ctx.translate(cx, cy);
  for (const sd of [-1, 1]) for (let i = 0; i < n; i++) {
   const u0 = 0.08 + i / n * 0.92, u1 = 0.08 + (i + 1) / n * 0.92 + 0.035, a = curve(u0), b = curve(u1), dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy), nx = dy / len, ny = -dx / len, th = Math.max(8, w * 0.022);
   const vis = cl((o.assemble ?? n) - i); if (vis <= 0) continue; const off = ex * 26 * (i % 2 ? 1 : 0.4) + i * 2 * ex + (1 - E.out(vis)) * w * 0.4, bend = fl * i * 0.012 * sd;
   ctx.save(); ctx.globalAlpha *= cl(vis * 2); ctx.scale(sd, 1); ctx.translate(a[0] + nx * (th * 0.5 * (i % 2) + off), a[1] + ny * off); ctx.rotate(Math.atan2(dy, dx) + bend);
   ctx.fillStyle = i % 2 ? '#A4774F' : '#94683f'; ctx.fillRect(0, -th / 2, len, th); ctx.fillStyle = 'rgba(255,230,190,0.25)'; ctx.fillRect(0, -th / 2, len, 2); ctx.strokeStyle = 'rgba(30,18,10,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(0, -th / 2, len, th);
   ctx.strokeStyle = 'rgba(70,45,25,0.35)'; ctx.lineWidth = 1; for (let g = 0; g < 3; g++) { ctx.beginPath(); ctx.moveTo(4, -th / 2 + th * (g + 1) / 4); ctx.lineTo(len - 4, -th / 2 + th * (g + 1) / 4 + Math.sin(g + i) * 2); ctx.stroke(); }
   const rv = cl((o.rivets ?? n) - i + 1); if (i > 0 && rv > 0) { const rr = th * 0.34 * E.back(rv); ctx.fillStyle = gl.rivets ? `rgba(255,212,71,${0.6 + 0.4 * gl.rivets})` : '#3a3530'; for (const fx of [0.06, 0.5, 0.94]) { ctx.beginPath(); ctx.arc(len * fx, 0, rr, 0, TAU); ctx.fill(); } }
   ctx.restore();
   if (i > 0 && sd === 1) pts.overlaps.push([cx + a[0], cy + a[1]]);
   if (i > 0 && gl.overlap) { ctx.save(); ctx.scale(sd, 1); ctx.strokeStyle = `rgba(255,212,71,${gl.overlap})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(a[0], a[1], th * 1.6, 0, TAU); ctx.stroke(); ctx.restore(); }
  }
  // quilla
  ctx.fillStyle = gl.keel ? '#c9925a' : '#5D3D29'; ctx.beginPath(); ctx.moveTo(-w * 0.07, -h * 0.02); ctx.lineTo(w * 0.07, -h * 0.02); ctx.lineTo(w * 0.035, h * 0.12); ctx.lineTo(-w * 0.035, h * 0.12); ctx.closePath(); ctx.fill(); if (gl.keel) { ctx.strokeStyle = `rgba(255,212,71,${gl.keel})`; ctx.lineWidth = 4; ctx.stroke(); }
  pts.keel = [cx, cy + h * 0.05];
  // cuaderna (costilla interior) y bao (viga transversal)
  ctx.save(); ctx.globalAlpha *= 1 - ex * 0.6; ctx.strokeStyle = gl.rib ? `rgba(255,212,71,${0.7 + 0.3 * gl.rib})` : '#c9925a'; ctx.lineWidth = Math.max(10, w * 0.03); ctx.lineCap = 'round'; ctx.beginPath(); for (let k = 0; k <= 30; k++) { const u = -0.82 + 1.64 * k / 30, p = curve(Math.abs(u)); ctx.lineTo(Math.sign(u) * p[0] * 0.9, p[1] * 0.92 - w * 0.03); } ctx.stroke();
  const by = curve(0.72)[1]; ctx.fillStyle = '#8b5a33'; ctx.fillRect(-curve(0.72)[0] * 0.93, by - 12, curve(0.72)[0] * 1.86, 22); ctx.restore();
  pts.rib = [cx + curve(0.45)[0] * 0.9, cy + curve(0.45)[1] * 0.92 - w * 0.03]; pts.beam = [cx, cy + by]; pts.top = [cx + curve(1)[0], cy + curve(1)[1]];
  ctx.restore(); return pts;
 };
 // Mapa ESTILIZADO del Atlántico Norte (Escandinavia, Islandia, Groenlandia, Terranova). Proyección cilíndrica con escala
 // cos(60°). o: { lon0, lon1, lat0, lat1, sea, land, ice, grid, coastGlow }. Devuelve proj([lon, lat]) → [px, py].
 const NATL = { // v1.13.1: costas más fieles (contornos simplificados a mano a partir de mapas físicos)
  groenlandia: [[-43.9, 59.8], [-42.5, 60.5], [-41.5, 61.6], [-40.4, 63.3], [-39.6, 64.6], [-37.5, 65.6], [-35.5, 66.2], [-33, 67.7], [-31, 68.2], [-27, 68.6], [-24.5, 69.8], [-23, 70.5], [-22, 71.8], [-21.8, 73.5], [-20, 74.5], [-18.8, 76.5], [-18.2, 78.5], [-17, 80], [-20, 81.5], [-30, 82.6], [-40, 83.3], [-50, 82.5], [-58, 81.8], [-63, 81.2], [-66, 80], [-71, 78.6], [-72.5, 77.5], [-68, 76.2], [-62, 75.9], [-58, 75.3], [-56.5, 74], [-55.5, 72.5], [-54.5, 71], [-52.5, 70.2], [-54, 69.5], [-51.5, 68.7], [-53.5, 67], [-53, 66], [-52, 64.5], [-50.5, 63], [-49, 61.8], [-48, 61], [-46.5, 60.6], [-45, 60.1]],
  islandia: [[-24.5, 65.5], [-23.6, 65.9], [-22.8, 66.4], [-21.5, 65.6], [-20.5, 66.1], [-18.8, 66.2], [-16.5, 66.5], [-15, 66.2], [-14.5, 65.8], [-13.6, 65.3], [-14.3, 64.6], [-15.4, 64.3], [-17, 63.9], [-18.8, 63.4], [-20.5, 63.7], [-22.7, 63.85], [-21.9, 64.15], [-22.5, 64.55], [-24.0, 64.85], [-22.2, 65.1]],
  escandinavia: [[5.0, 58.9], [5.2, 59.8], [4.9, 61.2], [5.4, 62.2], [6.8, 62.7], [8.3, 63.3], [9.8, 63.8], [11.0, 64.6], [12.3, 65.7], [13.3, 66.8], [14.5, 67.6], [15.8, 68.4], [17.5, 69.2], [19.5, 69.9], [22.5, 70.4], [25.0, 71.1], [28, 71.0], [30.5, 70.4], [31.2, 69.8], [30, 68], [29.7, 66.5], [28.6, 64.5], [29.8, 62.5], [28, 61], [25, 60.3], [22.5, 60.0], [21.4, 61.2], [21.4, 63], [24.5, 64.8], [25.4, 65.3], [22.5, 65.8], [21, 64.6], [19, 63.5], [17.6, 62.5], [17.2, 61.2], [18.4, 60.2], [17.8, 59.3], [16.6, 58.1], [16.4, 57], [14.5, 56.1], [12.9, 55.4], [12.5, 56.5], [11.6, 58.1], [10.5, 59.2], [9.8, 59.0], [8.3, 58.2], [7.0, 58.0], [5.8, 58.4]],
  dinamarca: [[8.1, 55.1], [8.6, 57.1], [10.6, 57.7], [10.4, 56.2], [12.3, 55.4], [9.8, 54.8]],
  britania: [[-5.7, 50.1], [1.4, 51.1], [1.7, 52.8], [0.2, 53.5], [-1.6, 55.1], [-2.1, 57.1], [-1.8, 57.6], [-3.1, 58.6], [-5, 58.6], [-6.2, 57.2], [-5.6, 56.3], [-5.2, 55.6], [-3.2, 54.6], [-4.6, 53.3], [-3.1, 51.6], [-5.2, 51.7]],
  irlanda: [[-10, 51.6], [-6.2, 52.1], [-6, 54.1], [-7.4, 55.3], [-8.5, 54.8], [-10, 54.2]],
  baffin: [[-62, 66.8], [-63.5, 65], [-64.7, 63.3], [-68, 62.5], [-71.5, 63.3], [-74, 64.8], [-77.5, 64.3], [-78.5, 66.5], [-75, 68.5], [-70, 70.6], [-73, 72], [-80, 73.7], [-90, 73.8], [-90, 69], [-82, 69], [-73, 67.5], [-66, 67.5]],
  america: [[-100, 62], [-94, 61], [-78, 62.4], [-77.5, 60.5], [-76.5, 58], [-77, 56], [-79, 54], [-78.5, 51.5], [-80, 51], [-79, 52.5], [-75, 59], [-70, 61.1], [-67.5, 58.4], [-64.3, 60.3], [-63.3, 59], [-62, 57.6], [-61.2, 56.2], [-60, 55.2], [-57.9, 54.4], [-56.2, 53.6], [-55.7, 52.4], [-56.9, 51.45], [-58.7, 51.1], [-60.3, 50.3], [-64, 50.2], [-66.6, 50.1], [-68.5, 49.2], [-70.5, 47.5], [-69, 48.3], [-66.5, 49.1], [-64.3, 48.9], [-64.8, 47.4], [-63.8, 46.1], [-61, 45.6], [-60, 46.0], [-61.4, 45.1], [-64, 44.5], [-66, 43.8], [-70, 43.2], [-71, 41.6], [-100, 41]],
  terranova: [[-59.4, 47.6], [-58.4, 47.6], [-56, 47.6], [-55.4, 46.9], [-54, 47.2], [-53.6, 46.6], [-52.6, 47.5], [-53.1, 47.8], [-53.6, 48.5], [-53.0, 49.0], [-54.5, 49.6], [-55.6, 49.9], [-55.9, 50.8], [-55.5, 51.6], [-56.2, 51.6], [-57.1, 51.0], [-58, 49.9], [-59.2, 48.5]],
 };
 P.NATL = NATL;
 P.northAtlantic = (ctx, x, y, w, h, t, o = {}) => {
  const lon0 = o.lon0 ?? -80, lon1 = o.lon1 ?? 25, lat0 = o.lat0 ?? 43, lat1 = o.lat1 ?? 78, k = Math.cos((o.latRef ?? 60) * Math.PI / 180);
  const sx = w / ((lon1 - lon0) * k), sy = h / (lat1 - lat0), sc = Math.min(sx, sy), ox = x + (w - (lon1 - lon0) * k * sc) / 2, oy = y + (h - (lat1 - lat0) * sc) / 2;
  const proj = (p) => [ox + (p[0] - lon0) * k * sc, oy + (lat1 - p[1]) * sc];
  ctx.save(); const sg = ctx.createLinearGradient(0, y, 0, y + h); sg.addColorStop(0, o.sea || '#163847'); sg.addColorStop(1, '#0D1820'); ctx.fillStyle = sg; ctx.fillRect(x, y, w, h);
  if (o.grid !== false) { ctx.strokeStyle = 'rgba(167,200,212,0.10)'; ctx.lineWidth = 1.5; for (let la = 45; la <= 75; la += 10) { const a = proj([lon0, la]), b = proj([lon1, la]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } for (let lo = -80; lo <= 20; lo += 20) { const a = proj([lo, lat0]), b = proj([lo, lat1]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } }
  ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  const poly = (pts) => { ctx.beginPath(); P.spline(pts.map(proj), 4).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); };
  for (const [name, pts] of Object.entries(NATL)) { poly(pts); ctx.fillStyle = o.land || '#49664B'; ctx.fill(); ctx.strokeStyle = 'rgba(220,232,233,0.55)'; ctx.lineWidth = 2; ctx.stroke();
   if (name === 'groenlandia' && o.ice !== false) { const c = proj([-41, 72.5]); ctx.save(); ctx.translate(c[0], c[1]); ctx.scale(0.84, 0.88); ctx.translate(-c[0], -c[1]); poly(pts); ctx.fillStyle = 'rgba(201,229,237,0.92)'; ctx.fill(); ctx.restore(); }
   if (name === 'islandia' || name === 'baffin') { const c = proj(name === 'islandia' ? [-18.5, 64.9] : [-74, 68]); ctx.save(); ctx.translate(c[0], c[1]); ctx.scale(0.45, 0.45); ctx.translate(-c[0], -c[1]); poly(pts); ctx.fillStyle = 'rgba(201,229,237,0.55)'; ctx.fill(); ctx.restore(); } }
  for (const p of [[-7, 62], [-1.3, 60.4], [-3, 59]]) { const q = proj(p); ctx.fillStyle = o.land || '#49664B'; ctx.beginPath(); ctx.arc(q[0], q[1], sc * 0.35, 0, TAU); ctx.fill(); }
  ctx.restore(); return proj;
 };
 // Ruta marítima: curva suave por puntos, se dibuja con p (0..1), trazo discontinuo que fluye y barquito en la punta.
 // o: { c, w, dash, ship (true), glow, speed }. Devuelve P.path de la curva completa.
 P.seaRoute = (ctx, pts, p, t, o = {}) => {
  const cv = P.spline(pts, 14), pa = P.path(cv), end = pa.L * cl(p); if (p <= 0) return pa; const c = o.c || '#FFD447', w = o.w || 7;
  const sub = [cv[0]]; for (let s = 10; s < end; s += 10) { const q = pa.at(s); sub.push([q[0], q[1]]); } const e = pa.at(end); sub.push([e[0], e[1]]);
  ctx.save(); if (o.glow !== false) P.strokePath(ctx, sub, w * 3.2, 'rgba(255,212,71,0.18)'); ctx.setLineDash(o.dash || [w * 2.6, w * 1.8]); ctx.lineDashOffset = -t * (o.speed ?? 40); P.strokePath(ctx, sub, w, c); ctx.setLineDash([]); ctx.restore();
  if (o.ship !== false && p < 1.0001) { ctx.save(); ctx.translate(e[0], e[1]); ctx.rotate(e[2]); const z = o.shipS || w * 3.4; ctx.fillStyle = '#5D3D29'; ctx.beginPath(); ctx.moveTo(-z, -z * 0.15); ctx.quadraticCurveTo(0, z * 0.55, z, -z * 0.15); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#D7C6A5'; ctx.fillRect(-z * 0.45, -z * 1.05, z * 0.9, z * 0.8); ctx.fillStyle = 'rgba(143,59,42,0.9)'; ctx.fillRect(-z * 0.1, -z * 1.05, z * 0.2, z * 0.8); ctx.restore(); }
  return pa;
 };
 // Costa del Atlántico Norte en la distancia (sobre la línea y). o: { x0, x1, h, c, snow, ice, green, seed, kind: 'fiordo'|'volcanica'|'glaciar'|'baja' }
 P.coast = (ctx, y, t, o = {}) => {
  const x0 = o.x0 ?? -200, x1 = o.x1 ?? W + 200, hh = o.h ?? 260, R = H.rng(o.seed || 3), kind = o.kind || 'fiordo'; const pts = []; const n = 34;
  for (let i = 0; i <= n; i++) { const u = i / n, base = kind === 'baja' ? 0.25 + 0.12 * Math.sin(u * 7 + 1) : kind === 'volcanica' ? 0.45 + 0.35 * Math.sin(u * 3.2 + 0.5) : 0.5 + 0.4 * Math.sin(u * 5.3 + R() * 0.5); pts.push([lerp(x0, x1, u), y - hh * cl(base + R.range(-0.12, 0.12), 0.05, 1)]); }
  ctx.save(); ctx.fillStyle = o.c || (kind === 'volcanica' ? '#3f4844' : '#68736C'); ctx.beginPath(); ctx.moveTo(x0, y + 4); pts.forEach((p) => ctx.lineTo(p[0], p[1])); ctx.lineTo(x1, y + 4); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.clip(); const gg = ctx.createLinearGradient(0, y - hh, 0, y); gg.addColorStop(0, 'rgba(255,255,255,0.08)'); gg.addColorStop(1, 'rgba(0,0,0,0.25)'); ctx.fillStyle = gg; ctx.fillRect(x0, y - hh - 10, x1 - x0, hh + 20);
   if (o.green ?? (kind !== 'glaciar')) { ctx.fillStyle = 'rgba(73,102,75,0.85)'; ctx.beginPath(); ctx.moveTo(x0, y + 4); pts.forEach((p) => ctx.lineTo(p[0], lerp(p[1], y, 0.55))); ctx.lineTo(x1, y + 4); ctx.closePath(); ctx.fill(); }
   if (o.snow ?? (kind !== 'baja')) { ctx.fillStyle = kind === 'glaciar' ? 'rgba(201,229,237,0.95)' : 'rgba(236,244,246,0.85)'; pts.forEach((p, i) => { if (i === 0 || y - p[1] < hh * (kind === 'glaciar' ? 0.3 : 0.62)) return; const q = pts[i - 1]; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(p[0] + 26, p[1] + hh * 0.12); ctx.lineTo(q[0] + 10, Math.max(p[1], q[1]) + hh * 0.06); ctx.closePath(); ctx.fill(); }); }
   if (kind === 'glaciar' && o.ice !== false) { ctx.fillStyle = 'rgba(201,229,237,0.75)'; ctx.fillRect(x0, y - hh * 0.95, x1 - x0, hh * 0.12); }
  ctx.restore();
  ctx.fillStyle = 'rgba(220,232,233,0.5)'; ctx.fillRect(x0, y - 1, x1 - x0, 3); ctx.restore();
 };
 P.iceberg = (ctx, x, y, s, t, o = {}) => { const R = H.rng(o.seed || 2), b = Math.sin(t * 0.8 + (o.seed || 0)) * s * 0.01; const top = [[-0.5, 0], [-0.38, -0.3], [-0.18, -0.42], [0.02, -0.7], [0.16, -0.5], [0.34, -0.46], [0.5, 0]].map(([u, v]) => [x + u * s + R.range(-2, 2), y + v * s + b]);
  ctx.save(); ctx.globalAlpha *= 0.25; ctx.fillStyle = '#7fb6c6'; ctx.beginPath(); ctx.ellipse(x, y + s * 0.25, s * 0.62, s * 0.3, 0, 0, TAU); ctx.fill(); ctx.restore();
  ctx.fillStyle = '#C9E5ED'; ctx.beginPath(); top.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(120,170,190,0.45)'; ctx.beginPath(); ctx.moveTo(top[3][0], top[3][1]); ctx.lineTo(top[4][0], top[4][1]); ctx.lineTo(top[5][0], top[5][1]); ctx.lineTo(top[6][0], top[6][1]); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(220,232,233,0.8)'; ctx.fillRect(x - s * 0.52, y - 2, s * 1.04, 4); };
 // Casa nórdica de césped y madera (L'Anse aux Meadows, Groenlandia). (x, y) = centro de la base.
 // o: { ruin (0 casa → 1 restos: montículos bajos de césped), smoke (t), door, glow }
 P.sodHouse = (ctx, x, y, w, h, t, o = {}) => {
  const ru = o.ruin || 0; ctx.save();
  if (ru < 1) { ctx.save(); ctx.globalAlpha *= 1 - ru;
   ctx.fillStyle = 'rgba(20,30,25,0.3)'; ctx.beginPath(); ctx.ellipse(x, y + 2, w * 0.56, h * 0.08, 0, 0, TAU); ctx.fill();
   // muros de turba (bloques en espiga) y techo redondeado cubierto de hierba
   ctx.fillStyle = '#6a5a3c'; ctx.beginPath(); ctx.moveTo(x - w / 2, y); ctx.lineTo(x - w / 2 + w * 0.02, y - h * 0.42); ctx.lineTo(x + w / 2 - w * 0.02, y - h * 0.42); ctx.lineTo(x + w / 2, y); ctx.closePath(); ctx.fill();
   ctx.strokeStyle = 'rgba(40,30,18,0.5)'; ctx.lineWidth = 2; for (let r = 0; r < 4; r++) { const yy = y - h * 0.1 * (r + 0.5); for (let c = 0; c < 14; c++) { const xx = x - w / 2 + w * (c + 0.5) / 14; ctx.beginPath(); ctx.moveTo(xx - w * 0.025, yy + (r % 2 ? -1 : 1) * h * 0.035); ctx.lineTo(xx + w * 0.025, yy - (r % 2 ? -1 : 1) * h * 0.035); ctx.stroke(); } }
   const rg = ctx.createLinearGradient(0, y - h, 0, y - h * 0.4); rg.addColorStop(0, '#6f8f58'); rg.addColorStop(1, '#49664B'); ctx.fillStyle = rg; ctx.beginPath(); ctx.moveTo(x - w * 0.53, y - h * 0.4); ctx.quadraticCurveTo(x - w * 0.45, y - h * 1.02, x, y - h); ctx.quadraticCurveTo(x + w * 0.45, y - h * 1.02, x + w * 0.53, y - h * 0.4); ctx.closePath(); ctx.fill();
   ctx.strokeStyle = 'rgba(150,180,110,0.6)'; ctx.lineWidth = 2; const Rg = H.rng(o.seed || 4); for (let i = 0; i < 40; i++) { const u = Rg.range(-0.48, 0.48), yy = y - h * (0.42 + (1 - Math.pow(Math.abs(u) / 0.53, 2)) * 0.55) + 3; ctx.beginPath(); ctx.moveTo(x + u * w, yy); ctx.lineTo(x + u * w + Rg.range(-4, 4), yy - Rg.range(5, 12)); ctx.stroke(); }
   // hastial de madera con puerta
   const dx = x + w * (o.doorX ?? 0.18); ctx.fillStyle = '#5D3D29'; ctx.fillRect(dx - w * 0.06, y - h * 0.38, w * 0.12, h * 0.38); ctx.fillStyle = '#2b1d13'; ctx.fillRect(dx - w * 0.035, y - h * 0.3, w * 0.07, h * 0.3); ctx.strokeStyle = 'rgba(164,119,79,0.6)'; ctx.lineWidth = 2; for (let k = 1; k < 3; k++) { ctx.beginPath(); ctx.moveTo(dx - w * 0.06 + w * 0.04 * k, y - h * 0.38); ctx.lineTo(dx - w * 0.06 + w * 0.04 * k, y - h * 0.3); ctx.stroke(); }
   if (o.smoke != null) { for (let i = 0; i < 6; i++) { const u = ((t * 0.25 + i / 6) % 1); ctx.fillStyle = `rgba(220,226,228,${0.35 * (1 - u)})`; ctx.beginPath(); ctx.arc(x - w * 0.1 + Math.sin(u * 5 + i) * 10 + u * 40, y - h - u * h * 1.2, 8 + u * 22, 0, TAU); ctx.fill(); } }
   if (o.glow) { ctx.strokeStyle = `rgba(255,212,71,${o.glow})`; ctx.lineWidth = 4; ctx.strokeRect(x - w / 2 - 6, y - h - 6, w + 12, h + 10); }
   ctx.restore(); }
  if (ru > 0) { ctx.save(); ctx.globalAlpha *= ru; ctx.fillStyle = '#5f7d4c'; ctx.beginPath(); ctx.moveTo(x - w / 2 - 10, y); ctx.quadraticCurveTo(x - w / 2, y - h * 0.2, x - w / 2 + w * 0.08, y - h * 0.16); ctx.lineTo(x + w / 2 - w * 0.08, y - h * 0.16); ctx.quadraticCurveTo(x + w / 2, y - h * 0.2, x + w / 2 + 10, y); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#7d9a5f'; ctx.fillRect(x - w / 2 + w * 0.1, y - h * 0.1, w * 0.8, h * 0.1); ctx.strokeStyle = 'rgba(40,55,35,0.6)'; ctx.lineWidth = 3; ctx.strokeRect(x - w / 2 + w * 0.08, y - h * 0.16, w * 0.84, h * 0.16); ctx.beginPath(); ctx.moveTo(x - w * 0.1, y - h * 0.16); ctx.lineTo(x - w * 0.1, y); ctx.moveTo(x + w * 0.2, y - h * 0.16); ctx.lineTo(x + w * 0.2, y); ctx.stroke(); ctx.restore(); }
  ctx.restore();
 };
 // Corte de madera con anillos de crecimiento. o: { n, hi (índice del anillo destacado contando desde la corteza),
 // count (0..1: recuento de anillos del destacado a la corteza), cut (marca de herramienta de metal), seed, glowC }
 P.treeRings = (ctx, x, y, r, t, o = {}) => {
  const n = o.n || 40, R = H.rng(o.seed || 12), wob = []; for (let i = 0; i < 6; i++) wob.push([R.range(0, TAU), R.range(0.01, 0.03), 2 + Math.floor(R() * 4)]);
  const rr = (i, a) => { const base = r * 0.92 * (1 - Math.pow(1 - (n - i) / n, 1.05) * 0) * ((n - i) / n); let k = 1; for (const [p, amp, f] of wob) k += amp * Math.sin(a * f + p); return Math.max(2, base * k); };
  const shape = (i) => { ctx.beginPath(); for (let k = 0; k <= 72; k++) { const a = k / 72 * TAU, q = rr(i, a); ctx.lineTo(x + Math.cos(a) * q, y + Math.sin(a) * q * 0.96); } ctx.closePath(); };
  ctx.save(); shape(-3); ctx.fillStyle = '#4a3324'; ctx.fill(); shape(0); const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, '#d9b98a'); g.addColorStop(1, '#c49a68'); ctx.fillStyle = g; ctx.fill();
  for (let i = 1; i < n; i++) { shape(i); ctx.strokeStyle = `rgba(110,72,40,${0.35 + 0.25 * ((i * 7) % 3) / 2})`; ctx.lineWidth = 1.2 + ((i * 13) % 4) * 0.5; ctx.stroke(); }
  if (o.hi != null) { shape(o.hi); ctx.strokeStyle = o.glowC || 'rgba(255,212,71,0.95)'; ctx.lineWidth = 6; ctx.shadowColor = 'rgba(255,212,71,0.8)'; ctx.shadowBlur = 14; ctx.stroke(); ctx.shadowBlur = 0; }
  const cnt = o.count || 0; if (cnt > 0 && o.hi != null) { const a = -0.55, m = Math.floor(o.hi * cl(cnt)); ctx.fillStyle = '#ffffff'; for (let i = 0; i <= m; i++) { const q = rr(o.hi - i, a); ctx.beginPath(); ctx.arc(x + Math.cos(a) * q, y + Math.sin(a) * q * 0.96, 4, 0, TAU); ctx.fill(); } }
  if (o.cut) { ctx.strokeStyle = 'rgba(60,40,25,0.9)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x + r * 0.55, y + r * 0.7); ctx.lineTo(x + r * 0.95, y + r * 0.2); ctx.stroke(); ctx.strokeStyle = 'rgba(255,240,210,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + r * 0.57, y + r * 0.66); ctx.lineTo(x + r * 0.93, y + r * 0.18); ctx.stroke(); }
  ctx.restore(); return { ringR: (i, a = -0.55) => rr(i, a), at: (i, a = -0.55) => [x + Math.cos(a) * rr(i, a), y + Math.sin(a) * rr(i, a) * 0.96] };
 };
 // Línea temporal cinematográfica. o: { from, to, step, p (0..1 dibujo), marks:[{v, label, sub, c, up}], span:[a, b, texto], spanP, px }
 P.timeline = (ctx, x0, x1, y, t, o = {}) => {
  const f = o.from ?? 900, to = o.to ?? 1600, map = (v) => lerp(x0, x1, (v - f) / (to - f)), p = o.p ?? 1, xe = lerp(x0, x1, p), px = o.px || 32;
  ctx.save(); ctx.strokeStyle = 'rgba(244,247,247,0.85)'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(xe, y); ctx.stroke();
  ctx.font = `700 ${px}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(244,247,247,0.75)'; for (let v = Math.ceil(f / (o.step || 100)) * (o.step || 100); v <= to; v += o.step || 100) { const xx = map(v); if (xx > xe) break; ctx.fillRect(xx - 2, y - 14, 4, 28); if (!(o.marks || []).some((m) => Math.abs(map(m.v) - xx) < px * 2.2)) ctx.fillText(String(v), xx, y + 60); }
  if (o.span && (o.spanP ?? 0) > 0) { const a = map(o.span[0]), b = lerp(a, map(o.span[1]), cl(o.spanP)); ctx.save(); ctx.shadowColor = 'rgba(255,212,71,0.9)'; ctx.shadowBlur = 20; ctx.strokeStyle = '#FFD447'; ctx.lineWidth = 14; ctx.beginPath(); ctx.moveTo(a, y); ctx.lineTo(b, y); ctx.stroke(); ctx.restore(); }
  for (const m of o.marks || []) { const xx = map(m.v); if (xx > xe + 1 || (m.a ?? 1) <= 0) continue; ctx.save(); ctx.globalAlpha *= m.a ?? 1; ctx.fillStyle = m.c || '#FFD447'; ctx.beginPath(); ctx.arc(xx, y, 18, 0, TAU); ctx.fill(); ctx.strokeStyle = '#0D1820'; ctx.lineWidth = 5; ctx.stroke();
   const up = m.up ?? true, ly = up ? y - 120 : y + 150; ctx.strokeStyle = m.c || '#FFD447'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(xx, y + (up ? -20 : 20)); ctx.lineTo(xx, ly + (up ? 30 : -50)); ctx.stroke();
   ctx.font = `800 ${px}px Nunito`; const sw = m.sub ? ctx.measureText(m.sub).width : 0; ctx.font = `900 ${Math.round(px * 1.9)}px Nunito`; const hw = Math.max(sw, ctx.measureText(String(m.label)).width) / 2 + 24, tx = cl(xx, hw, W - hw); ctx.fillStyle = m.c || '#FFD447'; ctx.fillText(String(m.label), tx, ly); if (m.sub) { ctx.font = `800 ${px}px Nunito`; ctx.fillStyle = '#F4F7F7'; ctx.fillText(m.sub, tx, ly + px * 1.3); } ctx.restore(); }
  ctx.restore(); return map;
 };
 // Cielo nocturno con estrellas que titilan (determinista). o: { a, y0, y1, n, seed, band (vía láctea), mark:[x,y] }
 P.nightSky = (ctx, t, o = {}) => { const a = o.a ?? 1; if (a <= 0) return; const y0 = o.y0 ?? -400, y1 = o.y1 ?? 900, R = H.rng(o.seed || 31); ctx.save(); ctx.globalAlpha *= a; const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#060d18'); g.addColorStop(1, '#1b3346'); ctx.fillStyle = g; ctx.fillRect(-600, y0, W + 1200, y1 - y0);
  if (o.band !== false) { ctx.save(); ctx.translate(540, (y0 + y1) / 2); ctx.rotate(-0.5); const bg = ctx.createLinearGradient(0, -120, 0, 120); bg.addColorStop(0, 'rgba(200,215,235,0)'); bg.addColorStop(0.5, 'rgba(200,215,235,0.12)'); bg.addColorStop(1, 'rgba(200,215,235,0)'); ctx.fillStyle = bg; ctx.fillRect(-1400, -120, 2800, 240); ctx.restore(); }
  for (let i = 0; i < (o.n || 260); i++) { const sx = R.range(-500, W + 500), sy = R.range(y0, y1), m = R(), tw = 0.6 + 0.4 * Math.sin(t * R.range(1, 4) + i); ctx.fillStyle = `rgba(240,246,255,${(0.35 + 0.65 * m) * tw})`; ctx.beginPath(); ctx.arc(sx, sy, 0.8 + m * m * 2.6, 0, TAU); ctx.fill(); }
  if (o.mark) { P.glow(ctx, o.mark[0], o.mark[1], 60, '255,240,200', 0.6); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(o.mark[0], o.mark[1], 5, 0, TAU); ctx.fill(); }
  ctx.restore(); };
 // Persona nórdica estilizada (túnica, capa, gorro; sin cascos con cuernos). pose: 'stand' | 'look' (mano a la frente) | 'row' | 'point' | 'walk'
 P.norse = (ctx, x, y, h, ph = 0, o = {}) => { const pose = o.pose || 'stand'; const hand = P.worker(ctx, x, y, h, ph, { pose: pose === 'row' ? 'pull' : pose === 'walk' ? 'walk' : 'stand', c: o.c || '#3a2c22', cloth: o.cloth || '#6b4a35' });
  const lean = pose === 'row' ? 0.42 : 0.05, hip = [x, y - h * 0.48], sh = [x + Math.sin(lean) * h * 0.32, hip[1] - Math.cos(lean) * h * 0.32], head = [sh[0] + Math.sin(lean) * h * 0.12, sh[1] - Math.cos(lean) * h * 0.12];
  ctx.save(); ctx.fillStyle = o.cloak || '#55606a'; ctx.beginPath(); ctx.moveTo(sh[0] - h * 0.06, sh[1] - h * 0.02); ctx.lineTo(sh[0] + h * 0.07, sh[1] - h * 0.02); ctx.lineTo(hip[0] + h * 0.1, hip[1] + h * 0.08); ctx.lineTo(hip[0] - h * 0.14, hip[1] + h * 0.1); ctx.closePath(); ctx.fill();
  ctx.fillStyle = o.cap || '#4a3a2c'; ctx.beginPath(); ctx.arc(head[0], head[1] - h * 0.01, h * 0.08, Math.PI, TAU); ctx.fill();
  if (pose === 'look' || pose === 'point') { ctx.strokeStyle = o.c || '#3a2c22'; ctx.lineWidth = h * 0.07; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(sh[0], sh[1]); if (pose === 'look') { ctx.lineTo(sh[0] + h * 0.14, sh[1] - h * 0.05); ctx.lineTo(head[0] + h * 0.09, head[1] - h * 0.02); } else ctx.lineTo(sh[0] + h * 0.3, sh[1] - h * 0.2); ctx.stroke(); }
  ctx.restore(); return hand; };
 // ---- v1.13.1 · figuras y arquitectura nórdica más fieles ----
 // Navegante nórdico de espaldas en 3/4 mirando a la derecha (horizonte). (x, y) = pies; h = altura.
 // o: { look (0..1 mano a la frente), turn (−1..1 giro de cabeza), wind (0..1 capa al viento), rim (0..1 luz de contorno), tunic, cloak }
 P.navigator = (ctx, x, y, h, t, o = {}) => {
  const lk = E.inOut(cl(o.look ?? 1)), wd = o.wind ?? 0.6, rim = o.rim ?? 0.8, tn = o.turn || 0, U = h, sw = Math.sin(t * 2.1) * wd, sw2 = Math.sin(t * 3.3 + 1) * wd;
  const tun = o.tunic || '#6b4a35', clo = o.cloak || '#3f4a52', trou = '#463c33', wrap = '#7b6a55', boot = '#2b1f17', skin = '#c99c78', hair = '#6a4a32';
  const poly = (pts, fill) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(x + p[0] * U, y + p[1] * U) : ctx.moveTo(x + p[0] * U, y + p[1] * U))); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); };
  const limb = (pts, w, col) => { ctx.strokeStyle = col; ctx.lineWidth = w * U; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(x + p[0] * U, y + p[1] * U) : ctx.moveTo(x + p[0] * U, y + p[1] * U))); ctx.stroke(); };
  ctx.save();
  ctx.fillStyle = 'rgba(10,8,6,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + 0.005 * U, 0.2 * U, 0.025 * U, 0, 0, TAU); ctx.fill();
  // capa (parte trasera, al viento)
  poly([[-0.13, -0.8], [-0.2 - 0.03 * sw, -0.62], [-0.27 - 0.06 * sw, -0.4], [-0.24 - 0.05 * sw2, -0.33], [-0.12, -0.36], [0.02, -0.4], [0.06, -0.78]], clo);
  // piernas: pantalón, vendas de lana (polainas) y botas
  limb([[-0.06, -0.5], [-0.075, -0.28], [-0.08, -0.05]], 0.075, trou); limb([[0.05, -0.5], [0.07, -0.28], [0.065, -0.05]], 0.08, trou);
  ctx.strokeStyle = wrap; ctx.lineWidth = 0.008 * U; for (const lx of [-0.078, 0.067]) for (let k = 0; k < 6; k++) { const yy = -0.24 + k * 0.032; ctx.beginPath(); ctx.moveTo(x + (lx - 0.035) * U, y + (yy + 0.012) * U); ctx.lineTo(x + (lx + 0.035) * U, y + yy * U); ctx.stroke(); }
  poly([[-0.12, -0.06], [-0.04, -0.06], [-0.03, 0], [-0.13, 0]], boot); poly([[0.03, -0.06], [0.11, -0.06], [0.14, 0], [0.03, 0]], boot);
  // túnica hasta la rodilla con cinturón
  const tg = ctx.createLinearGradient(x - 0.18 * U, 0, x + 0.18 * U, 0); tg.addColorStop(0, '#3e2a1d'); tg.addColorStop(0.6, tun); tg.addColorStop(1, '#8a6446'); poly([[-0.13, -0.8], [0.12, -0.8], [0.15, -0.6], [0.18, -0.37], [0.04, -0.35], [-0.17, -0.37], [-0.15, -0.6]], tg);
  ctx.strokeStyle = 'rgba(30,18,10,0.35)'; ctx.lineWidth = 0.006 * U; for (const fx of [-0.08, 0.0, 0.09]) { ctx.beginPath(); ctx.moveTo(x + fx * U, y - 0.53 * U); ctx.lineTo(x + (fx * 1.3) * U, y - 0.37 * U); ctx.stroke(); }
  poly([[-0.155, -0.56], [0.155, -0.56], [0.158, -0.525], [-0.158, -0.525]], '#2b1d13'); poly([[0.06, -0.565], [0.1, -0.565], [0.1, -0.52], [0.06, -0.52]], '#b08a3e');
  // brazo izquierdo (lejano) relajado
  limb([[-0.12, -0.77], [-0.16, -0.62], [-0.13, -0.49]], 0.06, '#5a3e2b'); ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(x - 0.13 * U, y - 0.475 * U, 0.025 * U, 0, TAU); ctx.fill();
  // capa sobre los hombros y broche
  poly([[-0.15, -0.81], [0.13, -0.82], [0.15, -0.74], [0.05, -0.7], [-0.16, -0.66]], clo); ctx.fillStyle = '#c9a24a'; ctx.beginPath(); ctx.arc(x + 0.11 * U, y - 0.77 * U, 0.018 * U, 0, TAU); ctx.fill(); ctx.strokeStyle = '#7a5a20'; ctx.lineWidth = 0.004 * U; ctx.stroke();
  // cabeza: cuello, nuca, oreja, mejilla y barba hacia la derecha; gorro de lana
  const hx = 0.01 + 0.015 * tn, hy = -0.905; poly([[-0.03, -0.83], [0.04, -0.83], [0.035, -0.87], [-0.025, -0.87]], '#a87e5e');
  ctx.fillStyle = hair; ctx.beginPath(); ctx.ellipse(x + hx * U, y + hy * U, 0.058 * U, 0.068 * U, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(x + (hx + 0.03) * U, y + (hy + 0.01) * U, 0.03 * U, 0.05 * U, 0.1, -Math.PI / 2, Math.PI / 2); ctx.fill();
  ctx.fillStyle = '#b5876a'; ctx.beginPath(); ctx.ellipse(x + (hx + 0.012) * U, y + (hy + 0.005) * U, 0.012 * U, 0.02 * U, 0, 0, TAU); ctx.fill();
  poly([[hx + 0.02, hy + 0.03], [hx + 0.07, hy + 0.025], [hx + 0.06, hy + 0.08], [hx + 0.02, hy + 0.07]], '#7a5536');
  ctx.fillStyle = '#5a4030'; ctx.beginPath(); ctx.ellipse(x + hx * U, y + (hy - 0.03) * U, 0.064 * U, 0.05 * U, 0, Math.PI, TAU); ctx.fill(); ctx.fillRect(x + (hx - 0.064) * U, y + (hy - 0.035) * U, 0.128 * U, 0.018 * U);
  // brazo derecho: de colgar a la mano sobre la frente (protege los ojos del sol)
  const el = [lerp(0.15, 0.22, lk), lerp(-0.62, -0.83, lk)], hd = [lerp(0.13, hx + 0.07, lk), lerp(-0.49, hy - 0.025, lk)];
  limb([[0.12, -0.77], el, hd], 0.058, '#5a3e2b'); ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(x + hd[0] * U, y + hd[1] * U, 0.035 * U, 0.017 * U, -0.25 * lk, 0, TAU); ctx.fill();
  // luz de contorno (sol a la derecha)
  if (rim > 0) { ctx.strokeStyle = `rgba(255,214,150,${0.55 * rim})`; ctx.lineWidth = 0.008 * U; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x + 0.13 * U, y - 0.8 * U); ctx.lineTo(x + 0.155 * U, y - 0.6 * U); ctx.lineTo(x + 0.18 * U, y - 0.38 * U); ctx.moveTo(x + (hx + 0.058) * U, y + (hy - 0.03) * U); ctx.lineTo(x + (hx + 0.06) * U, y + (hy + 0.03) * U); ctx.stroke(); }
  ctx.restore(); return { eye: [x + (hx + 0.06) * U, y + (hy - 0.005) * U], hand: [x + hd[0] * U, y + hd[1] * U] };
 };
 // Casa larga nórdica de madera y turba en vista 3/4. (x, y) = centro de la base del muro largo delantero (apoya en el suelo).
 // w = largo, d = fondo, h = alto del muro, o: { roof (alto del tejado), ruin (0 → 1 restos excavados), smoke (t), door (0..1 posición), seed, glow }
 P.longhouse = (ctx, x, y, w, d, h, t, o = {}) => {
  const rh = o.roof ?? h * 0.95, dx = d * 0.62, dy = -d * 0.34, ru = cl(o.ruin || 0), R = H.rng(o.seed || 3);
  const A = [x - w / 2, y], B = [x + w / 2, y], Cb = [x + w / 2 + dx, y + dy], Db = [x - w / 2 + dx, y + dy];
  const pg = (pts, f) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = f; ctx.fill(); };
  ctx.save();
  // sombra de contacto sobre el terreno
  ctx.fillStyle = 'rgba(20,30,18,0.35)'; pg([[A[0] - 8, A[1] + 4], [B[0] + 14, B[1] + 6], [Cb[0] + 22, Cb[1] + 4], [Db[0], Db[1]]], 'rgba(20,30,18,0.35)');
  if (ru < 1) { ctx.save(); ctx.globalAlpha *= 1 - ru;
   const turf = (pts, base, dark) => { pg(pts, base); ctx.save(); ctx.clip(); ctx.strokeStyle = dark; ctx.lineWidth = 2; const ys = Math.min(...pts.map((p) => p[1])), ye = Math.max(...pts.map((p) => p[1])), xs = Math.min(...pts.map((p) => p[0])), xe = Math.max(...pts.map((p) => p[0])); for (let yy = ys + 10, r = 0; yy < ye; yy += 16, r++) { for (let xx = xs + (r % 2) * 14; xx < xe; xx += 28) { ctx.beginPath(); ctx.moveTo(xx, yy + (r % 2 ? 7 : -7)); ctx.lineTo(xx + 14, yy - (r % 2 ? 7 : -7)); ctx.stroke(); } } ctx.restore(); };
   // muro del hastial (derecha), muro largo delantero
   turf([B, Cb, [Cb[0], Cb[1] - h], [B[0], B[1] - h]], '#5d4c33', 'rgba(35,25,14,0.45)');
   turf([A, B, [B[0], B[1] - h], [A[0], A[1] - h]], '#6e5a3c', 'rgba(35,25,14,0.5)');
   const sg = ctx.createLinearGradient(0, y - h, 0, y); sg.addColorStop(0, 'rgba(0,0,0,0)'); sg.addColorStop(1, 'rgba(20,14,8,0.35)'); pg([A, B, [B[0], B[1] - h], [A[0], A[1] - h]], sg);
   // tejado de turba con hierba: faldón delantero y extremo redondeado
   const ridgeL = [A[0] + dx * 0.5, A[1] + dy * 0.5 - h - rh], ridgeR = [B[0] + dx * 0.5, B[1] + dy * 0.5 - h - rh];
   const rg = ctx.createLinearGradient(0, ridgeL[1], 0, y - h); rg.addColorStop(0, '#7f9d5f'); rg.addColorStop(1, '#4d6a42');
   ctx.beginPath(); ctx.moveTo(A[0] - 10, A[1] - h + 6); ctx.quadraticCurveTo(A[0] - 6, ridgeL[1] + rh * 0.3, ridgeL[0], ridgeL[1]); ctx.lineTo(ridgeR[0], ridgeR[1]); ctx.quadraticCurveTo(B[0] + dx * 0.95 + 8, ridgeR[1] + rh * 0.35, Cb[0] + 10, Cb[1] - h + 4); ctx.lineTo(B[0] + 10, B[1] - h + 6); ctx.closePath(); ctx.fillStyle = rg; ctx.fill();
   ctx.fillStyle = 'rgba(40,58,34,0.45)'; pg([[B[0] + 10, B[1] - h + 6], [ridgeR[0], ridgeR[1]], [ridgeR[0] + 6, ridgeR[1] + 8], [Cb[0] + 10, Cb[1] - h + 4]], 'rgba(40,58,34,0.45)');
   ctx.strokeStyle = 'rgba(160,190,110,0.65)'; ctx.lineWidth = 2; for (let i = 0; i < Math.round(w / 6); i++) { const u = R(), v = R(), px = lerp(lerp(A[0], ridgeL[0], v), lerp(B[0], ridgeR[0], v), u), py = lerp(lerp(A[1] - h, ridgeL[1], v), lerp(B[1] - h, ridgeR[1], v), u); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + R.range(-4, 4), py - R.range(5, 11)); ctx.stroke(); }
   ctx.strokeStyle = 'rgba(40,55,30,0.6)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(A[0] - 10, A[1] - h + 6); ctx.lineTo(B[0] + 10, B[1] - h + 6); ctx.stroke();
   // puerta con marco de madera en el muro largo
   const dxp = lerp(A[0] + w * 0.15, B[0] - w * 0.15, o.door ?? 0.35), dw = Math.max(18, w * 0.09), dh = h * 0.82;
   ctx.fillStyle = '#4a2f1f'; ctx.fillRect(dxp - dw * 0.62, y - dh - h * 0.08, dw * 1.24, dh + h * 0.08); ctx.fillStyle = '#1e140d'; ctx.fillRect(dxp - dw / 2, y - dh, dw, dh); ctx.fillStyle = '#6b4a30'; ctx.fillRect(dxp - dw / 2, y - dh, dw * 0.45, dh); ctx.strokeStyle = 'rgba(30,18,10,0.6)'; ctx.lineWidth = 1.5; for (let k = 1; k < 3; k++) { ctx.beginPath(); ctx.moveTo(dxp - dw / 2 + dw * 0.15 * k, y - dh); ctx.lineTo(dxp - dw / 2 + dw * 0.15 * k, y); ctx.stroke(); }
   ctx.fillStyle = '#7a5a3a'; ctx.fillRect(dxp - dw * 0.7, y - 4, dw * 1.4, 6);
   if (o.smoke != null) { for (let i = 0; i < 6; i++) { const u = (t * 0.22 + i / 6) % 1, sx = lerp(ridgeL[0], ridgeR[0], 0.4); ctx.fillStyle = `rgba(225,230,232,${0.32 * (1 - u)})`; ctx.beginPath(); ctx.arc(sx + Math.sin(u * 5 + i) * 10 + u * 50, ridgeL[1] - 6 - u * h * 1.6, 7 + u * 24, 0, TAU); ctx.fill(); } }
   if (o.glow) { ctx.strokeStyle = `rgba(255,212,71,${o.glow})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(A[0] - 12, A[1] + 6); ctx.lineTo(B[0] + 12, B[1] + 6); ctx.lineTo(Cb[0] + 14, Cb[1]); ctx.stroke(); }
   ctx.restore(); }
  if (ru > 0) { ctx.save(); ctx.globalAlpha *= ru; // restos excavados: crestas bajas de turba que marcan los muros
   const k = 0.14, rid = (p, q) => { ctx.strokeStyle = '#4f6b3f'; ctx.lineWidth = Math.max(10, d * 0.16); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); ctx.strokeStyle = 'rgba(150,180,105,0.8)'; ctx.lineWidth = Math.max(4, d * 0.05); ctx.beginPath(); ctx.moveTo(p[0], p[1] - d * 0.05); ctx.lineTo(q[0], q[1] - d * 0.05); ctx.stroke(); };
   pg([A, B, Cb, Db], 'rgba(95,125,76,0.85)'); rid(Db, Cb); rid(A, Db); rid(B, Cb); rid(A, [lerp(A[0], B[0], 0.3), A[1]]); rid([lerp(A[0], B[0], 0.42), A[1]], B); rid([lerp(A[0], B[0], 0.55), lerp(A[1], Cb[1], 0.0)], [lerp(Db[0], Cb[0], 0.55), Db[1]]);
   if (o.glow) { ctx.strokeStyle = `rgba(255,212,71,${o.glow})`; ctx.lineWidth = 4; ctx.setLineDash([12, 8]); ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.lineTo(Cb[0], Cb[1]); ctx.lineTo(Db[0], Db[1]); ctx.closePath(); ctx.stroke(); ctx.setLineDash([]); }
   ctx.restore(); }
  ctx.restore(); return { door: [lerp(A[0] + w * 0.15, B[0] - w * 0.15, o.door ?? 0.35), y], top: [x + dx * 0.5, y + dy * 0.5 - h - rh], A, B, Cb, Db };
 };
 // Pieza de madera arqueológica (listón trabajado con borde de corteza y marcas de corte). o: { glowEnd, cuts }
 P.timber = (ctx, x, y, w, h, t, o = {}) => { ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot ?? -0.12);
  const g = ctx.createLinearGradient(0, -h / 2, 0, h / 2); g.addColorStop(0, '#9c7650'); g.addColorStop(0.5, '#7d5a3b'); g.addColorStop(1, '#4e3523'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-w / 2, -h * 0.45); ctx.lineTo(w / 2 - h * 0.2, -h / 2); ctx.lineTo(w / 2, h * 0.1); ctx.lineTo(w / 2 - h * 0.1, h / 2); ctx.lineTo(-w / 2 + h * 0.05, h * 0.48); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(45,28,15,0.4)'; ctx.lineWidth = 2; const R = H.rng(9); for (let i = 0; i < 9; i++) { const yy = -h * 0.4 + i * h * 0.1; ctx.beginPath(); ctx.moveTo(-w / 2 + 6, yy); for (let xx = -w / 2; xx < w / 2 - h * 0.2; xx += 30) ctx.lineTo(xx, yy + Math.sin(xx * 0.02 + i) * 3); ctx.stroke(); }
  ctx.fillStyle = '#3d2a1c'; ctx.fillRect(-w / 2, -h * 0.47, w * 0.85, h * 0.07); // borde de corteza (último anillo)
  ctx.strokeStyle = 'rgba(240,220,190,0.8)'; ctx.lineWidth = 3; for (const cx of o.cuts || [0.25, 0.32, 0.6]) { ctx.beginPath(); ctx.moveTo(-w / 2 + w * cx, -h * 0.3); ctx.lineTo(-w / 2 + w * cx + h * 0.25, h * 0.35); ctx.stroke(); }
  ctx.fillStyle = '#c49a68'; ctx.beginPath(); ctx.ellipse(-w / 2, 0, h * 0.18, h * 0.47, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(110,72,40,0.7)'; ctx.lineWidth = 1.5; for (let k = 1; k < 7; k++) { ctx.beginPath(); ctx.ellipse(-w / 2 + k * 0.6, h * 0.05, h * 0.18 * (1 - k / 8), h * 0.47 * (1 - k / 8), 0, 0, TAU); ctx.stroke(); }
  if (o.glowEnd) { ctx.strokeStyle = `rgba(255,212,71,${o.glowEnd})`; ctx.lineWidth = 5; ctx.beginPath(); ctx.ellipse(-w / 2, 0, h * 0.22, h * 0.52, 0, 0, TAU); ctx.stroke(); }
  ctx.restore(); return { end: [x - Math.cos(o.rot ?? -0.12) * w / 2, y - Math.sin(o.rot ?? -0.12) * w / 2] }; };
 // ================= v1.14 · MURALLAS, TIERRA APISONADA Y LOGÍSTICA (episodio «Gran Muralla») =================
 const sn = (x, s) => Math.sin(x * 0.0071 + s) * 0.5 + Math.sin(x * 0.0173 + s * 1.7) * 0.3 + Math.sin(x * 0.041 + s * 2.3) * 0.2;
 // Cordilleras por capas con crestas rocosas. o: { hor, sky:[arriba, horizonte], sun, sunA, layers, seed, arid (0..1), fogA, x0, x1, front:{y, amp},
 // part: 'back' (cielo y capas lejanas) | 'front' (solo la capa delantera) para dibujarlas con cámaras distintas (paralaje) }
 // Devuelve { ridge(x) } = altura (y) de la cresta delantera, para apoyar la muralla.
 // capa L de una cordillera: misma función para dibujar y para consultar la cresta (rugged 0..1: crestas rocosas y picos más marcados)
 const rangeLayer = (o, L) => { const hor = o.hor ?? 900, ar = o.arid || 0, seed = o.seed ?? 3, nL = o.layers ?? 5, fr = o.front || {}, rg = o.rugged || 0; const u = L / (nL - 1), base = lerp(hor - 60, fr.y ?? hor + 380, u), amp = lerp(140, fr.amp ?? 420, u) * (1 - ar * 0.35), s = seed + L * 3.1, sc = lerp(0.6, 1.25, u);
  const yAt = (x) => base - amp * (0.55 + 0.45 * sn(x / sc, s)) + amp * 0.18 * Math.abs(Math.sin(x * 0.011 / sc + s)) - rg * (amp * 0.2 * Math.pow(1 - Math.abs(Math.sin(x * 0.0042 / sc + s * 0.7)), 4) - (3 * Math.sin(x * 0.071 + s) + 1.6 * Math.sin(x * 0.19 + s * 2.1) + 0.8 * Math.sin(x * 0.43 + s)) * (0.4 + 0.6 * u));
  return { u, base, amp, yAt }; };
 P.rangeRidge = (o) => rangeLayer(o, (o.layers ?? 5) - 1).yAt;
 P.ranges = (ctx, t, o = {}) => {
  const hor = o.hor ?? 900, x0 = o.x0 ?? -800, x1 = o.x1 ?? W + 800, ar = o.arid || 0, seed = o.seed ?? 3, nL = o.layers ?? 5;
  const part = o.part; if (part !== 'front') { const sky = o.sky || ['#6f97ad', '#d7d6c4']; const g = ctx.createLinearGradient(0, hor - 1500, 0, hor); g.addColorStop(0, sky[0]); g.addColorStop(1, sky[1]); ctx.fillStyle = g; ctx.fillRect(x0, hor - 3000, x1 - x0, 3000 + 2400);
  if (o.sun) { P.glow(ctx, o.sun[0], o.sun[1], 520, '255,226,180', 0.5 * (o.sunA ?? 1)); P.glow(ctx, o.sun[0], o.sun[1], 110, '255,244,220', 0.95 * (o.sunA ?? 1)); } }
  const mix = (a, b, u) => { const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16), c = (s) => Math.round(lerp((pa >> s) & 255, (pb >> s) & 255, u)); return '#' + ((1 << 24) + (c(16) << 16) + (c(8) << 8) + c(0)).toString(16).slice(1); };
  const far = mix(o.farC || '#8fa6a8', '#c9b48e', ar), near = mix(o.nearC || '#425A39', '#8a6a45', ar), fr = o.front || {};
  let ridge = null;
  for (let L = 0; L < nL; L++) { const { u, base, amp, yAt } = rangeLayer(o, L), s = seed + L * 3.1;
   if ((part === 'back' && L === nL - 1) || (part === 'front' && L < nL - 1)) { if (L === nL - 1) ridge = yAt; continue; }
   ctx.beginPath(); ctx.moveTo(x0, HH + 1600); for (let x = x0; x <= x1; x += 12) ctx.lineTo(x, yAt(x)); ctx.lineTo(x1, HH + 1600); ctx.closePath();
   const lg = ctx.createLinearGradient(0, base - amp, 0, base + 400); lg.addColorStop(0, mix(far, near, u * 0.9 + 0.05)); lg.addColorStop(1, mix(far, near, Math.min(1, u * 1.1 + 0.2))); ctx.fillStyle = lg; ctx.fill();
   // luz en las laderas que miran al sol y vetas de roca
   ctx.save(); ctx.clip(); { const sunR = !(o.sun && o.sun[0] < 540); for (let x = x0 + 30; x <= x1 - 30; x += 18) { const y = yAt(x); if (!(y < yAt(x - 30) && y <= yAt(x + 30))) continue; const len = (base + 420 - y) * (0.8 + 0.4 * u), sp = 90 * (0.5 + u);
     const lit = ctx.createLinearGradient(x, y, x + (sunR ? sp : -sp), y + len); lit.addColorStop(0, `rgba(255,236,200,${0.1 + 0.06 * u})`); lit.addColorStop(1, 'rgba(255,236,200,0)'); ctx.fillStyle = lit; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (sunR ? sp * 1.4 : -sp * 1.4), y + len); ctx.lineTo(x + (sunR ? sp * 0.2 : -sp * 0.2), y + len); ctx.closePath(); ctx.fill();
     const dk = ctx.createLinearGradient(x, y, x - (sunR ? sp : -sp), y + len); dk.addColorStop(0, `rgba(20,30,20,${0.12 + 0.06 * u})`); dk.addColorStop(1, 'rgba(20,30,20,0)'); ctx.fillStyle = dk; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (sunR ? sp * 0.2 : -sp * 0.2), y + len); ctx.lineTo(x - (sunR ? sp * 1.2 : -sp * 1.2), y + len); ctx.closePath(); ctx.fill(); } }
   ctx.strokeStyle = `rgba(255,240,215,${0.15 + 0.2 * u})`; ctx.lineWidth = 1.5 + 2 * u; ctx.beginPath(); for (let x = x0; x <= x1; x += 12) (x === x0 ? ctx.moveTo(x, yAt(x) + 2) : ctx.lineTo(x, yAt(x) + 2)); ctx.stroke();
   if (u > 0.5) { const R = H.rng(seed + L); ctx.fillStyle = ar > 0.5 ? 'rgba(120,90,60,0.5)' : 'rgba(40,60,36,0.6)'; for (let i = 0; i < 160 * u; i++) { const x = R.range(x0, x1), y = yAt(x) + R.range(10, 600); ctx.beginPath(); ctx.arc(x, y, R.range(3, 9) * u, 0, TAU); ctx.fill(); } }
   ctx.restore();
   if (L < nL - 1 && (o.fogA ?? 0.6) > 0) { const fg = ctx.createLinearGradient(0, base - amp * 0.2, 0, base + 160); fg.addColorStop(0, 'rgba(216,217,201,0)'); fg.addColorStop(1, `rgba(216,217,201,${0.55 * (o.fogA ?? 0.6)})`); ctx.fillStyle = fg; ctx.fillRect(x0, base - amp * 0.2, x1 - x0, 400); }
   if (L === nL - 1) ridge = yAt; }
  return { ridge };
 };
 // ================= v1.14.1 · revisión maestra «Gran Muralla»: figuras, muralla con volumen, torres y cortes =================
 // IK de dos segmentos: devuelve el codo/rodilla entre a (origen) y t (objetivo) con longitudes l1, l2; side = ±1 elige el lado del pliegue
 const ik2 = (a, t, l1, l2, side) => { let dx = t[0] - a[0], dy = t[1] - a[1], d = Math.hypot(dx, dy); const dm = Math.min(Math.max(d, 1e-3), l1 + l2 - 1e-3); if (d > dm) { t = [a[0] + dx / d * dm, a[1] + dy / d * dm]; dx = t[0] - a[0]; dy = t[1] - a[1]; d = dm; } const ca = cl((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1), ang = Math.atan2(dy, dx) + side * Math.acos(ca); return [[a[0] + Math.cos(ang) * l1, a[1] + Math.sin(ang) * l1], t]; };
 const FIG_TUNIC = ['#6b5a46', '#4f5d58', '#7a5a3a', '#5b4a5e', '#857055', '#3f4d5a', '#6e4b3a', '#55603f'], FIG_SKIN = ['#b98a62', '#a87a55', '#c49a72', '#9c6f4c'];
 // Persona estilizada con proporciones (cabeza, torso, brazos y piernas articulados), ropa de trabajo (túnica cruzada con faja,
 // pantalón, calzado de tela) y sombrero o pañuelo variados. (x, y) = suelo bajo los pies: la figura se ajusta para que el pie más bajo
 // toque y. pose: 'walk' | 'stand' | 'carry' (pértiga al hombro) | 'ram' (pisón con las dos manos; o.lift 0..1) | 'chisel' | 'look' | 'lead'.
 // ph = fase de la marcha (usar distancia recorrida / zancada para que no patine). o: { var, dir, lift, target, scale }
 P.figure = (ctx, x, y, h, ph = 0, o = {}) => {
  const pose = o.pose || 'walk', v = o.var ?? 0, d = o.dir ?? 1, LT = h * 0.245, LS = h * 0.24, LU = h * 0.17, LF = h * 0.165, f = ph * TAU, lift = cl(o.lift ?? 0);
  const tun = FIG_TUNIC[v % FIG_TUNIC.length], tunD = '#2f2a24', trou = ['#3d3a35', '#4a4136', '#2f3538'][v % 3], sash = ['#a4473a', '#2f4a5e', '#8a7a4a', '#5a3d5a'][v % 4], skin = FIG_SKIN[v % FIG_SKIN.length];
  // piernas (ángulos desde la vertical; la rodilla se dobla hacia atrás)
  let legs; if (pose === 'walk' || pose === 'carry' || pose === 'lead') legs = [0, Math.PI].map((o2) => { const a = Math.sin(f + o2) * 0.42; return [a, 0.1 + 0.55 * Math.max(0, Math.sin(f + o2 + 1.9))]; });
  else if (pose === 'ram') legs = [[0.16, 0.12 + 0.12 * (1 - lift)], [-0.12, 0.12 + 0.12 * (1 - lift)]]; else if (pose === 'chisel') legs = [[0.3, 0.9], [-0.25, 0.25]]; else legs = [[0.05, 0.03], [-0.05, 0.03]];
  const hip0 = [0, 0], knees = [], ankles = [], toes = []; legs.forEach(([a, k]) => { const kn = [Math.sin(a) * LT, Math.cos(a) * LT], an = [kn[0] + Math.sin(a - k) * LS, kn[1] + Math.cos(a - k) * LS]; knees.push(kn); ankles.push(an); toes.push([an[0] + h * 0.07, an[1] + h * 0.012]); });
  const low = Math.max(ankles[0][1], ankles[1][1]) + h * 0.03, P_ = (p) => [x + d * p[0], y - low + p[1]]; // pie más bajo en el suelo
  const lean = pose === 'carry' ? 0.07 : pose === 'ram' ? 0.12 + 0.12 * (1 - lift) : pose === 'chisel' ? 0.55 : pose === 'walk' ? 0.05 : 0.02;
  const S = [Math.sin(lean) * h * 0.3, -Math.cos(lean) * h * 0.3], Hd = [S[0] + Math.sin(lean) * h * 0.11, S[1] - Math.cos(lean) * h * 0.115];
  // objetivos de las manos
  let tf, tb; if (pose === 'walk' || pose === 'lead') { tf = [S[0] + Math.sin(-f) * h * 0.13, S[1] + h * 0.29]; tb = [S[0] + Math.sin(-f + Math.PI) * h * 0.13, S[1] + h * 0.29]; if (pose === 'lead') tf = [S[0] + h * 0.28, S[1] + h * 0.12]; }
  else if (pose === 'carry') { tf = [S[0] + h * 0.15, S[1] + h * 0.02]; tb = [S[0] + Math.sin(-f + Math.PI) * h * 0.12, S[1] + h * 0.28]; }
  else if (pose === 'ram') { const px = h * 0.22, pb = low - lift * h * 0.24; tf = [px, pb - h * 0.5]; tb = [px, pb - h * 0.68]; }
  else if (pose === 'chisel') { tf = o.target ? [(o.target[0] - x) * d, o.target[1] - y + low] : [S[0] + h * 0.3, S[1] + h * 0.42]; tb = [S[0] + h * 0.18, S[1] + h * (0.12 + 0.14 * Math.abs(Math.sin(f * 2)))]; }
  else if (pose === 'look') { tf = [Hd[0] + h * 0.07, Hd[1] - h * 0.02]; tb = [S[0] - h * 0.02, S[1] + h * 0.3]; } else { tf = [S[0] + h * 0.03, S[1] + h * 0.31]; tb = [S[0] - h * 0.03, S[1] + h * 0.31]; }
  const [ef, hf] = ik2(S, tf, LU, LF, d > 0 ? 1 : 1), [eb, hb] = ik2(S, tb, LU, LF, 1);
  const L = (pts, w, c) => { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); pts.forEach((p, i) => { const q = P_(p); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.stroke(); };
  ctx.save();
  const g0 = P_([0, low]); ctx.fillStyle = 'rgba(20,18,14,0.3)'; ctx.beginPath(); ctx.ellipse(g0[0], y + 2, h * 0.16, h * 0.025, 0, 0, TAU); ctx.fill(); // sombra de contacto
  // pierna y brazo traseros (más oscuros)
  L([hip0, knees[1], ankles[1]], h * 0.075, '#262320'); L([ankles[1], toes[1]], h * 0.05, '#1f1b17');
  L([S, eb, hb], h * 0.062, '#3a3229'); { const q = P_(hb); ctx.fillStyle = '#8a6a50'; ctx.beginPath(); ctx.arc(q[0], q[1], h * 0.026, 0, TAU); ctx.fill(); }
  // pierna delantera (pantalón y calzado)
  L([hip0, knees[0], ankles[0]], h * 0.08, trou); L([ankles[0], toes[0]], h * 0.055, '#241f1a');
  // túnica cruzada hasta medio muslo con faja
  const tp = [[S[0] - h * 0.075, S[1] + h * 0.01], [S[0] + h * 0.07, S[1] + h * 0.01], [h * 0.1, h * 0.03], [h * 0.12, h * 0.16], [-h * 0.11, h * 0.16], [-h * 0.085, h * 0.02]];
  ctx.fillStyle = tun; ctx.beginPath(); tp.forEach((p, i) => { const q = P_(p); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath(); ctx.fill();
  { const a = P_([S[0] + h * 0.05, S[1] + h * 0.02]), b = P_([h * 0.02, -h * 0.02]); ctx.strokeStyle = tunD; ctx.lineWidth = h * 0.012; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  { const a = P_([-h * 0.095, -h * 0.01]), b = P_([h * 0.105, -h * 0.01]); ctx.strokeStyle = sash; ctx.lineWidth = h * 0.035; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  // cuello, cabeza (perfil con nariz) y cabello
  L([[S[0], S[1] + h * 0.01], [lerp(S[0], Hd[0], 0.6), lerp(S[1], Hd[1], 0.6)]], h * 0.045, skin);
  const hq = P_(Hd), hr = h * 0.066; ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(hq[0], hq[1], hr, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(hq[0] + d * hr * 0.9, hq[1] - hr * 0.1); ctx.lineTo(hq[0] + d * hr * 1.22, hq[1] + hr * 0.18); ctx.lineTo(hq[0] + d * hr * 0.85, hq[1] + hr * 0.3); ctx.fill();
  ctx.fillStyle = '#1f1a16'; ctx.beginPath(); ctx.arc(hq[0] - d * hr * 0.15, hq[1] - hr * 0.15, hr * 0.95, Math.PI * (d > 0 ? 0.55 : -0.55) + Math.PI, Math.PI * (d > 0 ? 1.95 : 0.05) + Math.PI * (d > 0 ? 0 : 1)); ctx.fill();
  const hat = v % 4; if (hat === 0) { ctx.fillStyle = '#c9b07a'; ctx.beginPath(); ctx.moveTo(hq[0] - hr * 2.1, hq[1] - hr * 0.35); ctx.lineTo(hq[0], hq[1] - hr * 1.55); ctx.lineTo(hq[0] + hr * 2.1, hq[1] - hr * 0.35); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(90,70,40,0.6)'; ctx.lineWidth = 1.2; ctx.stroke(); }
  else if (hat === 1) { ctx.fillStyle = ['#d8cfb8', '#5a4a3a', '#7a8a8a'][v % 3]; ctx.beginPath(); ctx.ellipse(hq[0] - d * hr * 0.1, hq[1] - hr * 0.55, hr * 1.02, hr * 0.55, 0, Math.PI, TAU); ctx.fill(); ctx.fillRect(hq[0] - hr, hq[1] - hr * 0.62, hr * 2, hr * 0.3); }
  else if (hat === 2) { ctx.fillStyle = '#1f1a16'; ctx.beginPath(); ctx.arc(hq[0] - d * hr * 0.1, hq[1] - hr * 1.05, hr * 0.38, 0, TAU); ctx.fill(); }
  else { ctx.fillStyle = '#3d3a35'; ctx.beginPath(); ctx.ellipse(hq[0] - d * hr * 0.05, hq[1] - hr * 0.6, hr * 0.9, hr * 0.45, 0, Math.PI, TAU); ctx.fill(); }
  // brazo delantero (manga) y mano
  L([S, ef, hf], h * 0.065, tun); { const q = P_(hf); ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(q[0], q[1], h * 0.028, 0, TAU); ctx.fill(); }
  ctx.restore();
  return { hf: P_(hf), hb: P_(hb), head: hq, sh: P_(S), feet: [P_(ankles[0]), P_(ankles[1])], low };
 };
 // laborer y porter (v1.14) pasan a usar la figura proporcionada (misma firma)
 P.laborer = (ctx, x, y, h, ph, o = {}) => { const pm = { walk: 'walk', chisel: 'chisel', stand: 'stand', pull: 'lead', look: 'look' }; const r = P.figure(ctx, x, y, h, ph, { pose: pm[o.pose || 'walk'] || 'walk', var: o.var, dir: o.dir, target: o.target });
  if ((o.pose || 'walk') === 'chisel') { ctx.save(); ctx.strokeStyle = '#4a3a2a'; ctx.lineWidth = h * 0.02; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(r.hb[0], r.hb[1]); ctx.lineTo(r.hb[0] + (o.dir ?? 1) * h * 0.04, r.hb[1] - h * 0.1); ctx.stroke(); ctx.fillStyle = '#5b5b58'; ctx.fillRect(r.hb[0] + (o.dir ?? 1) * h * 0.02 - h * 0.035, r.hb[1] - h * 0.13, h * 0.07, h * 0.04); ctx.strokeStyle = '#8a8f8a'; ctx.lineWidth = h * 0.015; ctx.beginPath(); ctx.moveTo(r.hf[0], r.hf[1]); ctx.lineTo(r.hf[0] + (o.dir ?? 1) * h * 0.02, r.hf[1] + h * 0.07); ctx.stroke(); ctx.restore(); }
  return r.hf; };
 P.porter = (ctx, x, y, h, ph, o = {}) => { const d = o.dir ?? 1, r = P.figure(ctx, x, y, h, ph, { pose: 'carry', var: o.var, dir: d }), sh = [r.sh[0], r.sh[1] - h * 0.02], bob = Math.sin(ph * TAU * 2) * h * 0.012;
  ctx.save(); ctx.strokeStyle = '#6b4a2e'; ctx.lineWidth = h * 0.028; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(sh[0] - h * 0.4, sh[1] + h * 0.035 + bob); ctx.quadraticCurveTo(sh[0], sh[1] - h * 0.025 + bob, sh[0] + h * 0.4, sh[1] + h * 0.035 + bob); ctx.stroke();
  for (const sd of [-1, 1]) { const bx = sh[0] + sd * h * 0.38, by = Math.min(y - h * 0.08, sh[1] + h * 0.36 + bob + Math.sin(ph * TAU * 2 + sd) * h * 0.01); ctx.strokeStyle = 'rgba(80,60,40,0.9)'; ctx.lineWidth = h * 0.008; ctx.beginPath(); ctx.moveTo(bx - h * 0.07, by - h * 0.06); ctx.lineTo(bx, sh[1] + h * 0.035 + bob); ctx.lineTo(bx + h * 0.07, by - h * 0.06); ctx.stroke(); ctx.fillStyle = '#9a7b4f'; ctx.beginPath(); ctx.moveTo(bx - h * 0.09, by - h * 0.06); ctx.lineTo(bx + h * 0.09, by - h * 0.06); ctx.lineTo(bx + h * 0.07, by + h * 0.06); ctx.lineTo(bx - h * 0.07, by + h * 0.06); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(70,50,30,0.5)'; ctx.lineWidth = 1; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(bx - h * 0.085, by - h * 0.03 + k * h * 0.03); ctx.lineTo(bx + h * 0.08, by - h * 0.03 + k * h * 0.03); ctx.stroke(); }
   if (o.load === 'piedra') { ctx.fillStyle = '#8f958e'; ctx.beginPath(); ctx.ellipse(bx - h * 0.025, by - h * 0.075, h * 0.045, h * 0.03, 0.2, 0, TAU); ctx.ellipse(bx + h * 0.035, by - h * 0.07, h * 0.04, h * 0.028, -0.2, 0, TAU); ctx.fill(); } else if (o.load === 'ladrillos') { ctx.fillStyle = '#a45c42'; ctx.fillRect(bx - h * 0.08, by - h * 0.1, h * 0.075, h * 0.035); ctx.fillRect(bx + h * 0.005, by - h * 0.1, h * 0.075, h * 0.035); ctx.fillStyle = '#93503a'; ctx.fillRect(bx - h * 0.045, by - h * 0.13, h * 0.075, h * 0.033); } else { ctx.fillStyle = '#8a6440'; ctx.beginPath(); ctx.ellipse(bx, by - h * 0.065, h * 0.085, h * 0.032, 0, Math.PI, TAU); ctx.fill(); } }
  ctx.restore(); };
 // ================= v1.14.2 · SISTEMA ÚNICO TERRENO + MURALLA + TORRES (corrección geométrica definitiva) =================
 // Proyección oblicua común: un punto de planta (X, profundidad d) se dibuja en (X + d·Dx, y + d·Dy), con D hacia arriba a la derecha.
 // El terreno a profundidad d se aproxima como gy(X) + d·Dy (el plano de la cresta inclinado con la profundidad).
 // Picos de una cresta (para colocar torres en los puntos altos), con separación mínima
 P.ridgePeaks = (gy, xa, xb, gap = 260) => { const sm2 = (x) => { let s = 0; for (let k = -3; k <= 3; k++) s += gy(x + k * 14); return s / 7; }; const c = []; for (let x = xa; x <= xb; x += 8) { const y = sm2(x); if (y <= sm2(x - 40) && y <= sm2(x + 40)) c.push([x, y]); } c.sort((a, b) => a[1] - b[1]); const out = []; for (const [x] of c) if (out.every((q) => Math.abs(q - x) >= gap)) out.push(x); return out.sort((a, b) => a - b); };
 const WS_COL = {
  ladrillo: { f: '#9c7764', fd: '#6e5242', s: '#b8a08b', sd: '#5f4636', t: '#c9b39e', pl: '#a3a69b', pld: '#6f736b', m: '#8d6b59' },
  piedra: { f: '#a4aaa0', fd: '#70766e', s: '#c2c6bc', sd: '#62695f', t: '#ccd0c6', pl: '#959b92', pld: '#626860', m: '#8e948b' },
  tierra: { f: '#b08758', fd: '#7d5a3a', s: '#c99f70', sd: '#6e4e33', t: '#d3ab7c', pl: '#9a7650', pld: '#6e4e33', m: '#a07a50' },
 };
 const quadP = (ctx, pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
 // Torre en la proyección común. T: { x, F (nivel del adarve en el plano frontal del muro), smoke, fire, pavilion }
 function wsTower(ctx, gy, T, g, t) {
  const { D, tw, tdp, pro, thH, h, st, sunL, ru } = g, C0 = WS_COL[st], dx0 = -pro * D[0], dy0 = -pro * D[1];
  const xl = T.x - tw / 2, xr = T.x + tw / 2, fl = xl + dx0, fr = xr + dx0, top = T.F + dy0 - thH * (1 - ru * 0.4), taper = st === 'tierra' ? tw * 0.12 : 0;
  const gF = (sx) => gy(sx - dx0) + dy0 + 4, gS = (d) => gy(xr) + d * D[1] + 4; // suelo bajo la cara frontal / lateral
  const cS = sunL ? C0.sd : C0.s, cF = sunL ? C0.f : C0.fd;
  // sombra proyectada de la torre sobre la ladera
  const Sx = (sunL ? 1 : -1) * h * 1.5; ctx.save(); ctx.globalAlpha *= 0.22; quadP(ctx, [[fl, gF(fl)], [fr, gF(fr)], [fr + Sx, gF(fr) + h * 0.45], [fl + Sx, gF(fl) + h * 0.45]], '#0e140c'); ctx.restore();
  // cara lateral derecha (de -pro a tdp-pro de profundidad); base sobre el terreno
  const sideTop0 = [fr - taper, top], sideTop1 = [fr - taper + tdp * D[0], top + tdp * D[1]];
  const sp = [sideTop0, sideTop1]; const nB = 8; for (let k = nB; k >= 0; k--) { const d = -pro + tdp * k / nB; sp.push([xr + d * D[0], gS(d)]); } ctx.beginPath(); sp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); const sg = ctx.createLinearGradient(0, top, 0, gS(0)); sg.addColorStop(0, cS); sg.addColorStop(1, C0.sd); ctx.fillStyle = sg; ctx.fill();
  // cara frontal: cuerpo (sobre el adarve) + zócalo de piedra hasta el terreno
  const fp = [[fl + taper, top], [fr - taper, top]]; for (let k = 0; k <= 10; k++) { const sx = fr - (fr - fl) * k / 10; fp.push([sx, gF(sx)]); } ctx.beginPath(); fp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); const fg = ctx.createLinearGradient(0, top, 0, T.F + dy0 + h); fg.addColorStop(0, C0.f); fg.addColorStop(1, cF); ctx.fillStyle = fg; ctx.fill();
  ctx.save(); ctx.clip(); const plTop = T.F + dy0 + h * 0.05; if (st === 'ladrillo') { ctx.fillStyle = C0.pl; ctx.fillRect(fl - 4, plTop, fr - fl + 8, 2000); ctx.strokeStyle = 'rgba(40,44,40,0.35)'; ctx.lineWidth = 1.2; for (let y = plTop + h * 0.22; y < plTop + 600; y += h * 0.22) { ctx.beginPath(); ctx.moveTo(fl, y); ctx.lineTo(fr, y); ctx.stroke(); for (let x = fl + ((y / (h * 0.22)) % 2) * h * 0.25; x < fr; x += h * 0.5) { ctx.beginPath(); ctx.moveTo(x, y - h * 0.22); ctx.lineTo(x, y); ctx.stroke(); } } }
   ctx.strokeStyle = 'rgba(45,32,24,0.28)'; ctx.lineWidth = 1; const ch = st === 'tierra' ? h * 0.2 : h * 0.09; for (let y = top + ch; y < plTop; y += ch) { ctx.beginPath(); ctx.moveTo(fl, y); ctx.lineTo(fr, y); ctx.stroke(); }
   const ao = ctx.createLinearGradient(0, top, 0, top + h * 0.25); ao.addColorStop(0, 'rgba(0,0,0,0.12)'); ao.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = ao; ctx.fillRect(fl, top, fr - fl, h * 0.25);
   const bo = ctx.createLinearGradient(0, gF(T.x) - h * 0.4, 0, gF(T.x)); bo.addColorStop(0, 'rgba(0,0,0,0)'); bo.addColorStop(1, 'rgba(10,12,8,0.35)'); ctx.fillStyle = bo; ctx.fillRect(fl - 4, gF(T.x) - h * 0.6, fr - fl + 8, h * 1.2); ctx.restore();
  // arista iluminada
  ctx.strokeStyle = sunL ? 'rgba(255,238,210,0.5)' : 'rgba(255,238,210,0.35)'; ctx.lineWidth = Math.max(1.5, h * 0.03); ctx.beginPath(); ctx.moveTo(sunL ? fl + taper : fr - taper, top); ctx.lineTo(sunL ? fl : fr, gF(sunL ? fl : fr)); ctx.stroke();
  // azotea
  quadP(ctx, [[fl + taper, top], [fr - taper, top], sideTop1, [fl + taper + tdp * D[0], top + tdp * D[1]]], C0.t);
  if (st !== 'tierra') {
   // ventanas arqueadas (frontal) y puerta al nivel del adarve en la cara lateral, donde entra el tramo de la derecha
   const arch = (pts, c) => quadP(ctx, pts, c), aw = tw * 0.12, ah = thH * 0.32, wy = top + thH * 0.32;
   for (const fx of [-0.28, 0, 0.28]) { const cx = (fl + fr) / 2 + fx * tw; const p = [[cx - aw / 2, wy + ah / 2], [cx - aw / 2, wy - ah / 2 + aw / 2]]; for (let k = 0; k <= 8; k++) { const a = Math.PI + Math.PI * k / 8; p.push([cx + Math.cos(a) * aw / 2, wy - ah / 2 + aw / 2 + Math.sin(a) * aw / 2]); } p.push([cx + aw / 2, wy + ah / 2]); arch(p, '#241a14'); }
   if (ru < 0.7) { const SP = (d, z) => [xr + d * D[0], T.F + d * D[1] - z]; const d0 = 0.28, d1 = 0.72, dz = h * 0.62; const p = [SP(d0, 0), SP(d0, dz * 0.7)]; for (let k = 0; k <= 8; k++) { const u = k / 8, d = lerp(d0, d1, u); p.push(SP(d, dz * 0.7 + Math.sin(u * Math.PI) * dz * 0.3)); } p.push(SP(d1, 0)); quadP(ctx, p, '#1b130e'); }
   // almenas con volumen en los bordes frontal y lateral de la azotea
   if (ru < 0.5) { const mw = tw / 9, mh = h * 0.24, dd = [D[0] * 0.14, D[1] * 0.14]; const merl = (x0, y0) => { quadP(ctx, [[x0 + mw, y0], [x0 + mw + dd[0], y0 + dd[1]], [x0 + mw + dd[0], y0 - mh + dd[1]], [x0 + mw, y0 - mh]], cS); quadP(ctx, [[x0, y0 - mh], [x0 + mw, y0 - mh], [x0 + mw + dd[0], y0 - mh + dd[1]], [x0 + dd[0], y0 - mh + dd[1]]], C0.t); quadP(ctx, [[x0, y0], [x0 + mw, y0], [x0 + mw, y0 - mh], [x0, y0 - mh]], C0.m); };
    for (let k = 1; k <= 3; k++) { const u = k / 4; merl(fr - mw + tdp * D[0] * u, top + tdp * D[1] * u); }
    for (let i = 0; i < 5; i++) merl(fl + i * mw * 2, top); }
   if (T.pavilion && ru < 0.3) { const cx = (fl + fr) / 2 + tdp * D[0] * 0.5, cy = top + tdp * D[1] * 0.5, pw = tw * 0.55, ph = thH * 0.32; quadP(ctx, [[cx - pw / 2, cy], [cx + pw / 2, cy], [cx + pw / 2, cy - ph], [cx - pw / 2, cy - ph]], '#7a3a2e'); ctx.fillStyle = '#3f4a46'; ctx.beginPath(); ctx.moveTo(cx - pw * 0.8, cy - ph + 4); ctx.quadraticCurveTo(cx - pw * 0.5, cy - ph - 6, cx - pw * 0.3, cy - ph - thH * 0.24); ctx.lineTo(cx + pw * 0.3, cy - ph - thH * 0.24); ctx.quadraticCurveTo(cx + pw * 0.5, cy - ph - 6, cx + pw * 0.8, cy - ph + 4); ctx.closePath(); ctx.fill(); }
  }
  const roof = [(fl + fr) / 2 + tdp * D[0] * 0.5, top + tdp * D[1] * 0.5];
  const sm3 = T.smoke || 0; if (sm3 > 0) { for (let i = 0; i < 16; i++) { const u = (t * 0.32 + i / 16) % 1, a = sm3 * (1 - u) * 0.8 * cl(u * 6); ctx.fillStyle = `rgba(72,68,64,${a})`; ctx.beginPath(); ctx.arc(roof[0] + Math.sin(u * 4 + i) * h * 0.25 + u * h, roof[1] - h * 0.2 - u * h * 6 * cl(sm3 * 1.5), h * (0.18 + u * 0.8), 0, TAU); ctx.fill(); } }
  const fi = T.fire || 0; if (fi > 0) { P.glow(ctx, roof[0], roof[1] - h * 0.2, h * 2.4, '255,170,60', 0.6 * fi); for (let i = 0; i < 6; i++) { const u = (t * 2 + i / 6) % 1; ctx.fillStyle = `rgba(255,${180 - u * 120},40,${fi * (1 - u)})`; ctx.beginPath(); ctx.ellipse(roof[0] + Math.sin(t * 9 + i) * h * 0.12, roof[1] - h * 0.2 - u * h * 0.9, h * 0.18 * (1 - u * 0.6), h * 0.36 * (1 - u * 0.4), 0, 0, TAU); ctx.fill(); } }
  return { x: T.x, top: [roof[0], top], roof, door: [xr + 0.5 * D[0], T.F + 0.5 * D[1]], F: T.F };
 }
 // Sistema de muralla sobre el terreno gy(x) entre xa y xb. o: { style, h, thick, build (0..1), towersX:[x…], towerSmoke:[…], towerFire:[…],
 // pavilionX:[x…], ruin, sunLeft, crenel, glow }. Devuelve { towers:[{x, top, roof, door, F}], walk(x) }
 P.wallSystem = (ctx, gy, xa, xb, t, o = {}) => {
  const st = o.style || 'ladrillo', C0 = WS_COL[st], h = o.h ?? 48, th0 = o.thick ?? h * 0.8, D = [th0 * 0.6, -th0 * 0.48], ru = cl(o.ruin || 0), sunL = !!o.sunLeft;
  const xe = lerp(xa, xb, cl(o.build ?? 1)), g = { D, tw: o.towerW ?? h * 1.8, tdp: 1.5, pro: 0.25, thH: o.towerH ?? h * 1.4, h, st, sunL, ru };
  const crest = (x) => { let s = 0; for (let k = -2; k <= 2; k++) s += gy(x + k * 10); return s / 5; }, floor = (x) => crest(x) - h * 0.92;
  const TX = (o.towersX || []).filter((x) => x > xa + g.tw * 0.6 && x < xb - g.tw * 0.6).sort((a, b) => a - b);
  const towers = TX.map((x, i) => ({ x, F: floor(x), smoke: (o.towerSmoke || [])[(o.towersX || []).indexOf(x)] || 0, fire: (o.towerFire || [])[(o.towersX || []).indexOf(x)] || 0, pavilion: (o.pavilionX || []).some((p) => Math.abs(p - x) < g.tw) }));
  // tramos entre torres (cada tramo termina en las caras de las torres)
  const segs = []; let a = xa, Fa = null; towers.forEach((T) => { segs.push({ a, b: T.x - g.tw / 2, Fa, Fb: T.F }); a = T.x + g.tw / 2; Fa = T.F; }); segs.push({ a, b: xb, Fa, Fb: null });
  // perfil del adarve: rampa si la pendiente es suave; escalones si es fuerte; enlazado al nivel de las torres
  const profile = (sg) => { const { a: x0, b: x1 } = sg, fa = sg.Fa ?? floor(x0), fb = sg.Fb ?? floor(x1), corr = (x) => lerp(fa - floor(x0), fb - floor(x1), cl((x - x0) / Math.max(1, x1 - x0))), slope = Math.abs(fb - fa) / Math.max(1, x1 - x0), pts = [];
   const er = (x) => ru * h * 0.45 * (0.5 + 0.5 * Math.sin(x * 0.045)) + (st === 'tierra' ? h * 0.06 * Math.sin(x * 0.11) : 0);
   // por tramos de la longitud de un escalón: pendiente local suave → rampa; fuerte → peldaño horizontal (el parapeto se escalona)
   const n = Math.max(1, Math.round((x1 - x0) / (h * 0.6))); for (let k = 0; k < n; k++) { const u0 = x0 + (x1 - x0) * k / n, u1 = x0 + (x1 - x0) * (k + 1) / n, mid = (u0 + u1) / 2;
    const lv = (x) => (k === 0 && sg.Fa != null && x - x0 < h * 0.6 ? fa : k === n - 1 && sg.Fb != null && x1 - x < h * 0.6 ? fb : floor(x) + corr(x));
    if (Math.abs(floor(u1) - floor(u0)) / Math.max(1, u1 - u0) > 0.1 || k === 0 || k === n - 1) { const y = lv(mid); pts.push([u0, y + er(u0)], [u1, y + er(u1)]); }
    else { for (let x = u0; x <= u1 + 0.1; x += 6) { const xx = Math.min(x, u1); pts.push([xx, lv(xx) + er(xx)]); } } }
   return pts; };
  const walkAll = []; segs.forEach((sg) => { if (sg.b > sg.a) sg.pts = profile(sg); });
  const clipPts = (pts) => { const out = []; for (const p of pts) { if (p[0] <= xe) out.push(p); else { if (out.length) out.push([xe, out[out.length - 1][1]]); break; } } return out; };
  const S = [(sunL ? 1 : -1) * h * 0.9, h * 0.8];
  ctx.save();
  // 1) sombras proyectadas de todos los tramos sobre la ladera
  segs.forEach((sg) => { if (!sg.pts) return; const pts = clipPts(sg.pts); if (pts.length < 2) return; const top = pts.map(([x, y]) => [x + S[0], Math.max(gy(x + S[0]) + 2, y + S[1] - h * 0.2)]); ctx.save(); ctx.globalAlpha *= 0.2; quadP(ctx, [...pts.map(([x]) => [x, gy(x) + 2]), ...top.reverse()], '#0e140c'); ctx.restore(); });
  // 2) tramo → torre → tramo (orden de dibujo correcto en la proyección oblicua)
  const drawSeg = (sg) => { if (!sg.pts) return; const pts = clipPts(sg.pts); if (pts.length < 2) return; const xs = pts[0][0], xf = pts[pts.length - 1][0], ph = st === 'tierra' ? 0 : h * 0.22;
   // adarve (superficie con anchura) y pretil interior
   quadP(ctx, [...pts, ...pts.slice().reverse().map(([x, y]) => [x + D[0], y + D[1]])], C0.t);
   for (let i = 1; i < pts.length; i++) if (Math.abs(pts[i][1] - pts[i - 1][1]) > 1 && Math.abs(pts[i][0] - pts[i - 1][0]) < 0.5) { const [x, y] = pts[i]; ctx.strokeStyle = 'rgba(60,45,35,0.45)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, Math.min(y, pts[i - 1][1])); ctx.lineTo(x + D[0], Math.min(y, pts[i - 1][1]) + D[1]); ctx.stroke(); }
   if (st !== 'tierra') { const ip = pts.map(([x, y]) => [x + D[0], y + D[1]]); quadP(ctx, [...ip.map(([x, y]) => [x, y - h * 0.16]), ...ip.slice().reverse()], C0.m); }
   // cara frontal: del parapeto al terreno (la base sigue el relieve)
   const front = [...pts.map(([x, y]) => [x, y - ph])]; for (let x = xf; x >= xs - 0.1; x -= 8) front.push([Math.max(x, xs), gy(Math.max(x, xs)) + 4]);
   ctx.beginPath(); front.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); const ymin = Math.min(...pts.map((p) => p[1])) - ph, fg = ctx.createLinearGradient(0, ymin, 0, ymin + h * 2.2); fg.addColorStop(0, C0.f); fg.addColorStop(1, C0.fd); ctx.fillStyle = fg; ctx.fill();
   ctx.save(); ctx.clip(); const R = H.rng(Math.round(xs) + 3);
   if (st === 'ladrillo') { ctx.fillStyle = C0.pl; ctx.beginPath(); ctx.moveTo(xs, 3000); for (let x = xs; x <= xf; x += 8) ctx.lineTo(x, Math.max(gy(x) - h * 0.55, pts[0][1] + h * 0.35)); ctx.lineTo(xf, 3000); ctx.closePath(); ctx.fill(); }
   ctx.strokeStyle = st === 'tierra' ? 'rgba(80,52,30,0.4)' : 'rgba(45,32,24,0.3)'; ctx.lineWidth = st === 'tierra' ? 2 : 1; const ch = st === 'tierra' ? h * 0.22 : st === 'piedra' ? h * 0.3 : h * 0.1;
   for (let k = 1; k < 26; k++) { ctx.beginPath(); for (let i = 1; i < pts.length; i++) { const [xa2, ya2] = pts[i - 1], [xb2, yb2] = pts[i]; if (Math.abs(xb2 - xa2) < 0.5) continue; ctx.moveTo(xa2, ya2 - ph + k * ch); ctx.lineTo(xb2, yb2 - ph + k * ch); } ctx.stroke(); }
   if (st !== 'tierra') { const jw = st === 'piedra' ? h * 0.42 : h * 0.24; for (let k = 0; k < 26; k++) for (let x = xs + (k % 2) * jw * 0.5 + (st === 'piedra' ? R.range(0, 8) : 0); x < xf; x += jw) { const y0 = lerp(pts[0][1], pts[pts.length - 1][1], (x - xs) / Math.max(1, xf - xs)) - ph + k * ch; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y0 + ch); ctx.stroke(); } }
   const ao = ctx.createLinearGradient(0, ymin, 0, ymin + h * 0.4); ao.addColorStop(0, 'rgba(0,0,0,0.14)'); ao.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = ao; ctx.fillRect(xs - 5, ymin, xf - xs + 10, h * 0.4);
   ctx.fillStyle = 'rgba(10,12,8,0.28)'; ctx.beginPath(); ctx.moveTo(xs, 3000); for (let x = xs; x <= xf; x += 8) ctx.lineTo(x, gy(x) - h * 0.25); ctx.lineTo(xf, 3000); ctx.closePath(); ctx.fill(); ctx.restore();
   // remate del parapeto y almenas con volumen
   ctx.strokeStyle = 'rgba(255,238,210,0.4)'; ctx.lineWidth = Math.max(1.5, h * 0.035); ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y - ph) : ctx.moveTo(x, y - ph))); ctx.stroke();
   if ((o.crenel ?? st === 'ladrillo') && ru < 0.6) { const mw = h * 0.26, mh = h * 0.26, dd = [D[0] * 0.13, D[1] * 0.13]; for (let x = xs + mw * 0.5; x < xf - mw; x += mw * 2.1) { let y = pts[0][1]; for (let i = 1; i < pts.length; i++) if (pts[i][0] >= x + mw / 2) { y = pts[i][1]; break; } const y0 = y - ph; quadP(ctx, [[x + mw, y0], [x + mw + dd[0], y0 + dd[1]], [x + mw + dd[0], y0 - mh + dd[1]], [x + mw, y0 - mh]], sunL ? C0.sd : C0.s); quadP(ctx, [[x, y0 - mh], [x + mw, y0 - mh], [x + mw + dd[0], y0 - mh + dd[1]], [x + dd[0], y0 - mh + dd[1]]], C0.t); quadP(ctx, [[x, y0], [x + mw, y0], [x + mw, y0 - mh], [x, y0 - mh]], C0.m); ctx.fillStyle = 'rgba(25,18,12,0.7)'; ctx.fillRect(x + mw * 0.42, y0 - mh * 0.66, mw * 0.16, mh * 0.34); } }
   // cara final donde se detiene la obra (muestra el grosor y el relleno)
   if (xf >= xe - 0.5 && xe < xb - 1) { const yT = pts[pts.length - 1][1] - ph; quadP(ctx, [[xf, yT], [xf + D[0], yT + D[1]], [xf + D[0], gy(xf) + D[1]], [xf, gy(xf) + 4]], sunL ? C0.sd : C0.s); ctx.save(); ctx.globalAlpha *= 0.5; P.matFill(ctx, [[xf + D[0] * 0.2, yT + D[1] * 0.2 + h * 0.1], [xf + D[0] * 0.8, yT + D[1] * 0.8 + h * 0.1], [xf + D[0] * 0.8, gy(xf) + D[1] * 0.8], [xf + D[0] * 0.2, gy(xf) + D[1] * 0.2]], st === 'tierra' ? 'tierra' : 'grava', { layer: h * 0.2 }); ctx.restore(); }
   if (o.glow) { ctx.strokeStyle = `rgba(255,212,71,${o.glow})`; ctx.lineWidth = 5; ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y - ph) : ctx.moveTo(x, y - ph))); ctx.stroke(); }
  };
  const outT = []; segs.forEach((sg, i) => { drawSeg(sg); const T = towers[i]; if (T && T.x - g.tw / 2 <= xe) outT.push(wsTower(ctx, gy, T, g, t)); });
  ctx.restore();
  return { towers: outT, walk: (x) => { for (const sg of segs) if (sg.pts && x >= sg.a && x <= sg.b) { for (let i = 1; i < sg.pts.length; i++) if (sg.pts[i][0] >= x) return sg.pts[i][1]; } return floor(x); } };
 };
 // Compatibilidad: muralla a partir de puntos (x creciente) → sistema único. towers = fracciones del recorrido en x.
 P.wallPath = (ctx, pts, t, o = {}) => { const gy = (x) => { if (x <= pts[0][0]) return pts[0][1]; for (let i = 1; i < pts.length; i++) if (pts[i][0] >= x) { const a = pts[i - 1], b = pts[i]; return lerp(a[1], b[1], (x - a[0]) / Math.max(1e-6, b[0] - a[0])); } return pts[pts.length - 1][1]; };
  const xa = pts[0][0], xb = pts[pts.length - 1][0], fr = o.towers || [], towersX = fr.map((f) => lerp(xa, xb, f));
  return P.wallSystem(ctx, gy, xa, xb, t, { ...o, h: o.h, towerH: o.towerS ? o.towerS * 0.5 : undefined, towersX, towerSmoke: fr.map((f) => (f === o.smokeAt ? o.smoke : 0)), towerFire: fr.map((f) => (f === o.fireAt ? o.fire : 0)), pavilionX: (o.pavilion || []).map((f) => lerp(xa, xb, f)) }); };
 // Torre aislada sobre suelo plano (catálogo y usos sueltos), con la misma geometría
 P.watchtower = (ctx, x, y, s, t, o = {}) => { const h = s * 0.42; return wsTower(ctx, () => y, { x, F: y - h, smoke: o.smoke, fire: o.fire, pavilion: o.pavilion }, { D: [h * 0.8 * 0.6, -h * 0.8 * 0.48], tw: h * 1.8, tdp: 1.5, pro: 0.25, thH: s - h, h, st: o.style || 'ladrillo', sunL: !!o.sunLeft, ru: o.ruin || 0 }, t); };
 // Texturas de materiales para cortes: tierra compactada (capas), grava/cascajo, piedra, ladrillo (aparejo con juntas), madera
 P.matFill = (ctx, pts, mat, o = {}) => { const R = H.rng(o.seed || 9); ctx.save(); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const base = { tierra: '#A4774C', grava: '#8d8a7c', piedra: '#9ca29b', ladrillo: '#A45C42', madera: '#8f6643', cana: '#8a8a52' }[mat] || '#888'; ctx.fillStyle = o.glow ? '#d0a070' : base; ctx.fill(); ctx.clip();
  if (mat === 'tierra') { const lh = o.layer || 22; for (let y = y1; y > y0; y -= lh) { ctx.fillStyle = 'rgba(70,46,26,0.45)'; ctx.fillRect(x0, y - 2, x1 - x0, 2); ctx.fillStyle = 'rgba(255,230,190,0.08)'; ctx.fillRect(x0, y - lh, x1 - x0, lh * 0.4); } ctx.fillStyle = 'rgba(80,55,32,0.4)'; for (let i = 0; i < (x1 - x0) * (y1 - y0) / 120; i++) ctx.fillRect(R.range(x0, x1), R.range(y0, y1), 2, 2); if (o.reeds) { for (let y = y1 - lh * 3; y > y0; y -= lh * 3) { ctx.fillStyle = 'rgba(130,140,70,0.9)'; ctx.fillRect(x0, y - 4, x1 - x0, 5); ctx.strokeStyle = 'rgba(80,90,40,0.8)'; ctx.lineWidth = 1; for (let x = x0; x < x1; x += 7) { ctx.beginPath(); ctx.moveTo(x, y - 4); ctx.lineTo(x + 5, y); ctx.stroke(); } } } }
  else if (mat === 'grava') { for (let i = 0; i < (x1 - x0) * (y1 - y0) / 140; i++) { ctx.fillStyle = ['#6f6c60', '#a8a596', '#7c827d', '#5f5a50'][i % 4]; ctx.beginPath(); ctx.ellipse(R.range(x0, x1), R.range(y0, y1), R.range(3, 9), R.range(2, 6), R.range(0, 3), 0, TAU); ctx.fill(); } }
  else if (mat === 'piedra') { for (let i = 0; i < (x1 - x0) * (y1 - y0) / 1400; i++) { const cx = R.range(x0, x1), cy = R.range(y0, y1), r = R.range(12, 26); ctx.fillStyle = ['#a8aea6', '#8f958e', '#b6bab0'][i % 3]; ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = k / 6 * TAU + R() * 0.4; ctx.lineTo(cx + Math.cos(a) * r * R.range(0.7, 1.1), cy + Math.sin(a) * r * 0.7 * R.range(0.7, 1.1)); } ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(50,52,48,0.6)'; ctx.lineWidth = 1.5; ctx.stroke(); } }
  else if (mat === 'ladrillo') { const bh = o.bh || 14, bw = bh * 2.6; for (let y = y1, r = 0; y > y0 - bh; y -= bh, r++) for (let x = x0 - (r % 2) * bw / 2; x < x1; x += bw) { ctx.fillStyle = (Math.round(x * 7 + y * 3) % 3) ? '#A45C42' : '#96523c'; ctx.fillRect(x + 1, y - bh + 1, bw - 2, bh - 2); } ctx.fillStyle = 'rgba(220,214,196,0.35)'; }
  else if (mat === 'madera') { ctx.strokeStyle = 'rgba(60,40,24,0.45)'; ctx.lineWidth = 1.5; for (let y = y0 + 4; y < y1; y += 6) { ctx.beginPath(); ctx.moveTo(x0, y); for (let x = x0; x < x1; x += 20) ctx.lineTo(x, y + Math.sin(x * 0.05 + y) * 1.5); ctx.stroke(); } }
  ctx.restore(); ctx.save(); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.strokeStyle = o.glow ? 'rgba(255,212,71,0.95)' : 'rgba(30,22,16,0.6)'; ctx.lineWidth = o.glow ? 5 : 2; ctx.stroke(); ctx.restore(); };
 // Cortes comparables de tres tipos de muro. kind: 'tierra' (apisonada, con capas de cañas opcionales), 'piedra' (mampostería
 // con relleno), 'ming' (núcleo de tierra compactada y cascajo, paramentos de ladrillo sobre cimiento de piedra, adarve y parapeto).
 // Devuelve puntos para rótulos. o: { reeds, glow:{…}, build (0..1, solo ming: hiladas) }
 P.wallSection = (ctx, x, y, w, h, t, kind, o = {}) => { const gl = o.glow || {}, pts = {}; ctx.save(); ctx.fillStyle = 'rgba(20,18,14,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + 6, w * 0.62, h * 0.05, 0, 0, TAU); ctx.fill();
  if (kind === 'tierra') { const tw = w * 0.62; P.matFill(ctx, [[x - w / 2, y], [x + w / 2, y], [x + tw / 2, y - h], [x - tw / 2, y - h]], 'tierra', { layer: h / 14, reeds: o.reeds, glow: gl.earth }); pts.earth = [x, y - h * 0.45]; pts.reed = [x + w * 0.2, y - h * (3 / 14) - 2]; }
  else if (kind === 'piedra') { const tw = w * 0.7, bt = w * 0.16; P.matFill(ctx, [[x - w / 2 + bt, y], [x + w / 2 - bt, y], [x + tw / 2 - bt * 0.8, y - h], [x - tw / 2 + bt * 0.8, y - h]], 'grava', { glow: gl.fill }); P.matFill(ctx, [[x - w / 2, y], [x - w / 2 + bt, y], [x - tw / 2 + bt * 0.8, y - h], [x - tw / 2, y - h]], 'piedra', { seed: 3, glow: gl.stone }); P.matFill(ctx, [[x + w / 2 - bt, y], [x + w / 2, y], [x + tw / 2, y - h], [x + tw / 2 - bt * 0.8, y - h]], 'piedra', { seed: 5, glow: gl.stone }); pts.fill = [x, y - h * 0.5]; pts.stone = [x + w * 0.4, y - h * 0.35]; }
  else { const tw = w * 0.78, bt = w * 0.1, fh = h * 0.15, bd = o.build ?? 1; P.matFill(ctx, [[x - w / 2 - 12, y], [x + w / 2 + 12, y], [x + w / 2 + 12, y - fh], [x - w / 2 - 12, y - fh]], 'piedra', { seed: 2, glow: gl.stone });
   const cL = (u) => lerp(x - w / 2 + bt, x - tw / 2 + bt * 0.8, u), cR = (u) => lerp(x + w / 2 - bt, x + tw / 2 - bt * 0.8, u), hy = (u) => y - fh - u * (h - fh - h * 0.05);
   P.matFill(ctx, [[cL(0), hy(0)], [cR(0), hy(0)], [cR(0.55), hy(0.55)], [cL(0.55), hy(0.55)]], 'tierra', { layer: h / 16, glow: gl.earth }); P.matFill(ctx, [[cL(0.55), hy(0.55)], [cR(0.55), hy(0.55)], [cR(1), hy(1)], [cL(1), hy(1)]], 'grava', { glow: gl.fill });
   for (const sd of [-1, 1]) { const ub = Math.max(0.02, bd); const ox = (u) => sd < 0 ? lerp(x - w / 2, x - tw / 2, u) : lerp(x + w / 2, x + tw / 2, u), ix = (u) => ox(u) - sd * bt; P.matFill(ctx, [[ox(0), hy(0)], [ix(0), hy(0)], [ix(ub), hy(ub)], [ox(ub), hy(ub)]], 'ladrillo', { bh: h / 34, glow: gl.brick }); }
   if (bd >= 1) { P.matFill(ctx, [[x - tw / 2, hy(1)], [x + tw / 2, hy(1)], [x + tw / 2, hy(1) - h * 0.035], [x - tw / 2, hy(1) - h * 0.035]], 'ladrillo', { bh: h * 0.035 }); const ph = h * 0.15; P.matFill(ctx, [[x + tw / 2 - bt * 0.7, hy(1) - h * 0.035], [x + tw / 2, hy(1) - h * 0.035], [x + tw / 2, hy(1) - ph], [x + tw / 2 - bt * 0.7, hy(1) - ph]], 'ladrillo', { bh: h / 34 }); P.matFill(ctx, [[x + tw / 2 - bt * 0.7, hy(1) - ph - h * 0.02], [x + tw / 2, hy(1) - ph - h * 0.02], [x + tw / 2, hy(1) - ph * 1.45], [x + tw / 2 - bt * 0.7, hy(1) - ph * 1.45]], 'ladrillo', { bh: h / 34 }); P.matFill(ctx, [[x - tw / 2, hy(1) - h * 0.035], [x - tw / 2 + bt * 0.6, hy(1) - h * 0.035], [x - tw / 2 + bt * 0.6, hy(1) - ph * 0.6], [x - tw / 2, hy(1) - ph * 0.6]], 'ladrillo', { bh: h / 34 }); }
   pts.earth = [x - w * 0.05, hy(0.25)]; pts.fill = [x + w * 0.05, hy(0.78)]; pts.brick = [lerp(x + w / 2, x + tw / 2, 0.5) - bt * 0.5, hy(0.5)]; pts.stone = [x + w * 0.32, y - fh / 2]; pts.parapet = [x + tw / 2 - bt * 0.35, hy(1) - h * 0.15]; }
  ctx.restore(); return pts; };
 // Carro de dos ruedas tirado por un buey. (x, y) = suelo bajo el centro. s = largo total. o: { load, phase (giro de ruedas), dir (1 derecha) }
 P.oxcart = (ctx, x, y, s, t, o = {}) => { const d = o.dir ?? 1, ph = o.phase || 0; ctx.save(); ctx.translate(x, y); ctx.scale(d, 1);
  ctx.fillStyle = 'rgba(20,20,15,0.3)'; ctx.beginPath(); ctx.ellipse(0, 4, s * 0.5, s * 0.04, 0, 0, TAU); ctx.fill();
  // buey
  const ox = s * 0.24, oy = -s * 0.2, lg = Math.sin(ph * TAU) * s * 0.025; ctx.fillStyle = '#5a4532'; ctx.beginPath(); ctx.ellipse(ox, oy, s * 0.17, s * 0.09, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(ox + s * 0.19, oy - s * 0.02, s * 0.06, s * 0.045, 0.3, 0, TAU); ctx.fill(); ctx.strokeStyle = '#d8ccb0'; ctx.lineWidth = s * 0.012; ctx.beginPath(); ctx.moveTo(ox + s * 0.17, oy - s * 0.06); ctx.quadraticCurveTo(ox + s * 0.15, oy - s * 0.11, ox + s * 0.2, oy - s * 0.12); ctx.stroke();
  ctx.strokeStyle = '#4a3828'; ctx.lineWidth = s * 0.025; ctx.lineCap = 'round'; for (const [lx, sg] of [[-0.11, 1], [-0.06, -1], [0.1, -1], [0.14, 1]]) { ctx.beginPath(); ctx.moveTo(ox + lx * s, oy + s * 0.05); ctx.lineTo(ox + lx * s + sg * lg, y * 0 - s * 0.005); ctx.stroke(); }
  // varas y caja
  ctx.strokeStyle = '#6b4a2e'; ctx.lineWidth = s * 0.015; ctx.beginPath(); ctx.moveTo(-s * 0.05, -s * 0.16); ctx.lineTo(ox + s * 0.05, oy - s * 0.04); ctx.stroke();
  ctx.fillStyle = '#795335'; ctx.fillRect(-s * 0.45, -s * 0.24, s * 0.4, s * 0.09); ctx.strokeStyle = 'rgba(40,25,15,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(-s * 0.45, -s * 0.24, s * 0.4, s * 0.09);
  const ld = o.load || 'tierra'; if (ld === 'ladrillos') { ctx.fillStyle = '#a45c42'; for (let r = 0; r < 2; r++) for (let i = 0; i < 6; i++) { ctx.fillRect(-s * 0.44 + i * s * 0.064, -s * 0.28 - r * s * 0.035, s * 0.058, s * 0.032); } } else if (ld === 'piedra') { ctx.fillStyle = '#8f958e'; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.ellipse(-s * 0.4 + i * s * 0.1, -s * 0.27, s * 0.055, s * 0.04, 0, 0, TAU); ctx.fill(); } } else { ctx.fillStyle = '#8a6440'; ctx.beginPath(); ctx.ellipse(-s * 0.25, -s * 0.24, s * 0.2, s * 0.06, 0, Math.PI, TAU); ctx.fill(); }
  // rueda de radios
  const wr = s * 0.13, wx = -s * 0.25, wy = -wr; ctx.strokeStyle = '#4a3020'; ctx.lineWidth = s * 0.018; ctx.beginPath(); ctx.arc(wx, wy, wr, 0, TAU); ctx.stroke(); ctx.lineWidth = s * 0.008; for (let k = 0; k < 8; k++) { const a = k / 8 * TAU + ph * TAU; ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(wx + Math.cos(a) * wr, wy + Math.sin(a) * wr); ctx.stroke(); } ctx.fillStyle = '#3a2416'; ctx.beginPath(); ctx.arc(wx, wy, s * 0.02, 0, TAU); ctx.fill();
  ctx.restore(); };
 // Animal de carga (burro/mula) con alforjas. o: { load, dir }
 P.packAnimal = (ctx, x, y, s, ph, o = {}) => { const d = o.dir ?? 1; ctx.save(); ctx.translate(x, y); ctx.scale(d, 1); const lg = Math.sin(ph * TAU) * s * 0.06;
  ctx.fillStyle = 'rgba(20,20,15,0.3)'; ctx.beginPath(); ctx.ellipse(0, 3, s * 0.45, s * 0.05, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#6a5a4c'; ctx.lineWidth = s * 0.06; ctx.lineCap = 'round'; for (const [lx, sg] of [[-0.25, 1], [-0.18, -1], [0.2, -1], [0.27, 1]]) { ctx.beginPath(); ctx.moveTo(lx * s, -s * 0.38); ctx.lineTo(lx * s + sg * lg, 0); ctx.stroke(); }
  ctx.fillStyle = '#7d6c5c'; ctx.beginPath(); ctx.ellipse(0, -s * 0.48, s * 0.36, s * 0.16, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(s * 0.28, -s * 0.55); ctx.lineTo(s * 0.48, -s * 0.78); ctx.lineTo(s * 0.6, -s * 0.66); ctx.lineTo(s * 0.4, -s * 0.44); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.ellipse(s * 0.6, -s * 0.66, s * 0.08, s * 0.06, 0.6, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(s * 0.47, -s * 0.86, s * 0.025, s * 0.08, -0.2, 0, TAU); ctx.fill();
  ctx.fillStyle = '#8a6a45'; ctx.fillRect(-s * 0.2, -s * 0.66, s * 0.36, s * 0.08); ctx.fillStyle = o.load === 'ladrillos' ? '#a45c42' : o.load === 'piedra' ? '#8f958e' : '#9a7b4f'; ctx.fillRect(-s * 0.18, -s * 0.6, s * 0.14, s * 0.2); ctx.fillRect(s * 0.0, -s * 0.6, s * 0.14, s * 0.2);
  ctx.restore(); };
 // Muro de tierra apisonada en construcción (alzado frontal). (x, y) = base centro. o: { total (capas objetivo), done (capas terminadas),
 // loose (0..1 vertido de la capa actual), compact (0..1), form (0..1 encofrado visible; tablones delanteros en corte, semitransparentes),
 // workers (n), hit (fase de golpes), cut (0..1 corte con capas marcadas), glowLayer }. Devuelve { surf, th, top, hits }
 P.rammedEarth = (ctx, x, y, w, h, t, o = {}) => {
  const n = o.total ?? 8, th = h / n, done = Math.floor(o.done ?? 0), lo = cl(o.loose ?? 0), cp = cl(o.compact ?? 0), fm = o.form ?? 1, R = H.rng(o.seed || 4);
  const x0 = x - w / 2, x1 = x + w / 2; ctx.save();
  ctx.fillStyle = 'rgba(25,20,15,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + 4, w * 0.58, th * 0.5, 0, 0, TAU); ctx.fill();
  // capas terminadas: cada una con su tono y textura de grano; líneas de junta visibles
  for (let i = 0; i < done; i++) { const yt = y - (i + 1) * th; const g = ctx.createLinearGradient(0, yt, 0, yt + th); const tone = (i % 2 ? 6 : -6) + R.range(-5, 5); g.addColorStop(0, `rgb(${170 + tone},${124 + tone},${80 + tone})`); g.addColorStop(1, `rgb(${136 + tone},${96 + tone},${60 + tone})`); ctx.fillStyle = g; ctx.fillRect(x0, yt, w, th + 0.5);
   ctx.fillStyle = 'rgba(80,55,32,0.35)'; for (let k = 0; k < w * th / 90; k++) ctx.fillRect(x0 + R() * w, yt + R() * th, 2, 2); ctx.fillStyle = 'rgba(70,46,26,0.55)'; ctx.fillRect(x0, yt + th - 2, w, 2); if (o.glowLayer === i) { ctx.strokeStyle = 'rgba(255,212,71,0.95)'; ctx.lineWidth = 4; ctx.strokeRect(x0, yt, w, th); } }
  // capa actual: tierra suelta que, al compactarse, baja de altura y se vuelve más densa
  let surf = y - done * th; if (lo > 0) { const hl = th * lerp(1.35, 1, cp) * lo, yt = surf - hl; ctx.fillStyle = cp > 0.5 ? '#9c7046' : '#a9845a'; ctx.beginPath(); ctx.moveTo(x0, surf); for (let k = 0; k <= 30; k++) { const xx = x0 + w * k / 30, bump = (1 - cp) * th * 0.25 * (0.5 + 0.5 * Math.sin(k * 1.7 + done)); ctx.lineTo(xx, yt + bump); } ctx.lineTo(x1, surf); ctx.closePath(); ctx.fill();
   ctx.fillStyle = `rgba(90,62,36,${0.25 + 0.4 * cp})`; for (let k = 0; k < w * hl / (70 - 40 * cp); k++) { ctx.beginPath(); ctx.arc(x0 + R() * w, yt + th * 0.15 + R() * (hl - th * 0.15), (1 - cp) * 2.5 + 1, 0, TAU); ctx.fill(); } surf = yt; }
  // encofrado: postes verticales y tablones horizontales que rodean las capas superiores
  if (fm > 0) { ctx.save(); ctx.globalAlpha *= fm; const fy0 = Math.min(surf, y - done * th) - th * 0.4, fy1 = y - Math.max(0, done - 1) * th; ctx.fillStyle = '#795335'; for (const px of [x0 - 14, x1 + 2]) { ctx.fillRect(px, fy0 - th * 1.2, 12, (y - fy0) + th * 1.2); } for (let b = 0; b < 3; b++) { const by = fy0 + b * th * 0.75; if (by > y) break; ctx.fillStyle = 'rgba(143,102,67,0.28)'; ctx.fillRect(x0 - 20, by, w + 40, th * 0.5); ctx.strokeStyle = 'rgba(121,83,53,0.95)'; ctx.lineWidth = 3; ctx.strokeRect(x0 - 20, by, w + 40, th * 0.5); } ctx.strokeStyle = '#5a3d29'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(x0 - 20, fy0 - th * 1.15); ctx.lineTo(x1 + 20, fy0 - th * 1.15); ctx.stroke(); ctx.strokeStyle = '#c9b48a'; ctx.lineWidth = 3; for (const px of [x0 - 8, x1 + 8]) { ctx.beginPath(); ctx.moveTo(px - 8, fy0 - th * 1.25); ctx.lineTo(px + 8, fy0 - th * 1.05); ctx.moveTo(px + 8, fy0 - th * 1.25); ctx.lineTo(px - 8, fy0 - th * 1.05); ctx.stroke(); } ctx.restore(); }
  // trabajadores con pisones: el pisón toca la superficie en cada golpe y levanta polvo
  const nw = o.workers ?? 0, wh = Math.min(th * 3.4, w * 0.36), hits = []; for (let i = 0; i < nw; i++) { const wx = x0 + w * (i + 0.5) / nw - wh * 0.12, ph = (o.hit || 0) + i * 0.37, lift = Math.pow(Math.max(0, Math.sin(ph * TAU)), 0.7), feet = surf;
   const fr = P.figure(ctx, wx, feet, wh, 0, { pose: 'ram', lift, var: i + 1 }); const px = wx + wh * 0.22, pb = feet - lift * wh * 0.24;
   ctx.strokeStyle = '#6b4a2e'; ctx.lineWidth = wh * 0.035; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(px, pb - wh * 0.86); ctx.lineTo(px, pb - wh * 0.06); ctx.stroke(); ctx.fillStyle = '#4e3a28'; ctx.beginPath(); ctx.moveTo(px - wh * 0.07, pb); ctx.lineTo(px + wh * 0.07, pb); ctx.lineTo(px + wh * 0.05, pb - wh * 0.08); ctx.lineTo(px - wh * 0.05, pb - wh * 0.08); ctx.closePath(); ctx.fill();
   // manos sobre el mango (se vuelven a dibujar encima del palo)
   ctx.fillStyle = FIG_SKIN[(i + 1) % FIG_SKIN.length]; for (const hh of [fr.hf, fr.hb]) { ctx.beginPath(); ctx.arc(px, hh[1], wh * 0.03, 0, TAU); ctx.fill(); }
   const frp = ((ph % 1) + 1) % 1, contact = frp >= 0.5 ? 1 - Math.min(1, (frp - 0.5) * 4) : 0; if (contact > 0.2) { hits.push([px, feet]); ctx.strokeStyle = `rgba(255,236,200,${0.6 * contact})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(px, feet, wh * 0.12 * (1.4 - contact), wh * 0.03, 0, 0, TAU); ctx.stroke(); for (let q = 0; q < 6; q++) { const a = q / 5 * Math.PI, rr = wh * 0.05 * (1.5 - contact); ctx.fillStyle = `rgba(196,168,126,${0.55 * contact})`; ctx.beginPath(); ctx.arc(px + Math.cos(a) * rr * 2.2, feet - Math.sin(a) * rr, rr * 0.6 + 3, 0, TAU); ctx.fill(); } } }
  // corte: capas marcadas
  const ct = o.cut || 0; if (ct > 0) { ctx.save(); ctx.globalAlpha *= ct; ctx.strokeStyle = 'rgba(255,240,210,0.9)'; ctx.lineWidth = 3; for (let i = 1; i <= done; i++) { const yy = y - i * th; ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x1, yy); ctx.stroke(); } ctx.restore(); }
  ctx.restore(); return { surf, th, top: y - done * th, hits };
 };
 // Corte de un muro Ming: cimiento de grandes piedras, paramentos de ladrillo, núcleo de tierra y cascajo, adarve enladrillado y parapeto almenado.
 // o: { core (0..1 revela el núcleo), build (0..1 hiladas de ladrillo colocadas), glow:{core, brick, stone} }. Devuelve puntos para rótulos.
 P.mingSection = (ctx, x, y, w, h, t, o = {}) => {
  const bt = w * 0.1, tw = w * 0.78, gl = o.glow || {}, bd = o.build ?? 1, R = H.rng(6);
  const L0 = [x - w / 2, y], R0 = [x + w / 2, y], L1 = [x - tw / 2, y - h], R1 = [x + tw / 2, y - h];
  ctx.save(); ctx.fillStyle = 'rgba(25,20,15,0.35)'; ctx.beginPath(); ctx.ellipse(x, y + 6, w * 0.6, h * 0.05, 0, 0, TAU); ctx.fill();
  // cimiento de piedra
  const fh = h * 0.16; ctx.fillStyle = gl.stone ? '#c9cfc4' : '#9ca29b'; ctx.fillRect(x - w / 2 - 10, y - fh, w + 20, fh); ctx.strokeStyle = 'rgba(40,40,36,0.6)'; ctx.lineWidth = 2; for (let r = 0; r < 2; r++) for (let i = 0; i < 7; i++) ctx.strokeRect(x - w / 2 - 10 + i * (w + 20) / 7 + (r % 2) * 20 - 10, y - fh + r * fh / 2, (w + 20) / 7, fh / 2);
  // núcleo (tierra apisonada y cascajo por capas)
  const coreP = [[L0[0] + bt, y - fh], [R0[0] - bt, y - fh], [R1[0] - bt * 0.8, y - h + h * 0.06], [L1[0] + bt * 0.8, y - h + h * 0.06]];
  ctx.beginPath(); coreP.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = gl.core ? '#c49562' : '#A4774C'; ctx.fill(); ctx.save(); ctx.clip(); ctx.strokeStyle = 'rgba(80,52,30,0.5)'; ctx.lineWidth = 2; for (let yy = y - fh - h * 0.07; yy > y - h; yy -= h * 0.07) { ctx.beginPath(); ctx.moveTo(x - w, yy); ctx.lineTo(x + w, yy); ctx.stroke(); } ctx.fillStyle = 'rgba(124,130,125,0.85)'; for (let i = 0; i < 40; i++) { ctx.beginPath(); ctx.ellipse(x + R.range(-w * 0.35, w * 0.35), R.range(y - h + h * 0.1, y - fh - 6), R.range(5, 14), R.range(4, 9), R.range(0, 3), 0, TAU); ctx.fill(); } ctx.restore();
  // paramentos de ladrillo (ataludados), hiladas que se colocan de abajo arriba
  const courses = 16, ch = (h - fh) / courses; for (const sd of [-1, 1]) for (let c = 0; c < courses; c++) { if (c / courses > bd) break; const yy = y - fh - (c + 1) * ch, uo = (c + 0.5) / courses, xo = sd < 0 ? lerp(L0[0], L1[0], uo) : lerp(R0[0], R1[0], uo), xi = xo - sd * bt; const bw = bt / 2; for (let k = 0; k < 2; k++) { const bx = Math.min(xo, xi) + k * bw + ((c % 2) ? bw * 0.5 : 0) * 0; ctx.fillStyle = gl.brick ? '#d07a5a' : (c + k) % 3 ? '#A45C42' : '#9a5540'; ctx.fillRect(bx, yy, bw - 1.5, ch - 1.5); } }
  // adarve y parapetos
  if (bd >= 1) { ctx.fillStyle = '#8f5a46'; ctx.fillRect(L1[0], y - h, tw, h * 0.04); ctx.fillStyle = '#A45C42'; const ph = h * 0.16; ctx.fillRect(R1[0] - bt * 0.7, y - h - ph, bt * 0.7, ph); for (let i = 0; i < 1; i++) ctx.fillRect(R1[0] - bt * 0.7, y - h - ph * 1.45, bt * 0.7, ph * 0.3); ctx.fillRect(L1[0], y - h - ph * 0.6, bt * 0.6, ph * 0.6); }
  ctx.restore(); return { core: [x, y - h * 0.5], brick: [lerp(R0[0], R1[0], 0.5) - bt * 0.5, y - h * 0.5], stone: [x + w * 0.3, y - fh / 2], parapet: [R1[0] - bt * 0.35, y - h - h * 0.12], walk: [x, y - h] };
 };
 // Mapa ESQUEMÁTICO del norte de China: costa (Bohai, Shandong, Liaodong), río Amarillo, desiertos (Gobi, Ordos) y relieve.
 // o: { lon0, lon1, lat0, lat1, latRef }. Devuelve proj([lon, lat]). P.CNWALLS: tramos aproximados por periodo.
 const CN = {
  mar: [[124.6, 40.1], [122.9, 39.6], [121.2, 38.8], [121.6, 39.5], [122.2, 40.4], [121.1, 40.9], [119.8, 40.0], [118.2, 39.2], [117.7, 38.4], [118.9, 37.5], [119.9, 37.2], [120.7, 37.8], [122.6, 37.4], [121.6, 36.8], [120.3, 36.0], [119.2, 35.0], [120.3, 34.3], [121.0, 32.0], [130, 32], [130, 41]],
  rio: [[96.5, 34.5], [100.5, 36.2], [103.8, 36.06], [105.2, 37.4], [106.3, 38.5], [106.8, 39.7], [108.5, 40.8], [110.0, 40.6], [111.3, 40.3], [110.9, 39.2], [110.6, 38.0], [110.4, 36.6], [110.3, 34.6], [112.5, 34.8], [113.6, 34.9], [115.5, 35.6], [116.9, 36.6], [118.9, 37.7]],
  gobi: [[96, 41.5], [102, 41.8], [108, 42.6], [112, 43.5], [114, 44.5], [104, 45.2], [95, 44]], ordos: [[107.5, 39.2], [109.5, 39.4], [110.2, 38.6], [108.7, 37.9], [107.3, 38.2]], badain: [[100, 39.6], [103.5, 40.5], [104.2, 39.2], [101.5, 38.8]],
 };
 P.CNWALLS = { // esquemas aproximados (simplificados) de algunos sistemas; no son trazados exactos
  estados: [[[111.0, 41.3], [113.5, 41.6], [116.5, 41.9], [119.5, 42.2], [122.5, 42.0]], [[104.0, 35.6], [106.5, 37.0], [109.8, 39.2], [110.6, 40.3]]],
  qin: [[[103.9, 35.4], [105.5, 36.5], [107.6, 38.9], [109.9, 41.2], [112.5, 41.4], [116.0, 41.8], [119.5, 42.1], [123.0, 41.6], [124.8, 40.8]]],
  han: [[[90.6, 40.4], [93.0, 40.3], [94.8, 40.3], [97.5, 40.1], [99.5, 39.6], [101.0, 39.0], [103.5, 38.2], [105.6, 38.6], [107.6, 39.3]], [[107.6, 41.4], [110.0, 41.9], [113.0, 42.4]]],
  ming: [[[98.2, 39.8], [100.4, 38.9], [102.6, 37.9], [103.9, 37.3], [105.2, 37.5], [106.2, 38.5], [107.2, 38.0], [108.7, 37.6], [109.7, 38.3], [111.3, 39.6], [113.3, 40.4], [114.9, 40.6], [116.0, 40.35], [117.2, 40.7], [118.6, 40.3], [119.8, 40.0]], [[119.8, 40.0], [121.0, 41.2], [122.6, 41.9], [124.4, 40.1]]],
 };
 P.chinaMap = (ctx, x, y, w, h, t, o = {}) => {
  const lon0 = o.lon0 ?? 88, lon1 = o.lon1 ?? 126, lat0 = o.lat0 ?? 32, lat1 = o.lat1 ?? 46, k = Math.cos((o.latRef ?? 39) * Math.PI / 180), sc = Math.min(w / ((lon1 - lon0) * k), h / (lat1 - lat0)), ox = x + (w - (lon1 - lon0) * k * sc) / 2, oy = y + (h - (lat1 - lat0) * sc) / 2;
  const proj = (p) => [ox + (p[0] - lon0) * k * sc, oy + (lat1 - p[1]) * sc];
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); const lg = ctx.createLinearGradient(0, y, 0, y + h); lg.addColorStop(0, '#7f8a6a'); lg.addColorStop(1, '#6a7a58'); ctx.fillStyle = lg; ctx.fillRect(x, y, w, h);
  const poly = (pts, fill) => { ctx.beginPath(); P.spline(pts.map(proj), 4).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); };
  poly(CN.gobi, 'rgba(201,180,142,0.85)'); poly(CN.badain, 'rgba(214,190,140,0.85)'); poly(CN.ordos, 'rgba(201,180,142,0.75)');
  // relieve: sombreado de cordilleras (Qilian, Yin, Taihang, Yan)
  ctx.strokeStyle = 'rgba(60,70,50,0.35)'; ctx.lineWidth = 3; for (const rg of [[[96, 38.5], [101, 37.8], [103, 36.8]], [[107, 41.1], [111, 41.3], [114, 41.6]], [[112.6, 39.8], [113.4, 37.5], [113.8, 35.5]], [[115.2, 40.6], [117.5, 40.9], [119, 40.6]]]) { const pp = rg.map(proj); for (let i = 0; i < 18; i++) { const u = i / 17, a = pp[Math.min(pp.length - 2, Math.floor(u * (pp.length - 1)))], b = pp[Math.min(pp.length - 1, Math.floor(u * (pp.length - 1)) + 1)], f = (u * (pp.length - 1)) % 1, px = lerp(a[0], b[0], f), py = lerp(a[1], b[1], f); ctx.beginPath(); ctx.moveTo(px - 10, py + 7); ctx.lineTo(px, py - 8); ctx.lineTo(px + 10, py + 7); ctx.stroke(); } }
  poly(CN.mar, '#2d5466'); ctx.strokeStyle = 'rgba(220,232,233,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); P.spline(CN.mar.slice(0, 18).map(proj), 4).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke();
  ctx.strokeStyle = '#4f8fb0'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.beginPath(); P.spline(CN.rio.map(proj), 6).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke();
  ctx.restore(); return proj;
 };
 // Tramo de muralla en un mapa: línea con dientes (símbolo cartográfico) que se dibuja con p. o: { w, c, glow }
 P.mapWall = (ctx, pts, p, t, o = {}) => { if (p <= 0) return; const cv = P.spline(pts, 10), pa = P.path(cv), end = pa.L * cl(p), c = o.c || '#A45C42', w = o.w || 7; const sub = [cv[0]]; for (let s = 6; s < end; s += 6) { const q = pa.at(s); sub.push([q[0], q[1]]); } const e = pa.at(end); sub.push([e[0], e[1]]);
  ctx.save(); if (o.glow !== false) P.strokePath(ctx, sub, w * 3, 'rgba(255,240,200,0.25)'); P.strokePath(ctx, sub, w, c); ctx.fillStyle = c; for (let s = 10; s < end; s += 18) { const q = pa.at(s); ctx.save(); ctx.translate(q[0], q[1]); ctx.rotate(q[2]); ctx.fillRect(-w * 0.4, -w * 1.25, w * 0.8, w * 0.75); ctx.restore(); } ctx.restore(); return pa; };
 // Polvo que se levanta (determinista). o: { s, c }
 P.dust = (ctx, x, y, t, t0, o = {}) => { const u = t - t0; if (u < 0 || u > 1.4) return; const s = o.s || 40, R = H.rng(o.seed || 3); ctx.save(); for (let i = 0; i < 10; i++) { const a = -Math.PI * R(), v = R.range(0.4, 1); ctx.fillStyle = o.c || `rgba(196,168,126,${0.55 * (1 - u / 1.4)})`; ctx.beginPath(); ctx.arc(x + Math.cos(a) * s * v * u * 1.6, y + Math.sin(a) * s * v * u * 0.6 - u * s * 0.3, s * (0.15 + u * 0.35) * v, 0, TAU); ctx.fill(); } ctx.restore(); };
 // ================= v1.15 · INGENIERÍA SÍSMICA: sismo, respuesta dinámica y puente con mecanismos integrados =================
 // Movimiento del terreno determinista: ug(t) desplazamiento y ag(t) aceleración (unidades de dibujo). o: { t0, t1, amp, seed, freqs, pulses:[[ta, tb, k]] }
 P.quakeGround = (o = {}) => { const t0 = o.t0 ?? 0, t1 = o.t1 ?? 20, A = o.amp ?? 10, R = H.rng(o.seed || 7), fs = o.freqs || [0.85, 1.3, 1.9, 2.6, 3.4], comps = fs.map((f) => ({ f, b: A / Math.pow(f, 1.1) / fs.length * 2.2, p: R.range(0, TAU) }));
  const env = (t) => { let e = sm(t0, t0 + 1.4, t) * (1 - sm(t1 - 2.5, t1, t)); if (o.pulses) { let m = o.floor ?? 0.25; for (const [a, b, k] of o.pulses) m = Math.max(m, k * sm(a - 0.8, a + 0.6, t) * (1 - sm(b - 0.8, b + 0.4, t))); e *= m; } return e; };
  return { env, ug: (t) => { const e = env(t); if (e <= 0) return 0; let s = 0; for (const c of comps) s += c.b * Math.sin(TAU * c.f * t + c.p); return e * s; }, ag: (t) => { const e = env(t); if (e <= 0) return 0; let s = 0; for (const c of comps) s -= c.b * Math.pow(TAU * c.f, 2) * Math.sin(TAU * c.f * t + c.p); return e * s; } }; };
 // Oscilador de 1 grado de libertad bajo aceleración de base: ü + 2ζωu̇ + ω²u = −ag(t). Integración de Newmark (aceleración media), determinista.
 // Devuelve u(t) (desplazamiento relativo) interpolado y su máximo. Tn = periodo (s), zeta = amortiguamiento.
 P.sdof = (ag, Tn, zeta, tA, tB, dt = 1 / 240) => { const w = TAU / Tn, n = Math.ceil((tB - tA) / dt) + 1, U = new Float32Array(n); let u = 0, v = 0, a = -ag(tA); const k = w * w, c = 2 * zeta * w, kh = k + 2 * c / dt + 4 / (dt * dt); let mx = 0;
  for (let i = 1; i < n; i++) { const t = tA + i * dt, p = -ag(t) + (4 / (dt * dt)) * u + (4 / dt) * v + a + c * ((2 / dt) * u + v); const un = p / kh, vn = (2 / dt) * (un - u) - v, an = (4 / (dt * dt)) * (un - u) - (4 / dt) * v - a; u = un; v = vn; a = an; U[i] = u; mx = Math.max(mx, Math.abs(u)); }
  const f = (t) => { const x = (t - tA) / dt; if (x <= 0) return 0; if (x >= n - 1) return U[n - 1]; const i = Math.floor(x), r = x - i; return U[i] * (1 - r) + U[i + 1] * r; }; f.max = mx; f.vel = (t) => (f(t + dt) - f(t - dt)) / (2 * dt); return f; };
 const SEC = { hor: '#A8B1B5', horD: '#68767D', horL: '#c3cbce', acero: '#596B77', aceroL: '#C4D0D5', caucho: '#30383C', disip: '#D9A35C', fuerza: '#FF674F', control: '#38C6D0', terreno: '#786A59', veg: '#425D50' };
 P.SEC = SEC;
 // Aislador elastomérico laminado (con núcleo de plomo opcional) en sección. (cx, cy) = centro; shear = desplazamiento de la placa superior respecto
 // de la inferior. Capas de caucho y láminas de acero que se deforman como un paralelogramo (sin separarse). o: { layers, lead, glow, bolts }
 P.isolatorDetail = (ctx, cx, cy, w, h, shear, t, o = {}) => { const n = o.layers ?? 6, pt = h * 0.14, core = h - 2 * pt, gl = o.glow || 0, x0 = cx - w / 2, yT = cy - h / 2, yB = cy + h / 2;
  ctx.save(); const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  // placa inferior (anclada a la subestructura) y superior (anclada al tablero), con pernos
  quad([[x0 - w * 0.08, yB], [x0 + w * 1.08, yB], [x0 + w * 1.08, yB - pt], [x0 - w * 0.08, yB - pt]], SEC.acero); quad([[x0 - w * 0.08 + shear, yT + pt], [x0 + w * 1.08 + shear, yT + pt], [x0 + w * 1.08 + shear, yT], [x0 - w * 0.08 + shear, yT]], SEC.acero);
  if (o.bolts !== false) { ctx.fillStyle = SEC.aceroL; for (const fx of [0.0, 1.0]) { ctx.fillRect(x0 + w * fx - w * 0.05, yB - pt * 0.5, w * 0.03, pt * 1.6); ctx.fillRect(x0 + w * fx - w * 0.05 + shear, yT - pt * 0.6, w * 0.03, pt * 1.6); } }
  // capas (caucho y láminas de acero) que se cortan lateralmente
  for (let i = 0; i < n; i++) { const u0 = i / n, u1 = (i + 1) / n, ya = yB - pt - core * u0, yb = yB - pt - core * u1, sa = shear * u0, sb = shear * u1; quad([[x0 + sa, ya], [x0 + w + sa, ya], [x0 + w + sb, yb], [x0 + sb, yb]], gl ? '#3c464b' : SEC.caucho); if (i > 0) { ctx.strokeStyle = SEC.aceroL; ctx.lineWidth = Math.max(1, h * 0.025); ctx.beginPath(); ctx.moveTo(x0 + sa + w * 0.04, ya); ctx.lineTo(x0 + w + sa - w * 0.04, ya); ctx.stroke(); } }
  // bordes del caucho ligeramente abombados
  ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = Math.max(1, h * 0.02); ctx.beginPath(); ctx.moveTo(x0, yB - pt); ctx.quadraticCurveTo(x0 - w * 0.04 + shear * 0.5, cy, x0 + shear, yT + pt); ctx.moveTo(x0 + w, yB - pt); ctx.quadraticCurveTo(x0 + w + w * 0.04 + shear * 0.5, cy, x0 + w + shear, yT + pt); ctx.stroke();
  if (o.lead) { const lw = w * 0.16; quad([[cx - lw / 2, yB - pt], [cx + lw / 2, yB - pt], [cx + lw / 2 + shear, yT + pt], [cx - lw / 2 + shear, yT + pt]], o.leadGlow ? '#9aa3a8' : '#7d868c'); }
  if (gl) { ctx.strokeStyle = `rgba(56,198,208,${gl})`; ctx.lineWidth = Math.max(2, h * 0.05); ctx.beginPath(); ctx.moveTo(x0 - w * 0.1, yB + 2); ctx.lineTo(x0 + w * 1.1, yB + 2); ctx.lineTo(x0 + w * 1.1 + shear, yT - 2); ctx.lineTo(x0 - w * 0.1 + shear, yT - 2); ctx.closePath(); ctx.stroke(); }
  ctx.restore(); return { top: [cx + shear, yT], bottom: [cx, yB], rubber: [x0 + w * 0.82 + shear * 0.5, cy], shim: [x0 + w * 0.2 + shear * 0.45, yB - pt - core * 0.5], lead: [cx + shear * 0.5, cy] }; };
 // Disipador viscoso entre dos anclajes a (cuerpo) y b (vástago). o: { cut (0..1 corte), heat (0..1), vel (signo/magnitud de velocidad relativa), r }
 P.damperDetail = (ctx, a, b, t, o = {}) => { const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), ang = Math.atan2(dy, dx), r = o.r ?? L * 0.09, cut = o.cut || 0, heat = cl(o.heat || 0), body = o.body ?? L * 0.6, rodL = o.rod ?? L * 0.55, pist = cl(L - rodL, r * 0.8, body + r * 0.2);
  ctx.save(); ctx.translate(a[0], a[1]); ctx.rotate(ang);
  const clevis = (x) => { ctx.fillStyle = SEC.acero; ctx.fillRect(x - r * 0.5, -r * 0.9, r, r * 1.8); ctx.fillStyle = SEC.aceroL; ctx.beginPath(); ctx.arc(x, 0, r * 0.32, 0, TAU); ctx.fill(); };
  clevis(0); clevis(L);
  // vástago
  ctx.fillStyle = SEC.aceroL; ctx.fillRect(pist, -r * 0.22, L - pist - r * 0.4, r * 0.44);
  // cuerpo (cilindro) con brillo; en corte se ve el fluido, la cabeza del pistón y los orificios
  const g = ctx.createLinearGradient(0, -r, 0, r); g.addColorStop(0, '#7e909b'); g.addColorStop(0.35, '#b9c6cc'); g.addColorStop(1, '#4a5964'); ctx.fillStyle = g; ctx.fillRect(r * 0.4, -r, body, r * 2);
  if (cut > 0) { ctx.save(); ctx.globalAlpha *= cut; const fg = ctx.createLinearGradient(r * 0.5, 0, r * 0.4 + body, 0); const hc = `rgba(${Math.round(217 + 38 * heat)},${Math.round(163 - 60 * heat)},${Math.round(92 - 50 * heat)},0.95)`; fg.addColorStop(0, hc); fg.addColorStop(1, `rgba(217,163,92,0.95)`); ctx.fillStyle = fg; ctx.fillRect(r * 0.55, -r * 0.78, body - r * 0.3, r * 1.56);
   const px = pist; ctx.fillStyle = SEC.aceroL; ctx.fillRect(px - r * 0.18, -r * 0.78, r * 0.36, r * 1.56); ctx.fillStyle = 'rgba(20,24,28,0.85)'; for (const oy of [-0.45, 0, 0.45]) ctx.fillRect(px - r * 0.18, oy * r - r * 0.06, r * 0.36, r * 0.12);
   const v = o.vel || 0; if (Math.abs(v) > 0.05) { ctx.strokeStyle = 'rgba(255,240,210,0.8)'; ctx.lineWidth = Math.max(1, r * 0.06); for (const oy of [-0.45, 0, 0.45]) { const ph = (t * 3) % 1; for (let k = 0; k < 2; k++) { const x0 = px - Math.sign(v) * r * (0.3 + (ph + k * 0.5) % 1 * 0.9); ctx.beginPath(); ctx.moveTo(x0, oy * r); ctx.lineTo(x0 - Math.sign(v) * r * 0.25, oy * r); ctx.stroke(); } } }
   if (heat > 0.05) P.glow(ctx, pist, 0, r * 2.4, '255,120,60', 0.35 * heat); ctx.restore(); }
  ctx.strokeStyle = 'rgba(20,24,28,0.6)'; ctx.lineWidth = Math.max(1, r * 0.06); ctx.strokeRect(r * 0.4, -r, body, r * 2);
  ctx.restore(); const P2 = (lx, ly) => [a[0] + Math.cos(ang) * lx - Math.sin(ang) * ly, a[1] + Math.sin(ang) * lx + Math.cos(ang) * ly]; return { body: P2(r * 0.4 + body * 0.3, 0), piston: P2(pist, 0), rod: P2((pist + L) / 2, 0), a, b }; };
 // Junta de dilatación de peines (alzado lateral): dos bordes de tablero con dientes de acero que se entrecruzan; gap = separación actual.
 P.jointDetail = (ctx, x, y, w, h, gap, t, o = {}) => { ctx.save(); const tw = h * 0.5, n = 5;
  ctx.fillStyle = SEC.hor; ctx.fillRect(x - w, y, w - gap / 2, h); ctx.fillRect(x + gap / 2, y, w - gap / 2, h); ctx.fillStyle = SEC.horD; ctx.fillRect(x - w, y + h * 0.8, w - gap / 2, h * 0.2); ctx.fillRect(x + gap / 2, y + h * 0.8, w - gap / 2, h * 0.2);
  for (let i = 0; i < n; i++) { const yy = y - h * 0.02 + i * 0; ctx.fillStyle = i % 2 ? SEC.acero : SEC.aceroL; } ctx.fillStyle = SEC.aceroL; ctx.fillRect(x - gap / 2 - tw * 0.1, y - h * 0.12, tw * 1.6 + gap * 0.5, h * 0.12); ctx.fillStyle = SEC.acero; ctx.fillRect(x + gap / 2 - tw * 1.5 - gap * 0.5 + tw * 0.1, y - h * 0.24, tw * 1.5 + gap * 0.5, h * 0.12);
  ctx.fillStyle = '#20262a'; ctx.beginPath(); ctx.moveTo(x - gap / 2, y + h * 0.2); ctx.quadraticCurveTo(x, y + h * 0.2 + gap * 0.3 + h * 0.1, x + gap / 2, y + h * 0.2); ctx.lineTo(x + gap / 2, y + h * 0.3); ctx.quadraticCurveTo(x, y + h * 0.3 + gap * 0.3 + h * 0.1, x - gap / 2, y + h * 0.3); ctx.closePath(); ctx.fill();
  if (o.glow) { ctx.strokeStyle = `rgba(56,198,208,${o.glow})`; ctx.lineWidth = 4; ctx.strokeRect(x - gap / 2 - 6, y - h * 0.3, gap + 12, h * 1.4); }
  ctx.restore(); return { gap: [x, y + h * 0.5] }; };
 // Flecha horizontal (fuerza o desplazamiento) anclada en (x, y); len con signo
 P.hArrow = (ctx, x, y, len, c, w = 14) => { if (Math.abs(len) < 3) return; const d = Math.sign(len), L = Math.abs(len), hl = Math.min(L * 0.5, w * 2); ctx.save(); ctx.fillStyle = c; ctx.shadowColor = 'rgba(0,0,0,0.4)'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.moveTo(x, y - w / 2); ctx.lineTo(x + d * (L - hl), y - w / 2); ctx.lineTo(x + d * (L - hl), y - w); ctx.lineTo(x + d * L, y); ctx.lineTo(x + d * (L - hl), y + w); ctx.lineTo(x + d * (L - hl), y + w / 2); ctx.lineTo(x, y + w / 2); ctx.closePath(); ctx.fill(); ctx.restore(); };
 // Coche estilizado de perfil (escala del puente)
 P.car = (ctx, x, y, s, c = '#c94f4f') => { ctx.save(); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(x - s * 0.5, y - s * 0.12); ctx.lineTo(x - s * 0.48, y - s * 0.3); ctx.lineTo(x - s * 0.2, y - s * 0.32); ctx.lineTo(x - s * 0.08, y - s * 0.5); ctx.lineTo(x + s * 0.26, y - s * 0.5); ctx.lineTo(x + s * 0.42, y - s * 0.3); ctx.lineTo(x + s * 0.5, y - s * 0.26); ctx.lineTo(x + s * 0.5, y - s * 0.12); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(200,225,235,0.85)'; ctx.fillRect(x - s * 0.04, y - s * 0.46, s * 0.12, s * 0.13); ctx.fillRect(x + s * 0.12, y - s * 0.46, s * 0.12, s * 0.13); ctx.fillStyle = '#1b1f22'; for (const fx of [-0.3, 0.3]) { ctx.beginPath(); ctx.arc(x + fx * s, y - s * 0.1, s * 0.11, 0, TAU); ctx.fill(); } ctx.restore(); };
 // PUENTE con mecanismos integrados (alzado 2,5D en proyección oblicua). Geometría en coordenadas de mundo; los mecanismos se dibujan siempre
 // con detalle (se ven al acercar la cámara). o: { x0, x1, deckTop, deckH, piers:[x…], ground(x), D, mode ('aislado'|'rigido'),
 // ug (terreno), up (deriva de las pilas), ud (tablero, absoluto), stroke (disipador), heat, xray (0..1), section (0..1 corte del terreno),
 // forces (0..1), demand (0..1 zonas de alta demanda), glow:{bearings, dampers, joints, piers, deck}, cars:[{x, c}], sunLeft }
 P.bridge = (ctx, t, o = {}) => {
  const x0 = o.x0 ?? 100, x1 = o.x1 ?? 2300, top = o.deckTop ?? 1000, dh = o.deckH ?? 64, D = o.D || [44, -30], piers = o.piers || [650, 1200, 1750], SEAT = 190, GW = 26, plat = o.plateau ?? (top + 6), deep = o.valley ?? 520, gnd = o.ground || ((x) => { const d = Math.min(x - (x0 + SEAT), (x1 - SEAT) - x); if (d <= 0) return plat; const u = Math.min(1, d / 720), toeY = plat + 236, base = plat + deep * u * u * (3 - 2 * u); return d < 40 ? lerp(plat, toeY, d / 40) : Math.max(base, toeY); });
  const ug = o.ug || 0, up = o.up || 0, ud = o.ud ?? 0, iso = (o.mode || 'aislado') === 'aislado', gl = o.glow || {}, xr = o.xray || 0, bh = o.bearH ?? 34, bw = 44, capH = 34, capW = 120, colW = 62, gap0 = 26, wide = Math.abs(D[0]) > 70;
  const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  const deckBot = top + dh, ds = dh * 0.36, bearTop = deckBot, bearBot = bearTop + (iso ? bh : 14), capTop = bearBot, capBot = capTop + capH;
  const out = { piers: [], bearings: [], dampers: [], joints: [] };
  const sec = o.section || 0, XA = x0 - 1400, XB = x1 + 1400, rx = (x0 + x1) / 2;
  const prof = (k, xa = XA, xb = XB) => { const pts = []; for (let x = xa; x <= xb; x += 20) pts.push([x + ug + D[0] * k, gnd(x) + D[1] * k]); return pts; };
  const under = (pts, c) => { ctx.beginPath(); ctx.moveTo(pts[0][0], 3200); pts.forEach((p) => ctx.lineTo(p[0], p[1])); ctx.lineTo(pts[pts.length - 1][0], 3200); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  ctx.save();
  // terreno con profundidad: franjas del fondo del valle de lejos a cerca (el valle es un volumen, no una silueta)
  const KF = o.depth ?? 4; for (let k = KF; k >= 0; k -= 0.5) { const f = k / KF; under(prof(k), `rgb(${Math.round(lerp(124, 92, f))},${Math.round(lerp(110, 92, f))},${Math.round(lerp(90, 84, f))})`); ctx.strokeStyle = `rgba(66,93,80,${0.55 - f * 0.3})`; ctx.lineWidth = 10; ctx.beginPath(); prof(k).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1] - 4) : ctx.moveTo(p[0], p[1] - 4))); ctx.stroke(); }
  // río que cruza el valle en profundidad
  if (o.river !== false) { const yb = gnd(rx) + 3, pr = (k, s) => [rx + s * 120 + ug + D[0] * k, yb + D[1] * k]; quad([pr(-1.4, -1), pr(-1.4, 1), pr(KF, 1), pr(KF, -1)], '#3c6f86'); ctx.strokeStyle = 'rgba(200,230,240,0.25)'; ctx.lineWidth = 3; for (let k = -1; k < KF; k += 0.7) { const a = pr(k + 0.1, -0.5), b = pr(k + 0.35, 0.3); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } }
  // corte del terreno (estratos) en la cara delantera cuando se pide sección
  if (sec > 0) { ctx.save(); ctx.globalAlpha *= sec; const p0 = prof(0); under(p0, '#6b5d4c'); ctx.beginPath(); ctx.moveTo(p0[0][0], 3200); p0.forEach((p) => ctx.lineTo(p[0], p[1])); ctx.lineTo(p0[p0.length - 1][0], 3200); ctx.closePath(); ctx.clip(); for (let k = 0; k < 7; k++) { ctx.strokeStyle = 'rgba(30,24,18,0.4)'; ctx.lineWidth = 3; ctx.beginPath(); for (let x = XA; x <= XB; x += 20) { const y = Math.max(gnd(x) + 40, plat + 160 + k * 110 + Math.sin(x * 0.004 + k) * 16); x === XA ? ctx.moveTo(x + ug, y) : ctx.lineTo(x + ug, y); } ctx.stroke(); } ctx.restore(); }
  // vegetación detrás del puente (apoyada en el terreno a su profundidad)
  if (o.trees !== false) { const R = H.rng(o.treeSeed || 11); for (let i = 0; i < 70; i++) { const x = R.range(XA + 100, XB - 100), k = R.range(1.4, KF), hh = R.range(45, 90); if (Math.abs(x - rx) < 200 || (k < 1.9 && piers.some((p) => Math.abs(x - p) < 90))) continue; const xx = x + ug + D[0] * k, y = gnd(x) + D[1] * k + 3; ctx.fillStyle = '#3a2f26'; ctx.fillRect(xx - 3, y - hh * 0.32, 6, hh * 0.32 + 2); ctx.fillStyle = R() < 0.5 ? '#425D50' : '#38524a'; ctx.beginPath(); ctx.moveTo(xx - hh * 0.28, y - hh * 0.28); ctx.lineTo(xx, y - hh); ctx.lineTo(xx + hh * 0.28, y - hh * 0.28); ctx.closePath(); ctx.fill(); } }
  // sombra del tablero sobre el fondo del valle (luz alta desde la izquierda)
  { const rel0 = cl(ud - ug, -gap0 + 3, gap0 - 3), a = x0 + SEAT, b = x1 - SEAT; ctx.save(); ctx.fillStyle = 'rgba(12,23,32,0.28)'; ctx.beginPath(); let first = true; for (let x = a; x <= b; x += 20) { const p = [x + rel0 + ug + 70 + D[0] * 0.1, gnd(x) + D[1] * 0.1]; first ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1]); first = false; } for (let x = b; x >= a; x -= 20) ctx.lineTo(x + rel0 + ug + 70 + D[0] * 1.05, gnd(x) + D[1] * 1.05); ctx.closePath(); ctx.fill(); ctx.restore(); }
  // estribos (fijos al terreno): muro frontal encajado en el talud, asiento, muro de guarda y losa de acceso sobre el terraplén
  const abut = (xa, dir) => { const xb = xa + ug, seatEnd = xb + dir * SEAT, yS = capTop, toe = Math.max(gnd(xa + dir * SEAT) + 50, yS + 150), back = xb - dir * 30, xs = [back, seatEnd].sort((p, q) => p - q), gx = dir > 0 ? xb - GW : xb;
   quad([[gx, top], [seatEnd, top], [seatEnd, yS], [gx, yS]], '#4a4136');
   quad([[xs[0], toe], [xs[1], toe], [xs[1], yS], [xs[0], yS]], SEC.hor); const fx = dir > 0 ? xs[1] : xs[0]; if (dir > 0) quad([[fx, yS], [fx + D[0], yS + D[1]], [fx + D[0], toe + D[1]], [fx, toe]], SEC.horD); quad([[xs[0], yS], [xs[1], yS], [xs[1] + D[0], yS + D[1]], [xs[0] + D[0], yS + D[1]]], SEC.horL);
   // muro de guarda y aleta (relleno contenido)
   quad([[gx, yS], [gx + GW, yS], [gx + GW, top + 4], [gx, top + 4]], SEC.horL); if (dir > 0) quad([[gx + GW, top + 4], [gx + GW + D[0], top + 4 + D[1]], [gx + GW + D[0], yS + D[1]], [gx + GW, yS]], SEC.horD);
   ctx.strokeStyle = 'rgba(30,36,40,0.35)'; ctx.lineWidth = 2; for (let y = yS + 30; y < toe; y += 34) { ctx.beginPath(); ctx.moveTo(xs[0], y); ctx.lineTo(xs[1], y); ctx.stroke(); }
   // losa de acceso con pretil
   const ra = dir > 0 ? xb - 1400 : xb, rb = dir > 0 ? xb : xb + 1400; quad([[ra, top], [rb, top], [rb + D[0], top + D[1]], [ra + D[0], top + D[1]]], '#4a5257'); quad([[ra, top], [rb, top], [rb, top + 18], [ra, top + 18]], SEC.horD);
   ctx.strokeStyle = 'rgba(240,240,220,0.7)'; ctx.setLineDash([26, 22]); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(ra + D[0] * 0.5, top + D[1] * 0.5); ctx.lineTo(rb + D[0] * 0.5, top + D[1] * 0.5); ctx.stroke(); ctx.setLineDash([]);
   rail(ra, rb, 0); rail(ra, rb, 1);
   return { seat: yS, guard: dir > 0 ? gx + GW : gx, xb, dir, seatEnd }; };
  // pretil de hormigón + baranda metálica a la profundidad u (0 = borde delantero, 1 = trasero)
  function rail(a, b, u) { const ox = D[0] * u, oy = D[1] * u; quad([[a + ox, top + oy], [b + ox, top + oy], [b + ox, top + oy - 12], [a + ox, top + oy - 12]], u ? '#8f999e' : SEC.horL); ctx.strokeStyle = SEC.aceroL; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(a + ox, top + oy - 26); ctx.lineTo(b + ox, top + oy - 26); ctx.stroke(); ctx.lineWidth = 2; for (let x = a; x <= b; x += 46) { ctx.beginPath(); ctx.moveTo(x + ox, top + oy - 12); ctx.lineTo(x + ox, top + oy - 26); ctx.stroke(); } }
  const A0 = abut(x0, 1), A1 = abut(x1, -1);
  // cimentaciones y pilas (la base sigue al terreno; la cabeza se desplaza up; la pila se flexiona como una ménsula)
  piers.forEach((px) => { const gb = gnd(px), bx = px + ug, tx = px + ug + up * (0.55 + 0.45 * cl((gb - capBot) / Math.max(1, gnd(rx) - capBot)));
   if (sec > 0) { ctx.save(); ctx.globalAlpha *= sec; ctx.fillStyle = SEC.horD; for (const ofx of [-48, -16, 16, 48]) ctx.fillRect(bx + ofx - 7, gb + 36, 14, 280); ctx.restore(); }
   const fb = Math.max(gb, gnd(px - 80), gnd(px + 80)) + 40, fd = 0.85; quad([[bx - 80, gb - 4], [bx + 80, gb - 4], [bx + 80 + D[0] * fd, gb - 4 + D[1] * fd], [bx - 80 + D[0] * fd, gb - 4 + D[1] * fd]], '#8a959a'); quad([[bx - 80, fb], [bx + 80, fb], [bx + 80, gb - 4], [bx - 80, gb - 4]], SEC.horD); quad([[bx + 80, gb - 4], [bx + 80 + D[0] * fd, gb - 4 + D[1] * fd], [bx + 80 + D[0] * fd, fb + D[1] * fd], [bx + 80, fb]], '#55626a');
   const N = 12, cd = 0.45, col = (s) => { const pts = []; for (let k = 0; k <= N; k++) { const u = k / N, y = lerp(gb - 4, capBot, u), dxu = (tx - bx) * (3 * u * u - 2 * u * u * u); pts.push([bx + dxu + s * colW / 2 + D[0] * 0.2, y + D[1] * 0.2]); } return pts; };
   const L = col(-1), Rr = col(1); quad([...Rr, ...Rr.slice().reverse().map(([x, y]) => [x + D[0] * cd, y + D[1] * cd])], '#7b878d'); const cg = ctx.createLinearGradient(bx - colW / 2, 0, bx + colW / 2, 0); cg.addColorStop(0, SEC.horD); cg.addColorStop(0.5, SEC.hor); cg.addColorStop(1, '#929da2'); quad([...L, ...Rr.slice().reverse()], cg);
   if (gl.piers) { ctx.strokeStyle = `rgba(255,212,71,${gl.piers})`; ctx.lineWidth = 4; ctx.beginPath(); L.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); Rr.slice().reverse().forEach((p) => ctx.lineTo(p[0], p[1])); ctx.closePath(); ctx.stroke(); }
   const dm = o.demand || 0; if (dm > 0) { const qb = [bx + D[0] * 0.2, gb - 30 + D[1] * 0.2]; P.glow(ctx, qb[0], qb[1], 90, '255,103,79', 0.55 * dm); ctx.strokeStyle = `rgba(255,103,79,${0.9 * dm})`; ctx.lineWidth = 2.5; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(qb[0] - colW / 2 + 6 + k * 14, gb - 8 + D[1] * 0.2); ctx.lineTo(qb[0] - colW / 2 + 12 + k * 14, gb - 30 - (k % 2) * 10 + D[1] * 0.2); ctx.stroke(); } }
   // cabezal: ocupa toda la anchura del tablero
   quad([[tx - capW / 2, capBot], [tx + capW / 2, capBot], [tx + capW / 2, capTop], [tx - capW / 2, capTop]], SEC.hor); quad([[tx + capW / 2, capTop], [tx + capW / 2 + D[0], capTop + D[1]], [tx + capW / 2 + D[0], capBot + D[1]], [tx + capW / 2, capBot]], SEC.horD); quad([[tx - capW / 2, capTop], [tx + capW / 2, capTop], [tx + capW / 2 + D[0], capTop + D[1]], [tx - capW / 2 + D[0], capTop + D[1]]], SEC.horL);
   // apoyos: una fila delantera y, en vistas de tres cuartos, una trasera (bajo cada viga)
   let bpt = null; const rows = wide ? [0.72, 0.18] : [0.12]; for (const u of rows) for (const ofx of [-30, 30]) { const cx = tx + ofx + D[0] * u, cyB = capTop + D[1] * u; if (iso) { const p = P.isolatorDetail(ctx, cx, cyB - bh / 2, bw * 0.95, bh, cl(ud - (tx - px), -bh * 0.5, bh * 0.5), t, { glow: gl.bearings, lead: true, layers: 5 }); if (ofx > 0 && u === rows[rows.length - 1]) bpt = p; } else { quad([[cx - 16, cyB], [cx + 16, cyB], [cx + 16, cyB - 14], [cx - 16, cyB - 14]], SEC.acero); quad([[cx - 10, cyB - 14], [cx + 10, cyB - 14], [cx + 10, cyB - 22], [cx - 10, cyB - 22]], SEC.aceroL); if (ofx > 0 && u === rows[rows.length - 1]) bpt = { top: [cx, cyB - 14], bottom: [cx, cyB] }; } }
   out.piers.push({ base: [bx + D[0] * 0.2, gb + D[1] * 0.2], top: [tx, capTop], cap: [tx, capBot] }); out.bearings.push(bpt);
   const fo = o.forces || 0; if (fo > 0) { const s = Math.sign(tx - bx || 1), mag = Math.min(1, Math.abs(tx - bx) / 14); ctx.save(); ctx.globalAlpha *= fo; P.hArrow(ctx, bx - s * 140, gb - 70, s * (60 + 90 * mag), SEC.fuerza, 18); P.hArrow(ctx, tx - s * 120, capBot + 34, s * (36 + 70 * mag), SEC.fuerza, 14); ctx.restore(); }
  });
  // tablero: losa de hormigón sobre vigas longitudinales (rigidizadores y diafragmas), que se desplaza ud
  const rel = cl(ud - ug, -gap0 + 3, gap0 - 3), dl = A0.guard + gap0 + rel, dr = A1.guard - gap0 + rel;
  for (const A of [A0, A1]) for (const u of (wide ? [0.7, 0.25] : [0.3])) { const cx = (A.dir > 0 ? A.guard + 150 : A.guard - 150) + D[0] * u, cyB = capTop + D[1] * u; if (iso) P.isolatorDetail(ctx, cx, cyB - bh / 2, bw * 0.95, bh, cl(ud - ug, -bh * 0.5, bh * 0.5), t, { glow: gl.bearings, lead: true, layers: 5 }); else quad([[cx - 16, cyB], [cx + 16, cyB], [cx + 16, cyB - 14], [cx - 16, cyB - 14]], SEC.acero); }
  ctx.save(); ctx.globalAlpha *= 1 - xr * 0.65;
  // vigas (retranqueadas respecto al borde de la losa) y vuelo de la losa
  const gi = 0.1, gx0 = dl + D[0] * gi, gx1 = dr + D[0] * gi, gy0 = top + ds + D[1] * gi, gy1 = deckBot + D[1] * gi; quad([[gx0, gy0], [gx1, gy0], [gx1, gy1], [gx0, gy1]], '#6c7a82'); quad([[gx1, gy0], [gx1 + D[0] * 0.8, gy0 + D[1] * 0.8], [gx1 + D[0] * 0.8, gy1 + D[1] * 0.8], [gx1, gy1]], '#56636a');
  ctx.strokeStyle = 'rgba(196,208,213,0.45)'; ctx.lineWidth = 2; for (let x = gx0 + 26; x < gx1; x += 52) { ctx.beginPath(); ctx.moveTo(x, gy0 + 3); ctx.lineTo(x, gy1 - 4); ctx.stroke(); } ctx.fillStyle = '#56636a'; ctx.fillRect(gx0, gy1 - 6, gx1 - gx0, 6);
  for (const px of piers) { const xx = px + ud + D[0] * gi; ctx.fillStyle = '#4d5960'; ctx.fillRect(xx - 6, gy0, 12, gy1 - gy0); }
  // calzada (cara superior) con líneas de carril
  quad([[dl, top], [dr, top], [dr + D[0], top + D[1]], [dl + D[0], top + D[1]]], '#4a5257');
  ctx.strokeStyle = 'rgba(240,240,220,0.7)'; ctx.lineWidth = 3; ctx.setLineDash([26, 22]); ctx.beginPath(); ctx.moveTo(dl + D[0] * 0.5, top + D[1] * 0.5); ctx.lineTo(dr + D[0] * 0.5, top + D[1] * 0.5); ctx.stroke(); ctx.setLineDash([]); if (wide) { ctx.strokeStyle = 'rgba(240,240,220,0.45)'; ctx.lineWidth = 2; for (const u of [0.1, 0.9]) { ctx.beginPath(); ctx.moveTo(dl + D[0] * u, top + D[1] * u); ctx.lineTo(dr + D[0] * u, top + D[1] * u); ctx.stroke(); } }
  for (const c of o.cars || []) { const span = dr - dl - 80, cx = dl + ((c.x % span) + span) % span + 40; P.car(ctx, cx + D[0] * (c.lane ?? 0.35), top + D[1] * (c.lane ?? 0.35) + 1, 46, c.c); }
  // canto de la losa (cara frontal) con juntas de dovelas
  const dg = ctx.createLinearGradient(0, top, 0, top + ds); dg.addColorStop(0, SEC.horL); dg.addColorStop(1, SEC.hor); quad([[dl, top], [dr, top], [dr, top + ds], [dl, top + ds]], dg); ctx.fillStyle = 'rgba(12,23,32,0.35)'; ctx.fillRect(dl, top + ds, dr - dl, 4);
  quad([[dr, top], [dr + D[0], top + D[1]], [dr + D[0], top + ds + D[1]], [dr, top + ds]], SEC.horD);
  ctx.strokeStyle = 'rgba(30,36,40,0.35)'; ctx.lineWidth = 2; for (let x = dl + 220; x < dr; x += 220) { ctx.beginPath(); ctx.moveTo(x, top + 2); ctx.lineTo(x, top + ds - 2); ctx.stroke(); }
  rail(dl, dr, 1); rail(dl, dr, 0);
  if (gl.deck) { ctx.strokeStyle = `rgba(255,212,71,${gl.deck})`; ctx.lineWidth = 4; ctx.strokeRect(dl, top - 26, dr - dl, dh + 26); }
  ctx.restore();
  if (xr > 0) { ctx.save(); ctx.globalAlpha *= xr; ctx.strokeStyle = SEC.aceroL; ctx.lineWidth = 3; ctx.strokeRect(dl, top, dr - dl, dh); ctx.strokeStyle = 'rgba(196,208,213,0.6)'; for (let x = dl + 55; x < dr; x += 110) { ctx.beginPath(); ctx.moveTo(x, top + ds); ctx.lineTo(x + 50, deckBot - 4); ctx.stroke(); } ctx.restore(); }
  // juntas de dilatación: peines sobre la calzada; bajo la losa se ve el muro de guarda (no un agujero)
  const jL = dl - A0.guard, jR = A1.guard - dr; out.joints.push({ x: (dl + A0.guard) / 2, y: top + 6, gap: jL }, { x: (dr + A1.guard) / 2, y: top + 6, gap: jR });
  for (const [j, ga, gb2] of [[out.joints[0], A0.guard, dl], [out.joints[1], dr, A1.guard]]) { const n = 8, Lt = gap0 * 0.85, sk = (xa, xb, u0, u1, c) => quad([[xa + D[0] * u0, top + D[1] * u0], [xb + D[0] * u0, top + D[1] * u0], [xb + D[0] * u1, top + D[1] * u1], [xa + D[0] * u1, top + D[1] * u1]], c);
   sk(ga, gb2, 0, 1, '#2a3034'); sk(ga - 14, ga, 0, 1, '#7d8a91'); sk(gb2, gb2 + 14, 0, 1, '#7d8a91'); for (let k = 0; k < 2 * n; k++) { const u0 = k / (2 * n) + 0.01, u1 = (k + 1) / (2 * n) - 0.01; if (k % 2) sk(ga - 6, ga + Lt, u0, u1, SEC.aceroL); else sk(gb2 - Lt, gb2 + 6, u0, u1, '#a9b8bf'); }
   ctx.fillStyle = '#56626a'; ctx.fillRect(ga, top, gb2 - ga, ds); ctx.strokeStyle = '#20262a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(ga, top + 6); ctx.quadraticCurveTo((ga + gb2) / 2, top + 6 + Math.max(2, (gb2 - ga) * 0.25), gb2, top + 6); ctx.stroke();
   if (gl.joints) { ctx.strokeStyle = `rgba(56,198,208,${gl.joints})`; ctx.lineWidth = 3; ctx.strokeRect(ga - 16, top + D[1] - 6, gb2 - ga + 32 + D[0], ds - D[1] + 12); } }
  // disipadores viscosos en los estribos: del asiento del estribo (fijo) a una ménsula bajo el extremo del tablero
  for (const [A, dir] of [[A0, 1], [A1, -1]]) { const ya = capTop - bh * 0.5, ax = A.guard + dir * 4, bx2 = (dir > 0 ? dl : dr) + dir * 86, L0 = 82 + gap0;
   ctx.fillStyle = SEC.acero; ctx.fillRect(ax - (dir > 0 ? 10 : 0), ya - 12, 10, 24); ctx.fillRect(bx2 - 7, deckBot - 2, 14, ya - deckBot + 12);
   const p = P.damperDetail(ctx, [ax, ya], [bx2, ya], t, { cut: o.cut || 0, heat: o.heat || 0, vel: (o.vel || 0) * dir, body: L0 * 0.62, rod: L0 * 0.58, r: bh * 0.3 }); if (gl.dampers) { ctx.strokeStyle = `rgba(217,163,92,${gl.dampers})`; ctx.lineWidth = 3; ctx.strokeRect(Math.min(ax, bx2) - 8, ya - 16, Math.abs(bx2 - ax) + 16, 32); } out.dampers.push(p); }
  // terreno cercano (delante de las zapatas): las cimentaciones quedan enterradas, nunca flotando
  if (sec < 1) { ctx.save(); ctx.globalAlpha *= 1 - sec; const a = x0 + SEAT + 4, b = x1 - SEAT - 4, p = [...prof(0, a, b)]; ctx.fillStyle = '#5c5246'; ctx.beginPath(); ctx.moveTo(p[0][0], 3200); p.forEach((q) => ctx.lineTo(q[0], q[1])); ctx.lineTo(p[p.length - 1][0], 3200); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(66,93,80,0.8)'; ctx.lineWidth = 12; ctx.beginPath(); p.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1] - 3) : ctx.moveTo(q[0], q[1] - 3))); ctx.stroke(); ctx.restore(); }
  ctx.restore();
  return out;
 };
 // ---------------- v1.15.1 · primeros planos mecánicos (misma pieza que en el puente, a escala de detalle) ----------------
 // Aislador elastomérico con núcleo de plomo (LRB) en 2,5D con su contexto: viga del tablero arriba y cabezal de pila abajo.
 // (cx, cy) centro del cuerpo; s = diámetro. o: { base (desplazamiento de la placa inferior = subestructura), top (placa superior = tablero),
 //   cut 0..1 (corte axial que muestra capas y núcleo), n (capas de caucho), glow, ctxDeck, ctxCap }
 // El núcleo de plomo se deforma por cortante con las capas (paralelogramo); no es un pistón.
 P.isolatorHD = (ctx, cx, cy, s, t, o = {}) => {
  const r = s / 2, ry = r * 0.26, Hh = s * 0.62, pt = s * 0.075, pw = s * 1.32, n = o.n ?? 8, b0 = o.base || 0, b1 = o.top ?? b0, cut = o.cut || 0, gl = o.glow || 0;
  const yB = cy + Hh / 2, yT = cy - Hh / 2, xs = (u) => cx + lerp(b0, b1, u), ys = (u) => lerp(yB, yT, u);
  const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  // caja 2,5D (cara frontal + cara superior en perspectiva leve)
  const box = (x, y, w, h, dep, cF, cT) => { const k = dep * 0.18; quad([[x - w / 2, y], [x + w / 2, y], [x + w / 2 - k, y - dep], [x - w / 2 + k, y - dep]], cT); quad([[x - w / 2, y], [x + w / 2, y], [x + w / 2, y + h], [x - w / 2, y + h]], cF); };
  ctx.save();
  // cabezal de pila (contexto, se mueve con la subestructura)
  if (o.ctxCap !== false) { const xc = cx + b0, yc = yB + pt; box(xc, yc, s * 3.4, s * 1.4, ry * 2.6, (() => { const g = ctx.createLinearGradient(0, yc, 0, yc + s * 1.4); g.addColorStop(0, SEC.hor); g.addColorStop(1, SEC.horD); return g; })(), SEC.horL); ctx.strokeStyle = 'rgba(30,36,40,0.25)'; ctx.lineWidth = 2; for (let y = yc + s * 0.35; y < yc + s * 1.4; y += s * 0.35) { ctx.beginPath(); ctx.moveTo(xc - s * 1.7, y); ctx.lineTo(xc + s * 1.7, y); ctx.stroke(); } }
  // placa inferior anclada al cabezal (pernos de anclaje)
  const plate = (x, y, top) => { box(x, y - pt, pw, pt, ry * 2.1, SEC.acero, '#7d8f9a'); ctx.fillStyle = SEC.aceroL; for (const fx of [-0.42, 0.42]) { const bx = x + pw * fx; ctx.fillRect(bx - s * 0.035, top ? y - pt - s * 0.03 : y - pt - s * 0.05, s * 0.07, s * 0.05); ctx.fillStyle = '#3d4a52'; ctx.fillRect(bx - s * 0.012, top ? y - pt - s * 0.09 : y - pt - s * 0.07, s * 0.024, s * 0.03); ctx.fillStyle = SEC.aceroL; } };
  plate(cx + b0, yB + pt, false);
  // anclajes embebidos (visibles en corte)
  if (cut > 0) { ctx.save(); ctx.globalAlpha *= cut; ctx.strokeStyle = '#3d4a52'; ctx.lineWidth = s * 0.03; for (const fx of [-0.42, 0.42]) { ctx.beginPath(); ctx.moveTo(cx + b0 + pw * fx, yB + pt); ctx.lineTo(cx + b0 + pw * fx, yB + pt + s * 0.5); ctx.stroke(); } ctx.restore(); }
  // cuerpo: capas de caucho y láminas de acero (bandas frontales de un cilindro que se corta lateralmente)
  const tr = 1 / (n + (n - 1) * 0.28), ts = tr * 0.28; let u = 0; const bands = [];
  for (let i = 0; i < n; i++) { bands.push([u, u + tr, 'r']); u += tr; if (i < n - 1) { bands.push([u, u + ts, 's']); u += ts; } }
  const band = (u0, u1, fill) => { const xa = xs(u0), xb = xs(u1), ya = ys(u0), yb = ys(u1); ctx.beginPath(); ctx.moveTo(xa - r, ya); ctx.ellipse(xa, ya, r, ry, 0, Math.PI, 0, true); ctx.lineTo(xb + r, yb); ctx.ellipse(xb, yb, r, ry, 0, 0, Math.PI, false); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); };
  for (const [u0, u1, k] of bands) { const g = ctx.createLinearGradient(xs(u0) - r, 0, xs(u0) + r, 0); if (k === 'r') { g.addColorStop(0, '#22292c'); g.addColorStop(0.45, gl ? '#4a565c' : '#3e484d'); g.addColorStop(1, '#1d2326'); } else { g.addColorStop(0, '#6f818c'); g.addColorStop(0.45, '#d5dfe3'); g.addColorStop(1, '#5d6d77'); } band(u0, u1, g); }
  // corte axial: capas en sección y núcleo de plomo central
  if (cut > 0) { ctx.save(); ctx.globalAlpha *= cut; const sx = (u, f) => xs(u) + r * f; for (const [u0, u1, k] of bands) quad([[sx(u0, -1), ys(u0)], [sx(u0, 1), ys(u0)], [sx(u1, 1), ys(u1)], [sx(u1, -1), ys(u1)]], k === 'r' ? '#363f44' : '#c4d0d5');
   ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; for (const [u0, u1, k] of bands) if (k === 'r') for (let f = -0.9; f < 0.9; f += 0.16) { ctx.beginPath(); ctx.moveTo(sx(u0, f), ys(u0)); ctx.lineTo(sx(u1, f + 0.08), ys(u1)); ctx.stroke(); }
   const lw = 0.13; const lg = ctx.createLinearGradient(cx - r * lw, 0, cx + r * lw, 0); lg.addColorStop(0, '#7f878d'); lg.addColorStop(0.5, '#b2bac0'); lg.addColorStop(1, '#757d83'); quad([[sx(0, -lw), ys(0)], [sx(0, lw), ys(0)], [sx(1, lw), ys(1)], [sx(1, -lw), ys(1)]], lg);
   ctx.restore(); }
  // borde abombado del caucho
  ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = Math.max(1, s * 0.008); ctx.beginPath(); ctx.moveTo(xs(0) - r, ys(0)); ctx.quadraticCurveTo(xs(0.5) - r * 1.04, ys(0.5), xs(1) - r, ys(1)); ctx.moveTo(xs(0) + r, ys(0)); ctx.quadraticCurveTo(xs(0.5) + r * 1.04, ys(0.5), xs(1) + r, ys(1)); ctx.stroke();
  // placa superior unida al tablero
  plate(cx + b1, yT, true);
  // ala inferior de la viga del tablero + alma + rigidizador sobre el apoyo (contexto, se mueve con el tablero)
  if (o.ctxDeck !== false) { const xd = cx + b1, yf = yT - pt, wd = s * 3.4; box(xd, yf - s * 0.1, wd, s * 0.1, ry * 1.6, '#5d6b73', '#8696a0'); const wg = ctx.createLinearGradient(0, yf - s * 1.1, 0, yf - s * 0.1); wg.addColorStop(0, '#7d8b93'); wg.addColorStop(1, '#5f6d75'); ctx.fillStyle = wg; ctx.fillRect(xd - wd / 2, yf - s * 1.1, wd, s * 1.0); ctx.fillStyle = '#4d5960'; for (const fx of [-0.42, -0.3, 0.3, 0.42]) ctx.fillRect(xd + s * fx - s * 0.025, yf - s * 1.1, s * 0.05, s * 1.0); ctx.strokeStyle = 'rgba(196,208,213,0.35)'; ctx.lineWidth = 2; for (let x = xd - wd / 2 + s * 0.4; x < xd + wd / 2; x += s * 0.55) if (Math.abs(x - xd) > s * 0.5) { ctx.beginPath(); ctx.moveTo(x, yf - s * 1.08); ctx.lineTo(x, yf - s * 0.12); ctx.stroke(); } ctx.fillStyle = '#5d6b73'; ctx.fillRect(xd - wd / 2, yf - s * 1.2, wd, s * 0.1); box(xd, yf - s * 1.52, wd * 1.08, s * 0.32, ry * 1.6, SEC.hor, SEC.horL); }
  if (gl) { ctx.strokeStyle = `rgba(56,198,208,${gl})`; ctx.lineWidth = Math.max(3, s * 0.02); ctx.beginPath(); ctx.moveTo(xs(0) - r * 1.12, ys(0) + ry * 1.2); ctx.lineTo(xs(0) + r * 1.12, ys(0) + ry * 1.2); ctx.lineTo(xs(1) + r * 1.12, ys(1) - ry * 1.2); ctx.lineTo(xs(1) - r * 1.12, ys(1) - ry * 1.2); ctx.closePath(); ctx.stroke(); }
  ctx.restore();
  return { topPlate: [cx + b1 + pw * 0.3, yT - pt * 0.5], bottomPlate: [cx + b0 - pw * 0.3, yB + pt * 0.5], rubber: [xs(0.48) - r * 0.75, ys(0.48)], shim: [xs(0.62) + r * 0.6, ys(0.62)], lead: [xs(0.5), ys(0.5)], bolt: [cx + b0 + pw * 0.42, yB - s * 0.02], deck: [cx + b1 - s * 1.2, yT - pt - s * 0.7], cap: [cx + b0 - s * 1.3, yB + pt + s * 0.7] };
 };
 // Disipador viscoso en detalle: placa de anclaje atornillada al estribo, articulaciones (rótulas/pasadores), cilindro con dos cámaras,
 // pistón con orificios y vástago unido a una ménsula del tablero. (ax, ay) pasador fijo; bx = pasador móvil (misma altura). s = diámetro.
 // o: { cut 0..1, vel (−1..1, velocidad relativa), heat 0..1, force (0..1 resistencia), cyl, rod, wall, girder }
 P.damperHD = (ctx, ax, ay, bx, s, t, o = {}) => {
  const r = s / 2, L = bx - ax, cyl = o.cyl ?? s * 4.4, rodL = o.rod ?? s * 3.8, c0 = ax + s * 0.75, c1 = c0 + cyl, pist = cl(bx - rodL, c0 + s * 0.35, c1 - s * 0.35), cut = o.cut || 0, v = o.vel || 0, heat = cl(o.heat || 0);
  const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  const metal = (y0, y1, a, b, c) => { const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, a); g.addColorStop(0.35, b); g.addColorStop(1, c); return g; };
  ctx.save();
  // estribo (contexto fijo) y placa de anclaje con pernos
  const wx = ax - s * 1.25; if (o.wall !== false) { const g = ctx.createLinearGradient(wx - s * 3, 0, wx, 0); g.addColorStop(0, SEC.horD); g.addColorStop(1, SEC.hor); ctx.fillStyle = g; ctx.fillRect(wx - s * 4, ay - s * 3.2, s * 4, s * 6.4); }
  quad([[wx, ay - s * 1.3], [wx + s * 0.28, ay - s * 1.3], [wx + s * 0.28, ay + s * 1.3], [wx, ay + s * 1.3]], SEC.acero); for (const dy of [-1, 1]) { ctx.fillStyle = SEC.aceroL; ctx.beginPath(); ctx.arc(wx + s * 0.14, ay + dy * s * 1.0, s * 0.08, 0, TAU); ctx.fill(); }
  quad([[wx + s * 0.28, ay - s * 0.5], [ax, ay - s * 0.42], [ax, ay + s * 0.42], [wx + s * 0.28, ay + s * 0.5]], '#66798a');
  // tablero (contexto móvil): ala de viga y ménsula atornillada que baja hasta el pasador móvil
  if (o.girder !== false) { quad([[bx - s * 3, ay - s * 2.5], [bx + s * 3, ay - s * 2.5], [bx + s * 3, ay - s * 2.2], [bx - s * 3, ay - s * 2.2]], '#6c7a82'); ctx.fillStyle = '#5d6b73'; ctx.fillRect(bx - s * 3, ay - s * 3.4, s * 6, s * 0.9); ctx.fillStyle = SEC.horL; ctx.fillRect(bx - s * 3, ay - s * 3.6, s * 6, s * 0.22); }
  quad([[bx - s * 0.32, ay - s * 2.2], [bx + s * 0.32, ay - s * 2.2], [bx + s * 0.2, ay], [bx - s * 0.2, ay]], '#66798a'); ctx.fillStyle = SEC.aceroL; for (const dx of [-0.16, 0.16]) { ctx.beginPath(); ctx.arc(bx + dx * s, ay - s * 2.05, s * 0.06, 0, TAU); ctx.fill(); }
  // vástago cromado
  ctx.fillStyle = metal(ay - r * 0.24, ay + r * 0.24, '#9fb0b8', '#f2f6f7', '#7a8b94'); ctx.fillRect(pist, ay - r * 0.24, bx - s * 0.3 - pist, r * 0.48);
  // cilindro con tapas
  ctx.fillStyle = metal(ay - r, ay + r, '#6f818c', '#c6d2d7', '#44535d'); ctx.beginPath(); ctx.roundRect(c0, ay - r, cyl, 2 * r, r * 0.25); ctx.fill(); ctx.fillStyle = metal(ay - r * 1.08, ay + r * 1.08, '#56656f', '#9fb0b8', '#3b4851'); ctx.fillRect(c0 - s * 0.05, ay - r * 1.08, s * 0.16, r * 2.16); ctx.fillRect(c1 - s * 0.11, ay - r * 1.08, s * 0.16, r * 2.16);
  // corte: cámaras con fluido, pistón con orificios, flujo esquemático en sentido contrario al pistón, calor (parte de la energía)
  if (cut > 0) { ctx.save(); ctx.globalAlpha *= cut; const ix0 = c0 + s * 0.12, ix1 = c1 - s * 0.12, ir = r * 0.78; const hc = `rgb(${Math.round(217 + 30 * heat)},${Math.round(163 - 55 * heat)},${Math.round(92 - 45 * heat)})`; const fg = ctx.createLinearGradient(0, ay - ir, 0, ay + ir); fg.addColorStop(0, hc); fg.addColorStop(1, '#b07a3c'); ctx.fillStyle = fg; ctx.fillRect(ix0, ay - ir, ix1 - ix0, ir * 2);
   ctx.fillStyle = metal(ay - ir, ay + ir, '#9fb0b8', '#e8eef0', '#7a8b94'); ctx.fillRect(pist - s * 0.11, ay - ir, s * 0.22, ir * 2); ctx.fillStyle = '#1d2326'; for (const oy of [-0.5, 0.5]) ctx.fillRect(pist - s * 0.11, ay + oy * ir - s * 0.03, s * 0.22, s * 0.06); ctx.fillStyle = '#2e3a40'; ctx.fillRect(pist - s * 0.12, ay - ir, s * 0.02, ir * 2); ctx.fillRect(pist + s * 0.1, ay - ir, s * 0.02, ir * 2);
   if (Math.abs(v) > 0.04) { const d = -Math.sign(v); ctx.strokeStyle = 'rgba(255,245,225,0.9)'; ctx.lineWidth = Math.max(2, s * 0.025); ctx.lineCap = 'round'; for (const oy of [-0.5, 0.5]) for (let k = 0; k < 3; k++) { const ph = ((t * (1.5 + 2.5 * Math.abs(v)) + k / 3) % 1); const xx = pist + d * s * (0.15 + ph * 0.8); if (xx < ix0 + s * 0.05 || xx > ix1 - s * 0.05) continue; ctx.beginPath(); ctx.moveTo(xx, ay + oy * ir); ctx.lineTo(xx + d * s * 0.16, ay + oy * ir); ctx.lineTo(xx + d * s * 0.1, ay + oy * ir - s * 0.05); ctx.moveTo(xx + d * s * 0.16, ay + oy * ir); ctx.lineTo(xx + d * s * 0.1, ay + oy * ir + s * 0.05); ctx.stroke(); } }
   if (heat > 0.03) P.glow(ctx, pist, ay, s * 1.6, '255,128,64', 0.42 * heat); ctx.restore(); }
  ctx.strokeStyle = 'rgba(20,24,28,0.6)'; ctx.lineWidth = Math.max(1, s * 0.02); ctx.beginPath(); ctx.roundRect(c0, ay - r, cyl, 2 * r, r * 0.25); ctx.stroke();
  // articulaciones (horquilla + pasador) en ambos extremos
  for (const [x, ear] of [[ax, c0], [bx, null]]) { quad([[x - s * 0.36, ay - s * 0.36], [x + s * 0.36, ay - s * 0.36], [x + s * 0.36, ay + s * 0.36], [x - s * 0.36, ay + s * 0.36]], '#56656f'); ctx.fillStyle = metal(ay - s * 0.16, ay + s * 0.16, '#c4d0d5', '#ffffff', '#8e9fa8'); ctx.beginPath(); ctx.arc(x, ay, s * 0.16, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2e3a40'; ctx.lineWidth = Math.max(1, s * 0.02); ctx.stroke(); if (ear) { ctx.fillStyle = '#66798a'; ctx.fillRect(x + s * 0.36, ay - s * 0.22, ear - x - s * 0.36, s * 0.44); } }
  // resistencia: fuerza del disipador contra el movimiento relativo (cualitativa, ∝ |v|^0,5)
  const f = o.force ?? 0; if (f > 0 && Math.abs(v) > 0.05) { ctx.save(); ctx.globalAlpha *= f; P.hArrow(ctx, bx + Math.sign(v) * s * 0.6, ay + s * 1.25, -Math.sign(v) * s * (0.6 + 1.6 * Math.sqrt(Math.abs(v))), SEC.fuerza, s * 0.2); ctx.restore(); }
  ctx.restore();
  return { cyl: [c0 + cyl * 0.75, ay - r], rod: [(pist + bx) / 2, ay], piston: [pist, ay], fluid: [(c0 + pist) / 2, ay + r * 0.4], pinA: [ax, ay], pinB: [bx, ay], plateA: [wx + s * 0.14, ay + s * 1.2], bracketB: [bx, ay - s * 1.6], force: [bx, ay + s * 1.25] };
 };
 // Vista desde la calzada (perspectiva con punto de fuga): carriles, pretiles, farolas y una junta de peines a la profundidad jz.
 // o: { vy (horizonte), gap (abertura en unidades de calzada; la capacidad es la longitud de los dientes), cars:[{X, z, c, front}], shake, glow, dusk }
 P.roadView = (ctx, t, o = {}) => {
  const vy = o.vy ?? 760, F = 760, cxp = 540 + (o.shake || 0), pr = (X, z, h = 0) => [cxp + X * F / z, vy + (1920 - vy) / z - h * F / z];
  const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  ctx.save();
  // valle a ambos lados (bajo el horizonte) y cordillera lejana
  const vg = ctx.createLinearGradient(0, vy, 0, 1920); vg.addColorStop(0, o.dusk ? '#4d5560' : '#3d4f55'); vg.addColorStop(1, '#5c5246'); ctx.fillStyle = vg; ctx.fillRect(0, vy, 1080, 1920 - vy);
  ctx.fillStyle = o.dusk ? '#2a3a48' : '#203b4c'; ctx.beginPath(); ctx.moveTo(0, vy + 2); for (let x = 0; x <= 1080; x += 30) ctx.lineTo(x, vy - 40 - 50 * Math.abs(Math.sin(x * 0.006 + 1)) - 20 * Math.sin(x * 0.021)); ctx.lineTo(1080, vy + 2); ctx.closePath(); ctx.fill();
  const z0 = 0.92, zf = 80, jz = o.jz ?? 3.2, g = o.gap ?? 0.07, Lf = o.finger ?? 0.16;
  // tablero (cerca) y estribo/acceso (más allá de la junta)
  quad([pr(-1, z0), pr(1, z0), pr(1, zf), pr(-1, zf)], '#4a5257');
  quad([pr(-1.22, z0), pr(-1, z0), pr(-1, zf), pr(-1.22, zf)], '#7f8a90'); quad([pr(1, z0), pr(1.22, z0), pr(1.22, zf), pr(1, zf)], '#7f8a90');
  for (const sgn of [-1, 1]) { quad([pr(sgn * 1.0, z0, 0), pr(sgn * 1.0, zf, 0), pr(sgn * 1.0, zf, 0.12), pr(sgn * 1.0, z0, 0.12)], sgn < 0 ? '#a7b0b4' : '#8e989d'); ctx.strokeStyle = SEC.aceroL; ctx.lineWidth = 3; ctx.beginPath(); for (let z = z0; z < 40; z *= 1.0) { const a = pr(sgn * 1.0, z, 0.26); z === z0 ? ctx.moveTo(a[0], a[1]) : ctx.lineTo(a[0], a[1]); z += 0.5; } ctx.stroke(); for (let z = 1; z < 30; z += 0.7) { const a = pr(sgn * 1.0, z, 0.12), b = pr(sgn * 1.0, z, 0.26); ctx.lineWidth = Math.max(1, 6 / z); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } for (let z = 1.6; z < 40; z += 3.5) { const a = pr(sgn * 1.12, z, 0.12), b = pr(sgn * 1.12, z, 1.0), c = pr(sgn * 0.92, z, 1.0); ctx.strokeStyle = '#8b979d'; ctx.lineWidth = Math.max(1, 10 / z); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.stroke(); if (o.dusk) P.glow(ctx, c[0], c[1] + 4, 60 / z * 3, '255,220,160', 0.35); } }
  // líneas de carril
  ctx.fillStyle = 'rgba(240,240,220,0.8)'; for (let z = z0 + ((t * (o.speed ?? 0)) % 1.2); z < 40; z += 1.2) { const a = pr(-0.02, z), b = pr(0.02, z), c = pr(0.02, z + 0.6), d = pr(-0.02, z + 0.6); quad([a, b, c, d], 'rgba(240,240,220,0.8)'); }
  for (const X of [-0.94, 0.94]) { ctx.strokeStyle = 'rgba(240,240,220,0.6)'; ctx.lineWidth = 3; const a = pr(X, z0), b = pr(X, zf); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  // junta de peines: hueco oscuro, dientes del tablero (cerca) y del estribo (lejos) que se solapan mientras g < Lf
  const zA = jz, zB = jz + g; quad([pr(-1, zA - 0.12), pr(1, zA - 0.12), pr(1, zA), pr(-1, zA)], '#8796a0'); quad([pr(-1, zB), pr(1, zB), pr(1, zB + 0.12), pr(-1, zB + 0.12)], '#8796a0'); quad([pr(-1, zA), pr(1, zA), pr(1, zB), pr(-1, zB)], '#14181b');
  const nf = 20; for (let i = 0; i < nf; i++) { const X0 = -1 + (2 * i) / nf + 0.012, X1 = -1 + (2 * (i + 1)) / nf - 0.012; if (i % 2) quad([pr(X0, zA), pr(X1, zA), pr(X1, zA + Lf), pr(X0, zA + Lf)], '#b8c6cc'); else quad([pr(X0, zB - Lf), pr(X1, zB - Lf), pr(X1, zB), pr(X0, zB)], '#9fb0b8'); }
  if (o.glow) { ctx.strokeStyle = `rgba(56,198,208,${o.glow})`; ctx.lineWidth = 4; const a = pr(-1.04, zA - 0.16), b = pr(1.04, zA - 0.16), c = pr(1.04, zB + 0.16), d = pr(-1.04, zB + 0.16); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.closePath(); ctx.stroke(); }
  // vehículos (de lejos a cerca): traseras (alejándose) o frontales (acercándose)
  for (const c of (o.cars || []).slice().sort((p, q) => q.z - p.z)) { if (c.z < z0 + 0.05 || c.z > 40) continue; const w = 0.34, h = 0.24, a = pr(c.X - w, c.z), b = pr(c.X + w, c.z, h); const W = b[0] - a[0], Hh = a[1] - b[1]; ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(a[0] - W * 0.04, a[1] - Hh * 0.08, W * 1.08, Hh * 0.12); ctx.fillStyle = c.c; ctx.beginPath(); ctx.roundRect(a[0], a[1] - Hh * 0.7, W, Hh * 0.62, W * 0.06); ctx.fill(); ctx.beginPath(); ctx.roundRect(a[0] + W * 0.14, a[1] - Hh, W * 0.72, Hh * 0.36, W * 0.08); ctx.fill(); ctx.fillStyle = 'rgba(30,40,50,0.8)'; ctx.fillRect(a[0] + W * 0.2, a[1] - Hh * 0.94, W * 0.6, Hh * 0.26); ctx.fillStyle = c.front ? '#fff6d8' : '#ff4a3a'; ctx.fillRect(a[0] + W * 0.05, a[1] - Hh * 0.5, W * 0.16, Hh * 0.1); ctx.fillRect(a[0] + W * 0.79, a[1] - Hh * 0.5, W * 0.16, Hh * 0.1); if (c.front) { P.glow(ctx, a[0] + W * 0.13, a[1] - Hh * 0.45, W * 0.5, '255,240,200', 0.3); P.glow(ctx, a[0] + W * 0.87, a[1] - Hh * 0.45, W * 0.5, '255,240,200', 0.3); } ctx.fillStyle = '#15191c'; ctx.fillRect(a[0] + W * 0.06, a[1] - Hh * 0.1, W * 0.18, Hh * 0.1); ctx.fillRect(a[0] + W * 0.76, a[1] - Hh * 0.1, W * 0.18, Hh * 0.1); }
  ctx.restore();
  const jp = pr(0.5, jz + g / 2); return { joint: jp, jointL: pr(-0.5, jz + g / 2), gapPx: pr(0, zA)[1] - pr(0, zB)[1], pr };
 };
 // Corte transversal por una pila: tablero (losa + 4 vigas + pretiles), apoyos, cabezal, fuste, zapata, pilotes y estratos.
 // (cx, gy) = eje y nivel del terreno; s = escala. o: { ug, up, ud (desplazamientos laterales), flow 0..1 (camino de cargas), hl:{deck, bearings, column, foundation}, iso }
 P.bridgeSection = (ctx, cx, gy, s, t, o = {}) => {
  const ug = o.ug || 0, up = o.up || 0, ud = o.ud ?? ug + up, hl = o.hl || {}, colH = s * 4.0, fH = s * 0.6, capH = s * 0.7, bH = s * 0.32, gH = s * 0.7, slab = s * 0.24;
  const quad = (pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  const hlS = (pts, a, c = '255,212,71') => { if (!a) return; ctx.strokeStyle = `rgba(${c},${a})`; ctx.lineWidth = 5; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke(); };
  ctx.save();
  // estratos (se mueven con el suelo)
  const bands = ['#7c6d5b', '#6e604f', '#625545', '#55493b']; bands.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(-200, gy + i * s * 1.3, 1480, s * 1.3 + 2); }); ctx.strokeStyle = 'rgba(30,24,18,0.35)'; ctx.lineWidth = 3; for (let i = 1; i < 4; i++) { ctx.beginPath(); for (let x = -200; x <= 1280; x += 30) { const y = gy + i * s * 1.3 + Math.sin((x - ug) * 0.01 + i) * 8; x === -200 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke(); }
  ctx.fillStyle = '#425D50'; ctx.fillRect(-200, gy - 6, 1480, 12);
  const bx = cx + ug, fy = gy + s * 0.15;
  // pilotes y zapata enterrados
  ctx.fillStyle = SEC.horD; for (const f of [-1.1, 0, 1.1]) ctx.fillRect(bx + f * s - s * 0.17, fy + fH, s * 0.34, s * 3.6);
  quad([[bx - s * 1.6, fy], [bx + s * 1.6, fy], [bx + s * 1.6, fy + fH], [bx - s * 1.6, fy + fH]], '#7d888d');
  hlS([[bx - s * 1.6, fy], [bx + s * 1.6, fy], [bx + s * 1.6, fy + fH + s * 3.6], [bx - s * 1.6, fy + fH + s * 3.6]], hl.foundation);
  // fuste (flexión de ménsula moderada) y cabezal en martillo
  const yTop = fy - colH, N = 10, pts = (sg) => { const a = []; for (let k = 0; k <= N; k++) { const u = k / N, y = lerp(fy, yTop, u); a.push([bx + up * (3 * u * u - 2 * u * u * u) + sg * s * 0.38, y]); } return a; }; const Lc = pts(-1), Rc = pts(1); const cg = ctx.createLinearGradient(bx - s * 0.4, 0, bx + s * 0.4, 0); cg.addColorStop(0, SEC.horD); cg.addColorStop(0.5, SEC.hor); cg.addColorStop(1, '#8c979c'); quad([...Lc, ...Rc.slice().reverse()], cg); hlS([...Lc, ...Rc.slice().reverse()], hl.column);
  const tx = bx + up, cB = yTop, cT = yTop - capH; quad([[tx - s * 0.6, cB], [tx + s * 0.6, cB], [tx + s * 1.9, cT + capH * 0.45], [tx + s * 1.9, cT], [tx - s * 1.9, cT], [tx - s * 1.9, cT + capH * 0.45]], SEC.hor);
  // apoyos bajo cada viga
  const gxs = [-1.45, -0.5, 0.5, 1.45]; const bearings = gxs.map((f) => { const x = tx + f * s; return o.iso === false ? (quad([[x - s * 0.22, cT], [x + s * 0.22, cT], [x + s * 0.22, cT - bH * 0.5], [x - s * 0.22, cT - bH * 0.5]], SEC.acero), [x, cT - bH * 0.25]) : (P.isolatorDetail(ctx, x, cT - bH / 2, s * 0.46, bH, cl(ud - ug - up, -bH * 0.5, bH * 0.5), t, { lead: true, layers: 4, glow: hl.bearings }), [x, cT - bH / 2]); });
  // tablero: vigas en I, diafragma, losa y pretiles
  const dx = tx - cx + (o.iso === false ? 0 : cl(ud - ug - up, -bH * 0.5, bH * 0.5)), yG = cT - (o.iso === false ? bH * 0.5 : bH); gxs.forEach((f) => { const x = cx + dx + f * s; quad([[x - s * 0.22, yG], [x + s * 0.22, yG], [x + s * 0.22, yG - s * 0.07], [x - s * 0.22, yG - s * 0.07]], '#5d6b73'); ctx.fillStyle = '#6c7a82'; ctx.fillRect(x - s * 0.04, yG - gH, s * 0.08, gH); quad([[x - s * 0.18, yG - gH], [x + s * 0.18, yG - gH], [x + s * 0.18, yG - gH + s * 0.06], [x - s * 0.18, yG - gH + s * 0.06]], '#5d6b73'); });
  ctx.fillStyle = 'rgba(77,89,96,0.85)'; ctx.fillRect(cx + dx - s * 1.45, yG - gH * 0.8, s * 2.9, gH * 0.55);
  const yS = yG - gH; quad([[cx + dx - s * 2.3, yS], [cx + dx + s * 2.3, yS], [cx + dx + s * 2.3, yS - slab], [cx + dx - s * 2.3, yS - slab]], SEC.horL); ctx.fillStyle = '#4a5257'; ctx.fillRect(cx + dx - s * 2.0, yS - slab - s * 0.05, s * 4.0, s * 0.05);
  for (const sg of [-1, 1]) { const x = cx + dx + sg * s * 2.15; quad([[x - s * 0.15, yS - slab], [x + s * 0.15, yS - slab], [x + s * 0.09, yS - slab - s * 0.42], [x - s * 0.09, yS - slab - s * 0.42]], SEC.hor); ctx.strokeStyle = SEC.aceroL; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, yS - slab - s * 0.42); ctx.lineTo(x, yS - slab - s * 0.62); ctx.stroke(); }
  hlS([[cx + dx - s * 2.3, yS - slab - s * 0.05], [cx + dx + s * 2.3, yS - slab - s * 0.05], [cx + dx + s * 2.3, yG + 4], [cx + dx - s * 2.3, yG + 4]], hl.deck);
  // camino de cargas: del suelo a la cimentación, el fuste, el cabezal, los apoyos y el tablero (chevrones animados)
  const fl = o.flow || 0; if (fl > 0) { const path = [[bx, gy + s * 3.4], [bx, fy + fH * 0.5], [bx + up * 0.5, (fy + yTop) / 2], [tx, cT + capH * 0.4], [tx, cT - bH / 2], [cx + dx, yS - slab * 0.5]]; const seg = []; let Lt = 0; for (let i = 0; i < path.length - 1; i++) { const l = Math.hypot(path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1]); seg.push(l); Lt += l; } ctx.save(); ctx.globalAlpha *= fl; for (let k = 0; k < 14; k++) { let d = ((t * 0.32 + k / 14) % 1) * Lt * fl, i = 0; while (i < seg.length - 1 && d > seg[i]) { d -= seg[i]; i++; } const a = path[i], b = path[i + 1], u = Math.min(1, d / seg[i]), x = lerp(a[0], b[0], u), y = lerp(a[1], b[1], u), an = Math.atan2(b[1] - a[1], b[0] - a[0]); ctx.save(); ctx.translate(x, y); ctx.rotate(an); ctx.fillStyle = SEC.fuerza; ctx.beginPath(); ctx.moveTo(s * 0.16, 0); ctx.lineTo(-s * 0.08, -s * 0.13); ctx.lineTo(-s * 0.02, 0); ctx.lineTo(-s * 0.08, s * 0.13); ctx.closePath(); ctx.fill(); ctx.restore(); } ctx.restore(); }
  ctx.restore();
  return { deck: [cx + dx + s * 2.0, yS - slab * 0.5], girder: [cx + dx - s * 1.45, yG - gH * 0.5], bearing: bearings[3], cap: [tx - s * 1.5, cT + capH * 0.3], column: [bx + up * 0.5 + s * 0.38, (fy + yTop) / 2], footing: [bx + s * 1.6, fy + fH * 0.5], piles: [bx + s * 1.1, fy + fH + s * 2], ground: [bx - s * 2.6, gy + s * 0.6] };
 };
 // ---------------- v1.16 · túneles bajo ríos: río, geología, tuneladora EPB, dovelas, juntas y túnel terminado ----------------
 // UN SOLO SISTEMA DE COORDENADAS (P.TUN): x a lo largo del eje del túnel (sección longitudinal) o a lo largo del río (sección transversal),
 // y vertical hacia abajo. El túnel va bajo el lecho, en la capa de arcilla (compatible con una tuneladora EPB), nunca dentro del agua abierta.
 const TC = { fondo: '#0B1821', aguaP: '#123D54', aguaL: '#2987A7', espuma: '#D7EDF0', sup: '#76624D', arcilla: '#A27B59', arena: '#C2A67C', grava: '#8E8B80', roca: '#626C71', acero: '#354751', aceroL: '#A9BCC5', corte: '#E4A33B', hormigon: '#B4BEC0', sello: '#303C43', presion: '#FF735A', protegida: '#43D0C6', oro: '#FFD447', blanco: '#F4F7F8', lechada: '#9a948a', marina: '#7a6248' };
 P.TC = TC;
 const TUN = { GS: 600, WS: 650, xa: 760, xb: 2240, TY: 1330, R: 96, x0: 300, x1: 2700, w: 24, ti: 12 };
 TUN.bed = (x) => { const a = TUN.xa, b = TUN.xb; if (x <= a - 160 || x >= b + 160) return TUN.GS; const e = Math.min(x - (a - 160), (b + 160) - x), u = Math.min(1, e / 300), s = u * u * (3 - 2 * u); return TUN.GS + (965 + 22 * Math.sin(x * 0.011) - TUN.GS) * s; };
 // techos de capa (y absoluta): arena/limo bajo el lecho, arcilla (donde va el túnel), grava y roca
 TUN.layers = [{ k: 'arena', c: TC.arena, top: (x) => TUN.bed(x) }, { k: 'arcilla', c: TC.arcilla, top: (x) => Math.max(TUN.bed(x) + 50, 1150 + 28 * Math.sin(x * 0.004)) }, { k: 'grava', c: TC.grava, top: (x) => 1505 + 22 * Math.sin(x * 0.003 + 1) }, { k: 'roca', c: TC.roca, top: (x) => 1650 + 30 * Math.sin(x * 0.0025 + 2) }];
 P.TUN = TUN;
 const tq = (ctx, pp, c) => { ctx.beginPath(); pp.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
 // estado de avance de la tuneladora a partir de un número continuo de anillos: excava (0–0,6) y luego monta el anillo (0,6–1)
 // edificios de la ciudad en las orillas (deterministas)
 const CITY = (() => { const R = H.rng(31), a = []; for (let x = -900; x < 3700; x += R.range(60, 120)) { if (x > TUN.xa - 220 && x < TUN.xb + 220) continue; a.push({ x, w: R.range(40, 90), h: R.range(60, 260), k: R.range(0.3, 2.2), c: R() < 0.5 ? '#2a3d4a' : '#33495a' }); } return a.sort((p, q) => q.k - p.k); })();
 // Sección longitudinal por el eje del túnel (corte técnico 2,5D): cielo, ciudad, río en sección, capas, nivel freático, pozo de ataque,
 // revestimiento de anillos, relleno anular, tuneladora EPB (P.tbmSide) o túnel terminado con vías y tren.
 // o: { st (P.tbmState), mode 'obra'|'terminado', D, t, rot (giro cabeza), press 0..1, support 0..1, flow 0..1, train (x frente), boats, glow{}, xray }
 P.tunWorld = (ctx, t, o = {}) => {
  const { GS, WS, TY, R, x0, x1, w, ti } = TUN, D = o.D || [40, -30], XA = -1400, XB = 4200, mode = o.mode || 'obra', S = o.st || P.tbmState(o.cyc ?? 40), gl = o.glow || {};
  ctx.save();
  // cielo y luz natural
  const sg = ctx.createLinearGradient(0, -900, 0, GS); sg.addColorStop(0, '#0B1821'); sg.addColorStop(1, o.dusk ? '#8a6a52' : '#3d6680'); ctx.fillStyle = sg; ctx.fillRect(XA, -2400, XB - XA, WS + 2440);
  // ciudad en profundidad (dos orillas)
  for (const b of CITY) { const ox = D[0] * b.k, oy = D[1] * b.k, y0 = GS + oy; tq(ctx, [[b.x + ox, y0], [b.x + b.w + ox, y0], [b.x + b.w + ox, y0 - b.h], [b.x + ox, y0 - b.h]], b.c); ctx.fillStyle = o.dusk ? 'rgba(255,214,150,0.55)' : 'rgba(215,237,240,0.18)'; for (let yy = y0 - b.h + 10; yy < y0 - 8; yy += 16) for (let xx = b.x + 6; xx < b.x + b.w - 6; xx += 12) if (((xx * 7 + yy * 3) | 0) % 5) ctx.fillRect(xx + ox, yy, 5, 7); }
  // superficie superior del terreno (franja en profundidad) y del agua
  const bedPts = []; for (let x = XA; x <= XB; x += 20) bedPts.push([x, TUN.bed(x)]);
  tq(ctx, [[XA, GS], [TUN.xa - 160, GS], [TUN.xa - 160 + D[0] * 2.4, GS + D[1] * 2.4], [XA + D[0] * 2.4, GS + D[1] * 2.4]], '#5f6b4f'); tq(ctx, [[TUN.xb + 160, GS], [XB, GS], [XB + D[0] * 2.4, GS + D[1] * 2.4], [TUN.xb + 160 + D[0] * 2.4, GS + D[1] * 2.4]], '#5f6b4f');
  const wa = TUN.xa - 110, wb = TUN.xb + 110; const wg = ctx.createLinearGradient(0, WS + D[1] * 2.4, 0, WS); wg.addColorStop(0, '#1f5f78'); wg.addColorStop(1, TC.aguaL); tq(ctx, [[wa, WS], [wb, WS], [wb + D[0] * 2.4, WS + D[1] * 2.4], [wa + D[0] * 2.4, WS + D[1] * 2.4]], wg);
  ctx.strokeStyle = 'rgba(215,237,240,0.35)'; ctx.lineWidth = 2; for (let k = 0; k < 9; k++) { const u = ((k / 9 + t * 0.05) % 1) * 2.4, xs = wa + D[0] * u, ys = WS + D[1] * u; ctx.beginPath(); for (let x = 0; x <= wb - wa; x += 30) ctx.lineTo(xs + x, ys + 2 * Math.sin(x * 0.03 + t * 2 + k)); ctx.stroke(); }
  // muros de ribera
  for (const [x, s] of [[TUN.xa - 160, 1], [TUN.xb + 160, -1]]) tq(ctx, [[x - s * 8, GS - 10], [x + s * 8, GS - 10], [x + s * 8, GS + 20], [x - s * 8, GS + 20]], '#7f8a8c');
  // capas geológicas (sección frontal)
  TUN.layers.forEach((L) => { ctx.beginPath(); ctx.moveTo(XA, 3400); for (let x = XA; x <= XB; x += 20) ctx.lineTo(x, L.top(x)); ctx.lineTo(XB, 3400); ctx.closePath(); ctx.fillStyle = L.c; ctx.fill(); }); { const dg = ctx.createLinearGradient(0, 900, 0, 2100); dg.addColorStop(0, 'rgba(11,24,33,0)'); dg.addColorStop(1, 'rgba(11,24,33,0.55)'); ctx.fillStyle = dg; ctx.beginPath(); ctx.moveTo(XA, 3400); for (let x = XA; x <= XB; x += 20) ctx.lineTo(x, TUN.bed(x)); ctx.lineTo(XB, 3400); ctx.closePath(); ctx.fill(); }
  // textura de capas: puntos/estratos deterministas
  { const Rr = H.rng(5); ctx.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 900; i++) { const x = Rr.range(XA, XB), y = Rr.range(TUN.bed(x) + 6, 2300); ctx.fillRect(x, y, 3, 2); } ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 2; TUN.layers.slice(1).forEach((L) => { ctx.beginPath(); for (let x = XA; x <= XB; x += 20) x === XA ? ctx.moveTo(x, L.top(x)) : ctx.lineTo(x, L.top(x)); ctx.stroke(); }); }
  // suelo superficial en las orillas
  ctx.fillStyle = TC.sup; ctx.beginPath(); ctx.moveTo(XA, GS); bedPts.forEach((p) => ctx.lineTo(p[0], p[1])); for (let i = bedPts.length - 1; i >= 0; i--) ctx.lineTo(bedPts[i][0], bedPts[i][1] + (bedPts[i][1] <= GS + 1 ? 46 : 14)); ctx.closePath(); ctx.fill();
  // agua del río en sección (de la superficie al lecho): degradado, rayos de luz y partículas en suspensión
  ctx.save(); ctx.beginPath(); ctx.moveTo(wa, WS); bedPts.filter((p) => p[0] >= wa && p[0] <= wb).forEach((p) => ctx.lineTo(p[0], p[1])); ctx.lineTo(wb, WS); ctx.closePath(); const ag = ctx.createLinearGradient(0, WS, 0, 990); ag.addColorStop(0, TC.aguaL); ag.addColorStop(1, TC.aguaP); ctx.fillStyle = ag; ctx.fill(); ctx.clip();
   ctx.globalCompositeOperation = 'lighter'; for (let k = 0; k < 7; k++) { const x = wa + 120 + k * 210 + 30 * Math.sin(t * 0.4 + k); const g = ctx.createLinearGradient(0, WS, 0, 980); g.addColorStop(0, 'rgba(120,200,220,0.10)'); g.addColorStop(1, 'rgba(120,200,220,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x, WS); ctx.lineTo(x + 50, WS); ctx.lineTo(x + 130, 990); ctx.lineTo(x + 60, 990); ctx.closePath(); ctx.fill(); } ctx.globalCompositeOperation = 'source-over';
   const Rp = H.rng(9); ctx.fillStyle = 'rgba(215,237,240,0.35)'; for (let i = 0; i < 120; i++) { const x = Rp.range(wa, wb), y = Rp.range(WS + 10, 980), r = Rp.range(0.8, 2.2); ctx.beginPath(); ctx.arc(x + Math.sin(t * 0.7 + i) * 6, y + Math.cos(t * 0.5 + i) * 4, r, 0, TAU); ctx.fill(); } ctx.restore();
  // sedimentos del lecho en el cauce
  { const bp = bedPts.filter((p) => p[0] >= wa && p[0] <= wb && p[1] > WS + 20); if (bp.length > 2) { ctx.fillStyle = '#8f7d63'; ctx.beginPath(); ctx.moveTo(bp[0][0], bp[0][1]); bp.forEach((p) => ctx.lineTo(p[0], p[1] - 2 + 2 * Math.sin(p[0] * 0.09))); for (let i = bp.length - 1; i >= 0; i--) ctx.lineTo(bp[i][0], bp[i][1] + 14); ctx.closePath(); ctx.fill(); } }
  // superficie del agua (línea con oleaje) y barcos que cruzan
  ctx.strokeStyle = TC.espuma; ctx.lineWidth = 3; ctx.beginPath(); for (let x = wa; x <= wb; x += 12) { const y = WS + 2.5 * Math.sin(x * 0.04 + t * 2.2); x === wa ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke();
  if (o.boats !== false) for (const [x, k, c] of [[1150 + 40 * Math.sin(t * 0.2), 1.2, '#c9cfd2'], [1800 - 30 * Math.sin(t * 0.17), 0.5, '#d4a24e']]) { const bx = x + D[0] * k, by = WS + D[1] * k + 2 * Math.sin(t * 1.5 + x); tq(ctx, [[bx - 70, by - 6], [bx + 80, by - 6], [bx + 60, by + 12], [bx - 60, by + 12]], c); tq(ctx, [[bx - 30, by - 30], [bx + 30, by - 30], [bx + 30, by - 6], [bx - 30, by - 6]], '#e8ecef'); }
  // nivel freático en las orillas (línea discontinua al nivel del río)
  if (o.watertable) { ctx.save(); ctx.globalAlpha *= o.watertable; ctx.strokeStyle = TC.aguaL; ctx.setLineDash([14, 10]); ctx.lineWidth = 3; for (const [a, b] of [[XA, TUN.xa - 160], [TUN.xb + 160, XB]]) { ctx.beginPath(); ctx.moveTo(a, WS); ctx.lineTo(b, WS); ctx.stroke(); } ctx.setLineDash([]); ctx.restore(); }
  // pozos de ataque y de salida
  const shaft = (x) => { tq(ctx, [[x - 90, GS], [x + 10, GS], [x + 10, TY + R + 30], [x - 90, TY + R + 30]], '#2b3a44'); tq(ctx, [[x - 100, GS - 4], [x - 90, GS - 4], [x - 90, TY + R + 40], [x - 100, TY + R + 40]], TC.hormigon); tq(ctx, [[x + 10, GS - 4], [x + 20, GS - 4], [x + 20, TY - R - 10], [x + 10, TY - R - 10]], TC.hormigon); tq(ctx, [[x - 100, TY + R + 30], [x + 20, TY + R + 30], [x + 20, TY + R + 44], [x - 100, TY + R + 44]], TC.hormigon); ctx.strokeStyle = TC.oro; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(x - 110, GS - 4); ctx.lineTo(x - 110, GS - 120); ctx.lineTo(x + 40, GS - 120); ctx.lineTo(x + 40, GS - 4); ctx.moveTo(x - 40, GS - 120); ctx.lineTo(x - 40, GS + 60); ctx.stroke(); };
  shaft(x0); if (mode === 'terminado' || S.xm > x1 - 500) shaft(x1 + 100);
  // túnel: perforación, relleno anular, cara interior (media caña) y revestimiento cortado
  const xEnd = mode === 'terminado' ? x1 : S.rf, xBore = mode === 'terminado' ? x1 : S.xm;
  tq(ctx, [[x0 + 10, TY - R], [xBore, TY - R], [xBore, TY + R], [x0 + 10, TY + R]], TC.lechada);
  const Ro = R - 10, Ri = Ro - ti; const lining = (xa, xb, nRing0) => { const ig = ctx.createLinearGradient(0, TY - Ri, 0, TY + Ri); ig.addColorStop(0, '#6f7a7d'); ig.addColorStop(0.5, '#c7cfd1'); ig.addColorStop(1, '#5c6669'); tq(ctx, [[xa, TY - Ri], [xb, TY - Ri], [xb, TY + Ri], [xa, TY + Ri]], ig);
   ctx.strokeStyle = 'rgba(48,60,67,0.55)'; ctx.lineWidth = 1.5; for (let x = xa, i = nRing0; x < xb - 0.5; x += w, i++) { ctx.beginPath(); ctx.moveTo(x, TY - Ri); ctx.lineTo(x, TY + Ri); ctx.stroke(); const off = (i % 2) * 0.39; for (let k = 0; k < 7; k++) { const a = off + (k * TAU) / 7, y = TY - Ri * Math.cos(a); if (Math.sin(a) > 0.15) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(Math.min(xb, x + w), y); ctx.stroke(); } } }
   for (const s of [-1, 1]) { tq(ctx, [[xa, TY + s * Ri], [xb, TY + s * Ri], [xb, TY + s * Ro], [xa, TY + s * Ro]], TC.hormigon); ctx.fillStyle = TC.sello; for (let x = xa; x <= xb + 0.5; x += w) { ctx.fillRect(x - 1, TY + s * Ri, 2, s * ti); ctx.fillRect(x - 2, TY + s * (Ro - 3), 4, s * 2.5); } } };
  if (xEnd > x0 + 10) lining(x0 + 10, xEnd, 0);
  if (mode === 'terminado') { // solera, andén, vías, luces e instalaciones
   tq(ctx, [[x0 + 10, TY + Ri * 0.55], [x1, TY + Ri * 0.55], [x1, TY + Ri], [x0 + 10, TY + Ri]], '#8e979a'); ctx.fillStyle = '#3a3f42'; for (let x = x0 + 14; x < x1; x += 9) ctx.fillRect(x, TY + Ri * 0.55 - 3, 5, 3); ctx.fillStyle = '#c9d2d6'; ctx.fillRect(x0 + 10, TY + Ri * 0.55 - 6, x1 - x0 - 10, 2.5);
   ctx.strokeStyle = 'rgba(40,46,50,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x0 + 10, TY - Ri * 0.6); ctx.lineTo(x1, TY - Ri * 0.6); ctx.stroke(); for (let x = x0 + 30; x < x1; x += 70) P.glow(ctx, x, TY - Ri * 0.78, 22, '255,236,200', 0.55);
   if (o.train != null) { const tx = o.train, L = 520, y1 = TY + Ri * 0.55 - 6, y0 = y1 - Ri * 1.05; for (let c = 0; c < 4; c++) { const a = tx - c * (L / 4) - 4, b = a - L / 4 + 8; if (b > x1 || a < x0) continue; ctx.fillStyle = '#d9dee0'; ctx.beginPath(); ctx.roundRect(b, y0, a - b, y1 - y0 - 4, c === 0 ? [4, 16, 4, 4] : 4); ctx.fill(); ctx.fillStyle = TC.protegida; ctx.fillRect(b, y0 + (y1 - y0) * 0.62, a - b, 4); ctx.fillStyle = 'rgba(40,60,75,0.85)'; for (let x = b + 8; x < a - 14; x += 18) ctx.fillRect(x, y0 + 8, 12, 12); ctx.fillStyle = '#2a2f33'; ctx.fillRect(b + 8, y1 - 6, 14, 5); ctx.fillRect(a - 22, y1 - 6, 14, 5); } P.glow(ctx, tx + 4, y1 - 14, 40, '255,240,200', 0.7); } }
  if (mode === 'obra' && o.tbm !== false) P.tbmSide(ctx, S, t, o); else if (mode === 'obra') { tq(ctx, [[S.rf, TY - R], [S.xm, TY - R], [S.xm, TY + R], [S.rf, TY + R]], '#1a2328'); tq(ctx, [[S.xm - 4, TY - R], [S.xm + 4, TY - R], [S.xm + 4, TY + R], [S.xm - 4, TY + R]], '#6b5039'); }
  // presiones: del terreno y del agua sobre el frente y la perforación (rojo) / soporte en la cámara (turquesa)
  const pr = o.press || 0; if (pr > 0 && mode === 'obra') { ctx.save(); ctx.globalAlpha *= pr; for (let k = -2; k <= 2; k++) { const y = TY + k * R * 0.36; P.hArrow(ctx, S.xm + 70, y, -46, TC.presion, 10); } for (let x = S.xm - 300; x < S.xm + 60; x += 60) { for (const s of [-1, 1]) { ctx.save(); ctx.translate(x, TY + s * (R + 50)); ctx.rotate(s > 0 ? -Math.PI / 2 : Math.PI / 2); P.hArrow(ctx, 0, 0, 36, TC.presion, 9); ctx.restore(); } } ctx.restore(); }
  const su = o.support || 0; if (su > 0 && mode === 'obra') { ctx.save(); ctx.globalAlpha *= su; for (let k = -1; k <= 1; k++) P.hArrow(ctx, S.xm - 58, TY + k * R * 0.42, 34, TC.protegida, 10); ctx.restore(); }
  ctx.restore();
  return { st: S, face: [S.xm, TY], chamber: [S.xm - 41, TY - R * 0.45], screwIn: [S.xm - 34, TY + R - 26], screwOut: [S.xm - 300, TY - R * 0.18 - 26], belt: [S.xm - 420, TY - R * 0.18], cyl: [S.xm - 180, TY - R + 26], erector: [S.rf + w / 2, TY], tail: [S.xm - 360, TY + R - 6], bulkhead: [S.xm - 68, TY + R * 0.3], shaftH: [S.xm - 80, TY], ring: [S.rf - w * 2, TY - (R - 10 - ti)], crown: [S.xm - 600, TY - R], grout: [S.xm - 420, TY + R - 5], bed: [1500, TUN.bed(1500)], water: [1500, 820], shaft: [x0 - 40, GS + 200] };
 };
 // v1.16.1 · ciclo completo: excavar (0–0,6) → retraer cilindros (0,6–0,66) → montar 7 dovelas (0,66–0,94) → apoyar cilindros en el anillo nuevo (0,94–1)
 P.tbmState = (cyc, base = 900) => { const n = Math.floor(cyc), f = cyc - n, w = TUN.w, adv = f < 0.6 ? (f / 0.6) * w : w, build = f < 0.66 ? -1 : f < 0.94 ? Math.min(6.999, ((f - 0.66) / 0.28) * 7) : 7, retr = f < 0.6 ? 0 : f < 0.66 ? E.inOut((f - 0.6) / 0.06) : f < 0.94 ? 1 : 1 - E.inOut((f - 0.94) / 0.06); return { n, f, adv, build, retr, xm: base + n * w + adv, rf: base - 270 + n * w, excavating: f < 0.6 }; };
 // Tuneladora EPB en sección longitudinal, como UN SOLO SISTEMA: todas las piezas se colocan respecto al frente xm y al eje TY.
 // Cabeza (gira; sus aberturas dejan pasar el terreno) → árbol al rodamiento principal → mamparo → cámara llena de terreno acondicionado
 // → tornillo sinfín (entrada en la cámara, hélice que gira, motor y compuerta de salida) → cinta → vagonetas.
 // Cilindros: cuerpo fijo al anillo de empuje del escudo; vástago y zapata apoyados en la cara del último anillo (se extienden al excavar,
 // se retraen para montar y vuelven a apoyarse en el anillo nuevo). Erector con viga giratoria, brazo telescópico y pinza.
 P.tbmSide = (ctx, S, t, o = {}) => {
  const { TY, R, w, ti } = TUN, xm = S.xm, rot = o.rot ?? t * 1.2, flow = o.flow ?? 1, gl = o.glow || {}, Ro = R - 10, Ri = Ro - ti, xt = xm - 360, xH = xm - 18, xB = xm - 72, xC = xm - 64;
  ctx.save();
  // --- escudo: piel delantera, articulación y cola ---
  for (const s of [-1, 1]) { const g = ctx.createLinearGradient(0, TY + s * (R - 8), 0, TY + s * R); g.addColorStop(0, '#2a3a44'); g.addColorStop(1, TC.acero); tq(ctx, [[xt, TY + s * (R - 8)], [xH, TY + s * (R - 8)], [xH, TY + s * R], [xt, TY + s * R]], g); ctx.fillStyle = 'rgba(169,188,197,0.4)'; ctx.fillRect(xt, TY + s * R - (s > 0 ? 2 : 0), xH - xt, 2); ctx.fillStyle = '#1b262d'; ctx.fillRect(xm - 170, TY + s * (R - 8), 3, s * 8); }
  // interior del escudo (penumbra con estructura): de la cola al mamparo
  const x0i = S.rf + (S.build >= 0 ? w : 0); { const bg = ctx.createLinearGradient(0, TY - R, 0, TY + R); bg.addColorStop(0, '#18222a'); bg.addColorStop(0.5, '#27353e'); bg.addColorStop(1, '#141c22'); tq(ctx, [[x0i, TY - R + 8], [xB, TY - R + 8], [xB, TY + R - 8], [x0i, TY + R - 8]], bg); ctx.strokeStyle = 'rgba(169,188,197,0.12)'; ctx.lineWidth = 2; for (let x = xB - 30; x > x0i; x -= 30) { ctx.beginPath(); ctx.moveTo(x, TY - R + 8); ctx.lineTo(x, TY + R - 8); ctx.stroke(); } }
  // anillo de empuje (estructura donde se anclan los cilindros)
  for (const s of [-1, 1]) tq(ctx, [[xm - 150, TY + s * (R - 8)], [xm - 136, TY + s * (R - 8)], [xm - 136, TY + s * (R - 40)], [xm - 150, TY + s * (R - 40)]], '#4a5d69');
  // --- equipos posteriores (pórticos sobre ruedas), cinta y vagonetas ---
  const by = TY - R * 0.18; for (let x = xt - 20; x > xt - 760; x -= 150) { ctx.strokeStyle = '#4b5d68'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(x, TY + Ri - 10); ctx.lineTo(x, by - 14); ctx.lineTo(x - 120, by - 14); ctx.lineTo(x - 120, TY + Ri - 10); ctx.moveTo(x, TY + Ri - 10); ctx.lineTo(x - 120, by - 14); ctx.stroke(); tq(ctx, [[x - 100, TY + 10], [x - 30, TY + 10], [x - 30, TY + Ri - 14], [x - 100, TY + Ri - 14]], '#3c4d57'); ctx.fillStyle = '#20282d'; for (const wx of [x - 10, x - 110]) { ctx.beginPath(); ctx.arc(wx, TY + Ri - 6, 5, 0, TAU); ctx.fill(); } }
  // cinta: rodillos y marina que viaja hacia atrás
  ctx.fillStyle = '#20282d'; ctx.fillRect(xt - 780, by, (xm - 300) - (xt - 780), 4); for (let x = xm - 300; x > xt - 780; x -= 26) { ctx.beginPath(); ctx.arc(x, by + 6, 2.5, 0, TAU); ctx.fill(); }
  if (flow > 0) { ctx.fillStyle = TC.marina; const ph = (t * 55) % 20; for (let x = xm - 304 - ph; x > xt - 780; x -= 20) { ctx.beginPath(); ctx.ellipse(x, by - 3, 8, 4, 0, Math.PI, 0); ctx.fill(); } }
  for (let c = 0; c < 3; c++) { const x = xt - 820 - c * 70; tq(ctx, [[x - 30, TY + Ri - 42], [x + 30, TY + Ri - 42], [x + 26, TY + Ri - 10], [x - 26, TY + Ri - 10]], '#56636b'); ctx.fillStyle = TC.marina; ctx.beginPath(); ctx.ellipse(x, TY + Ri - 42, 28, 9, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = '#20282d'; ctx.beginPath(); ctx.arc(x - 16, TY + Ri - 6, 5, 0, TAU); ctx.arc(x + 16, TY + Ri - 6, 5, 0, TAU); ctx.fill(); }
  // --- dovelas en montaje dentro de la cola (vistas de canto: arriba/abajo cuando su ángulo lo permite) ---
  // mismo orden y ángulos que P.ringBuild: solera (abajo) primero; la clave (arriba) se cierra al final. En el plano de corte solo se ven
  // la solera y la clave; la dovela que lleva el erector se ve más o menos según lo cerca que pase del plano.
  const ORD = [3, 2, 4, 1, 5, 6, 0], AM = (j) => -Math.PI / 2 + (j + 0.5) * TAU / 7, kB = S.build >= 0 ? Math.floor(S.build) : -1;
  const slab = (y, up, c) => { ctx.fillStyle = c; ctx.fillRect(S.rf + 1, up ? y - ti : y, w - 2, ti); ctx.fillStyle = TC.sello; ctx.fillRect(S.rf + 1, up ? y - 3 : y, 2, 3); };
  if (kB >= 1) slab(TY + Ro - ti, false, TC.hormigon); if (kB >= 6) slab(TY - Ro + ti, true, TC.hormigon);
  // --- cilindros de empuje (varios, arriba y abajo): cuerpo fijo, vástago y zapata ---
  const rodEnd = S.excavating ? S.rf : lerp(S.rf, S.rf + w + 6, S.retr) + (S.build >= 7 ? 0 : 0); for (const s of [-1, 1]) for (const dy of [26, 46]) { const y = TY + s * (R - dy), xb0 = xm - 140, xb1 = xm - 215; const g = ctx.createLinearGradient(0, y - 8, 0, y + 8); g.addColorStop(0, '#6b8292'); g.addColorStop(0.5, '#8ea4b2'); g.addColorStop(1, '#425663'); tq(ctx, [[xb1, y - 8], [xb0, y - 8], [xb0, y + 8], [xb1, y + 8]], g); const re = S.build >= 7 && S.retr < 1 ? lerp(S.rf + w, S.rf + w + 6, S.retr) : rodEnd; ctx.fillStyle = '#d9e2e6'; ctx.fillRect(re, y - 4, xb1 - re, 8); ctx.fillStyle = '#2f3d46'; ctx.fillRect(re - 4, y - 11, 6, 22); if (gl.cyl) { ctx.strokeStyle = `rgba(255,212,71,${gl.cyl})`; ctx.lineWidth = 3; ctx.strokeRect(re - 7, y - 13, xb0 - re + 10, 26); } }
  // --- erector: viga giratoria, brazo telescópico y pinza que sostiene la dovela actual ---
  { const ex = S.rf + w / 2; ctx.fillStyle = '#3e505c'; ctx.fillRect(ex - 10, TY - 30, 20, 60); ctx.beginPath(); ctx.arc(ex, TY, 16, 0, TAU); ctx.fillStyle = '#5c7180'; ctx.fill(); ctx.strokeStyle = '#2c3a42'; ctx.lineWidth = 3; ctx.stroke();
   if (S.build >= 0 && S.build < 7) { const k = Math.floor(S.build), u = S.build - k, am = AM(ORD[k]); let d = am - Math.PI / 2; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU; const a = Math.PI / 2 + d * E.inOut(cl((u - 0.22) / 0.48)), rr = lerp(Ro * 0.6, Ro * 0.7, E.inOut(cl(u / 0.22))) + Ro * 0.3 * E.inOut(cl((u - 0.7) / 0.3)), sn = Math.sin(a), vis = Math.pow(Math.abs(sn), 2), y = TY + rr * sn, down = sn > 0, yi = down ? y - ti : y + ti; ctx.save(); ctx.globalAlpha *= 0.35 + 0.65 * vis; ctx.strokeStyle = '#8a9aa4'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(ex, TY); ctx.lineTo(ex, (TY + yi) / 2); ctx.stroke(); ctx.strokeStyle = TC.oro; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(ex, (TY + yi) / 2); ctx.lineTo(ex, yi); ctx.stroke(); ctx.fillStyle = TC.hormigon; ctx.fillRect(S.rf + 1, down ? y - ti : y, w - 2, ti); ctx.fillStyle = TC.oro; ctx.fillRect(ex - 9, yi - 3, 18, 6); ctx.restore(); }
   else { ctx.strokeStyle = '#8a9aa4'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(ex, TY); ctx.lineTo(ex, TY + Ro * 0.45); ctx.stroke(); }
   if (gl.erector) P.glow(ctx, ex, TY, 80, '255,212,71', 0.45 * gl.erector); }
  // alimentador de dovelas (abajo, detrás del erector) con la siguiente dovela esperando
  tq(ctx, [[S.rf - 60, TY + Ri - 26], [S.rf - 4, TY + Ri - 26], [S.rf - 4, TY + Ri - 16], [S.rf - 60, TY + Ri - 16]], '#4f6470'); ctx.fillStyle = '#9aa4a7'; ctx.fillRect(S.rf - 56, TY + Ri - 36, 48, 10);
  // --- tornillo sinfín: entrada dentro de la cámara (por debajo), atraviesa el mamparo, sube hacia atrás; motor arriba; compuerta y tolva a la cinta ---
  const sa = [xm - 34, TY + R - 26], sb = [xm - 300, by - 26], SL = Math.hypot(sb[0] - sa[0], sb[1] - sa[1]), an = Math.atan2(sb[1] - sa[1], sb[0] - sa[0]);
  ctx.save(); ctx.translate(sa[0], sa[1]); ctx.rotate(an); const tg = ctx.createLinearGradient(0, -13, 0, 13); tg.addColorStop(0, '#5f7582'); tg.addColorStop(0.5, '#86a0ad'); tg.addColorStop(1, '#3f525e'); tq(ctx, [[0, -13], [SL, -13], [SL, 13], [0, 13]], tg);
  ctx.fillStyle = '#2a2018'; ctx.fillRect(3, -10, SL - 6, 20); // interior (corte)
  const ph = (t * 1.4 * flow) % 1; ctx.strokeStyle = '#c9d2d6'; ctx.lineWidth = 2.5; for (let x = -16 + ph * 16; x < SL - 4; x += 16) { if (x < 4) continue; ctx.beginPath(); ctx.moveTo(x, -10); ctx.quadraticCurveTo(x + 6, 0, x + 10, 10); ctx.stroke(); } ctx.fillStyle = '#9fb0b8'; ctx.fillRect(4, -2, SL - 8, 4);
  if (flow > 0) { ctx.fillStyle = TC.marina; for (let x = 6 + ((t * 48 * flow) % 16); x < SL - 6; x += 16) { ctx.beginPath(); ctx.ellipse(x, 4, 6, 4, 0, 0, TAU); ctx.fill(); } }
  ctx.restore();
  tq(ctx, [[sb[0] - 26, sb[1] - 20], [sb[0] + 4, sb[1] - 20], [sb[0] + 4, sb[1] + 8], [sb[0] - 26, sb[1] + 8]], '#5c7180'); ctx.fillStyle = '#2c3a42'; ctx.fillRect(sb[0] - 22, sb[1] - 16, 22, 4);
  tq(ctx, [[sb[0] - 2, sb[1] + 8], [sb[0] + 14, sb[1] + 8], [sb[0] + 8, by], [sb[0] - 6, by]], '#4f6470'); if (flow > 0) { ctx.fillStyle = TC.marina; const fy = sb[1] + 10 + ((t * 40) % (by - sb[1] - 12)); ctx.fillRect(sb[0] + 1, fy, 6, 5); }
  if (gl.screw) { ctx.save(); ctx.translate(sa[0], sa[1]); ctx.rotate(an); ctx.strokeStyle = `rgba(255,212,71,${gl.screw})`; ctx.lineWidth = 3; ctx.strokeRect(-6, -18, SL + 12, 36); ctx.restore(); }
  // --- accionamiento principal y árbol que une la cabeza con el rodamiento ---
  for (const s of [-1, 1]) { tq(ctx, [[xm - 122, TY + s * 18], [xB, TY + s * 18], [xB, TY + s * 44], [xm - 122, TY + s * 44]], '#5c7180'); ctx.fillStyle = '#3e505c'; ctx.fillRect(xm - 118, TY + s * 24 - (s < 0 ? 14 : 0), 40, 14); }
  tq(ctx, [[xm - 92, TY - 16], [xB, TY - 16], [xB, TY + 16], [xm - 92, TY + 16]], '#7c8e99');
  // --- mamparo de presión con sensores ---
  { const g = ctx.createLinearGradient(xB, 0, xC, 0); g.addColorStop(0, '#556b79'); g.addColorStop(1, '#7a92a1'); tq(ctx, [[xB, TY - R + 8], [xC, TY - R + 8], [xC, TY + R - 8], [xB, TY + R - 8]], g); for (const k of [-0.6, 0, 0.55]) { ctx.fillStyle = TC.protegida; ctx.beginPath(); ctx.arc(xC + 2, TY + k * R, 4, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(67,208,198,0.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(xC + 2, TY + k * R); ctx.lineTo(xB - 6, TY + k * R); ctx.stroke(); } }
  // --- cámara de excavación LLENA de terreno acondicionado (con espuma) ---
  { ctx.save(); ctx.beginPath(); ctx.rect(xC, TY - R + 8, xH - xC, 2 * R - 16); ctx.clip(); const cg = ctx.createLinearGradient(0, TY - R, 0, TY + R); cg.addColorStop(0, '#8d6d4f'); cg.addColorStop(1, '#6b5039'); ctx.fillStyle = cg; ctx.fillRect(xC, TY - R, xH - xC, 2 * R); const Rr = H.rng(17); for (let i = 0; i < 90; i++) { const ph2 = (Rr() + t * 0.18 * flow) % 1, x = xC + 2 + Rr() * (xH - xC - 4), y = TY - R + 8 + ph2 * (2 * R - 16); ctx.fillStyle = Rr() < 0.25 ? 'rgba(235,225,205,0.5)' : 'rgba(45,32,22,0.5)'; ctx.beginPath(); ctx.arc(x, y, Rr.range(1.2, 3), 0, TAU); ctx.fill(); } ctx.restore(); if (gl.chamber) { ctx.strokeStyle = `rgba(67,208,198,${gl.chamber})`; ctx.lineWidth = 3; ctx.strokeRect(xC, TY - R + 8, xH - xC, 2 * R - 16); } }
  // boca de entrada del tornillo en la parte baja de la cámara: el terreno entra en el tubo
  { const ix = xm - 34, iy = TY + R - 26; ctx.fillStyle = '#5f7582'; ctx.beginPath(); ctx.ellipse(ix, iy, 9, 15, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#1a120c'; ctx.beginPath(); ctx.ellipse(ix + 1, iy, 6, 11, 0, 0, TAU); ctx.fill(); if (flow > 0) { ctx.fillStyle = TC.marina; for (let i = 0; i < 4; i++) { const ph5 = ((t * 0.9 + i / 4) % 1); ctx.beginPath(); ctx.arc(ix + 14 - ph5 * 14, iy - 20 + ph5 * 18, 2.6, 0, TAU); ctx.fill(); } } }
  // árbol de la cabeza atravesando la cámara hasta el rodamiento
  ctx.fillStyle = '#8a7a5c'; ctx.fillRect(xC, TY - 10, xH - xC, 20); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(xC, TY + 4, xH - xC, 6);
  // --- cabeza de corte en sección: placa con aberturas que giran (por ellas pasa el terreno) y herramientas en contacto con el frente ---
  { const op = [0, 1, 2].map((k) => TY + R * 0.62 * Math.sin(rot + (k * TAU) / 3)), gh = R * 0.2; const g = ctx.createLinearGradient(xH, 0, xm, 0); g.addColorStop(0, '#9c6a1e'); g.addColorStop(1, TC.corte); ctx.fillStyle = g; ctx.beginPath(); ctx.rect(xH, TY - R + 2, xm - xH, 2 * R - 4); for (const y of op) ctx.rect(xm, y - gh / 2, -(xm - xH), gh); ctx.fill('evenodd');
   ctx.fillStyle = '#6a4815'; ctx.fillRect(xH, TY - R + 2, 3, 2 * R - 4); for (let k = 0; k < 18; k++) { const a = rot + (k * TAU) / 9 + (k > 8 ? 0.35 : 0), rr = (k > 8 ? 0.42 : 0.84) * R, y = TY + rr * Math.sin(a), fr = Math.cos(a); if (fr < 0 || op.some((oy) => Math.abs(oy - y) < gh / 2 + 3)) continue; ctx.fillStyle = `rgba(53,71,81,${0.55 + 0.45 * fr})`; ctx.beginPath(); ctx.moveTo(xm, y - 5); ctx.lineTo(xm + 9 * fr, y - 1); ctx.lineTo(xm + 9 * fr, y + 1); ctx.lineTo(xm, y + 5); ctx.closePath(); ctx.fill(); }
   ctx.fillStyle = '#7a5212'; ctx.beginPath(); ctx.moveTo(xm, TY - 12); ctx.lineTo(xm + 14, TY); ctx.lineTo(xm, TY + 12); ctx.closePath(); ctx.fill();
   // terreno cortado que entra por las aberturas hacia la cámara (trayectoria física: frente → abertura → cámara)
   if (flow > 0) { const Rr = H.rng(23); ctx.fillStyle = 'rgba(110,80,52,0.9)'; for (let i = 0; i < 24; i++) { const k = i % 3, ph3 = (Rr() + t * 1.1 * flow) % 1, yy = op[k] + (Rr() - 0.5) * gh * 0.7, x = xm + 6 - ph3 * (xm + 6 - xC - 6); ctx.beginPath(); ctx.arc(x, yy + (x < xH ? (ph3 - 0.5) * 18 : 0), 2.4, 0, TAU); ctx.fill(); } }
   if (gl.head) { ctx.strokeStyle = `rgba(255,212,71,${gl.head})`; ctx.lineWidth = 3; ctx.strokeRect(xH - 4, TY - R - 4, 30, 2 * R + 8); } }
  // --- cepillos de cola e inyección de lechada al hueco anular detrás del escudo ---
  ctx.strokeStyle = '#1d262c'; ctx.lineWidth = 1.5; for (const s of [-1, 1]) for (let x = xt + 4; x < xt + 46; x += 4) { ctx.beginPath(); ctx.moveTo(x, TY + s * (R - 8)); ctx.lineTo(x + 3, TY + s * Ro); ctx.stroke(); }
  for (const s of [-1, 1]) { ctx.fillStyle = '#c0b49c'; ctx.fillRect(xt - 4, TY + s * (R - 6) - (s < 0 ? 0 : 4), 10, 4); }
  ctx.restore();
 };
 // Cabeza de corte EPB vista de frente (2,5D): aro robusto con cortadores perimetrales, 6 brazos en cajón con cara lateral (profundidad),
 // rascadores y rippers a lo largo de los brazos, grandes aberturas por las que entra el terreno, refuerzos y centro con cortador central.
 P.cutterFace = (ctx, cx, cy, R, ang, t, o = {}) => {
  ctx.save(); const dz = R * 0.035, rng = H.rng(77);
  // terreno del frente detrás (visible por las aberturas) que se desplaza hacia el interior
  const sg = ctx.createRadialGradient(cx, cy, R * 0.1, cx, cy, R); sg.addColorStop(0, '#3b2a1d'); sg.addColorStop(1, '#5a4330'); ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
  const Rr = H.rng(11); for (let i = 0; i < 160; i++) { const a = Rr() * TAU, ph = (Rr() + t * 0.5) % 1, rr = R * (0.95 - ph * 0.7); ctx.fillStyle = Rr() < 0.5 ? 'rgba(162,123,89,0.85)' : 'rgba(95,70,48,0.85)'; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr, R * 0.012 * (1 + Rr()), 0, TAU); ctx.fill(); }
  // placas frontales entre brazos: dejan ranuras de entrada junto a cada brazo (relación de apertura parcial, típica de una EPB)
  for (let i = 0; i < 6; i++) { const a0 = ang + (i * TAU) / 6 + 0.2, a1 = ang + ((i + 1) * TAU) / 6 - 0.2; ctx.beginPath(); ctx.arc(cx + dz * 0.6, cy + dz * 0.6, R * 0.92, a0, a1); ctx.arc(cx + dz * 0.6, cy + dz * 0.6, R * 0.2, a1, a0, true); ctx.closePath(); ctx.fillStyle = '#6a4815'; ctx.fill(); const pg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.2, cx, cy, R); pg.addColorStop(0, '#dca246'); pg.addColorStop(1, '#a36c1f'); ctx.beginPath(); ctx.arc(cx, cy, R * 0.92, a0, a1); ctx.arc(cx, cy, R * 0.2, a1, a0, true); ctx.closePath(); ctx.fillStyle = pg; ctx.fill(); ctx.fillStyle = 'rgba(60,40,20,0.22)'; for (let k = 0; k < 8; k++) { const aa = lerp(a0, a1, rng()), rr2 = R * (0.25 + 0.6 * rng()); ctx.fillRect(cx + Math.cos(aa) * rr2, cy + Math.sin(aa) * rr2, R * 0.03, R * 0.008); } for (let r2 = 0.34; r2 < 0.9; r2 += 0.18) { const aa = (a0 + a1) / 2 + (r2 * 7 % 0.3) - 0.15; ctx.fillStyle = TC.acero; ctx.beginPath(); ctx.arc(cx + Math.cos(aa) * R * r2, cy + Math.sin(aa) * R * r2, R * 0.022, 0, TAU); ctx.fill(); } }
  // anillo interior de refuerzo
  ctx.strokeStyle = '#7a5212'; ctx.lineWidth = R * 0.05; ctx.beginPath(); ctx.arc(cx + dz, cy + dz, R * 0.56, 0, TAU); ctx.stroke(); ctx.strokeStyle = '#c98d2e'; ctx.beginPath(); ctx.arc(cx, cy, R * 0.56, 0, TAU); ctx.stroke();
  // brazos en cajón (cara lateral oscura = profundidad) con herramientas
  for (let i = 0; i < 6; i++) { const a = ang + (i * TAU) / 6, ca = Math.cos(a), sa = Math.sin(a), nx = -sa, ny = ca, w0 = R * 0.075, r0 = R * 0.16, r1 = R * 0.97;
   const P4 = (r, s) => [cx + ca * r + nx * s, cy + sa * r + ny * s]; tq(ctx, [P4(r0, w0), P4(r1, w0), [P4(r1, w0)[0] + dz, P4(r1, w0)[1] + dz], [P4(r0, w0)[0] + dz, P4(r0, w0)[1] + dz]], '#6a4815');
   const g = ctx.createLinearGradient(P4(r0, -w0)[0], P4(r0, -w0)[1], P4(r0, w0)[0], P4(r0, w0)[1]); g.addColorStop(0, '#f0b955'); g.addColorStop(1, '#b97a22'); tq(ctx, [P4(r0, -w0), P4(r1, -w0), P4(r1, w0), P4(r0, w0)], g);
   ctx.fillStyle = 'rgba(60,40,20,0.25)'; for (let k = 0; k < 6; k++) ctx.fillRect(...P4(r0 + (r1 - r0) * rng(), (rng() - 0.5) * w0), R * 0.02, R * 0.006);
   // rascadores a ambos bordes y rippers en el eje
   for (let r = r0 + R * 0.06; r < r1 - R * 0.04; r += R * 0.085) { for (const s of [-1, 1]) { const p = P4(r, s * (w0 + R * 0.012)); ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(a); ctx.fillStyle = '#d7dde0'; ctx.fillRect(-R * 0.022, -R * 0.012, R * 0.044, R * 0.024); ctx.fillStyle = TC.acero; ctx.fillRect(-R * 0.022, s * R * 0.006, R * 0.044, R * 0.006); ctx.restore(); } }
   for (let r = r0 + R * 0.12; r < r1; r += R * 0.17) { const p = P4(r, 0); ctx.fillStyle = TC.acero; ctx.beginPath(); ctx.arc(p[0], p[1], R * 0.03, 0, TAU); ctx.fill(); ctx.fillStyle = TC.aceroL; ctx.beginPath(); ctx.arc(p[0] - R * 0.006, p[1] - R * 0.006, R * 0.012, 0, TAU); ctx.fill(); } }
  // aro exterior robusto con cortadores perimetrales (gálibo)
  ctx.strokeStyle = '#6a4815'; ctx.lineWidth = R * 0.09; ctx.beginPath(); ctx.arc(cx + dz, cy + dz, R * 0.95, 0, TAU); ctx.stroke(); const rg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.5, cx, cy, R); rg.addColorStop(0, '#f2bd5c'); rg.addColorStop(1, '#a8701e'); ctx.strokeStyle = rg; ctx.lineWidth = R * 0.08; ctx.beginPath(); ctx.arc(cx, cy, R * 0.95, 0, TAU); ctx.stroke();
  for (let k = 0; k < 30; k++) { const a = ang + (k * TAU) / 30, p = [cx + Math.cos(a) * R * 0.99, cy + Math.sin(a) * R * 0.99]; ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(a); ctx.fillStyle = TC.acero; ctx.fillRect(-R * 0.012, -R * 0.022, R * 0.04, R * 0.044); ctx.restore(); }
  // centro: cubo con cortador central (cola de pez)
  ctx.fillStyle = '#7a5212'; ctx.beginPath(); ctx.arc(cx + dz, cy + dz, R * 0.17, 0, TAU); ctx.fill(); const cg = ctx.createRadialGradient(cx - R * 0.05, cy - R * 0.05, 1, cx, cy, R * 0.17); cg.addColorStop(0, '#f2c068'); cg.addColorStop(1, '#a8701e'); ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, R * 0.17, 0, TAU); ctx.fill();
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang); ctx.fillStyle = TC.acero; ctx.beginPath(); ctx.moveTo(-R * 0.12, -R * 0.03); ctx.lineTo(R * 0.12, -R * 0.03); ctx.lineTo(R * 0.15, 0); ctx.lineTo(R * 0.12, R * 0.03); ctx.lineTo(-R * 0.12, R * 0.03); ctx.lineTo(-R * 0.15, 0); ctx.closePath(); ctx.fill(); ctx.restore();
  P.glow(ctx, cx - R * 0.4, cy - R * 0.5, R * 0.9, '255,220,150', 0.12);
  ctx.restore(); const am = ang + 0.12; return { tool: [cx + Math.cos(ang) * R * 0.7, cy + Math.sin(ang) * R * 0.7], opening: [cx + Math.cos(am) * R * 0.75, cy + Math.sin(am) * R * 0.75], rim: [cx + Math.cos(ang + 0.1) * R * 0.95, cy + Math.sin(ang + 0.1) * R * 0.95], center: [cx, cy] };
 };
 // Montaje de un anillo visto de frente dentro de la cola del escudo. Dovelas con volumen (cara frontal + canto), anillo anterior con juntas
 // longitudinales ESCALONADAS respecto al actual, erector con corona giratoria, brazo telescópico y pinza de dos patines, alimentador abajo.
 // o: { placed (0..7 continuo) }. Orden: solera → laterales alternos → clave (llave al final).
 P.ringBuild = (ctx, cx, cy, R, t, o = {}) => {
  const Ro = R, Ri = R * 0.84, n = 7, gap = 0.012, pl = o.placed ?? 0, k = Math.floor(pl), u = pl - k, dep = 0.955, stag = Math.PI / n;
  const ann = (a0, a1, r0, r1, sc, c) => { ctx.beginPath(); ctx.arc(cx, cy, r1 * sc, a0, a1); ctx.arc(cx, cy, r0 * sc, a1, a0, true); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); };
  const seg = (a0, a1, rOut, front, back, glow) => { const s = rOut / Ro; ann(a0, a1, Ri * s, Ro * s, dep, back); ctx.beginPath(); ctx.moveTo(cx + Math.cos(a0) * Ri * s, cy + Math.sin(a0) * Ri * s); ctx.lineTo(cx + Math.cos(a0) * Ri * s * dep, cy + Math.sin(a0) * Ri * s * dep); ctx.arc(cx, cy, Ri * s * dep, a0, a1); ctx.lineTo(cx + Math.cos(a1) * Ri * s, cy + Math.sin(a1) * Ri * s); ctx.arc(cx, cy, Ri * s, a1, a0, true); ctx.closePath(); ctx.fillStyle = '#7e8789'; ctx.fill(); ann(a0, a1, Ri * s, Ro * s, 1, front); ctx.strokeStyle = 'rgba(48,60,67,0.9)'; ctx.lineWidth = Math.max(1.5, R * 0.006); ctx.beginPath(); ctx.arc(cx, cy, (Ri + (Ro - Ri) * 0.78) * s, a0 + 0.02, a1 - 0.02); ctx.stroke(); if (glow) { ctx.strokeStyle = `rgba(255,212,71,${glow})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, Ro * s, a0, a1); ctx.arc(cx, cy, Ri * s, a1, a0, true); ctx.closePath(); ctx.stroke(); } };
  ctx.save();
  // escudo (piel de acero con bisel interior)
  ctx.fillStyle = TC.acero; ctx.beginPath(); ctx.arc(cx, cy, R * 1.12, 0, TAU); ctx.arc(cx, cy, R * 1.01, 0, TAU, true); ctx.fill(); ctx.strokeStyle = 'rgba(169,188,197,0.5)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, R * 1.11, Math.PI * 1.1, Math.PI * 1.6); ctx.stroke(); ctx.fillStyle = '#151d22'; ctx.beginPath(); ctx.arc(cx, cy, R * 1.01, 0, TAU); ctx.fill();
  // anillo anterior (ya montado, más atrás): juntas desfasadas media dovela
  for (let i = 0; i < n; i++) { const a0 = -Math.PI / 2 + stag + (i * TAU) / n + gap, a1 = -Math.PI / 2 + stag + ((i + 1) * TAU) / n - gap; seg(a0, a1, Ro * 0.985, '#7d878a', '#646c6e'); }
  const order = [3, 2, 4, 1, 5, 6, 0], ang = (j) => [-Math.PI / 2 + (j * TAU) / n + gap, -Math.PI / 2 + ((j + 1) * TAU) / n - gap];
  for (let i = 0; i < Math.min(k, n); i++) { const [a0, a1] = ang(order[i]); seg(a0, a1, Ro, TC.hormigon, '#8f989b', o.glowPlaced ? o.glowPlaced : 0); }
  // erector: corona giratoria, contrapeso, brazo telescópico y pinza
  const j = k < n ? order[k] : order[n - 1], [b0, b1] = ang(j), am = (b0 + b1) / 2, start = Math.PI / 2; let d = am - start; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU;
  const p1 = E.inOut(cl(u / 0.22)), p2 = E.inOut(cl((u - 0.22) / 0.48)), p3 = E.inOut(cl((u - 0.7) / 0.3)), a = k < n ? start + d * p2 : am, rr = k < n ? lerp(Ro * 0.6, Ro * 0.7, p1) + (Ro - Ro * 0.7) * p3 : Ro * 0.6;
  ctx.strokeStyle = '#4b5d68'; ctx.lineWidth = R * 0.05; ctx.beginPath(); ctx.arc(cx, cy, R * 0.42, 0, TAU); ctx.stroke(); ctx.strokeStyle = '#6f8592'; ctx.lineWidth = R * 0.014; ctx.beginPath(); ctx.arc(cx, cy, R * 0.44, 0, TAU); ctx.stroke();
  const ca = Math.cos(a), sa = Math.sin(a), nx = -sa, ny = ca; tq(ctx, [[cx - ca * R * 0.42 + nx * R * 0.09, cy - sa * R * 0.42 + ny * R * 0.09], [cx - ca * R * 0.3 + nx * R * 0.09, cy - sa * R * 0.3 + ny * R * 0.09], [cx - ca * R * 0.3 - nx * R * 0.09, cy - sa * R * 0.3 - ny * R * 0.09], [cx - ca * R * 0.42 - nx * R * 0.09, cy - sa * R * 0.42 - ny * R * 0.09]], '#3a4851');
  const rIn = rr - (Ro - Ri) - R * 0.04; for (const s of [-1, 1]) tq(ctx, [[cx + nx * s * R * 0.06, cy + ny * s * R * 0.06], [cx + ca * R * 0.46 + nx * s * R * 0.06, cy + sa * R * 0.46 + ny * s * R * 0.06], [cx + ca * R * 0.46 + nx * s * R * 0.03, cy + sa * R * 0.46 + ny * s * R * 0.03], [cx + nx * s * R * 0.03, cy + ny * s * R * 0.03]], '#5c7180');
  tq(ctx, [[cx + ca * R * 0.3 + nx * R * 0.035, cy + sa * R * 0.3 + ny * R * 0.035], [cx + ca * rIn + nx * R * 0.035, cy + sa * rIn + ny * R * 0.035], [cx + ca * rIn - nx * R * 0.035, cy + sa * rIn - ny * R * 0.035], [cx + ca * R * 0.3 - nx * R * 0.035, cy + sa * R * 0.3 - ny * R * 0.035]], TC.oro);
  for (const s of [-1, 1]) { const px = cx + ca * (rIn + R * 0.02) + nx * s * R * 0.07, py = cy + sa * (rIn + R * 0.02) + ny * s * R * 0.07; ctx.save(); ctx.translate(px, py); ctx.rotate(a + Math.PI / 2); ctx.fillStyle = '#2c3a42'; ctx.fillRect(-R * 0.035, -R * 0.02, R * 0.07, R * 0.04); ctx.restore(); }
  ctx.fillStyle = '#4b5d68'; ctx.beginPath(); ctx.arc(cx, cy, R * 0.14, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2c3a42'; ctx.lineWidth = R * 0.02; ctx.stroke();
  if (k < n) seg(b0 + (a - am), b1 + (a - am), rr, '#cfd6d8', '#9aa3a6', 0.7);
  // alimentador (abajo, delante de la solera) con la dovela siguiente
  if (k < n - 1 && o.feeder !== false) { ctx.fillStyle = '#4f6470'; ctx.fillRect(cx - R * 0.32, cy + R * 0.66, R * 0.64, R * 0.06); }
  ctx.restore();
  const [c0, c1] = ang(order[Math.max(0, Math.min(k, n) - 1)]); return { erector: [cx + ca * R * 0.38, cy + sa * R * 0.38], held: [cx + Math.cos(a) * (rr - (Ro - Ri) / 2), cy + Math.sin(a) * (rr - (Ro - Ri) / 2)], ring: [cx + Math.cos((c0 + c1) / 2) * (Ro + Ri) / 2, cy + Math.sin((c0 + c1) / 2) * (Ro + Ri) / 2], prev: [cx + Math.cos(-Math.PI / 2 + stag + 0.02) * Ro * 0.92, cy + Math.sin(-Math.PI / 2 + stag + 0.02) * Ro * 0.92], shield: [cx + R * 0.76, cy - R * 0.76] };
 };
 // Sección transversal del revestimiento en el terreno: terreno excavado (con agua en los poros), hueco anular que se rellena de lechada
 // (inyección desde abajo hacia arriba), anillo de 7 dovelas con juntas y sellos comprimidos, superficie interior seca.
 // o: { grout 0..1, press 0..1, glowJoint }
 P.ringSection = (ctx, cx, cy, R, t, o = {}) => {
  const Rb = R * 1.08, Ro = R, Ri = R * 0.86, n = 7, off = -Math.PI / 2 + Math.PI / n, gr = cl(o.grout ?? 1);
  ctx.save();
  const sg = ctx.createRadialGradient(cx, cy, Rb, cx, cy, Rb * 2.4); sg.addColorStop(0, '#9c7656'); sg.addColorStop(1, '#6e523b'); ctx.fillStyle = sg; ctx.fillRect(cx - 1200, cy - 1400, 2400, 2800);
  const Rr = H.rng(19); for (let i = 0; i < 420; i++) { const a = Rr() * TAU, r = Rb * (1.04 + Rr() * 1.6), x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; ctx.fillStyle = Rr() < 0.3 ? 'rgba(41,135,167,0.45)' : 'rgba(0,0,0,0.12)'; ctx.beginPath(); ctx.arc(x, y, R * 0.008 * (1 + Rr()), 0, TAU); ctx.fill(); }
  // hueco anular (oscuro) y lechada que lo va llenando desde la solera hacia la clave por ambos lados
  ctx.fillStyle = '#20282c'; ctx.beginPath(); ctx.arc(cx, cy, Rb, 0, TAU); ctx.arc(cx, cy, Ro, 0, TAU, true); ctx.fill();
  if (gr > 0) { const sp = Math.PI * gr; ctx.fillStyle = TC.lechada; ctx.beginPath(); ctx.arc(cx, cy, Rb, Math.PI / 2 - sp, Math.PI / 2 + sp); ctx.arc(cx, cy, Ro, Math.PI / 2 + sp, Math.PI / 2 - sp, true); ctx.closePath(); ctx.fill(); if (gr < 1) for (const s of [-1, 1]) { const a = Math.PI / 2 + s * sp; P.glow(ctx, cx + Math.cos(a) * (Ro + Rb) / 2, cy + Math.sin(a) * (Ro + Rb) / 2, R * 0.08, '214,207,194', 0.6); } }
  // dovelas con juntas y sellos (en la ranura cerca de la cara exterior)
  for (let i = 0; i < n; i++) { const a0 = off + (i * TAU) / n + 0.008, a1 = off + ((i + 1) * TAU) / n - 0.008; const g = ctx.createRadialGradient(cx, cy, Ri, cx, cy, Ro); g.addColorStop(0, '#9aa4a7'); g.addColorStop(1, '#c4ccce'); ctx.beginPath(); ctx.arc(cx, cy, Ro, a0, a1); ctx.arc(cx, cy, Ri, a1, a0, true); ctx.closePath(); ctx.fillStyle = g; ctx.fill(); }
  for (let i = 0; i < n; i++) { const a = off + (i * TAU) / n, rS = Ro - (Ro - Ri) * 0.22; ctx.save(); ctx.translate(cx + Math.cos(a) * rS, cy + Math.sin(a) * rS); ctx.rotate(a); ctx.fillStyle = TC.sello; ctx.fillRect(-R * 0.025, -R * 0.016, R * 0.05, R * 0.032); ctx.restore(); if (o.glowJoint && i === 3) { P.glow(ctx, cx + Math.cos(a) * rS, cy + Math.sin(a) * rS, R * 0.12, '255,212,71', 0.5 * o.glowJoint); } }
  // interior seco
  const ig = ctx.createRadialGradient(cx, cy - R * 0.2, 4, cx, cy, Ri); ig.addColorStop(0, '#3e4b52'); ig.addColorStop(1, '#232d32'); ctx.fillStyle = ig; ctx.beginPath(); ctx.arc(cx, cy, Ri, 0, TAU); ctx.fill();
  const pr = o.press || 0; if (pr > 0) { ctx.save(); ctx.globalAlpha *= pr; for (let k = 0; k < 10; k++) { const a = (k * TAU) / 10 + 0.3; ctx.save(); ctx.translate(cx + Math.cos(a) * (Rb + R * 0.32), cy + Math.sin(a) * (Rb + R * 0.32)); ctx.rotate(a + Math.PI); P.hArrow(ctx, 0, 0, R * 0.2, TC.presion, R * 0.045); ctx.restore(); } ctx.restore(); }
  ctx.restore(); const aj = off + (3 * TAU) / n; return { grout: [cx + Math.cos(-0.6) * (Ro + Rb) / 2, cy + Math.sin(-0.6) * (Ro + Rb) / 2], seg: [cx + Math.cos(0.2) * (Ro + Ri) / 2, cy + Math.sin(0.2) * (Ro + Ri) / 2], joint: [cx + Math.cos(aj) * (Ro - (Ro - Ri) * 0.22), cy + Math.sin(aj) * (Ro - (Ro - Ri) * 0.22)], soil: [cx + Rb * 1.4, cy - Rb * 0.9], inside: [cx, cy + Ri * 0.4], top: [cx + Math.cos(off + (5 * TAU) / n) * Ro, cy + Math.sin(off + (5 * TAU) / n) * Ro] };
 };
 // Sección transversal: río que fluye a lo ancho, columna de agua, lecho, capas y el túnel (círculo) bajo el lecho.
 // o: { mode 'obra'|'terminado', cx, train 0..1 (tren visto de frente), boats, flow, press, xray (corte transparente), dusk, ring (dovelas visibles) }
 P.tunCross = (ctx, t, o = {}) => {
  const { GS, WS, TY, R, ti } = TUN, cx = o.cx ?? 540, XA = -1500, XB = 2600, yb = (x) => 965 + 16 * Math.sin(x * 0.006 + 1) + 8 * Math.sin(x * 0.021), Ro = R - 10, Ri = Ro - ti;
  ctx.save();
  const sg = ctx.createLinearGradient(0, -1200, 0, WS); sg.addColorStop(0, '#0B1821'); sg.addColorStop(1, o.dusk ? '#9a7458' : '#5d8aa4'); ctx.fillStyle = sg; ctx.fillRect(XA, -3000, XB - XA, WS + 3000);
  // orilla lejana con ciudad
  ctx.fillStyle = '#4d5a52'; ctx.fillRect(XA, WS - 40, XB - XA, 40); for (const b of CITY) { const x = (b.x * 1.3) % 4000 - 1500; ctx.fillStyle = b.c; ctx.fillRect(x, WS - 40 - b.h * 0.7, b.w * 0.8, b.h * 0.7); ctx.fillStyle = o.dusk ? 'rgba(255,214,150,0.6)' : 'rgba(215,237,240,0.18)'; for (let yy = WS - 40 - b.h * 0.7 + 8; yy < WS - 48; yy += 14) for (let xx = x + 5; xx < x + b.w * 0.8 - 5; xx += 11) if (((xx * 7 + yy * 3) | 0) % 5) ctx.fillRect(xx, yy, 4, 6); }
  // agua: columna con degradado, rayos, partículas y corriente que fluye hacia +x
  const ag = ctx.createLinearGradient(0, WS, 0, 1000); ag.addColorStop(0, TC.aguaL); ag.addColorStop(1, TC.aguaP); ctx.fillStyle = ag; ctx.fillRect(XA, WS, XB - XA, 1100 - WS);
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (let k = -3; k < 9; k++) { const x = k * 260 + 40 * Math.sin(t * 0.3 + k); const g = ctx.createLinearGradient(0, WS, 0, 990); g.addColorStop(0, 'rgba(120,200,220,0.12)'); g.addColorStop(1, 'rgba(120,200,220,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x, WS); ctx.lineTo(x + 60, WS); ctx.lineTo(x + 150, 990); ctx.lineTo(x + 70, 990); ctx.closePath(); ctx.fill(); } ctx.restore();
  const fl = o.flow ?? 1; { const Rr = H.rng(13); for (let i = 0; i < 160; i++) { const y = Rr.range(WS + 10, 960), sp = Rr.range(30, 90) * fl, x = XA + ((Rr.range(0, XB - XA) + t * sp) % (XB - XA)); ctx.fillStyle = 'rgba(215,237,240,0.3)'; ctx.fillRect(x, y, 2 + sp * 0.06, 1.6); } }
  ctx.strokeStyle = TC.espuma; ctx.lineWidth = 3; ctx.beginPath(); for (let x = XA; x <= XB; x += 12) { const y = WS + 3 * Math.sin(x * 0.03 - t * 2.4); x === XA ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke();
  if (o.boats !== false) for (const [x0, sp, c, sc] of [[-100, 40, '#c9cfd2', 1], [700, 26, '#d4a24e', 0.8], [1300, 33, '#e8ecef', 0.6]]) { const x = -500 + ((x0 + 500 + t * sp) % 2100), y = WS + 2 * Math.sin(t * 1.4 + x0); tq(ctx, [[x - 90 * sc, y - 8], [x + 100 * sc, y - 8], [x + 78 * sc, y + 14], [x - 74 * sc, y + 14]], c); tq(ctx, [[x - 40 * sc, y - 40 * sc], [x + 36 * sc, y - 40 * sc], [x + 36 * sc, y - 8], [x - 40 * sc, y - 8]], '#e8ecef'); ctx.fillStyle = 'rgba(41,135,167,0.5)'; ctx.fillRect(x - 74 * sc, y + 14, 152 * sc, 6); }
  // lecho y capas
  const lay = [[(x) => yb(x), TC.arena], [(x) => Math.max(yb(x) + 50, 1150 + 20 * Math.sin(x * 0.004)), TC.arcilla], [(x) => 1505 + 18 * Math.sin(x * 0.003 + 1), TC.grava], [(x) => 1650 + 24 * Math.sin(x * 0.0025 + 2), TC.roca]];
  for (const [f, c] of lay) { ctx.beginPath(); ctx.moveTo(XA, 3400); for (let x = XA; x <= XB; x += 20) ctx.lineTo(x, f(x)); ctx.lineTo(XB, 3400); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 2; ctx.stroke(); }
  { const Rr = H.rng(6); ctx.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 700; i++) { const x = Rr.range(XA, XB), y = Rr.range(yb(x) + 6, 2300); ctx.fillRect(x, y, 3, 2); } ctx.fillStyle = 'rgba(66,93,80,0.6)'; for (let x = XA; x < XB; x += 34) { const y = yb(x); ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 3 + 4 * Math.sin(t + x), y - 14, x + 6, y); ctx.fill(); } }
  // lecho de sedimentos (limo) con ondulaciones y cáusticas de luz que se mueven sobre él
  { ctx.fillStyle = '#8f7d63'; ctx.beginPath(); ctx.moveTo(XA, yb(XA)); for (let x = XA; x <= XB; x += 16) ctx.lineTo(x, yb(x) - 2 + 2 * Math.sin(x * 0.09)); for (let x = XB; x >= XA; x -= 16) ctx.lineTo(x, yb(x) + 16); ctx.closePath(); ctx.fill(); ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(140,210,230,0.18)'; ctx.lineWidth = 3; for (let k = 0; k < 3; k++) { ctx.beginPath(); for (let x = XA; x <= XB; x += 14) { const y = yb(x) - 4 - k * 9 + 5 * Math.sin(x * 0.03 + t * 1.3 + k * 2); x === XA ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke(); } ctx.restore(); const hz = ctx.createLinearGradient(0, WS, 0, 990); hz.addColorStop(0, 'rgba(18,61,84,0)'); hz.addColorStop(1, 'rgba(18,61,84,0.35)'); ctx.fillStyle = hz; ctx.fillRect(XA, WS + 8, XB - XA, 980 - WS); }
  // corte transparente del terreno sobre el túnel
  if (o.xray) { ctx.save(); ctx.globalAlpha *= o.xray; ctx.fillStyle = 'rgba(244,247,248,0.12)'; ctx.fillRect(cx - R - 40, yb(cx), 2 * R + 80, TY - R - yb(cx)); ctx.strokeStyle = 'rgba(244,247,248,0.7)'; ctx.setLineDash([12, 10]); ctx.lineWidth = 3; ctx.strokeRect(cx - R - 40, yb(cx), 2 * R + 80, TY - R - yb(cx)); ctx.setLineDash([]); ctx.restore(); }
  // túnel: perforación, lechada, anillo de dovelas con juntas y sellos, interior
  ctx.fillStyle = TC.lechada; ctx.beginPath(); ctx.arc(cx, TY, R, 0, TAU); ctx.fill();
  const n = 7, off = o.ringOff ?? 0.2; for (let i = 0; i < n; i++) { const a0 = off + (i * TAU) / n + 0.012, a1 = off + ((i + 1) * TAU) / n - 0.012; ctx.beginPath(); ctx.arc(cx, TY, Ro, a0, a1); ctx.arc(cx, TY, Ri, a1, a0, true); ctx.closePath(); ctx.fillStyle = TC.hormigon; ctx.fill(); const am = off + (i * TAU) / n; ctx.fillStyle = TC.sello; ctx.beginPath(); ctx.arc(cx + Math.cos(am) * (Ro - 3), TY + Math.sin(am) * (Ro - 3), 2, 0, TAU); ctx.fill(); }
  const ig = ctx.createRadialGradient(cx, TY, 4, cx, TY, Ri); ig.addColorStop(0, o.mode === 'terminado' ? '#46555c' : '#1d272d'); ig.addColorStop(1, o.mode === 'terminado' ? '#2a353b' : '#10171b'); ctx.fillStyle = ig; ctx.beginPath(); ctx.arc(cx, TY, Ri, 0, TAU); ctx.fill();
  if (o.mode === 'terminado') { ctx.save(); ctx.beginPath(); ctx.arc(cx, TY, Ri, 0, TAU); ctx.clip(); ctx.fillStyle = '#8e979a'; ctx.fillRect(cx - Ri, TY + Ri * 0.55, 2 * Ri, Ri); ctx.fillStyle = '#c9d2d6'; ctx.fillRect(cx - Ri * 0.42, TY + Ri * 0.55 - 3, 5, 3); ctx.fillRect(cx + Ri * 0.38, TY + Ri * 0.55 - 3, 5, 3); for (const s of [-1, 1]) P.glow(ctx, cx + s * Ri * 0.6, TY - Ri * 0.55, 14, '255,236,200', 0.8);
   const tr = o.train ?? 0; if (tr > 0) { ctx.globalAlpha *= tr; const w2 = Ri * 0.62, h2 = Ri * 1.05, y1 = TY + Ri * 0.55 - 3; ctx.fillStyle = '#d9dee0'; ctx.beginPath(); ctx.roundRect(cx - w2, y1 - h2, 2 * w2, h2 - 2, [16, 16, 4, 4]); ctx.fill(); ctx.fillStyle = 'rgba(40,60,75,0.9)'; ctx.fillRect(cx - w2 * 0.75, y1 - h2 * 0.82, w2 * 1.5, h2 * 0.32); ctx.fillStyle = TC.protegida; ctx.fillRect(cx - w2, y1 - h2 * 0.32, 2 * w2, 3); for (const s of [-1, 1]) P.glow(ctx, cx + s * w2 * 0.6, y1 - h2 * 0.18, 14, '255,240,200', 0.9); } ctx.restore(); }
  const pr = o.press || 0; if (pr > 0) { ctx.save(); ctx.globalAlpha *= pr; for (let k = 0; k < 12; k++) { const a = (k * TAU) / 12; ctx.save(); ctx.translate(cx + Math.cos(a) * (R + 46), TY + Math.sin(a) * (R + 46)); ctx.rotate(a + Math.PI); P.hArrow(ctx, 0, 0, 34, TC.presion, 9); ctx.restore(); } for (let x = cx - 260; x <= cx + 260; x += 130) { ctx.save(); ctx.translate(x, WS + 60); ctx.rotate(Math.PI / 2); P.hArrow(ctx, 0, 0, 150, 'rgba(255,115,90,0.75)', 12); ctx.restore(); } ctx.restore(); }
  ctx.restore();
  return { tunnel: [cx, TY], crown: [cx, TY - Ro], ring: [cx + Ro * 0.7, TY - Ro * 0.7], bed: [cx, yb(cx)], water: [cx, (WS + yb(cx)) / 2], surface: [cx, WS], sand: [cx + 200, (yb(cx + 200) + 1150) / 2], clay: [cx + 260, 1250], gravel: [cx + 260, 1570] };
 };
 // Toma aérea de un río ancho atravesando una ciudad (perspectiva desde lo alto). o: { alt 0..1 (1 alto → 0 sobre el agua), dusk, tunnel (línea del trazado, 0..1) }
 P.riverAerial = (ctx, t, o = {}) => {
  const alt = o.alt ?? 1, hz = 360 - 260 * (1 - alt), f = 900, h = lerp(60, 600, alt), pr = (X, Z) => [540 + (X * f) / Z, hz + (h * f) / Z / 6 * 6 / 6 * 1 + 0], P3 = (X, Y, Z) => [540 + (X * f) / Z, hz + ((h - Y) * f) / Z];
  ctx.save();
  const sg = ctx.createLinearGradient(0, 0, 0, hz); sg.addColorStop(0, '#0B1821'); sg.addColorStop(1, o.dusk ? '#c08a5a' : '#7fa7bd'); ctx.fillStyle = sg; ctx.fillRect(0, 0, 1080, hz + 2);
  ctx.fillStyle = '#4e5a4c'; ctx.fillRect(0, hz, 1080, 1920 - hz);
  // río: banda curva que va hacia el horizonte
  const rX = (Z) => 80 * Math.sin(Z * 0.0018) - 40, rW = 380, zs = []; for (let Z = 220; Z < 9000; Z *= 1.06) zs.push(Z);
  ctx.beginPath(); zs.forEach((Z, i) => { const p = P3(rX(Z) - rW, 0, Z); i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); }); zs.slice().reverse().forEach((Z) => { const p = P3(rX(Z) + rW, 0, Z); ctx.lineTo(p[0], p[1]); }); ctx.closePath(); const rg = ctx.createLinearGradient(0, hz, 0, 1920); rg.addColorStop(0, '#6f9fb2'); rg.addColorStop(0.3, TC.aguaL); rg.addColorStop(1, TC.aguaP); ctx.fillStyle = rg; ctx.fill();
  ctx.save(); ctx.clip(); const Rr = H.rng(41); ctx.strokeStyle = 'rgba(215,237,240,0.35)'; ctx.lineWidth = 2; for (let i = 0; i < 90; i++) { const X = Rr.range(-rW, rW), Z = 250 + ((Rr.range(0, 6000) - t * 160) % 6000 + 6000) % 6000, a = P3(rX(Z) + X, 0, Z), b = P3(rX(Z) + X, 0, Z + 60); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } ctx.restore();
  // trazado del túnel bajo el río (discontinuo)
  if (o.tunnel) { ctx.save(); ctx.globalAlpha *= o.tunnel; ctx.strokeStyle = TC.oro; ctx.lineWidth = 4; ctx.setLineDash([18, 12]); const Zt = 1500, a = P3(-1800, 0, Zt), b = P3(1800, 0, Zt); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); ctx.restore(); }
  // barcos
  for (const [X, Z0, sp, c] of [[-120, 1600, 90, '#e8ecef'], [140, 2600, -70, '#d4a24e'], [-40, 4200, 60, '#c9cfd2']]) { const Z = Z0 + ((t * sp) % 1200), p = P3(rX(Z) + X, 0, Z), s = f / Z; tq(ctx, [[p[0] - 14 * s, p[1] - 40 * s], [p[0] + 14 * s, p[1] - 40 * s], [p[0] + 16 * s, p[1] + 40 * s], [p[0] - 16 * s, p[1] + 40 * s]], c); ctx.strokeStyle = 'rgba(215,237,240,0.5)'; ctx.lineWidth = Math.max(1, 3 * s); ctx.beginPath(); ctx.moveTo(p[0] - 16 * s, p[1] + 40 * s); ctx.lineTo(p[0] - 40 * s, p[1] + 140 * s); ctx.moveTo(p[0] + 16 * s, p[1] + 40 * s); ctx.lineTo(p[0] + 40 * s, p[1] + 140 * s); ctx.stroke(); }
  // ciudad: bloques extruidos en ambas orillas (de lejos a cerca)
  const blocks = []; { const Rr = H.rng(43); for (let Z = 300; Z < 7000; Z += Rr.range(120, 220)) for (const s of [-1, 1]) for (let j = 0; j < 4; j++) { const X = rX(Z) + s * (rW + 90 + j * 260 + Rr.range(0, 60)), w = Rr.range(120, 200), d = Rr.range(100, 180), hb = Rr.range(80, 420) * (j === 0 ? 0.6 : 1); blocks.push({ X, Z, w, d, hb, c: Rr() < 0.5 ? '#3a4d5a' : '#465b68' }); } }
  blocks.sort((a, b) => b.Z - a.Z).forEach((b) => { const x0 = b.X - b.w / 2, x1 = b.X + b.w / 2, z0 = b.Z, z1 = b.Z + b.d; const F = [P3(x0, 0, z0), P3(x1, 0, z0), P3(x1, b.hb, z0), P3(x0, b.hb, z0)], T = [P3(x0, b.hb, z0), P3(x1, b.hb, z0), P3(x1, b.hb, z1), P3(x0, b.hb, z1)]; const side = b.X < 0 ? [P3(x1, 0, z0), P3(x1, 0, z1), P3(x1, b.hb, z1), P3(x1, b.hb, z0)] : [P3(x0, 0, z0), P3(x0, 0, z1), P3(x0, b.hb, z1), P3(x0, b.hb, z0)]; tq(ctx, side, '#2b3a44'); tq(ctx, F, b.c); tq(ctx, T, '#6f8592'); if (o.dusk) { ctx.fillStyle = 'rgba(255,214,150,0.5)'; const s = f / z0; for (let yy = 12; yy < b.hb - 10; yy += 26) { const p = P3(x0 + 10, yy, z0); ctx.fillRect(p[0], p[1] - 6 * s, (b.w - 20) * s, 6 * s); } } });
  ctx.restore();
 };
 // Junta entre dovelas en macro (corte por la junta): dos cantos de hormigón con ranura, sello elastomérico (perfil con huecos)
 // que se comprime al cerrar la junta; agua y terreno presionan desde fuera (arriba); la lechada rellena el espacio anular.
 P.gasketHD = (ctx, cx, cy, s, t, o = {}) => {
  const c = cl(o.close ?? 1), gap = lerp(s * 0.5, s * 0.06, c), th = s * 1.6, gw = s * 0.36, gh = lerp(s * 0.3, s * 0.2, c);
  ctx.save();
  // exterior: lechada y terreno con agua a presión
  ctx.fillStyle = TC.arcilla; ctx.fillRect(cx - s * 4, cy - th / 2 - s * 1.6, s * 8, s * 1.0); ctx.fillStyle = TC.lechada; ctx.fillRect(cx - s * 4, cy - th / 2 - s * 0.6, s * 8, s * 0.6);
  const wa = o.water ?? 1; if (wa > 0) { ctx.save(); ctx.globalAlpha *= wa; ctx.fillStyle = 'rgba(41,135,167,0.55)'; ctx.beginPath(); ctx.moveTo(cx - gap / 2 - s * 0.4, cy - th / 2 - s * 0.6); ctx.lineTo(cx + gap / 2 + s * 0.4, cy - th / 2 - s * 0.6); ctx.lineTo(cx + gap / 2, cy - th / 2); ctx.lineTo(cx + gap / 2, cy - th / 2 + s * 0.42); ctx.lineTo(cx - gap / 2, cy - th / 2 + s * 0.42); ctx.lineTo(cx - gap / 2, cy - th / 2); ctx.closePath(); ctx.fill(); for (const dx of [-1.6, 0, 1.6]) { ctx.save(); ctx.translate(cx + dx * s, cy - th / 2 - s * 1.5); ctx.rotate(Math.PI / 2); P.hArrow(ctx, 0, 0, s * 0.7, TC.presion, s * 0.16); ctx.restore(); } ctx.restore(); }
  // dos dovelas (cantos) con ranura para el sello
  for (const sg of [-1, 1]) { const x0 = sg < 0 ? cx - s * 4 : cx + gap / 2, x1 = sg < 0 ? cx - gap / 2 : cx + s * 4; const g = ctx.createLinearGradient(0, cy - th / 2, 0, cy + th / 2); g.addColorStop(0, '#c7cfd1'); g.addColorStop(1, '#949ea1'); ctx.fillStyle = g; ctx.fillRect(x0, cy - th / 2, x1 - x0, th); ctx.fillStyle = 'rgba(0,0,0,0.08)'; const Rr = H.rng(sg > 0 ? 3 : 4); for (let i = 0; i < 80; i++) ctx.fillRect(Rr.range(x0, x1), Rr.range(cy - th / 2, cy + th / 2), 2, 2);
   const ex = sg < 0 ? cx - gap / 2 : cx + gap / 2; ctx.fillStyle = '#2a3337'; ctx.fillRect(sg < 0 ? ex - gw * 0.55 : ex, cy - th / 2 + s * 0.42, gw * 0.55, gh + s * 0.04);
   // sello elastomérico con huecos (se comprime y ensancha)
   const gx0 = sg < 0 ? ex - gw * 0.55 : ex - (gw * 0.5 - gw * 0.55) * 0, gx = sg < 0 ? ex - gw * 0.5 : ex, wgt = gw * 0.5 + (c > 0.5 ? (c - 0.5) * 0.12 * s : 0); ctx.fillStyle = TC.sello; ctx.beginPath(); ctx.roundRect(sg < 0 ? ex - gw * 0.5 : ex, cy - th / 2 + s * 0.44, wgt, gh, s * 0.04); ctx.fill(); ctx.fillStyle = '#1b2226'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse((sg < 0 ? ex - gw * 0.5 : ex) + wgt * (0.2 + i * 0.3), cy - th / 2 + s * 0.44 + gh * 0.5, wgt * 0.08, gh * 0.25 * (1 - 0.5 * c), 0, 0, TAU); ctx.fill(); } void gx0; void gx; }
  // perno curvo de unión entre dovelas
  ctx.strokeStyle = '#5a6a73'; ctx.lineWidth = s * 0.12; ctx.beginPath(); ctx.moveTo(cx - s * 1.4, cy + th * 0.3); ctx.quadraticCurveTo(cx, cy + th * 0.05, cx + s * 1.4, cy + th * 0.3); ctx.stroke();
  // interior del túnel (seco)
  ctx.fillStyle = 'rgba(67,208,198,0.18)'; ctx.fillRect(cx - s * 4, cy + th / 2, s * 8, s * 0.9);
  ctx.restore();
  return { gasket: [cx, cy - th / 2 + s * 0.44 + gh / 2], water: [cx + s * 1.6, cy - th / 2 - s * 1.5], grout: [cx - s * 2.6, cy - th / 2 - s * 0.3], segL: [cx - s * 2.6, cy + th * 0.1], segR: [cx + s * 2.6, cy + th * 0.1], bolt: [cx + s * 1.0, cy + th * 0.22], inside: [cx - s * 2.8, cy + th / 2 + s * 0.45] };
 };
 // Interior de un túnel ferroviario terminado en perspectiva: anillos que se alejan, juntas, luminarias, bandejas de cables, andén de evacuación, vía y tren.
 // o: { train (z del frente del tren; null = sin tren), dir (1 se aleja / −1 se acerca), speed (para las luces), cam (desplazamiento lateral) }
 P.tunnelView = (ctx, t, o = {}) => {
  const vx = 540 + (o.cam || 0), vy = 900, F = 520, pr = (X, Y, z) => [vx + (X * F) / z, vy + (Y * F) / z];
  ctx.save(); ctx.fillStyle = '#0d1418'; ctx.fillRect(0, 0, 1080, 1920);
  // paredes: discos rellenos de cerca a lejos (más oscuros con la distancia) y juntas de anillo
  const zf = 60, sp = o.speed ?? 0, ph = (t * sp) % 0.6; for (let z = 0.3; z <= zf; z += 0.6) { const zz = z - ph; if (zz < 0.3) continue; const p = pr(0, 0, zz), rr = F / zz, sh = Math.max(0, Math.min(1, 1.1 / zz)); ctx.fillStyle = `rgb(${Math.round(26 + 104 * sh)},${Math.round(34 + 106 * sh)},${Math.round(38 + 106 * sh)})`; ctx.beginPath(); ctx.arc(p[0], p[1], rr, 0, TAU); ctx.fill(); ctx.strokeStyle = `rgba(20,26,30,${0.25 + 0.4 * sh})`; ctx.lineWidth = Math.max(1, 6 / zz); ctx.stroke(); for (let k = 0; k < 7; k++) { const a = ((Math.round(z / 0.6) % 2) * 0.45) + (k * TAU) / 7; ctx.beginPath(); ctx.moveTo(p[0] + Math.cos(a) * rr, p[1] + Math.sin(a) * rr); ctx.lineTo(p[0] + Math.cos(a) * F / (zz + 0.6), p[1] + Math.sin(a) * F / (zz + 0.6)); ctx.stroke(); } }
  ctx.fillStyle = '#0e1418'; ctx.beginPath(); ctx.arc(vx, vy, F / zf, 0, TAU); ctx.fill();
  // luminarias en la clave y bandejas
  for (let z = 1; z < 40; z += 2.4) { const zz = z - ((t * sp) % 2.4); if (zz < 0.7) continue; const a = pr(-0.55, -0.72, zz), b = pr(0.55, -0.72, zz); P.glow(ctx, a[0], a[1], 90 / zz, '255,236,200', 0.6); P.glow(ctx, b[0], b[1], 90 / zz, '255,236,200', 0.6); }
  ctx.strokeStyle = 'rgba(60,70,76,0.9)'; ctx.lineWidth = 6; for (const X of [-0.9, 0.9]) { const a = pr(X, -0.2, 0.3), b = pr(X, -0.2, zf); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  // solera, andén y vía
  tq(ctx, [pr(-0.84, 0.55, 0.28), pr(0.84, 0.55, 0.28), pr(0.84, 0.55, zf), pr(-0.84, 0.55, zf)], '#6f787b'); tq(ctx, [pr(0.55, 0.42, 0.28), pr(0.9, 0.42, 0.28), pr(0.9, 0.42, zf), pr(0.55, 0.42, zf)], '#8e979a'); tq(ctx, [pr(0.55, 0.42, 0.28), pr(0.55, 0.55, 0.28), pr(0.55, 0.55, zf), pr(0.55, 0.42, zf)], '#5c6669');
  for (let z = 0.3; z < 30; z += 0.35) { const zz = z - ((t * sp) % 0.35); if (zz < 0.29) continue; tq(ctx, [pr(-0.31, 0.55, zz), pr(0.21, 0.55, zz), pr(0.21, 0.55, zz + 0.07), pr(-0.31, 0.55, zz + 0.07)], '#3a3f42'); }
  { ctx.strokeStyle = '#b9c4c9'; ctx.lineWidth = 3; const a = pr(0.58, 0.18, 0.3), b = pr(0.58, 0.18, zf); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); for (let z = 0.4; z < 20; z += 1.2) { const zz = z - ((t * sp) % 1.2); if (zz < 0.32) continue; const p = pr(0.58, 0.42, zz), q = pr(0.58, 0.18, zz); ctx.lineWidth = Math.max(1, 4 / zz); ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); } for (const [X, Y] of [[-0.92, -0.05], [-0.92, 0.08], [0.92, -0.3]]) { ctx.strokeStyle = 'rgba(70,80,86,0.95)'; ctx.lineWidth = 8; const a2 = pr(X, Y, 0.3), b2 = pr(X, Y, zf); ctx.beginPath(); ctx.moveTo(a2[0], a2[1]); ctx.lineTo(b2[0], b2[1]); ctx.stroke(); } const fg = ctx.createRadialGradient(vx, vy, 10, vx, vy, 420); fg.addColorStop(0, 'rgba(14,20,24,0.85)'); fg.addColorStop(1, 'rgba(14,20,24,0)'); ctx.fillStyle = fg; ctx.fillRect(vx - 420, vy - 420, 840, 840); }
  for (const X of [-0.195, 0.095]) { ctx.strokeStyle = '#c9d2d6'; ctx.lineWidth = 4; const a = pr(X, 0.54, 0.28), b = pr(X, 0.54, zf); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  // tren (frente visto de cara cuando se acerca)
  if (o.train != null && o.train > 0.6) { const z = o.train, w = 0.62, h = 1.0, a = pr(-0.05 - w / 2 - 0.0, 0.54 - h, z), b = pr(-0.05 + w / 2, 0.54, z); const W = b[0] - a[0], Hh = b[1] - a[1]; ctx.fillStyle = '#d9dee0'; ctx.beginPath(); ctx.roundRect(a[0], a[1], W, Hh, [W * 0.28, W * 0.28, W * 0.04, W * 0.04]); ctx.fill(); ctx.fillStyle = 'rgba(40,60,75,0.92)'; ctx.fillRect(a[0] + W * 0.12, a[1] + Hh * 0.14, W * 0.76, Hh * 0.3); ctx.fillStyle = TC.protegida; ctx.fillRect(a[0], a[1] + Hh * 0.66, W, Hh * 0.04); for (const s of [0.2, 0.8]) P.glow(ctx, a[0] + W * s, a[1] + Hh * 0.8, W * 0.35, '255,240,200', 0.85); }
  ctx.restore(); return { pr };
 };
 // ---------------- v1.17 · motor 3D ligero + puente colgante (Tacoma Narrows 1940): oscilación vertical, torsión, flujo y colapso ----------------
 // Cámara 3D: pos, tgt, f (focal en px). Proyección en perspectiva con orden del pintor y ocultación de caras traseras.
 P.cam3 = (pos, tgt, f = 900, roll = 0) => { const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], crs = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], nrm = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const fw = nrm(sub(tgt, pos)); let rt = nrm(crs(fw, [0, 1, 0])), up = crs(rt, fw); if (roll) { const c = Math.cos(roll), s = Math.sin(roll), r2 = rt.map((v, i) => v * c + up[i] * s), u2 = up.map((v, i) => up[i] * c - rt[i] * s); rt = r2; up = u2; }
  const pr = (p) => { const v = sub(p, pos), z = dot(v, fw); return [540 + (f * dot(v, rt)) / Math.max(0.5, z), 960 - (f * dot(v, up)) / Math.max(0.5, z), z]; };
  // recorte de polígonos contra el plano cercano (z ≥ near) antes de proyectar: evita caras perdidas o invertidas cerca de la cámara
  const clip = (pts, near = 2) => { const C = pts.map((p) => { const v = sub(p, pos); return [dot(v, rt), dot(v, up), dot(v, fw)]; }), out = []; for (let i = 0; i < C.length; i++) { const a = C[i], b = C[(i + 1) % C.length], ia = a[2] >= near, ib = b[2] >= near; if (ia) out.push(a); if (ia !== ib) { const k = (near - a[2]) / (b[2] - a[2]); out.push([a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, near]); } } return out.map((c) => [540 + (f * c[0]) / c[2], 960 - (f * c[1]) / c[2], c[2]]); };
  return { pos, tgt, f, fw, rt, up, pr, clip, depth: (p) => dot(sub(p, pos), fw) }; };
 const hexRgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
 const shade = (h, k, fog, fk) => { const a = hexRgb(h), b = hexRgb(fog); return `rgb(${a.map((v, i) => Math.round(lerp(Math.min(255, v * k), b[i], fk))).join(',')})`; };
 const TK = { fondo: '#0B1424', cielo: '#7d93a2', tormenta: '#344956', nube: '#B6C5CA', acero: '#52687C', aceroS: '#2a3843', aceroL: '#A9BAC4', cable: '#1f2a33', hormigon: '#A5AAAB', calzada: '#474B4C', agua: '#274D61', espuma: '#D6E7E9', veg: '#455A46', viento: '#51C4E5', peligro: '#F17C56', energia: '#F4C466', oro: '#FFD447', blanco: '#F5F7F7' };
 P.TK = TK;
 // Geometría (metros): vano central 853, vanos laterales 335, tablero 11,9 de ancho con vigas laterales de alma llena de 2,4 m, torres de ~130 m.
 const TAC = { L: 853, Ls: 335, W: 11.9, Hg: 2.4, deckY: 58, towerTop: 130, sag: 71, hs: 15.24, xT: 426.5 }; TAC.xA = TAC.xT + TAC.Ls; P.TAC = TAC;
 // Estado del movimiento: { Av (amplitud vertical, m), nv (semiondas), fv (Hz), Th (amplitud de torsión, rad), ft (Hz), t, side (factor vanos laterales) }
 // Modo de torsión con un nodo en el centro del vano (las dos mitades giran en sentidos opuestos), como el 7-nov-1940.
 // vertical: onda estacionaria + componente que avanza a lo largo del vano (nula en las torres)
 TAC.w = (x, m) => { if (Math.abs(x) >= TAC.xT) return 0; const u = (x + TAC.xT) / TAC.L, n = m.nv || 6, wt = TAU * (m.fv || 0.6) * m.t, tr = m.trav ?? 0.4; return (m.Av || 0) * ((1 - tr) * Math.sin(n * Math.PI * u) * Math.sin(wt) + tr * Math.sin(Math.PI * u) * Math.sin(n * Math.PI * u - wt)); };
 TAC.th = (x, m) => { if (Math.abs(x) >= TAC.xT) return 0; const u = (x + TAC.xT) / TAC.L; return (m.Th || 0) * Math.sin(TAU * u) * Math.sin(TAU * (m.ft || 0.2) * m.t + (m.ph || 0)); };
 // Colapso: tramos [xa, xb, tRotura]; después caen con gravedad y giro (cuerpo rígido), chocan con el agua y se hunden.
 const fallPose = (x, m, seg) => { const tau = m.t - seg[2]; if (tau <= 0) return null; const g = 9.81, y0 = TAC.deckY, ty = Math.max(0, y0 - 0.5 * g * tau * tau), th0 = TAC.th((seg[0] + seg[1]) / 2, { ...m, t: seg[2] }), xc = (seg[0] + seg[1]) / 2; const imp = Math.sqrt((2 * y0) / g), sink = Math.max(0, tau - imp); return { dy: ty - y0 - sink * 3, rot: th0 + (seg[3] || 0.35) * tau * (tau < imp ? 1 : 0.2), pitch: (seg[4] || 0.08) * tau * (x - xc) / 100, xc, tau, imp }; };
 TAC.segOf = (x, m) => (m.fail || []).find((s) => x >= s[0] && x <= s[1] && m.t > s[2]);
 // Puente completo en 3D. o: { m (estado), cam (P.cam3), cars:[{x, lane, c}], xray, wind (0..1 líneas de viento), glow:{girder, hangers}, fogK }
 P.tacBridge = (ctx, t, o = {}) => {
  const m = { t, ...(o.m || {}) }, cam = o.cam, pr = cam.pr, W2 = TAC.W / 2, fog = o.fog || '#8fa3ae', fogD = o.fogD || 6000, items = [], xr = o.xray || 0;
  const fk = (z) => cl(z / fogD) * 0.7;
  const poly = (pts, col, k = 1, cull = true, extra) => { const P2 = cam.clip(pts); if (P2.length < 3) return; if (cull) { let a = 0; for (let i = 0; i < P2.length; i++) { const p = P2[i], q = P2[(i + 1) % P2.length]; a += p[0] * q[1] - q[0] * p[1]; } if (a > 0) return; } const z = P2.reduce((s, p) => s + p[2], 0) / P2.length; items.push({ z, f: () => { ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = shade(col, k, fog, fk(z)); ctx.fill(); if (extra) extra(P2); } }); };
  const line = (a, b, col, wm, alpha = 1) => { const A2 = pr(a), B2 = pr(b); if (A2[2] < 1 || B2[2] < 1) return; const z = (A2[2] + B2[2]) / 2; items.push({ z: z - 0.01, f: () => { ctx.strokeStyle = shade(col, 1, fog, fk(z)); ctx.globalAlpha = alpha; ctx.lineWidth = Math.max(0.6, (wm * cam.f) / z); ctx.beginPath(); ctx.moveTo(A2[0], A2[1]); ctx.lineTo(B2[0], B2[1]); ctx.stroke(); ctx.globalAlpha = 1; } }); };
  const box = (x0, x1, y0, y1, z0, z1, col) => { const p = (x, y, z) => [x, y, z]; poly([p(x0, y1, z0), p(x1, y1, z0), p(x1, y1, z1), p(x0, y1, z1)].reverse(), col, 1.15); poly([p(x0, y0, z0), p(x1, y0, z0), p(x1, y1, z0), p(x0, y1, z0)], col, 0.95); poly([p(x1, y0, z1), p(x0, y0, z1), p(x0, y1, z1), p(x1, y1, z1)], col, 0.8); poly([p(x0, y0, z1), p(x0, y0, z0), p(x0, y1, z0), p(x0, y1, z1)], col, 0.7); poly([p(x1, y0, z0), p(x1, y0, z1), p(x1, y1, z1), p(x1, y1, z0)], col, 0.88); };
  // --- sección del tablero en x: centro, giro y puntos de borde (tras el colapso: pose de caída del tramo) ---
  const sect = (x) => { const seg = TAC.segOf(x, m); let yc = TAC.deckY + TAC.w(x, m), th = TAC.th(x, m), dx = 0; if (seg) { const fp = fallPose(x, m, seg); if (fp) { yc = TAC.deckY + TAC.w(x, { ...m, t: seg[2] }) + fp.dy + fp.pitch * 0; th = fp.rot * (x < fp.xc ? 1 : 1); yc += (x - fp.xc) * Math.sin(fp.pitch) ; } } const c = Math.cos(th), s = Math.sin(th); const P3 = (zz, yy) => [x + dx, yc + yy * c + zz * s, zz * c - yy * s]; return { yc, th, P3, seg }; };
  // --- tablero: segmentos entre estaciones; calzada, cara exterior de las vigas, coronación y fondo ---
  const inside = Math.abs(cam.pos[2]) < W2 + 1 && Math.abs(cam.pos[1] - TAC.deckY) < 25 && Math.abs(cam.pos[0]) < TAC.xA;
  const xs = []; for (let x = -TAC.xA; x <= TAC.xA + 0.1; x += TAC.hs / 2) xs.push(x);
  for (let i = 0; i < xs.length - 1; i++) { const a = sect(xs[i]), b = sect(xs[i + 1]); if ((a.seg || b.seg) && a.seg !== b.seg) continue; if (a.seg) { const fp = fallPose(xs[i], m, a.seg); if (fp && fp.tau > fp.imp + 2.5) continue; }
   const gT = 0.6, gB = -1.8, rw = W2 - 0.25;
   poly([a.P3(-rw, 0), b.P3(-rw, 0), b.P3(rw, 0), a.P3(rw, 0)], TK.calzada, 1.0, false, (Q) => { if (i % 6 === 0 && Q.length === 4) { ctx.strokeStyle = 'rgba(245,247,247,0.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo((Q[0][0] + Q[3][0]) / 2, (Q[0][1] + Q[3][1]) / 2); ctx.lineTo((Q[1][0] + Q[2][0]) / 2, (Q[1][1] + Q[2][1]) / 2); ctx.stroke(); } });
   for (const sg of [-1, 1]) { const zO = sg * W2, zI = sg * (W2 - 0.3); if (!inside) poly(sg < 0 ? [a.P3(zO, gB), b.P3(zO, gB), b.P3(zO, gT), a.P3(zO, gT)] : [b.P3(zO, gB), a.P3(zO, gB), a.P3(zO, gT), b.P3(zO, gT)], TK.acero, 1.0, true); poly([a.P3(zO, gT), b.P3(zO, gT), b.P3(zI, gT), a.P3(zI, gT)], TK.aceroL, 1.0, false); }
   poly([a.P3(W2, gB), b.P3(W2, gB), b.P3(-W2, gB), a.P3(-W2, gB)], TK.aceroS, 0.8, true);
   if (xr > 0 && i % 2 === 0) { line(a.P3(-W2, -0.4), a.P3(W2, -0.4), TK.aceroL, 0.25, xr); } }
  // --- cables principales (dos), con flecha parabólica, que acompañan a cada borde; en el tramo caído el cable sube al perder carga ---
  const cableY = (x, sg) => { const X = Math.abs(x); let y; if (X <= TAC.xT) { const u = x / TAC.xT; y = TAC.towerTop - TAC.sag * (1 - u * u); } else { const v = (X - TAC.xT) / TAC.Ls; y = TAC.towerTop - (TAC.towerTop - 22) * v - 38 * Math.sin(Math.PI * v) * 0.6 + (m.sideSag || 0) * Math.sin(Math.PI * v); } const sc = sect(x); if (!sc.seg) y += (TAC.w(x, m) + Math.sin(TAC.th(x, m)) * W2 * sg) * (X <= TAC.xT ? 1 : 0); else y += (m.lift || 10) * (1 - Math.exp(-(m.t - sc.seg[2]) / 1.2)) * (1 + 0.15 * Math.sin((m.t - sc.seg[2]) * 3)); return y; };
  for (const sg of [-1, 1]) { let prev = null; for (let x = -TAC.xA; x <= TAC.xA + 0.1; x += TAC.hs) { const p = [x, cableY(x, sg), sg * W2]; if (prev) line(prev, p, TK.cable, 1.3); prev = p; } }
  // --- péndolas: del cable al borde superior de la viga; si su tramo cayó, cuelgan sueltas ---
  for (let x = -TAC.xA + TAC.hs; x < TAC.xA; x += TAC.hs) { if (Math.abs(Math.abs(x) - TAC.xT) < 8) continue; const sc = sect(x); for (const sg of [-1, 1]) { const top = [x, cableY(x, sg), sg * W2]; if (sc.seg) { const tau = m.t - sc.seg[2], len = Math.min(18, top[1] - TAC.deckY); line(top, [x + Math.sin(tau * 2 + x) * 2, top[1] - len, sg * W2], TK.aceroL, 0.12, 0.8); continue; } if ((m.snap || []).some((s) => Math.abs(s[0] - x) < 1 && m.t > s[1])) { line(top, [x, top[1] - 10, sg * W2], TK.peligro, 0.14, 0.9); continue; } line(top, sc.P3(sg * W2, 0.6), o.glow && o.glow.hangers ? TK.energia : TK.aceroL, 0.12, 0.9); } }
  // --- torres: dos patas, travesaños y arriostramiento en X; pilas de hormigón en el agua ---
  for (const xt of [-TAC.xT, TAC.xT]) { box(xt - 18, xt + 18, -4, 9, -16, 16, TK.hormigon); for (const sg of [-1, 1]) box(xt - 2.4, xt + 2.4, 9, TAC.towerTop + 2, sg * W2 - 2.2, sg * W2 + 2.2, TK.acero); for (const yy of [TAC.deckY - 6, 92, TAC.towerTop - 3]) box(xt - 2, xt + 2, yy - 2.5, yy + 2.5, -W2 + 2, W2 - 2, TK.acero); for (const [ya, yb] of [[TAC.deckY - 4, 92], [92, TAC.towerTop - 4]]) { line([xt - 1.8, ya, -W2 + 2], [xt - 1.8, yb, W2 - 2], TK.aceroS, 0.6); line([xt - 1.8, yb, -W2 + 2], [xt - 1.8, ya, W2 - 2], TK.aceroS, 0.6); } box(xt - 2.6, xt + 2.6, TAC.towerTop + 2, TAC.towerTop + 6, -W2 - 2.4, W2 + 2.4, TK.aceroS); }
  // --- anclajes en tierra y pilas de los vanos laterales ---
  for (const s of [-1, 1]) { box(s * TAC.xA - 20, s * TAC.xA + 20, 0, 24, -14, 14, TK.hormigon); for (let k = 1; k <= 2; k++) { const x = s * (TAC.xT + (k * TAC.Ls) / 3); box(x - 2.5, x + 2.5, 0, TAC.deckY - 2, -W2 + 1, W2 - 1, TK.hormigon); } }
  // --- vehículos de 1940 sobre la calzada (siguen la sección) ---
  for (const c of o.cars || []) { const sc = sect(c.x); if (sc.seg) continue; const z0 = c.lane * W2 * 0.5, P3 = sc.P3; const L = 5, Wc = 1.9, H1 = 1.0, H2 = 1.6; const q = (dx, dz, y) => { const s2 = sect(c.x + dx); return s2.P3(z0 + dz, y); }; poly([q(-L / 2, -Wc / 2, H1), q(L / 2, -Wc / 2, H1), q(L / 2, Wc / 2, H1), q(-L / 2, Wc / 2, H1)].reverse(), c.c, 1.1, false); poly([q(-L / 2, -Wc / 2, 0.3), q(L / 2, -Wc / 2, 0.3), q(L / 2, -Wc / 2, H1), q(-L / 2, -Wc / 2, H1)], c.c, 0.9, false); poly([q(-1.2, -Wc / 2 + 0.1, H1), q(1.0, -Wc / 2 + 0.1, H1), q(0.8, -Wc / 2 + 0.2, H2), q(-1.0, -Wc / 2 + 0.2, H2)], '#2a3136', 1, false); void P3; }
  items.sort((a, b) => b.z - a.z); for (const it of items) it.f();
  return { sect, cableY, pr };
 };
 // Entorno del estrecho en 3D: cielo con nubes, colinas lejanas con bosque, orillas, agua con oleaje y espuma, niebla. Se dibuja antes del puente.
 P.tacWorld = (ctx, t, o = {}) => {
  const cam = o.cam, pr = cam.pr, fog = o.fog || '#8fa3ae', warm = o.warm || 0;
  // cielo
  const hz = pr([cam.pos[0] + cam.fw[0] * 20000, 0, cam.pos[2] + cam.fw[2] * 20000])[1]; const sg = ctx.createLinearGradient(0, 0, 0, Math.max(200, hz)); sg.addColorStop(0, warm ? '#4a5560' : TK.tormenta); sg.addColorStop(1, warm ? '#c9a27e' : TK.cielo); ctx.fillStyle = sg; ctx.fillRect(0, 0, 1080, 1920);
  const R = H.rng(12); for (let i = 0; i < 14; i++) { const x = ((R.range(-300, 1400) + t * R.range(4, 12)) % 1700) - 300, y = R.range(60, Math.max(120, hz - 120)), w = R.range(220, 520); ctx.fillStyle = `rgba(182,197,202,${R.range(0.10, 0.28)})`; ctx.beginPath(); ctx.ellipse(x, y, w, w * 0.16, 0, 0, TAU); ctx.fill(); }
  // agua (plano y=0)
  const wg = ctx.createLinearGradient(0, hz, 0, 1920); wg.addColorStop(0, shade(TK.agua, 1.4, fog, 0.3)); wg.addColorStop(1, shade(TK.agua, 0.65, fog, 0)); ctx.fillStyle = wg; ctx.fillRect(0, hz, 1080, 1920 - hz);
  // colinas y orillas (bosque de Washington) a ambos lados del estrecho y al fondo
  const ridge = (pts0, seed, col) => { const Rr = H.rng(seed), top = pts0.map((p, i) => [p[0], p[1] + 40 * Math.sin(i * 0.7 + seed) + Rr.range(0, 18), p[2]]), base = pts0.map((p) => [p[0], 0, p[2]]).reverse(); for (let i = 0; i < top.length - 1; i++) { const P2 = cam.clip([top[i], top[i + 1], base[base.length - 2 - i], base[base.length - 1 - i]]); if (P2.length < 3) continue; ctx.beginPath(); P2.forEach((p, j) => (j ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); } };
  const line3 = (a, b, n, h) => { const r = []; for (let i = 0; i <= n; i++) r.push([lerp(a[0], b[0], i / n), h, lerp(a[1], b[1], i / n)]); return r; };
  const hc = shade(TK.veg, 0.85, fog, 0.55); ridge(line3([-9000, 5200], [9000, 5200], 60, 170), 3, hc); ridge(line3([9000, -5200], [-9000, -5200], 60, 160), 5, hc); ridge(line3([4600, -5200], [4600, 5200], 40, 140), 6, hc); ridge(line3([-4600, 5200], [-4600, -5200], 40, 140), 9, hc);
  // orillas próximas: terreno con talud (bloques), a cada lado del vano central
  for (const s of [-1, 1]) { const x0 = s * 640, x1 = s * 4000, zz = 3000; const fillC = (pts, col) => { const P2 = cam.clip(pts); if (P2.length < 3) return; ctx.fillStyle = col; ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); };
   fillC([[x0, 0, -zz], [x0 + s * 120, 70, -zz], [x0 + s * 120, 70, zz], [x0, 0, zz]], shade(TK.veg, 0.7, fog, 0.25)); fillC([[x0 + s * 120, 70, -zz], [x1, 90, -zz], [x1, 90, zz], [x0 + s * 120, 70, zz]], shade(TK.veg, 0.95, fog, 0.2)); fillC([[x0 - s * 6, 0.2, -zz], [x0 + s * 14, 0.2, -zz], [x0 + s * 14, 0.2, zz], [x0 - s * 6, 0.2, zz]], 'rgba(214,231,233,0.6)');
   const Rt = H.rng(s > 0 ? 7 : 8); for (let i = 0; i < 260; i++) { const x = s * Rt.range(700, 2600), z = Rt.range(-2500, 2500), h = Rt.range(14, 30), b = pr([x, 72, z]), tp = pr([x, 72 + h, z]); if (b[2] < 2) continue; const w = Math.max(1, ((h * 0.35) * cam.f) / b[2]); ctx.fillStyle = shade('#3b5040', 1, fog, cl(b[2] / 4000) * 0.8); ctx.beginPath(); ctx.moveTo(b[0] - w, b[1]); ctx.lineTo(tp[0], tp[1]); ctx.lineTo(b[0] + w, b[1]); ctx.closePath(); ctx.fill(); } }
  // oleaje: destellos que se desplazan con el viento (eje z)
  const Rw = H.rng(21); ctx.strokeStyle = 'rgba(214,231,233,0.35)'; for (let i = 0; i < 420; i++) { const x = Rw.range(-1800, 1800), z = ((Rw.range(-1600, 1600) + t * 6) % 3200) - 1600, a = pr([x, 0, z]), b = pr([x + 8, 0, z]); if (a[2] < 2) continue; ctx.lineWidth = Math.max(0.6, 300 / a[2]); ctx.globalAlpha = cl(1 - a[2] / 3500) * 0.8; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } ctx.globalAlpha = 1;
  // niebla ligera sobre el estrecho
  const fgr = ctx.createLinearGradient(0, hz - 160, 0, hz + 120); fgr.addColorStop(0, 'rgba(182,197,202,0)'); fgr.addColorStop(0.6, 'rgba(182,197,202,0.35)'); fgr.addColorStop(1, 'rgba(182,197,202,0)'); ctx.fillStyle = fgr; ctx.fillRect(0, hz - 160, 1080, 280);
  return { hz };
 };
 // Viento visualizado en 3D: trazos semitransparentes que cruzan el estrecho (dirección +z), deterministas. o: { k (densidad 0..1), y0, y1 }
 P.tacWind = (ctx, t, cam, o = {}) => { const k = o.k ?? 1; if (k <= 0) return; const R = H.rng(31), n = Math.round(160 * k); ctx.save(); ctx.lineCap = 'round'; for (let i = 0; i < n; i++) { const x = R.range(-900, 900), y = R.range(o.y0 ?? 20, o.y1 ?? 130), sp = R.range(14, 22), z = ((R.range(0, 600) + t * sp) % 600) - 300, a = cam.pr([x, y, z]), b = cam.pr([x, y + Math.sin(t + i) * 0.5, z + 26]); if (a[2] < 2 || b[2] < 2) continue; const al = 0.45 * Math.sin(Math.PI * ((z + 300) / 600)); ctx.strokeStyle = `rgba(81,196,229,${al * k})`; ctx.lineWidth = Math.max(1, 900 / a[2]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } ctx.restore(); };
 // Sección transversal del tablero de 1940 (vigas laterales de alma llena + losa + vigas transversales) que gira th; flujo didáctico alrededor:
 // líneas de corriente que se desvían según el giro, separación detrás de las vigas y un remolino que recorre el tablero sincronizado con el giro;
 // momento aerodinámico (flecha curva) en fase con la velocidad de giro (aporta energía). o: { flow, vortex, moment, w (velocidad angular normalizada), type 'H'|'cajon', labels }
 P.tacSection = (ctx, cx, cy, s, th, t, o = {}) => {
  const W2 = TAC.W / 2, flow = o.flow ?? 1, type = o.type || 'H', c = Math.cos(th), sn = Math.sin(th), T2 = (z, y) => [cx + (z * c + y * sn) * s, cy - (y * c - z * sn) * s];
  ctx.save();
  // líneas de corriente (viento de izquierda a derecha)
  // línea de corriente que rodea el cuerpo girado (nunca lo atraviesa): y = yb ± (holgura + softplus(distancia))
  const sp = (x) => Math.log(1 + Math.exp(3 * x)) / 3, tn = Math.tan(th), env = (z) => Math.exp(-Math.pow(z / (W2 + 2.5), 4)), sline = (h, z) => { const e = env(z), yb = -tn * cl(z, -W2, W2) * e, sg2 = h >= 0 ? 1 : -1, gap = (type === 'H' ? 2.2 : type === 'celosia' ? 0.5 : 2.4) * e, d = sg2 * (h - yb); let y = yb + sg2 * (gap + sp(d - gap)) * e + h * (1 - e); if (type === 'H' && z > W2) { const k = Math.min(1, (z - W2) / 6) * Math.exp(-(z - W2) / 28); y += sg2 * 1.2 * Math.exp(-Math.abs(h) / 2.5) * k + 0.4 * Math.sin(z * 0.45 - t * 6 + h) * k * Math.exp(-Math.abs(h) / 1.8); } return y; };
  if (flow > 0) { const n = 14; for (let i = 0; i < n; i++) { const h = (i - (n - 1) / 2) * 1.3 + (i < n / 2 ? -0.2 : 0.2); ctx.beginPath(); for (let z = -40; z <= 46; z += 0.5) { const p = [cx + z * s, cy - sline(h, z) * s]; z === -40 ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1]); } ctx.strokeStyle = `rgba(81,196,229,${0.55 * flow})`; ctx.lineWidth = 2.2; ctx.stroke(); }
   // partículas que viajan por el flujo
   const R = H.rng(4); ctx.fillStyle = `rgba(214,231,233,${0.8 * flow})`; for (let k = 0; k < 70; k++) { const h = R.range(-9, 9), z = ((R.range(0, 86) + t * 9) % 86) - 40; ctx.beginPath(); ctx.arc(cx + z * s, cy - sline(h, z) * s, 2.2, 0, TAU); ctx.fill(); } }
  // remolinos (zona de flujo separado) que recorren la cara superior/inferior según la fase del giro (representación didáctica, no sólidos)
  const vx = o.vortex ?? 0; if (vx > 0 && type === 'H') { for (let k = 0; k < 2; k++) { const ph = ((t * 0.2 + k * 0.5) % 1), z = lerp(-W2, W2 + 10, ph), up = (k === 0) === (Math.sin(t * TAU * 0.2) > 0) ? 1 : -1, p = [cx + z * s, cy - (up * 1.6) * s]; for (let r = 0; r < 3; r++) { ctx.strokeStyle = `rgba(81,196,229,${0.5 * vx * (1 - r * 0.25)})`; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(p[0], p[1], (0.6 + r * 0.55) * s, t * 4 + r, t * 4 + r + Math.PI * 1.4); ctx.stroke(); } } }
  // sección
  const q = (pts, col) => { ctx.beginPath(); pts.forEach((p, i) => { const P2 = T2(p[0], p[1]); i ? ctx.lineTo(P2[0], P2[1]) : ctx.moveTo(P2[0], P2[1]); }); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); };
  if (type === 'H') { for (const sg of [-1, 1]) q([[sg * W2 - 0.18, 0.6], [sg * W2 + 0.18, 0.6], [sg * W2 + 0.18, -1.8], [sg * W2 - 0.18, -1.8]], TK.acero); q([[-W2, 0.02], [W2, 0.02], [W2, -0.25], [-W2, -0.25]], TK.hormigon); q([[-W2, -0.25], [W2, -0.25], [W2, -0.55], [-W2, -0.55]], TK.aceroS); q([[-W2 + 0.3, 0.02], [W2 - 0.3, 0.02], [W2 - 0.3, 0.12], [-W2 + 0.3, 0.12]], TK.calzada); for (const sg of [-1, 1]) q([[sg * W2 - 0.6, 0.6], [sg * W2 + 0.6, 0.6], [sg * W2 + 0.6, 0.48], [sg * W2 - 0.6, 0.48]], TK.aceroL); }
  else if (type === 'celosia') { ctx.strokeStyle = TK.aceroL; ctx.lineWidth = 4; const L2 = (a, b) => { const A2 = T2(a[0], a[1]), B2 = T2(b[0], b[1]); ctx.beginPath(); ctx.moveTo(A2[0], A2[1]); ctx.lineTo(B2[0], B2[1]); ctx.stroke(); }; for (const sg of [-1, 1]) { L2([sg * W2, 0.4], [sg * W2, -7.6]); } L2([-W2, -7.6], [W2, -7.6]); L2([-W2, 0.4], [W2, -7.6]); L2([W2, 0.4], [-W2, -7.6]); q([[-W2 - 0.4, 0.4], [W2 + 0.4, 0.4], [W2 + 0.4, 0.0], [-W2 - 0.4, 0.0]], TK.hormigon); q([[-W2, 0.4], [W2, 0.4], [W2, 0.5], [-W2, 0.5]], TK.calzada); }
  else { q([[-W2 - 2.5, -0.6], [-W2 + 0.5, 0.25], [W2 - 0.5, 0.25], [W2 + 2.5, -0.6], [W2 - 0.8, -2.0], [-W2 + 0.8, -2.0]], TK.aceroL); q([[-W2 + 0.3, 0.25], [W2 - 0.3, 0.25], [W2 - 0.3, 0.35], [-W2 + 0.3, 0.35]], TK.calzada); }
  // bordes marcados y eje de giro
  const eL = T2(-W2, 0.6), eR = T2(W2, 0.6), ce = T2(0, -0.5); if (o.edges) { ctx.fillStyle = TK.oro; for (const p of [eL, eR]) { ctx.beginPath(); ctx.arc(p[0], p[1], 9, 0, TAU); ctx.fill(); } ctx.fillStyle = TK.blanco; ctx.beginPath(); ctx.arc(ce[0], ce[1], 6, 0, TAU); ctx.fill(); }
  // momento aerodinámico: flecha curva cuyo sentido sigue a la velocidad de giro (en fase → aporta energía)
  const mo = o.moment ?? 0; if (mo > 0 && Math.abs(o.w || 0) > 0.05) { const dir = Math.sign(o.w), r = (W2 + 3) * s, a0 = -0.9, a1 = 0.9; ctx.save(); ctx.strokeStyle = `rgba(241,124,86,${mo})`; ctx.fillStyle = `rgba(241,124,86,${mo})`; ctx.lineWidth = 10 * Math.min(1, Math.abs(o.w) + 0.3); ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2 + a0 * dir, -Math.PI / 2 + a1 * dir, dir < 0); ctx.stroke(); const ae = -Math.PI / 2 + a1 * dir, ex = cx + Math.cos(ae) * r, ey = cy + Math.sin(ae) * r, tg = ae + (dir > 0 ? Math.PI / 2 : -Math.PI / 2); ctx.beginPath(); ctx.moveTo(ex + Math.cos(tg) * 26, ey + Math.sin(tg) * 26); ctx.lineTo(ex + Math.cos(tg + 2.5) * 22, ey + Math.sin(tg + 2.5) * 22); ctx.lineTo(ex + Math.cos(tg - 2.5) * 22, ey + Math.sin(tg - 2.5) * 22); ctx.closePath(); ctx.fill(); ctx.restore(); }
  ctx.restore(); return { left: eL, right: eR, center: ce, girder: T2(W2, -0.6), slab: T2(-W2 * 0.4, -0.1) };
 };
 // Ensayo en túnel de viento de un modelo seccional (montado sobre muelles): sección tipo 'H' (1940) u otra; th = giro actual.
 P.windTunnel = (ctx, cx, cy, w, h, th, t, o = {}) => { ctx.save(); P.rr(ctx, cx - w / 2, cy - h / 2, w, h, 18, '#13202a'); ctx.strokeStyle = TK.aceroL; ctx.lineWidth = 4; ctx.strokeRect(cx - w / 2 + 10, cy - h / 2 + 10, w - 20, h - 20); ctx.fillStyle = '#2a3a46'; ctx.fillRect(cx - w / 2 + 10, cy - h / 2 + 10, w - 20, 18); ctx.fillRect(cx - w / 2 + 10, cy + h / 2 - 28, w - 20, 18);
  ctx.beginPath(); ctx.rect(cx - w / 2 + 12, cy - h / 2 + 30, w - 24, h - 60); ctx.clip(); const s = Math.min(w / 46, h / 16); P.tacSection(ctx, cx, cy, s, th, t, { flow: 1, vortex: o.type === 'H' ? 0.8 : 0, type: o.type || 'H', moment: 0 });
  for (const sg of [-1, 1]) { const ax = cx + sg * (TAC.W / 2 + 1) * s * Math.cos(th), ay = cy + sg * (TAC.W / 2 + 1) * s * Math.sin(th); ctx.strokeStyle = TK.energia; ctx.lineWidth = 3; ctx.beginPath(); for (let k = 0; k <= 12; k++) { const yy = lerp(ay, cy - h / 2 + 30, k / 12); ctx.lineTo(ax + (k % 2 ? 8 : -8), yy); } ctx.stroke(); }
  ctx.restore(); };
 // Mapa estilizado del estado de Washington con Puget Sound y el estrecho de Tacoma (no es un mapa de precisión).
 P.mapWA = (ctx, x, y, w, h, t, o = {}) => { const L0 = -124.9, L1 = -116.8, A0 = 45.4, A1 = 49.2, pr = (lo, la) => [x + ((lo - L0) / (L1 - L0)) * w, y + ((A1 - la) / (A1 - A0)) * h];
  const st = [[-124.7, 48.4], [-123.2, 48.25], [-122.75, 49.0], [-117.03, 49.0], [-117.03, 46.0], [-118.98, 46.0], [-119.3, 45.93], [-120.5, 45.7], [-121.2, 45.6], [-122.3, 45.55], [-122.76, 45.65], [-123.1, 46.15], [-123.9, 46.25], [-124.05, 46.3], [-124.1, 46.9], [-124.2, 47.4], [-124.6, 48.0]];
  const ps = [[-122.75, 48.35], [-122.45, 48.2], [-122.33, 47.95], [-122.38, 47.62], [-122.42, 47.4], [-122.5, 47.3], [-122.55, 47.25], [-122.68, 47.18], [-122.9, 47.12], [-122.95, 47.22], [-122.78, 47.3], [-122.62, 47.33], [-122.6, 47.5], [-122.62, 47.7], [-122.68, 47.9], [-122.85, 48.1], [-123.1, 48.15]];
  ctx.save(); ctx.fillStyle = 'rgba(69,90,70,0.85)'; ctx.beginPath(); st.forEach((p, i) => { const q = pr(...p); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath(); ctx.fill(); ctx.strokeStyle = TK.aceroL; ctx.lineWidth = 3; ctx.stroke();
  ctx.fillStyle = TK.agua; ctx.beginPath(); ps.forEach((p, i) => { const q = pr(...p); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath(); ctx.fill();
  const tn = pr(-122.55, 47.27); P.glow(ctx, tn[0], tn[1], 60, '255,212,71', 0.6 + 0.3 * Math.sin(t * 4)); ctx.fillStyle = TK.oro; ctx.beginPath(); ctx.arc(tn[0], tn[1], 9, 0, TAU); ctx.fill(); ctx.restore(); return { tacoma: tn }; };
 // ---------------- v1.17.1 · material documental, bandera y sección detallada ----------------
 // Tarjeta documental para una fotografía real (NO se altera su contenido): relación de aspecto original, marco fino, sombra suave,
 // entrada 96 %→100 % con desplazamiento vertical sutil, salida suave, acercamiento lento opcional (recorte dentro del marco), rótulos.
 // o: { label, tag ('ARCHIVO HISTÓRICO'), zoom: [cx0, cy0, z0, cx1, cy1, z1] (centro relativo 0..1 y aumento al inicio y al final), tilt (rad, leve) }
 P.docPhoto = (ctx, img, cx, cy, maxW, maxH, t, t0, t1, o = {}) => { if (!img || !img.width || t < t0 - 0.01 || t > t1 + 0.01) return null; const ia = img.width / img.height; let w = maxW, h = w / ia; if (h > maxH) { h = maxH; w = h * ia; }
  const a = sm(t0, t0 + 0.6, t) * (1 - sm(t1 - 0.5, t1, t)), s = 0.96 + 0.04 * E.out(sm(t0, t0 + 0.8, t)), dy = (1 - E.out(sm(t0, t0 + 0.8, t))) * 24; if (a <= 0) return null;
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(cx, cy + dy); if (o.tilt) ctx.transform(1, 0, Math.sin(o.tilt) * 0.15, 1, 0, 0); ctx.scale(s, s);
  ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 40; ctx.shadowOffsetY = 18; ctx.fillStyle = '#e9e6dd'; ctx.fillRect(-w / 2 - 10, -h / 2 - 10, w + 20, h + 20); ctx.shadowColor = 'transparent';
  ctx.save(); ctx.beginPath(); ctx.rect(-w / 2, -h / 2, w, h); ctx.clip(); const zm = o.zoom || [0.5, 0.5, 1, 0.5, 0.5, 1], u = E.inOut(win(t, t0, t1)), zx = lerp(zm[0], zm[3], u), zy = lerp(zm[1], zm[4], u), zz = lerp(zm[2], zm[5], u), dw = w * zz, dh = h * zz; ctx.drawImage(img, -w / 2 - (dw - w) * zx, -h / 2 - (dh - h) * zy, dw, dh); ctx.restore();
  ctx.strokeStyle = 'rgba(20,24,28,0.55)'; ctx.lineWidth = 1.5; ctx.strokeRect(-w / 2, -h / 2, w, h);
  // rótulos: «ARCHIVO HISTÓRICO» (arriba a la izquierda, sobre el marco) y pie de foto (abajo)
  ctx.font = '700 32px "IBM Plex Mono"'; const tg = o.tag || 'ARCHIVO HISTÓRICO', tw = ctx.measureText(tg).width; ctx.fillStyle = 'rgba(11,21,32,0.9)'; ctx.fillRect(-w / 2 - 10, -h / 2 - 62, tw + 32, 48); ctx.fillStyle = '#F4C542'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(tg, -w / 2 + 6, -h / 2 - 37);
  if (o.label) { ctx.font = '800 36px Nunito'; const lw = ctx.measureText(o.label).width; ctx.fillStyle = 'rgba(11,21,32,0.9)'; ctx.fillRect(w / 2 + 10 - lw - 36, h / 2 + 14, lw + 36, 56); ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'right'; ctx.fillText(o.label, w / 2 - 8, h / 2 + 43); }
  ctx.restore(); return { x: cx - w / 2, y: cy - h / 2, w, h };
 };
 // Bandera de EE. UU. dibujada con sus proporciones oficiales (1 : 1,9; 13 franjas; cantón de 7 franjas de alto y 0,76 del alto de ancho; 50 estrellas 6/5).
 P.usFlag = (ctx, x, y, hh) => { const w = hh * 1.9, sh = hh / 13, cw = hh * 0.76, ch = sh * 7; ctx.save(); for (let i = 0; i < 13; i++) { ctx.fillStyle = i % 2 ? '#FFFFFF' : '#B22234'; ctx.fillRect(x, y + i * sh, w, sh + 0.5); } ctx.fillStyle = '#3C3B6E'; ctx.fillRect(x, y, cw, ch); ctx.fillStyle = '#FFFFFF'; const r = Math.max(0.6, hh * 0.0308); for (let row = 0; row < 9; row++) { const n = row % 2 ? 5 : 6; for (let k = 0; k < n; k++) { const sx = x + cw * ((row % 2 ? 2 : 1) + k * 2) / 12, sy = y + ch * (row + 1) / 10; ctx.beginPath(); for (let j = 0; j < 10; j++) { const a = -Math.PI / 2 + (j * Math.PI) / 5, rr = j % 2 ? r * 0.4 : r; ctx.lineTo(sx + Math.cos(a) * rr, sy + Math.sin(a) * rr); } ctx.closePath(); ctx.fill(); } } ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.strokeRect(x, y, w, hh); ctx.restore(); return w; };
 // Cápsula informativa con bandera (identificador geográfico discreto). Entrada y salida suaves.
 P.flagPill = (ctx, text, cx, cy, t, t0, t1, o = {}) => { const a = sm(t0, t0 + 0.4, t) * (1 - sm(t1 - 0.4, t1, t)); if (a <= 0) return; const px = o.px || 34, fh = px * 0.8; ctx.save(); ctx.globalAlpha *= a; ctx.font = `800 ${px}px Nunito`; const tw = ctx.measureText(text).width, w = fh * 1.9 + 24 + tw + 44, h = px * 1.7, x0 = cx - w / 2, y0 = cy - h / 2 + (1 - E.out(sm(t0, t0 + 0.5, t))) * 14; P.rr(ctx, x0, y0, w, h, h / 2, 'rgba(11,21,32,0.9)'); P.usFlag(ctx, x0 + 22, y0 + (h - fh) / 2, fh); ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(text, x0 + 22 + fh * 1.9 + 18, y0 + h / 2 + 2); ctx.restore(); };
 // Sección del tablero de 1940 en 2,5D (extruida): losa, vigas laterales de alma llena con alas y rigidizadores, vigas transversales,
 // largueros y profundidad; th = giro de demostración; o: { labels, depth, closed (miniatura de sección cerrada para comparar) }
 P.tacSection3D = (ctx, cx, cy, s, th, t, o = {}) => { const W2 = TAC.W / 2, dz = o.depth ?? [s * 3.2, -s * 1.9], c = Math.cos(th), sn = Math.sin(th), T2 = (z, y, k = 0) => [cx + (z * c + y * sn) * s + dz[0] * k, cy - (y * c - z * sn) * s + dz[1] * k];
  const q = (pts, col, k = 0) => { ctx.beginPath(); pts.forEach((p, i) => { const P2 = T2(p[0], p[1], p[2] ?? k); i ? ctx.lineTo(P2[0], P2[1]) : ctx.moveTo(P2[0], P2[1]); }); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); };
  const ext = (z0, y0, z1, y1, col) => q([[z0, y0, 0], [z1, y1, 0], [z1, y1, 1], [z0, y0, 1]], col);
  ctx.save();
  // vigas transversales (se ven a lo largo de la profundidad bajo la losa)
  for (let k = 1; k >= 0; k -= 0.25) { q([[-W2, -0.25, k], [W2, -0.25, k], [W2, -1.15, k], [-W2, -1.15, k]], k > 0 ? '#3a4950' : TK.aceroS); }
  // larguero inferior y fondo de la losa
  ext(-W2, -0.25, W2, -0.25, '#56646c');
  // vigas laterales: alma (cara exterior extruida), alas superior e inferior, rigidizadores
  for (const sg of [-1, 1]) { const zo = sg * (W2 + 0.18); ext(zo, 0.6, zo, -1.8, sg > 0 ? '#59676f' : '#6b7a82'); q([[zo, 0.6, 0], [zo, -1.8, 0], [zo - sg * 0.36, -1.8, 0], [zo - sg * 0.36, 0.6, 0]], TK.acero); for (const yy of [0.6, -1.8]) q([[sg * W2 - 0.5, yy, 0], [sg * W2 + 0.5, yy, 0], [sg * W2 + 0.5, yy + (yy > 0 ? -0.12 : 0.12), 0], [sg * W2 - 0.5, yy + (yy > 0 ? -0.12 : 0.12), 0]], TK.aceroL); ext(sg * W2 - 0.5, 0.6, sg * W2 + 0.5, 0.6, '#8b9aa2'); ctx.strokeStyle = 'rgba(173,188,194,0.35)'; ctx.lineWidth = 2; for (let k = 0.2; k < 1; k += 0.2) { const a = T2(zo, 0.5, k), b = T2(zo, -1.7, k); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } }
  // losa de hormigón y calzada (cara superior extruida + canto frontal)
  ext(-W2 + 0.18, 0.12, W2 - 0.18, 0.12, '#5b6062'); q([[-W2 + 0.18, 0.12, 0], [W2 - 0.18, 0.12, 0], [W2 - 0.18, -0.25, 0], [-W2 + 0.18, -0.25, 0]], TK.hormigon); ctx.strokeStyle = 'rgba(245,247,250,0.6)'; ctx.setLineDash([10, 10]); ctx.lineWidth = 2; const l0 = T2(0, 0.13, 0), l1 = T2(0, 0.13, 1); ctx.beginPath(); ctx.moveTo(l0[0], l0[1]); ctx.lineTo(l1[0], l1[1]); ctx.stroke(); ctx.setLineDash([]);
  // eje longitudinal (punto) y flecha de giro
  const ce = T2(0, -0.6, 0); ctx.fillStyle = TK.blanco; ctx.beginPath(); ctx.arc(ce[0], ce[1], 6, 0, TAU); ctx.fill(); if (o.rot) { ctx.save(); ctx.globalAlpha *= o.rot; ctx.strokeStyle = TK.oro; ctx.lineWidth = 6; const r = (W2 + 2.2) * s; ctx.beginPath(); ctx.arc(ce[0], ce[1], r, -Math.PI / 2 - 0.6, -Math.PI / 2 + 0.6); ctx.stroke(); const ea = -Math.PI / 2 + 0.6, ex = ce[0] + Math.cos(ea) * r, ey = ce[1] + Math.sin(ea) * r; ctx.fillStyle = TK.oro; ctx.beginPath(); ctx.moveTo(ex + 14, ey - 4); ctx.lineTo(ex - 8, ey - 16); ctx.lineTo(ex - 4, ey + 10); ctx.closePath(); ctx.fill(); ctx.restore(); }
  ctx.restore(); return { girder: T2(W2 + 0.18, -0.6, 0), slab: T2(-W2 * 0.4, -0.05, 0), beams: T2(-W2 * 0.3, -0.9, 0.6), width: [T2(-W2, 0.9, 0), T2(W2, 0.9, 0)], center: ce, depthPt: T2(W2, 0.6, 1) };
 };
 // ---------------- v1.18 · módulo COMUNICACIONES Y ÉPOCAS (1926 ↔ hoy) ----------------
 // Dos mundos y una transformación progresiva: TELÉFONO ANTIGUO → IDEA → INALÁMBRICO → BOLSILLO → SMARTPHONE → VIDEOLLAMADA.
 // Paletas oficiales de época (P.ERA.old / P.ERA.now), gradación de película sepia que se retira poco a poco (P.eraGrade),
 // objetos de 1926 (teléfono de candelero, centralita con operadoras, calle con postes y cables, torre de radio, revista
 // reconstruida, figura de Tesla anciano estilizada) y objetos de hoy (smartphone genérico con vista de corte, mano, videollamada,
 // estación base, fibra óptica, paquetes de datos, Tierra nocturna con enlaces conceptuales). Todo determinista y apoyado en superficies.
 P.ERA = {
  old: { cafe: '#9D7954', ocre: '#C6A06B', oscuro: '#493627', papel: '#E1C9A1', bronce: '#A77C45', negro: '#202021', gris: '#73736E' },
  now: { azul: '#176EAF', cian: '#48D5F2', noche: '#101F37', fondo: '#0C1421', gris: '#8E9EA9', hielo: '#D9E9F0', turq: '#6AD8E8', oro: '#FFD447', blanco: '#F5F7FA' },
 };
 P.mixc = (a, b, u) => H.rgba(H.mix(a, b, cl(u)));
 let GRAIN_TILE = null;
 const grainTile = () => { if (GRAIN_TILE) return GRAIN_TILE; const c = H.layer(256, 256), g = c.getContext('2d'), im = g.createImageData(256, 256), R = H.rng(1926); for (let i = 0; i < im.data.length; i += 4) { const v = R() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; } g.putImageData(im, 0, 0); GRAIN_TILE = c; return c; };
 // Gradación de época sobre lo ya dibujado en el beat (antes de los subtítulos): amt 1 = película de 1926 (tono sepia, velo cálido,
 // parpadeo, viñeta, grano, polvo y rayas, todo función de t), 0 = imagen digital limpia. Valores intermedios para la transición temporal.
 P.eraGrade = (ctx, amt, t, o = {}) => { amt = cl(amt); if (amt <= 0.002) return; const f = Math.floor(t * 12), R = H.rng(f * 7 + 3);
  ctx.save(); ctx.globalCompositeOperation = 'color'; ctx.globalAlpha = 0.88 * amt; ctx.fillStyle = '#9D7954'; ctx.fillRect(0, 0, W, HH);
  ctx.globalCompositeOperation = 'multiply'; ctx.globalAlpha = 0.25 * amt; ctx.fillStyle = '#E1C9A1'; ctx.fillRect(0, 0, W, HH);
  ctx.globalCompositeOperation = 'source-over'; const fl = (R() - 0.5) * 0.07 * amt; ctx.globalAlpha = Math.abs(fl); ctx.fillStyle = fl > 0 ? '#fff4dc' : '#1a1208'; ctx.fillRect(0, 0, W, HH);
  const g = ctx.createRadialGradient(540, 900, 420, 540, 960, 1250); g.addColorStop(0, 'rgba(32,22,12,0)'); g.addColorStop(1, `rgba(32,22,12,${0.72 * amt})`); ctx.globalAlpha = 1; ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH);
  if (o.grain !== false) { const Rg = H.rng(Math.floor(t * 12) * 5 + 1); ctx.globalCompositeOperation = 'overlay'; ctx.globalAlpha = 0.06 * amt; const tl = grainTile(), ox = -Math.floor(Rg() * 512), oy = -Math.floor(Rg() * 512); for (let y = oy; y < HH; y += 512) for (let x = ox; x < W; x += 512) ctx.drawImage(tl, x, y, 512, 512); ctx.globalCompositeOperation = 'source-over'; }
  if (o.dust !== false) { ctx.fillStyle = 'rgba(30,20,10,0.6)'; for (let i = 0; i < 7; i++) { const x = R() * W, y = R() * HH, r = 1 + R() * 3.2; ctx.globalAlpha = amt * 0.55 * R(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }
   if (R() < 0.45) { const x = R() * W; ctx.globalAlpha = amt * 0.22; ctx.strokeStyle = 'rgba(245,232,205,0.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + (R() - 0.5) * 30, HH); ctx.stroke(); } }
  ctx.restore();
 };
 // Tono «tecnológico» (opuesto a eraGrade): velo azul profundo + brillo cian suave en el centro. amt 0..1.
 P.techGrade = (ctx, amt) => { amt = cl(amt); if (amt <= 0.002) return; ctx.save(); ctx.globalCompositeOperation = 'soft-light'; ctx.globalAlpha = 0.35 * amt; ctx.fillStyle = '#176EAF'; ctx.fillRect(0, 0, W, HH); ctx.globalCompositeOperation = 'source-over'; const g = ctx.createRadialGradient(540, 960, 380, 540, 960, 1300); g.addColorStop(0, 'rgba(12,20,33,0)'); g.addColorStop(1, `rgba(12,20,33,${0.6 * amt})`); ctx.globalAlpha = 1; ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); ctx.restore(); };

 // Arcos de señal (radio) que nacen en (x,y), viajan en dirección dir (rad) con apertura spread y se desvanecen. Conceptuales.
 // o: { dir, spread, n, col, speed (px/s), r0, r1, w, a }
 P.radioWaves = (ctx, x, y, t, o = {}) => { const n = o.n || 4, r0 = o.r0 ?? 20, r1 = o.r1 ?? 320, sp = o.speed ?? 220, dir = o.dir ?? -Math.PI / 2, ap = o.spread ?? 0.9, per = (r1 - r0) / sp; ctx.save(); ctx.strokeStyle = o.col || '#48D5F2'; ctx.lineCap = 'round';
  for (let i = 0; i < n; i++) { const u = (((t / per) + i / n) % 1 + 1) % 1, r = lerp(r0, r1, u), a = (o.a ?? 1) * Math.sin(Math.PI * u) * (1 - u * 0.4); if (a <= 0.01) continue; ctx.globalAlpha = a; ctx.lineWidth = (o.w || 6) * (1 - u * 0.5); ctx.beginPath(); ctx.arc(x, y, r, dir - ap / 2, dir + ap / 2); ctx.stroke(); }
  ctx.restore(); };

 // Teléfono de candelero (años 20) apoyado en una superficie en y: base, columna, boquilla, horquilla y auricular colgado (con la
 // copa arriba). s ≈ alto/300. o: { lift 0..1 (lleva el auricular a o.ear=[x,y]), ring 0..1 (vibración del timbre), wireTo [x,y], col }
 P.candlestick = (ctx, x, y, s, t, o = {}) => { const C = P.ERA.old, met = o.col || '#1f1c1a', hi = 'rgba(255,238,205,0.28)', ring = o.ring ? Math.sin(t * 90) * 2.2 * o.ring : 0;
  ctx.save(); ctx.translate(x + ring, y); ctx.scale(s, s);
  ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.beginPath(); ctx.ellipse(0, 2, 86, 13, 0, 0, TAU); ctx.fill();
  if (o.wire !== false) { const wx = o.wireTo ? (o.wireTo[0] - x) / s : -520, wy = o.wireTo ? (o.wireTo[1] - y) / s : 4; ctx.strokeStyle = '#151311'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(-58, -6); ctx.bezierCurveTo(-120, 6, wx * 0.5, wy * 0.5 + 10, wx, wy); ctx.stroke(); }
  ctx.fillStyle = met; ctx.beginPath(); ctx.moveTo(-72, 0); ctx.quadraticCurveTo(-68, -28, -30, -36); ctx.lineTo(30, -36); ctx.quadraticCurveTo(68, -28, 72, 0); ctx.closePath(); ctx.fill(); ctx.fillStyle = hi; ctx.fillRect(-28, -35, 56, 4);
  ctx.fillStyle = met; ctx.fillRect(-9, -252, 18, 220); ctx.fillStyle = hi; ctx.fillRect(-6, -250, 4, 214);
  ctx.save(); ctx.translate(0, -258); ctx.rotate(-0.28); ctx.fillStyle = met; ctx.beginPath(); ctx.moveTo(-12, 8); ctx.lineTo(12, 8); ctx.lineTo(30, -36); ctx.lineTo(-30, -36); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#34302b'; ctx.beginPath(); ctx.ellipse(0, -36, 31, 9, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#0b0a09'; ctx.beginPath(); ctx.ellipse(0, -36, 21, 6, 0, 0, TAU); ctx.fill(); ctx.restore();
  ctx.strokeStyle = met; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(8, -176); ctx.lineTo(30, -182); ctx.lineTo(36, -198); ctx.stroke();
  const lift = cl(o.lift || 0), u = E.inOut(lift); let rx = 46, ry = -196, ra = 0; if (lift > 0 && o.ear) { rx = lerp(46, (o.ear[0] - x) / s, u); ry = lerp(-196, (o.ear[1] - y) / s, u); ra = lerp(0, -0.5, u); }
  ctx.strokeStyle = '#151311'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(42, -12); ctx.bezierCurveTo(96, -14, rx + 40, ry + 150, rx, ry + 76); ctx.stroke();
  ctx.save(); ctx.translate(rx, ry); ctx.rotate(ra); ctx.fillStyle = met; ctx.beginPath(); ctx.moveTo(-24, -6); ctx.lineTo(24, -6); ctx.lineTo(14, 12); ctx.lineTo(-14, 12); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.roundRect(-10, 10, 20, 70, 8); ctx.fill(); ctx.fillStyle = hi; ctx.fillRect(-6, 16, 3, 58); ctx.restore();
  ctx.restore(); return { mouth: [x + 10 * s, y - 296 * s], top: [x, y - 300 * s], base: [x, y] };
 };

 // Centralita telefónica manual (años 20): mueble de madera con paneles de jacks y lamparitas, repisa con clavijas y cordones, y
 // operadoras sentadas de espaldas (sillas apoyadas en el suelo floorY). o: { n, plug(i,c,t)→0..1, lamps (0/1), h }
 P.switchboard = (ctx, x, floorY, w, t, o = {}) => { const n = o.n || 3, h = o.h || 640, top = floorY - h, shelfY = floorY - 300, pw = (w - 40) / n, jx = (i, c) => x + 20 + i * pw + 22 + c * (pw - 44) / 7, jy = (r) => top + 52 + r * 25;
  ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(x - 20, floorY - 6, w + 40, 12);
  ctx.fillStyle = '#4a3627'; ctx.fillRect(x, top, w, h); ctx.fillStyle = '#3a2a1e'; ctx.fillRect(x - 12, top - 26, w + 24, 32); ctx.fillStyle = 'rgba(255,230,190,0.12)'; ctx.fillRect(x - 12, top - 26, w + 24, 5);
  for (let i = 0; i < n; i++) { const px = x + 20 + i * pw; ctx.fillStyle = '#2b2019'; ctx.fillRect(px + 8, top + 30, pw - 16, shelfY - top - 50);
   for (let r = 0; r < 9; r++) for (let c = 0; c < 8; c++) { ctx.fillStyle = '#0f0b08'; ctx.beginPath(); ctx.arc(jx(i, c), jy(r), 5, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(214,180,120,0.35)'; ctx.beginPath(); ctx.arc(jx(i, c), jy(r), 7, Math.PI * 1.1, Math.PI * 1.7); ctx.fill(); }
   for (let c = 0; c < 8; c++) { const R = H.rng(i * 31 + c + 5), on = (o.lamps ?? 1) && Math.sin(t * (1.1 + R() * 2.2) + R() * 6) > 0.55; ctx.fillStyle = on ? '#ffd27a' : '#5a4630'; if (on) { ctx.shadowColor = '#ffc860'; ctx.shadowBlur = 14; } ctx.beginPath(); ctx.arc(jx(i, c), jy(9) + 4, 6, 0, TAU); ctx.fill(); ctx.shadowBlur = 0; } }
  ctx.fillStyle = '#5c4230'; ctx.fillRect(x - 16, shelfY, w + 32, 26); ctx.fillStyle = '#3e2d20'; ctx.fillRect(x, shelfY + 26, w, floorY - shelfY - 26); ctx.fillStyle = 'rgba(255,230,190,0.14)'; ctx.fillRect(x - 16, shelfY, w + 32, 4);
  const plugs = []; for (let i = 0; i < n; i++) for (let c = 0; c < 4; c++) { const px = x + 20 + i * pw, bx = px + 36 + c * (pw - 72) / 3, by = shelfY + 4, R = H.rng(i * 13 + c * 7 + 1), tj = [jx(i, Math.floor(R() * 8)), jy(Math.floor(R() * 9))], u = E.inOut(cl(o.plug ? o.plug(i, c, t) : 0)), ex = lerp(bx, tj[0], u), ey = lerp(by - 26, tj[1] + 6, u);
   if (u > 0.01) { ctx.strokeStyle = c % 2 ? '#2a1f18' : '#17120e'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(bx, by + 4); ctx.quadraticCurveTo((bx + ex) / 2, Math.max(by, ey) + 70 * (1 - u) + 30, ex, ey + 14); ctx.stroke(); }
   ctx.fillStyle = '#b48a52'; ctx.fillRect(ex - 4, ey - 2, 8, 18); ctx.fillStyle = '#2a1f18'; ctx.fillRect(ex - 6, ey + 12, 12, 10); plugs.push([ex, ey]); }
  const ops = []; for (let i = 0; i < n; i++) { const ox = x + 20 + i * pw + pw / 2, sy = floorY - 190, cb = ['#3b3a38', '#4a3d33', '#2f2a26'][i % 3], arm = 0.5 + 0.5 * Math.sin(t * 1.3 + i * 2.1);
   ctx.fillStyle = '#2a1d14'; ctx.fillRect(ox - 52, sy, 104, 16); ctx.fillRect(ox - 48, sy + 16, 9, floorY - sy - 16); ctx.fillRect(ox + 39, sy + 16, 9, floorY - sy - 16);
   ctx.fillStyle = cb; ctx.beginPath(); ctx.moveTo(ox - 56, sy + 2); ctx.quadraticCurveTo(ox - 62, sy - 150, ox - 34, sy - 172); ctx.lineTo(ox + 34, sy - 172); ctx.quadraticCurveTo(ox + 62, sy - 150, ox + 56, sy + 2); ctx.closePath(); ctx.fill();
   ctx.strokeStyle = cb; ctx.lineWidth = 18; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(ox + 30, sy - 150); ctx.quadraticCurveTo(ox + 64, sy - 190, ox + 52 + arm * 18, sy - 250 - arm * 70); ctx.stroke(); ctx.fillStyle = '#c9a882'; ctx.beginPath(); ctx.arc(ox + 52 + arm * 18, sy - 258 - arm * 70, 10, 0, TAU); ctx.fill();
   ctx.fillStyle = '#c9a882'; ctx.fillRect(ox - 11, sy - 192, 22, 24); ctx.fillStyle = '#2a1a10'; ctx.beginPath(); ctx.ellipse(ox, sy - 218, 35, 40, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(ox, sy - 188, 38, 12, 0, 0, TAU); ctx.fill();
   ctx.strokeStyle = '#0c0b0a'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(ox, sy - 218, 41, Math.PI * 1.02, Math.PI * 1.98); ctx.stroke(); ctx.fillStyle = '#0c0b0a'; ctx.beginPath(); ctx.arc(ox - 40, sy - 212, 9, 0, TAU); ctx.fill();
   ctx.fillStyle = '#2a1d14'; ctx.fillRect(ox - 46, sy - 74, 92, 70); ctx.fillStyle = 'rgba(255,230,190,0.1)'; ctx.fillRect(ox - 46, sy - 74, 92, 5); ops.push([ox, sy - 218]); }
  ctx.restore(); return { top, shelfY, plugs, ops, jack: (i, r, c) => [jx(i, c), jy(r)] };
 };

 // Calle de una gran ciudad de los años 20 (genérica, sin edificios reconocibles): rascacielos escalonados con ventanas, postes de
 // teléfono con crucetas, aisladores y haces de cables, acera y calzada (suelo gy), autos de época que ruedan sobre la calzada.
 // o: { gy, poles:[x...], wires 0..1, cut 0..1 (los cables desaparecen de izquierda a derecha → «el cable se vuelve señal»), cars, seed }
 P.city1926 = (ctx, t, o = {}) => { const gy = o.gy ?? 1380, poles = o.poles || [170, 910], R0 = H.rng(o.seed || 11);
  ctx.save(); const g = ctx.createLinearGradient(0, 0, 0, gy); g.addColorStop(0, '#c4a57c'); g.addColorStop(1, '#ead6b2'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, gy);
  for (const L of [{ c: '#b39572', w: 'rgba(250,230,190,0.18)', hm: 520, hx: 980, sd: 3 }, { c: '#8a6e50', w: 'rgba(255,226,170,0.28)', hm: 360, hx: 820, sd: 9 }]) { const R = H.rng(L.sd + (o.seed || 0)); let x = -30;
   while (x < W + 30) { const bw = 90 + R() * 120, bh = L.hm + R() * (L.hx - L.hm), y0 = gy - bh; ctx.fillStyle = L.c; ctx.fillRect(x, y0, bw, bh); const t1 = R() < 0.7; if (t1) { ctx.fillRect(x + bw * 0.15, y0 - bh * 0.12, bw * 0.7, bh * 0.12 + 2); if (R() < 0.6) { ctx.fillRect(x + bw * 0.3, y0 - bh * 0.2, bw * 0.4, bh * 0.08 + 2); if (R() < 0.5) ctx.fillRect(x + bw * 0.47, y0 - bh * 0.27, bw * 0.06, bh * 0.07); } }
    ctx.fillStyle = L.w; for (let wy = y0 + 18; wy < gy - 30; wy += 26) for (let wx = x + 10; wx < x + bw - 14; wx += 18) if (R() < 0.55) ctx.fillRect(wx, wy, 8, 12); x += bw + 6 + R() * 10; } }
  ctx.fillStyle = '#6b5640'; ctx.fillRect(0, gy, W, 44); ctx.fillStyle = '#7e6750'; ctx.fillRect(0, gy, W, 6); ctx.fillStyle = '#4b3c2d'; ctx.fillRect(0, gy + 44, W, HH - gy - 44); ctx.fillStyle = 'rgba(225,201,161,0.25)'; for (let x = -((t * 40) % 160); x < W; x += 160) ctx.fillRect(x, gy + 190, 80, 8);
  const top = 340, arms = [top + 30, top + 90, top + 150], wy = (ai, k) => arms[ai] - 8, cut = cl(o.cut || 0), wa = o.wires ?? 1;
  const xs = [-80, ...poles, W + 80]; for (let s = 0; s < xs.length - 1; s++) for (let ai = 0; ai < 3; ai++) for (let k = 0; k < 6; k++) { const xa = xs[s], xb = xs[s + 1], ox = (k - 2.5) * 24, mid = (xa + xb) / 2, sag = 40 + k * 3 + ai * 6, vis = 1 - sm(cut * 1.3 - 0.15, cut * 1.3 + 0.05, (mid + 80) / (W + 160)); if (vis * wa <= 0.01) continue; ctx.globalAlpha = 0.85 * vis * wa; ctx.strokeStyle = '#2a2018'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(xa + ox, wy(ai, k)); ctx.quadraticCurveTo(mid + ox, wy(ai, k) + sag * 2, xb + ox, wy(ai, k)); ctx.stroke(); }
  ctx.globalAlpha = 1; for (const px of poles) { ctx.fillStyle = '#3d2e21'; ctx.beginPath(); ctx.moveTo(px - 11, gy + 30); ctx.lineTo(px - 7, top); ctx.lineTo(px + 7, top); ctx.lineTo(px + 11, gy + 30); ctx.closePath(); ctx.fill(); for (const ay of arms) { ctx.fillRect(px - 82, ay, 164, 12); for (let k = 0; k < 6; k++) { ctx.fillStyle = '#d8c7a6'; ctx.fillRect(px + (k - 2.5) * 24 - 4, ay - 14, 8, 14); ctx.fillStyle = '#3d2e21'; } } }
  if (o.cars !== false) for (let i = 0; i < 2; i++) { const dir = i ? -1 : 1, sp = 90 + i * 30, cx = dir > 0 ? ((t * sp + 300 * i) % 1500) - 220 : W + 220 - ((t * sp + 520) % 1500), cy = gy + (i ? 150 : 300); P.car1926(ctx, cx, cy, i ? 0.85 : 1.1, t, dir); }
  ctx.restore(); return { gy, top, poles, wireY: arms.map((a) => a - 8) };
 };
 // Auto de los años 20 (silueta genérica de turismo cerrado) apoyado en y (suelo); ruedas de radios que giran según t.
 P.car1926 = (ctx, x, y, s, t, dir = 1) => { ctx.save(); ctx.translate(x, y); ctx.scale(s * dir, s); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(0, 0, 150, 12, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#1f1b18'; ctx.beginPath(); ctx.moveTo(-140, -40); ctx.lineTo(-140, -80); ctx.lineTo(-110, -88); ctx.lineTo(-100, -170); ctx.lineTo(40, -170); ctx.lineTo(54, -96); ctx.lineTo(140, -90); ctx.lineTo(146, -40); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#c9b38c'; ctx.fillRect(-88, -158, 56, 54); ctx.fillRect(-22, -158, 54, 54); ctx.fillStyle = '#2b2622'; ctx.fillRect(-150, -48, 300, 10); ctx.fillStyle = '#e9dcbf'; ctx.beginPath(); ctx.arc(142, -82, 9, 0, TAU); ctx.fill();
  for (const wx of [-92, 96]) { ctx.fillStyle = '#121010'; ctx.beginPath(); ctx.arc(wx, -34, 34, 0, TAU); ctx.fill(); ctx.strokeStyle = '#8c7a5e'; ctx.lineWidth = 3; const a0 = t * 4 * dir; for (let k = 0; k < 8; k++) { const a = a0 + k * Math.PI / 4; ctx.beginPath(); ctx.moveTo(wx, -34); ctx.lineTo(wx + Math.cos(a) * 26, -34 + Math.sin(a) * 26); ctx.stroke(); } ctx.fillStyle = '#8c7a5e'; ctx.beginPath(); ctx.arc(wx, -34, 6, 0, TAU); ctx.fill(); }
  ctx.restore(); };

 // Torre de radio de celosía de los años 20 apoyada en gy, con riostras y antena; o.waves 0..1 emite arcos de señal (conceptuales).
 P.radioTower = (ctx, x, gy, h, t, o = {}) => { const top = gy - h, bw = h * 0.16; ctx.save(); ctx.strokeStyle = o.col || '#2c231b'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x - bw, gy); ctx.lineTo(x - 6, top); ctx.moveTo(x + bw, gy); ctx.lineTo(x + 6, top); ctx.stroke(); ctx.lineWidth = 2.5;
  for (let k = 0; k < 14; k++) { const u0 = k / 14, u1 = (k + 1) / 14, w0 = lerp(bw, 6, u0), w1 = lerp(bw, 6, u1), y0 = lerp(gy, top, u0), y1 = lerp(gy, top, u1); ctx.beginPath(); ctx.moveTo(x - w0, y0); ctx.lineTo(x + w1, y1); ctx.moveTo(x + w0, y0); ctx.lineTo(x - w1, y1); ctx.moveTo(x - w1, y1); ctx.lineTo(x + w1, y1); ctx.stroke(); }
  ctx.lineWidth = 1.5; ctx.globalAlpha = 0.6; for (const sg of [-1, 1]) { ctx.beginPath(); ctx.moveTo(x, top + h * 0.3); ctx.lineTo(x + sg * h * 0.55, gy); ctx.stroke(); } ctx.globalAlpha = 1;
  ctx.fillStyle = o.col || '#2c231b'; ctx.fillRect(x - bw - 30, gy - 8, 2 * bw + 60, 10); ctx.fillRect(x - 2, top - 40, 4, 40); ctx.beginPath(); ctx.arc(x, top - 42, 7, 0, TAU); ctx.fill();
  if (o.waves) { P.radioWaves(ctx, x - 10, top - 42, t, { dir: Math.PI, spread: 1.1, n: 4, col: o.wcol || '#E1C9A1', r1: o.r1 || 420, a: o.waves, w: 7 }); P.radioWaves(ctx, x + 10, top - 42, t + 0.4, { dir: 0, spread: 1.1, n: 4, col: o.wcol || '#E1C9A1', r1: o.r1 || 420, a: o.waves, w: 7 }); }
  ctx.restore(); return { top: [x, top - 42] }; };

 // Nikola Tesla hacia 1926 (≈70 años) — RECONSTRUCCIÓN ESTILIZADA, no un retrato: alto y muy delgado, traje oscuro de tres piezas,
 // cuello alto blanco y corbata, pelo gris peinado con raya al medio, bigote gris, rostro enjuto. De pie con los zapatos en y.
 // s: escala (alto ≈ 780·s px). o: { look −1..1 (giro de la cabeza), hand 'down'|'chin'|'point'|'pocket', tag (rótulo) } — sin labios
 // animados ni diálogo inventado: solo respiración y parpadeo sutiles.
 P.teslaOld = (ctx, x, y, s, t, o = {}) => { const suit = o.suit || '#262422', skin = o.skin || '#d2b190', hair = o.hair || '#b9b4ab', lk = cl(o.look || 0, -1, 1), br = 1 + Math.sin(t * 1.6) * 0.006, blink = (t % 4.3) < 0.12;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(0, 2, 110, 14, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#121110'; ctx.beginPath(); ctx.ellipse(-30, -8, 34, 11, 0, 0, TAU); ctx.ellipse(32, -8, 34, 11, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = suit; ctx.beginPath(); ctx.moveTo(-50, -14); ctx.lineTo(-44, -390); ctx.lineTo(44, -390); ctx.lineTo(50, -14); ctx.lineTo(14, -14); ctx.lineTo(2, -330); ctx.lineTo(-12, -14); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.translate(0, -390); ctx.scale(1, br); ctx.translate(0, 390);
  ctx.beginPath(); ctx.moveTo(-58, -330); ctx.lineTo(-74, -592); ctx.quadraticCurveTo(-70, -612, -40, -618); ctx.lineTo(40, -618); ctx.quadraticCurveTo(70, -612, 74, -592); ctx.lineTo(58, -330); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#3a3633'; ctx.beginPath(); ctx.moveTo(-26, -612); ctx.lineTo(0, -470); ctx.lineTo(26, -612); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#ece6da'; ctx.beginPath(); ctx.moveTo(-18, -612); ctx.lineTo(0, -560); ctx.lineTo(18, -612); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#4a4440'; ctx.beginPath(); ctx.moveTo(-6, -596); ctx.lineTo(6, -596); ctx.lineTo(4, -540); ctx.lineTo(0, -532); ctx.lineTo(-4, -540); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#c9b48a'; for (const by of [-520, -488, -456]) { ctx.beginPath(); ctx.arc(0, by, 3.2, 0, TAU); ctx.fill(); } ctx.strokeStyle = '#c9b48a'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, -470); ctx.quadraticCurveTo(-22, -440, -34, -460); ctx.stroke();
  ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-26, -612); ctx.lineTo(-40, -470); ctx.lineTo(-30, -330); ctx.moveTo(26, -612); ctx.lineTo(40, -470); ctx.lineTo(30, -330); ctx.stroke();
  const arm = (sg, mode) => { ctx.strokeStyle = suit; ctx.lineWidth = 30; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; const sx = sg * 66, sy = -590; let ex, ey, hx, hy; if (mode === 'chin') { ex = sg * 70; ey = -470; hx = sg * 18; hy = -650; } else if (mode === 'point') { ex = sg * 130; ey = -520; hx = sg * 200; hy = -560; } else if (mode === 'pocket') { ex = sg * 86; ey = -470; hx = sg * 36; hy = -500; } else { ex = sg * 80; ey = -460; hx = sg * 78; hy = -330; }
   ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.lineTo(hx, hy); ctx.stroke(); ctx.strokeStyle = '#ece6da'; ctx.lineWidth = 26; ctx.beginPath(); ctx.moveTo(lerp(ex, hx, 0.88), lerp(ey, hy, 0.88)); ctx.lineTo(lerp(ex, hx, 0.93), lerp(ey, hy, 0.93)); ctx.stroke(); ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(hx, hy, 13, 17, 0, 0, TAU); ctx.fill(); };
  arm(-1, o.handL || 'down'); arm(1, o.hand || 'down');
  ctx.fillStyle = skin; ctx.fillRect(-15, -650, 30, 40); ctx.fillStyle = '#ece6da'; ctx.beginPath(); ctx.moveTo(-28, -618); ctx.lineTo(-24, -650); ctx.lineTo(24, -650); ctx.lineTo(28, -618); ctx.lineTo(0, -606); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.translate(lk * 8, 0); ctx.fillStyle = skin; ctx.beginPath(); ctx.moveTo(-40, -712); ctx.quadraticCurveTo(-42, -664, -22, -646); ctx.quadraticCurveTo(0, -634, 22, -646); ctx.quadraticCurveTo(42, -664, 40, -712); ctx.quadraticCurveTo(40, -770, 0, -772); ctx.quadraticCurveTo(-40, -770, -40, -712); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-42, -705, 7, 14, 0, 0, TAU); ctx.ellipse(42, -705, 7, 14, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(120,80,50,0.18)'; ctx.beginPath(); ctx.ellipse(-24, -682, 10, 14, 0, 0, TAU); ctx.ellipse(24, -682, 10, 14, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = hair; ctx.beginPath(); ctx.moveTo(-43, -712); ctx.quadraticCurveTo(-48, -786, -2, -790); ctx.lineTo(-2, -770); ctx.quadraticCurveTo(-30, -762, -38, -726); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(43, -712); ctx.quadraticCurveTo(48, -786, 2, -790); ctx.lineTo(2, -770); ctx.quadraticCurveTo(30, -762, 38, -726); ctx.closePath(); ctx.fill();
  const ex = lk * 6; ctx.fillStyle = '#2a2420'; if (blink) { ctx.fillRect(-24 + ex, -712, 14, 2.5); ctx.fillRect(10 + ex, -712, 14, 2.5); } else { ctx.beginPath(); ctx.ellipse(-17 + ex, -712, 4.5, 3.5, 0, 0, TAU); ctx.ellipse(17 + ex, -712, 4.5, 3.5, 0, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#8a857d'; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-28 + ex, -726); ctx.quadraticCurveTo(-17 + ex, -732, -8 + ex, -726); ctx.moveTo(8 + ex, -726); ctx.quadraticCurveTo(17 + ex, -732, 28 + ex, -726); ctx.stroke();
  ctx.strokeStyle = 'rgba(110,70,45,0.45)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(ex, -708); ctx.lineTo(ex - 4, -684); ctx.lineTo(ex + 3, -682); ctx.stroke();
  ctx.fillStyle = '#a7a199'; ctx.beginPath(); ctx.moveTo(ex - 22, -668); ctx.quadraticCurveTo(ex - 10, -680, ex, -674); ctx.quadraticCurveTo(ex + 10, -680, ex + 22, -668); ctx.quadraticCurveTo(ex, -664, ex - 22, -668); ctx.fill();
  ctx.strokeStyle = 'rgba(90,60,40,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ex - 9, -656); ctx.lineTo(ex + 9, -656); ctx.stroke();
  ctx.restore(); ctx.restore();
  ctx.restore(); return { head: [x + lk * 8 * s, y - 710 * s], hand: [x + (o.hand === 'point' ? 200 : o.hand === 'pocket' ? 36 : 78) * s, y - (o.hand === 'point' ? 560 : o.hand === 'pocket' ? 500 : 330) * s], pocket: [x + 34 * s, y - 500 * s], top: [x, y - 790 * s] };
 };

 // Revista de 1926 RECONSTRUIDA (no facsímil): papel envejecido, cabecera con tipografía genérica, metadatos reales que se pasen en o,
 // ilustración abstracta y líneas de texto ilegibles (nunca citas inventadas) + sello «RECONSTRUCCIÓN CONCEPTUAL».
 // o: { title, date, head, by, rot, tag, page 0..1 (pasa página), hi 0..1 (resalta un párrafo de líneas) }
 P.magazine1926 = (ctx, cx, cy, s, t, o = {}) => { const w = 560, h = 760; ctx.save(); ctx.translate(cx, cy); ctx.rotate(o.rot ?? -0.04); ctx.scale(s, s);
  ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 40; ctx.shadowOffsetY = 18; ctx.fillStyle = '#e4cfa6'; ctx.fillRect(-w / 2, -h / 2, w, h); ctx.shadowColor = 'transparent';
  const R = H.rng(77); ctx.fillStyle = 'rgba(120,85,45,0.08)'; for (let i = 0; i < 60; i++) { ctx.beginPath(); ctx.arc(-w / 2 + R() * w, -h / 2 + R() * h, 4 + R() * 26, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#3a2a1c'; ctx.lineWidth = 3; ctx.strokeRect(-w / 2 + 22, -h / 2 + 22, w - 44, h - 44);
  ctx.fillStyle = '#2b1f15'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 86px Fraunces'; ctx.fillText(o.title || 'REVISTA', 0, -h / 2 + 96); ctx.fillRect(-w / 2 + 40, -h / 2 + 150, w - 80, 4);
  ctx.font = '600 30px Fraunces'; ctx.fillText(o.date || '', 0, -h / 2 + 184); ctx.fillRect(-w / 2 + 40, -h / 2 + 208, w - 80, 2);
  ctx.font = 'italic 600 40px Fraunces'; ctx.fillText(o.head || '', 0, -h / 2 + 262); ctx.font = '500 26px Fraunces'; ctx.fillText(o.by || '', 0, -h / 2 + 306);
  ctx.fillStyle = 'rgba(73,54,39,0.5)'; for (let c = 0; c < 2; c++) for (let l = 0; l < 13; l++) { const lx = -w / 2 + 48 + c * (w / 2 - 30), ly = -h / 2 + 352 + l * 26, lw = (w / 2 - 70) * (l === 12 ? 0.5 : 0.82 + R() * 0.18); ctx.fillRect(lx, ly, lw, 9); }
  if (o.hi) { ctx.globalAlpha = o.hi; ctx.fillStyle = 'rgba(255,212,71,0.45)'; ctx.fillRect(-w / 2 + 42, -h / 2 + 344 + 5 * 26, w / 2 - 50, 26 * 4); ctx.globalAlpha = 1; }
  if (o.page) { const u = E.inOut(cl(o.page)); ctx.save(); ctx.transform(1 - 2 * u, 0, -0.15 * Math.sin(Math.PI * u), 1, (w / 2) * 2 * u, 0); ctx.fillStyle = u < 0.5 ? '#dcc59a' : '#cdb58a'; ctx.fillRect(-w / 2, -h / 2, w, h); ctx.restore(); }
  ctx.restore(); if (o.tag !== false) { ctx.save(); ctx.font = '700 32px "IBM Plex Mono"'; const tg = o.tag || 'RECONSTRUCCIÓN CONCEPTUAL', tw = ctx.measureText(tg).width; ctx.fillStyle = 'rgba(32,32,33,0.88)'; ctx.fillRect(cx - tw / 2 - 18, cy + (h / 2) * s + 22, tw + 36, 50); ctx.fillStyle = '#E1C9A1'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(tg, cx, cy + (h / 2) * s + 48); ctx.restore(); }
  return { w: w * s, h: h * s };
 };

 // Chaleco en primer plano (bolsillo de reloj, botones, cadena) con un aparato CONCEPTUAL plano que asoma del bolsillo.
 // dev 0..1 = cuánto sale; glow 0..1 = la pantalla se ilumina. Ocupa un rectángulo (x,y,w,h); el torso sale por el borde inferior.
 P.vestPocket = (ctx, x, y, w, h, t, o = {}) => { const dev = cl(o.dev || 0), px = x + w * 0.62, py = y + h * 0.5, pw = w * 0.26; ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.fillStyle = '#2b2622'; ctx.fillRect(x, y, w, h); ctx.strokeStyle = 'rgba(225,201,161,0.08)'; ctx.lineWidth = 2; for (let sx = x - h; sx < x + w; sx += 22) { ctx.beginPath(); ctx.moveTo(sx, y + h); ctx.lineTo(sx + h * 0.15, y); ctx.stroke(); }
  ctx.fillStyle = '#1b1816'; ctx.beginPath(); ctx.moveTo(x + w * 0.46, y); ctx.lineTo(x + w * 0.5, y + h); ctx.lineTo(x, y + h); ctx.lineTo(x, y); ctx.closePath(); ctx.globalAlpha = 0.55; ctx.fill(); ctx.globalAlpha = 1;
  ctx.fillStyle = '#c9b48a'; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(x + w * 0.47, y + h * (0.12 + k * 0.24), 13, 0, TAU); ctx.fill(); }
  const dh = pw * 1.45, dy = py - dh * 0.92 * E.out(dev) + 6; ctx.save(); ctx.beginPath(); ctx.rect(px - pw / 2 - 20, y, pw + 40, py + 8 - y); ctx.clip(); ctx.fillStyle = '#3b3530'; ctx.beginPath(); ctx.roundRect(px - pw * 0.42, dy, pw * 0.84, dh, 12); ctx.fill(); ctx.fillStyle = o.glow ? P.mixc('#5a4a38', '#E1C9A1', o.glow) : '#5a4a38'; ctx.beginPath(); ctx.roundRect(px - pw * 0.34, dy + 14, pw * 0.68, dh * 0.62, 6); ctx.fill(); if (o.glow) { ctx.globalAlpha = o.glow * 0.6; ctx.shadowColor = '#ffe2a8'; ctx.shadowBlur = 40; ctx.fill(); ctx.shadowBlur = 0; ctx.globalAlpha = 1; } ctx.restore();
  ctx.fillStyle = '#231f1c'; ctx.fillRect(px - pw / 2, py, pw, 16); ctx.fillStyle = 'rgba(225,201,161,0.22)'; ctx.fillRect(px - pw / 2, py, pw, 3);
  ctx.strokeStyle = '#c9a85e'; ctx.lineWidth = 5; ctx.setLineDash([9, 5]); ctx.beginPath(); ctx.moveTo(x + w * 0.47, y + h * 0.36); ctx.quadraticCurveTo(x + w * 0.36, y + h * 0.62, x + w * 0.2, y + h * 0.52); ctx.stroke(); ctx.setLineDash([]);
  ctx.restore(); return { device: [px, dy + dh * 0.3], pocket: [px, py] };
 };

 // Smartphone GENÉRICO (sin marca ni logotipo): cuerpo redondeado, cámara perforada, altavoz, botones laterales; pantalla dibujada
 // por o.screen(ctx, x, y, w, h). o.cut 0..1 = vista de corte: la pantalla se desplaza y aparecen cámara, micrófono, procesador,
 // antenas y batería (devuelve sus posiciones para rotular). o: { rot, glow (resplandor de pantalla), body }
 P.smartphone = (ctx, cx, cy, h, t, o = {}) => { const w = h * 0.48, r = h * 0.075, cut = E.inOut(cl(o.cut || 0)), sx = w * 0.035, x = -w / 2, y = -h / 2; ctx.save(); ctx.translate(cx, cy); if (o.rot) ctx.rotate(o.rot);
  ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = h * 0.06; ctx.shadowOffsetY = h * 0.03; ctx.fillStyle = o.body || '#1c2636'; ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.strokeStyle = 'rgba(217,233,240,0.45)'; ctx.lineWidth = Math.max(2, h * 0.004); ctx.stroke(); ctx.fillStyle = '#2b3a50'; ctx.fillRect(w / 2 - 1, -h * 0.22, h * 0.008, h * 0.1); ctx.fillRect(w / 2 - 1, -h * 0.08, h * 0.008, h * 0.06);
  const S = { x: x + sx, y: y + sx, w: w - 2 * sx, h: h - 2 * sx }, pts = {};
  if (cut > 0) { ctx.save(); ctx.beginPath(); ctx.roundRect(S.x, S.y, S.w, S.h, r * 0.8); ctx.clip(); ctx.fillStyle = '#0f1a2a'; ctx.fillRect(S.x, S.y, S.w, S.h);
   ctx.fillStyle = '#123a2e'; ctx.fillRect(S.x + S.w * 0.08, S.y + S.h * 0.04, S.w * 0.84, S.h * 0.3); ctx.strokeStyle = 'rgba(106,216,232,0.35)'; ctx.lineWidth = 2; for (let k = 0; k < 7; k++) { ctx.beginPath(); ctx.moveTo(S.x + S.w * 0.1, S.y + S.h * (0.07 + k * 0.035)); ctx.lineTo(S.x + S.w * 0.9, S.y + S.h * (0.07 + k * 0.035)); ctx.stroke(); }
   const cam = [S.x + S.w * 0.28, S.y + S.h * 0.1]; ctx.fillStyle = '#0b0f16'; ctx.beginPath(); ctx.arc(cam[0], cam[1], S.w * 0.11, 0, TAU); ctx.fill(); ctx.strokeStyle = '#48D5F2'; ctx.lineWidth = 3; ctx.stroke(); ctx.fillStyle = '#176EAF'; ctx.beginPath(); ctx.arc(cam[0], cam[1], S.w * 0.05, 0, TAU); ctx.fill(); pts.camera = cam;
   const soc = [S.x + S.w * 0.64, S.y + S.h * 0.2]; ctx.fillStyle = '#1e2a3a'; ctx.fillRect(soc[0] - S.w * 0.13, soc[1] - S.w * 0.13, S.w * 0.26, S.w * 0.26); ctx.strokeStyle = '#FFD447'; ctx.lineWidth = 3; ctx.strokeRect(soc[0] - S.w * 0.13, soc[1] - S.w * 0.13, S.w * 0.26, S.w * 0.26); pts.chip = soc;
   ctx.fillStyle = '#26364c'; ctx.beginPath(); ctx.roundRect(S.x + S.w * 0.1, S.y + S.h * 0.38, S.w * 0.8, S.h * 0.48, 12); ctx.fill(); ctx.strokeStyle = 'rgba(142,158,169,0.6)'; ctx.lineWidth = 2; ctx.stroke(); pts.battery = [S.x + S.w * 0.5, S.y + S.h * 0.62];
   const mic = [S.x + S.w * 0.5, S.y + S.h * 0.94]; ctx.fillStyle = '#0b0f16'; ctx.beginPath(); ctx.roundRect(mic[0] - S.w * 0.08, mic[1] - 8, S.w * 0.16, 16, 8); ctx.fill(); ctx.strokeStyle = '#48D5F2'; ctx.lineWidth = 3; ctx.stroke(); pts.mic = mic;
   ctx.strokeStyle = '#6AD8E8'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(S.x + 6, S.y + S.h * 0.02); ctx.lineTo(S.x + 6, S.y + S.h * 0.3); ctx.moveTo(S.x + S.w - 6, S.y + S.h * 0.7); ctx.lineTo(S.x + S.w - 6, S.y + S.h * 0.98); ctx.stroke(); pts.antenna = [S.x + 6, S.y + S.h * 0.16];
   ctx.restore(); }
  if (cut < 1) { ctx.save(); ctx.translate(cut * w * 1.15, -cut * h * 0.05); ctx.globalAlpha *= 1 - cut * 0.85; ctx.beginPath(); ctx.roundRect(S.x, S.y, S.w, S.h, r * 0.8); ctx.fillStyle = '#0C1421'; ctx.fill(); ctx.save(); ctx.clip(); if (o.screen) o.screen(ctx, S.x, S.y, S.w, S.h); ctx.restore();
   ctx.fillStyle = '#05070b'; ctx.beginPath(); ctx.arc(0, S.y + S.h * 0.035, Math.max(5, h * 0.011), 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(S.x + S.w * 0.55, S.y); ctx.lineTo(S.x, S.y + S.h * 0.45); ctx.closePath(); ctx.fill();
   if (o.glow) { ctx.globalAlpha = o.glow * 0.5; ctx.shadowColor = '#48D5F2'; ctx.shadowBlur = h * 0.12; ctx.strokeStyle = 'rgba(72,213,242,0.4)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(S.x, S.y, S.w, S.h, r * 0.8); ctx.stroke(); } ctx.restore(); }
  ctx.restore(); const map = (p) => { const c = Math.cos(o.rot || 0), sn = Math.sin(o.rot || 0); return [cx + p[0] * c - p[1] * sn, cy + p[0] * sn + p[1] * c]; }; const out = { w, h, screen: { x: cx + S.x, y: cy + S.y, w: S.w, h: S.h } }; for (const k in pts) out[k] = map(pts[k]); return out;
 };
 // Mano que sostiene un teléfono vertical de alto h centrado en (cx,cy): layer 'back' (palma y dedos por detrás, antebrazo hasta el
 // borde inferior del cuadro, nada flota) y 'front' (pulgar por delante). Llamar 'back' antes de P.phone y 'front' después.
 P.handHold = (ctx, cx, cy, h, layer, o = {}) => { const w = h * 0.48, a = w / 2, b = h / 2, sk = o.skin || '#c98f6a', sl = o.sleeve || '#2a3e5c', dk = H.rgba(H.mix(sk, '#3a1e10', 0.32)), dk2 = H.rgba(H.mix(sk, '#3a1e10', 0.5)), lt = H.rgba(H.mix(sk, '#fff1e6', 0.28)), nail = H.rgba(H.mix(sk, '#f6d3c6', 0.42)), X = (u) => cx + u * w, Y = (v) => cy + v;
  // dedos (índice → meñique): fila a la altura v, grosor fw, saliente L hacia fuera del borde izquierdo
  const F = [[0.02 * h, 0.24 * w, 0.21 * w], [0.125 * h, 0.24 * w, 0.24 * w], [0.228 * h, 0.225 * w, 0.22 * w], [0.322 * h, 0.195 * w, 0.17 * w]];
  // pulgar: base fuera del borde derecho → articulación → punta sobre la pantalla
  const TB = [0.66, 0.3 * h], TJ = [0.47, 0.205 * h], TT = [0.27, 0.125 * h], tw0 = 0.27 * w, tw1 = 0.205 * w;
  const thumbPath = (dx = 0, dy = 0) => { const pts = [TB, TJ, TT].map(([u, v]) => [X(u) + dx, Y(v) + dy]), wd = [tw0, (tw0 + tw1) / 2, tw1], L = [], R = []; for (let i = 0; i < 3; i++) { const p = pts[i], q = pts[Math.min(2, i + 1)], r = pts[Math.max(0, i - 1)], dxx = q[0] - r[0], dyy = q[1] - r[1], n = Math.hypot(dxx, dyy) || 1, nx = -dyy / n, ny = dxx / n; L.push([p[0] + nx * wd[i] / 2, p[1] + ny * wd[i] / 2]); R.push([p[0] - nx * wd[i] / 2, p[1] - ny * wd[i] / 2]); }
   const ang = Math.atan2(pts[2][1] - pts[1][1], pts[2][0] - pts[1][0]); ctx.beginPath(); ctx.moveTo(L[0][0], L[0][1]); ctx.quadraticCurveTo(L[1][0], L[1][1], L[2][0], L[2][1]); ctx.arc(pts[2][0], pts[2][1], wd[2] / 2, ang + Math.PI / 2, ang - Math.PI / 2, true); ctx.quadraticCurveTo(R[1][0], R[1][1], R[0][0], R[0][1]); const a0 = Math.atan2(R[0][1] - pts[0][1], R[0][0] - pts[0][0]); ctx.arc(pts[0][0], pts[0][1], wd[0] / 2, a0, a0 + Math.PI, false); ctx.closePath(); return { pts, ang }; };
  ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  if (layer === 'back') {
   // antebrazo (llega al borde inferior del cuadro) y manga
   const wl = [X(0.0), Y(b + 0.34 * w)], wr = [X(0.66), Y(b + 0.26 * w)], fl = [X(0.12), HH + 60], fr = [X(1.0), HH + 60];
   ctx.fillStyle = sk; ctx.beginPath(); ctx.moveTo(wl[0], wl[1]); ctx.lineTo(wr[0], wr[1]); ctx.lineTo(fr[0], fr[1]); ctx.lineTo(fl[0], fl[1]); ctx.closePath(); ctx.fill();
   const cu = (k) => [lerp(wl[0], fl[0], k), lerp(wl[1], fl[1], k)], cv = (k) => [lerp(wr[0], fr[0], k), lerp(wr[1], fr[1], k)], k0 = cl((cy + b + 0.75 * w - wl[1]) / Math.max(1, fl[1] - wl[1]), 0.05, 0.9);
   ctx.fillStyle = sl; ctx.beginPath(); ctx.moveTo(...cu(k0)); ctx.quadraticCurveTo((cu(k0)[0] + cv(k0)[0]) / 2, (cu(k0)[1] + cv(k0)[1]) / 2 + w * 0.06, ...cv(k0)); ctx.lineTo(fr[0] + w * 0.1, fr[1]); ctx.lineTo(fl[0] - w * 0.1, fl[1]); ctx.closePath(); ctx.fill();
   ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = Math.max(2, w * 0.025); ctx.beginPath(); ctx.moveTo(...cu(k0 + 0.03)); ctx.quadraticCurveTo((cu(k0)[0] + cv(k0)[0]) / 2, (cu(k0)[1] + cv(k0)[1]) / 2 + w * 0.09, ...cv(k0 + 0.03)); ctx.stroke();
   if (o.v2) { // v1.19.2: una sola silueta (masa de la mano + falanges solapadas), rellena de una vez y con sombreado interior
    const hp = new Path2D(), yTop = Y(F[0][0] - F[0][1] * 0.45), yBot = Y(F[3][0] + F[3][1] * 0.4), xL = X(-0.5) - w * 0.07;
    hp.moveTo(X(0.3), Y(0)); hp.lineTo(X(0.7), Y(0.2 * h)); hp.bezierCurveTo(X(0.9), Y(0.3 * h), X(0.86), Y(b - 0.02 * w), wr[0], wr[1]); hp.lineTo(wl[0], wl[1]); hp.quadraticCurveTo(X(-0.05), Y(b + 0.31 * w), X(-0.3), Y(b + 0.22 * w)); hp.quadraticCurveTo(X(-0.55), Y(b + 0.1 * w), xL + w * 0.01, yBot); hp.quadraticCurveTo(xL - w * 0.05, (yTop + yBot) / 2, xL, yTop + F[0][1] * 0.12); hp.lineTo(X(-0.2), yTop); hp.closePath();
    F.forEach(([v, fw, L]) => { const y = Y(v), x0 = X(-0.5) - L; hp.roundRect(x0, y - fw * 0.54, X(-0.2) - x0, fw * 1.08, [fw * 0.5, 0, 0, fw * 0.5]); });
    const g2 = ctx.createLinearGradient(X(-0.75), 0, X(0.8), 0); g2.addColorStop(0, dk); g2.addColorStop(0.18, sk); g2.addColorStop(0.3, lt); g2.addColorStop(0.6, sk); g2.addColorStop(1, dk); ctx.fillStyle = g2; ctx.fill(hp);
    ctx.save(); ctx.clip(hp); ctx.strokeStyle = dk2; ctx.globalAlpha = 0.3; ctx.lineWidth = w * 0.06; ctx.stroke(hp); ctx.restore();
    ctx.strokeStyle = 'rgba(60,30,15,0.4)'; ctx.lineWidth = Math.max(1.2, w * 0.01); for (let i = 0; i < 3; i++) { const y = Y((F[i][0] + F[i][1] * 0.5 + F[i + 1][0] - F[i + 1][1] * 0.5) / 2), x0 = X(-0.5) - Math.min(F[i][2], F[i + 1][2]) + w * 0.03; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(X(-0.5), y); ctx.stroke(); }
    F.forEach(([v, fw, L]) => { const kx = X(-0.5) - L * 0.42, y = Y(v); ctx.beginPath(); ctx.moveTo(kx - fw * 0.05, y - fw * 0.24); ctx.quadraticCurveTo(kx + fw * 0.04, y, kx - fw * 0.05, y + fw * 0.24); ctx.stroke(); });
   } else {
   // palma detrás del teléfono: talón bajo el borde inferior y eminencia del pulgar fuera del borde derecho
   const g = ctx.createLinearGradient(X(-0.3), 0, X(0.7), 0); g.addColorStop(0, dk); g.addColorStop(0.55, sk); g.addColorStop(1, sk); ctx.fillStyle = g;
   ctx.beginPath(); ctx.moveTo(X(-0.4), Y(0.0)); ctx.lineTo(X(-0.42), Y(b - 0.02 * w)); ctx.quadraticCurveTo(X(-0.38), Y(b + 0.16 * w), X(-0.05), Y(b + 0.2 * w)); ctx.quadraticCurveTo(X(0.0), Y(b + 0.28 * w), wl[0], wl[1]); ctx.lineTo(wr[0], wr[1]); ctx.bezierCurveTo(X(0.86), Y(b - 0.02 * w), X(0.9), Y(0.3 * h), X(0.7), Y(0.2 * h)); ctx.lineTo(X(0.3), Y(0.0)); ctx.closePath(); ctx.fill();
   // dedos que rodean el borde izquierdo (se ven sus falanges por fuera del borde)
   F.forEach(([v, fw, L], i) => { const y = Y(v), x0 = X(-0.5) - L, x1 = X(-0.25); const gg = ctx.createLinearGradient(0, y - fw / 2, 0, y + fw / 2); gg.addColorStop(0, lt); gg.addColorStop(0.45, sk); gg.addColorStop(1, dk); ctx.fillStyle = gg; ctx.beginPath(); ctx.roundRect(x0, y - fw / 2, x1 - x0, fw, [fw * 0.42, 0, 0, fw * 0.42]); ctx.fill();
    ctx.strokeStyle = dk2; ctx.lineWidth = Math.max(1.2, w * 0.01); ctx.beginPath(); ctx.moveTo(x1, y + fw / 2); ctx.lineTo(x0 + fw * 0.35, y + fw / 2); ctx.stroke();
    ctx.strokeStyle = dk; ctx.globalAlpha = 0.6; ctx.lineWidth = Math.max(1, w * 0.007); const kx = X(-0.5) - L * 0.45; ctx.beginPath(); ctx.moveTo(kx - fw * 0.04, y - fw * 0.22); ctx.quadraticCurveTo(kx + fw * 0.03, y, kx - fw * 0.04, y + fw * 0.22); ctx.stroke(); ctx.globalAlpha = 1; });
   }
  } else {
   // yemas de los dedos apoyadas en el frente del borde izquierdo, con uña y sombra de contacto
   F.forEach(([v, fw], i) => { const y = Y(v) + fw * 0.02, x = X(-0.5) + w * 0.02, rx = w * 0.06, ry = fw * 0.43; ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.filter = `blur(${Math.max(1, w * 0.02)}px)`; ctx.beginPath(); ctx.ellipse(x + w * 0.03, y + fw * 0.06, rx, ry, 0, 0, TAU); ctx.fill(); ctx.restore();
    ctx.fillStyle = sk; ctx.beginPath(); ctx.moveTo(X(-0.5) - w * 0.04, y - ry); ctx.lineTo(x, y - ry); ctx.ellipse(x, y, rx, ry, 0, -Math.PI / 2, Math.PI / 2); ctx.lineTo(X(-0.5) - w * 0.04, y + ry); ctx.closePath(); ctx.fill();
    const gp = ctx.createLinearGradient(0, y - ry, 0, y + ry); gp.addColorStop(0, 'rgba(255,240,230,0.18)'); gp.addColorStop(0.6, 'rgba(0,0,0,0)'); gp.addColorStop(1, 'rgba(60,25,10,0.35)'); ctx.fillStyle = gp; ctx.fill();
    ctx.fillStyle = nail; ctx.globalAlpha = 0.75; ctx.beginPath(); ctx.ellipse(x + rx * 0.3, y - ry * 0.02, rx * 0.42, ry * 0.5, 0, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.strokeStyle = dk; ctx.lineWidth = Math.max(1, w * 0.007); ctx.beginPath(); ctx.moveTo(X(-0.5) - w * 0.02, y - ry * 0.9); ctx.lineTo(X(-0.5) - w * 0.02, y + ry * 0.9); ctx.stroke(); });
   // pulgar sobre la pantalla: sombra de contacto, volumen, uña y pliegue
   ctx.save(); ctx.beginPath(); ctx.roundRect(X(-0.5), Y(-b), w, h, h * 0.075); ctx.clip(); ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.filter = `blur(${Math.max(2, w * 0.035)}px)`; thumbPath(w * 0.035, w * 0.05); ctx.fill(); ctx.restore();
   const gt = ctx.createLinearGradient(X(0.45), Y(0.1 * h), X(0.58), Y(0.32 * h)); gt.addColorStop(0, lt); gt.addColorStop(0.55, sk); gt.addColorStop(1, sk); ctx.fillStyle = gt; const th = thumbPath(); ctx.fill();
   const [p0, p1, p2] = th.pts, an = th.ang; ctx.strokeStyle = dk; ctx.lineWidth = Math.max(1.2, w * 0.011); ctx.beginPath(); ctx.moveTo(p1[0] - Math.sin(an) * tw1 * 0.3, p1[1] + Math.cos(an) * tw1 * 0.3); ctx.quadraticCurveTo(p1[0] + Math.cos(an) * w * 0.02, p1[1] + Math.sin(an) * w * 0.02, p1[0] + Math.sin(an) * tw1 * 0.32, p1[1] - Math.cos(an) * tw1 * 0.32); ctx.stroke();
   ctx.save(); ctx.translate(p2[0] - Math.cos(an) * tw1 * 0.12, p2[1] - Math.sin(an) * tw1 * 0.12); ctx.rotate(an); ctx.fillStyle = nail; ctx.beginPath(); ctx.ellipse(0, -tw1 * 0.04, tw1 * 0.42, tw1 * 0.3, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.ellipse(tw1 * 0.08, -tw1 * 0.14, tw1 * 0.16, tw1 * 0.08, 0, 0, TAU); ctx.fill(); ctx.restore();
  }
  ctx.restore(); };

 // Persona estilizada en plano medio (busto) para videollamadas o escenas: hombros, cuello, cabeza, pelo; parpadeo y leve
 // movimiento de cabeza (sin labios sincronizados). o: { skin, hair, shirt, style 'short'|'long'|'bun', look, t }
 P.persona = (ctx, cx, cy, s, t, o = {}) => { const sk = o.skin || '#c98f6a', hr = o.hair || '#2b1d14', sh = o.shirt || '#176EAF', nod = Math.sin(t * 1.1 + (o.ph || 0)) * 3, blink = ((t + (o.ph || 0)) % 3.7) < 0.12; ctx.save(); ctx.translate(cx, cy); ctx.scale(s, s);
  ctx.fillStyle = sh; ctx.beginPath(); ctx.moveTo(-190, 260); ctx.quadraticCurveTo(-180, 120, -70, 100); ctx.lineTo(70, 100); ctx.quadraticCurveTo(180, 120, 190, 260); ctx.closePath(); ctx.fill(); ctx.fillStyle = sk; ctx.fillRect(-30, 40, 60, 70); ctx.beginPath(); ctx.moveTo(-34, 100); ctx.lineTo(0, 140); ctx.lineTo(34, 100); ctx.closePath(); ctx.fill();
  ctx.translate(0, nod); if (o.style === 'long') { ctx.fillStyle = hr; ctx.beginPath(); ctx.roundRect(-88, -90, 176, 210, 70); ctx.fill(); }
  ctx.fillStyle = sk; ctx.beginPath(); ctx.ellipse(0, -10, 74, 92, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(-74, -6, 12, 20, 0, 0, TAU); ctx.ellipse(74, -6, 12, 20, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = hr; ctx.beginPath(); ctx.moveTo(-78, -10); ctx.quadraticCurveTo(-90, -110, 0, -108); ctx.quadraticCurveTo(90, -110, 78, -10); ctx.quadraticCurveTo(60, -70, 0, -66); ctx.quadraticCurveTo(-50, -66, -78, -10); ctx.fill(); if (o.style === 'bun') { ctx.beginPath(); ctx.arc(0, -112, 34, 0, TAU); ctx.fill(); }
  const lx = (o.look || 0) * 6; ctx.fillStyle = '#1b1410'; if (blink) { ctx.fillRect(-36 + lx, -14, 20, 3); ctx.fillRect(16 + lx, -14, 20, 3); } else { ctx.beginPath(); ctx.ellipse(-26 + lx, -14, 7, 8, 0, 0, TAU); ctx.ellipse(26 + lx, -14, 7, 8, 0, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = 'rgba(40,20,10,0.6)'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-40 + lx, -36); ctx.lineTo(-14 + lx, -38); ctx.moveTo(14 + lx, -38); ctx.lineTo(40 + lx, -36); ctx.stroke(); ctx.beginPath(); ctx.arc(lx, 30, 22, 0.25, Math.PI - 0.25); ctx.stroke();
  ctx.restore(); };
 // Interfaz genérica de videollamada dentro de (x,y,w,h): fondo de la otra persona, persona remota, recuadro propio, barra superior con
 // tiempo de llamada y botones (micrófono, cámara, colgar). o: { t0 (inicio de la llamada), remote:{...P.person}, self:{...}, connect 0..1 }
 P.videoCall = (ctx, x, y, w, h, t, o = {}) => { const con = cl(o.connect ?? 1); ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  const g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, o.bg0 || '#2a4a6a'); g.addColorStop(1, o.bg1 || '#13243a'); ctx.fillStyle = g; ctx.fillRect(x, y, w, h); ctx.fillStyle = 'rgba(255,212,71,0.12)'; ctx.fillRect(x + w * 0.62, y + h * 0.12, w * 0.24, h * 0.3); ctx.fillStyle = 'rgba(217,233,240,0.08)'; ctx.fillRect(x, y + h * 0.66, w, h * 0.34);
  if (con > 0) { ctx.globalAlpha = con; P.persona(ctx, x + w / 2, y + h * 0.52, w / 520, t, o.remote || {}); ctx.globalAlpha = 1; }
  if (con < 1) { ctx.fillStyle = `rgba(12,20,33,${1 - con})`; ctx.fillRect(x, y, w, h); ctx.strokeStyle = '#48D5F2'; ctx.lineWidth = 6; ctx.globalAlpha = 1 - con; ctx.beginPath(); ctx.arc(x + w / 2, y + h * 0.45, w * 0.12, t * 5, t * 5 + 4.4); ctx.stroke(); ctx.globalAlpha = 1; }
  const pw = w * 0.3, ph = pw * 1.4, px = x + w - pw - w * 0.05, py = y + h * 0.07; ctx.save(); ctx.beginPath(); ctx.roundRect(px, py, pw, ph, 16); ctx.clip(); ctx.fillStyle = '#3b4c5e'; ctx.fillRect(px, py, pw, ph); P.persona(ctx, px + pw / 2, py + ph * 0.55, pw / 520, t, { ...(o.self || {}), ph: 1.3 }); ctx.restore(); ctx.strokeStyle = 'rgba(245,247,250,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(px, py, pw, ph, 16); ctx.stroke();
  const sec = Math.max(0, Math.floor(t - (o.t0 ?? t))); ctx.fillStyle = 'rgba(12,20,33,0.6)'; ctx.beginPath(); ctx.roundRect(x + w * 0.05, y + h * 0.07, w * 0.32, h * 0.055, h * 0.027); ctx.fill(); ctx.fillStyle = '#F5F7FA'; ctx.font = `700 ${Math.round(h * 0.03)}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(`● ${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`, x + w * 0.21, y + h * 0.0975);
  const by = y + h * 0.88, br = w * 0.075; [[-1, '#2f4258'], [0, '#e8505b'], [1, '#2f4258']].forEach(([k, c]) => { const bx = x + w / 2 + k * w * 0.24; ctx.fillStyle = c; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill(); ctx.strokeStyle = '#F5F7FA'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.beginPath(); if (k === -1) { ctx.roundRect(bx - br * 0.18, by - br * 0.5, br * 0.36, br * 0.62, br * 0.18); ctx.moveTo(bx - br * 0.36, by); ctx.arc(bx, by, br * 0.36, Math.PI, 0, true); ctx.moveTo(bx, by + br * 0.36); ctx.lineTo(bx, by + br * 0.55); } else if (k === 1) { ctx.rect(bx - br * 0.45, by - br * 0.3, br * 0.6, br * 0.6); ctx.moveTo(bx + br * 0.15, by); ctx.lineTo(bx + br * 0.5, by - br * 0.25); ctx.lineTo(bx + br * 0.5, by + br * 0.25); ctx.closePath(); } else { ctx.moveTo(bx - br * 0.45, by + br * 0.1); ctx.quadraticCurveTo(bx, by - br * 0.35, bx + br * 0.45, by + br * 0.1); } ctx.stroke(); });
  ctx.restore(); };

 // Estación base de telefonía móvil apoyada en gy: monopolo troncocónico, plataforma con tres sectores de antenas de panel, escalera,
 // armario de equipos y valla. o.waves 0..1 emite arcos hacia o.dir. Devuelve la posición de las antenas.
 P.cellTower = (ctx, x, gy, h, t, o = {}) => { const top = gy - h; ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(x, gy + 2, h * 0.2, 10, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#8E9EA9'; ctx.beginPath(); ctx.moveTo(x - h * 0.03, gy); ctx.lineTo(x - h * 0.012, top + 40); ctx.lineTo(x + h * 0.012, top + 40); ctx.lineTo(x + h * 0.03, gy); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(x - h * 0.008, top + 40, h * 0.006, h - 40);
  ctx.fillStyle = '#6b7c88'; ctx.fillRect(x - h * 0.12, top + 30, h * 0.24, 10); ctx.fillRect(x - h * 0.12, top + 110, h * 0.24, 8); for (const k of [-1, 0, 1]) { const ax = x + k * h * 0.1; ctx.fillStyle = '#D9E9F0'; ctx.beginPath(); ctx.roundRect(ax - 11, top, 22, 120, 6); ctx.fill(); ctx.strokeStyle = 'rgba(16,31,55,0.4)'; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.fillStyle = '#5d6c78'; ctx.fillRect(x + h * 0.05, gy - 90, 70, 90); ctx.fillStyle = '#48D5F2'; ctx.fillRect(x + h * 0.05 + 10, gy - 76, 8, 8); ctx.strokeStyle = 'rgba(142,158,169,0.6)'; ctx.lineWidth = 2; for (let fx = x - h * 0.16; fx <= x + h * 0.16; fx += 16) { ctx.beginPath(); ctx.moveTo(fx, gy); ctx.lineTo(fx, gy - 50); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(x - h * 0.16, gy - 50); ctx.lineTo(x + h * 0.16, gy - 50); ctx.stroke();
  if (o.waves) { const d = o.dir ?? Math.PI; P.radioWaves(ctx, x + Math.cos(d) * 20, top + 60, t, { dir: d, spread: 0.9, n: 4, col: o.col || '#48D5F2', r1: o.r1 || 360, a: o.waves, w: 6 }); }
  ctx.restore(); return { ant: [x, top + 60], base: [x, gy] };
 };
 // Fibra óptica: trazo (polilínea) con funda, núcleo brillante y pulsos de luz que viajan; prog 0..1 revela el tendido.
 P.fiberPath = (ctx, pts, t, o = {}) => { if (pts.length < 2) return; const L = [0]; for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); const tot = L[L.length - 1], prog = cl(o.prog ?? 1), at = (d) => { let i = 1; while (i < L.length - 1 && L[i] < d) i++; const u = (d - L[i - 1]) / Math.max(1e-6, L[i] - L[i - 1]); return [lerp(pts[i - 1][0], pts[i][0], u), lerp(pts[i - 1][1], pts[i][1], u)]; };
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.setLineDash([tot * prog, tot + 10]); ctx.strokeStyle = o.sheath || '#22344d'; ctx.lineWidth = o.w || 18; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); ctx.strokeStyle = o.col || '#48D5F2'; ctx.globalAlpha = 0.55; ctx.lineWidth = (o.w || 18) * 0.25; ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  const n = o.pulses ?? 5, sp = o.speed ?? 420; ctx.fillStyle = '#F5F7FA'; ctx.shadowColor = o.col || '#48D5F2'; ctx.shadowBlur = 22; for (let k = 0; k < n; k++) { const d = ((t * sp + k * tot / n) % tot); if (d > tot * prog) continue; const p = at(d); ctx.beginPath(); ctx.arc(p[0], p[1], (o.w || 18) * 0.42, 0, TAU); ctx.fill(); }
  ctx.restore(); return { at, len: tot };
 };
 // Paquetes de datos (cuadritos con 0/1) que viajan de (x0,y0) a (x1,y1). o: { n, col, speed (veces/s), size, a, arc (curvatura px) }
 P.dataPackets = (ctx, x0, y0, x1, y1, t, o = {}) => { const n = o.n || 6, sz = o.size || 26, sp = o.speed ?? 0.5, arc = o.arc || 0; ctx.save(); ctx.font = `700 ${Math.round(sz * 0.7)}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let k = 0; k < n; k++) { const u = ((t * sp + k / n) % 1 + 1) % 1, a = (o.a ?? 1) * Math.sin(Math.PI * u); if (a < 0.03) continue; const px = lerp(x0, x1, u), py = lerp(y0, y1, u) - Math.sin(Math.PI * u) * arc; ctx.globalAlpha = a; ctx.fillStyle = o.col || '#48D5F2'; ctx.beginPath(); ctx.roundRect(px - sz / 2, py - sz / 2, sz, sz, 5); ctx.fill(); ctx.fillStyle = '#0C1421'; ctx.fillText(((k * 7 + Math.floor(t * 3)) % 3) ? '1' : '0', px, py + 1); }
  ctx.restore(); };

 // Tierra nocturna (proyección ortográfica): océano azul noche, luces de ciudades agrupadas alrededor de grandes metrópolis reales
 // (lat, lon aproximadas), borde de atmósfera y ENLACES CONCEPTUALES (arcos punteados entre ciudades, con un punto que viaja).
 // o: { lon0, lat0, arcs:[[lat1,lon1,lat2,lon2,t0]], lights 0..1 }. Los arcos son conceptuales: la señal real usa redes (no una onda).
 const METROS = [[40.7, -74], [34, -118], [41.9, -87.6], [19.4, -99.1], [-23.5, -46.6], [-34.6, -58.4], [4.7, -74.1], [-12, -77], [10.5, -66.9], [43.7, -79.4], [45.5, -73.6], [29.8, -95.4], [33.7, -84.4], [25.8, -80.2], [47.6, -122.3], [37.8, -122.4], [51.5, -0.1], [48.9, 2.35], [40.4, -3.7], [41.4, 2.2], [52.5, 13.4], [41.9, 12.5], [55.8, 37.6], [59.9, 30.3], [50.1, 8.7], [45.5, 9.2], [52.4, 4.9], [38.7, -9.1], [41, 29], [30, 31.2], [6.5, 3.4], [-26.2, 28], [-1.3, 36.8], [33.6, -7.6], [24.7, 46.7], [25.2, 55.3], [35.7, 51.4], [19, 72.8], [28.6, 77.2], [13, 77.6], [22.6, 88.4], [23.8, 90.4], [13.7, 100.5], [1.35, 103.8], [-6.2, 106.8], [14.6, 121], [22.3, 114.2], [31.2, 121.5], [39.9, 116.4], [23.1, 113.3], [30.6, 114.3], [37.6, 127], [35.7, 139.7], [34.7, 135.5], [-33.9, 151.2], [-37.8, 145], [-36.8, 174.8], [64.1, -21.9], [61.2, -149.9], [21.3, -157.8], [-33.4, -70.6], [-15.8, -47.9], [-8, -34.9], [18.5, -69.9], [23.1, -82.4], [9, -79.5], [3.4, -76.5], [-0.2, -78.5], [6.2, -75.6]];
 let EARTH_PTS = null;
 P.earthNight = (ctx, cx, cy, r, t, o = {}) => { if (!EARTH_PTS) { const R = H.rng(42); EARTH_PTS = []; for (const [la, lo] of METROS) { EARTH_PTS.push([la, lo, 1]); for (let k = 0; k < 26; k++) EARTH_PTS.push([la + R.gauss() * 2.6, lo + R.gauss() * 3.2, 0.25 + R() * 0.5]); } }
  const lon0 = (o.lon0 ?? -60) * Math.PI / 180, lat0 = (o.lat0 ?? 15) * Math.PI / 180, cl0 = Math.cos(lat0), sl0 = Math.sin(lat0), pr = (la, lo, alt = 0) => { const f = la * Math.PI / 180, l = lo * Math.PI / 180 - lon0, x = Math.cos(f) * Math.sin(l), y = cl0 * Math.sin(f) - sl0 * Math.cos(f) * Math.cos(l), z = sl0 * Math.sin(f) + cl0 * Math.cos(f) * Math.cos(l), k = r * (1 + alt); return [cx + x * k, cy - y * k, z]; };
  ctx.save(); const ga = ctx.createRadialGradient(cx, cy, r * 0.9, cx, cy, r * 1.18); ga.addColorStop(0, 'rgba(72,213,242,0.35)'); ga.addColorStop(1, 'rgba(72,213,242,0)'); ctx.fillStyle = ga; ctx.beginPath(); ctx.arc(cx, cy, r * 1.18, 0, TAU); ctx.fill();
  const go = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r); go.addColorStop(0, '#1b3554'); go.addColorStop(1, '#0a1626'); ctx.fillStyle = go; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(106,216,232,0.08)'; ctx.lineWidth = 1.5; for (let la = -60; la <= 60; la += 30) { ctx.beginPath(); let st = false; for (let lo = -180; lo <= 180; lo += 6) { const p = pr(la, lo); if (p[2] > 0) { st ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); st = true; } else st = false; } ctx.stroke(); }
  const li = o.lights ?? 1; for (const [la, lo, b] of EARTH_PTS) { const p = pr(la, lo); if (p[2] <= 0.02) continue; ctx.globalAlpha = li * b * Math.min(1, p[2] * 2.5); ctx.fillStyle = b > 0.9 ? '#FFE9A8' : '#FFD447'; ctx.beginPath(); ctx.arc(p[0], p[1], b > 0.9 ? 3.2 : 1.6, 0, TAU); ctx.fill(); }
  ctx.globalAlpha = 1; ctx.strokeStyle = 'rgba(217,233,240,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
  for (const A2 of o.arcs || []) { const [la1, lo1, la2, lo2, t0 = 0] = A2, u = cl((t - t0) / 1.2); if (u <= 0) continue; const f1 = la1 * Math.PI / 180, l1 = lo1 * Math.PI / 180, f2 = la2 * Math.PI / 180, l2 = lo2 * Math.PI / 180, v1 = [Math.cos(f1) * Math.cos(l1), Math.cos(f1) * Math.sin(l1), Math.sin(f1)], v2 = [Math.cos(f2) * Math.cos(l2), Math.cos(f2) * Math.sin(l2), Math.sin(f2)], om = Math.acos(cl(v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2], -1, 1));
   const P2 = (s2) => { const a = Math.sin((1 - s2) * om) / Math.sin(om), b = Math.sin(s2 * om) / Math.sin(om), v = [a * v1[0] + b * v2[0], a * v1[1] + b * v2[1], a * v1[2] + b * v2[2]]; return pr(Math.asin(cl(v[2], -1, 1)) * 180 / Math.PI, Math.atan2(v[1], v[0]) * 180 / Math.PI, Math.sin(Math.PI * s2) * 0.16); };
   ctx.strokeStyle = o.arcCol || '#48D5F2'; ctx.lineWidth = 3.5; ctx.setLineDash([12, 10]); ctx.lineDashOffset = -t * 40; ctx.beginPath(); let st = false; for (let s2 = 0; s2 <= u + 1e-6; s2 += 0.02) { const p = P2(Math.min(s2, u)); if (p[2] > -0.15) { st ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); st = true; } else st = false; } ctx.stroke(); ctx.setLineDash([]);
   for (const e of [0, 1]) { const p = P2(e); if (p[2] > 0 && (e === 0 || u >= 1)) { ctx.fillStyle = '#F5F7FA'; ctx.beginPath(); ctx.arc(p[0], p[1], 6, 0, TAU); ctx.fill(); } } if (u >= 1) { const p = P2((t * 0.5 + t0) % 1); if (p[2] > -0.1) { ctx.fillStyle = '#FFD447'; ctx.shadowColor = '#FFD447'; ctx.shadowBlur = 14; ctx.beginPath(); ctx.arc(p[0], p[1], 6, 0, TAU); ctx.fill(); ctx.shadowBlur = 0; } } }
  ctx.restore(); return { pr };
 };

 // Contador de año que rueda como un marcador mecánico (cada dígito sube por separado): from → to con u 0..1.
 P.yearRoll = (ctx, cx, cy, px, from, to, u, o = {}) => { const s1 = String(from), s2 = String(to), n = Math.max(s1.length, s2.length), dw = px * 0.66; ctx.save(); ctx.font = o.font || `800 ${px}px "Space Grotesk"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let i = 0; i < n; i++) { const a = +s1[i] || 0, b = +s2[i] || 0, x = cx + (i - (n - 1) / 2) * dw, uu = E.inOut(cl((u - i * 0.08) / 0.7)), steps = (b - a + 10) % 10, v = a + steps * uu, d0 = Math.floor(v), fr = v - d0; ctx.save(); ctx.beginPath(); ctx.rect(x - dw / 2, cy - px * 0.6, dw, px * 1.2); ctx.clip(); ctx.fillStyle = o.col || '#F5F7FA'; ctx.fillText(String(d0 % 10), x, cy - fr * px * 1.1); ctx.fillText(String((d0 + 1) % 10), x, cy + (1 - fr) * px * 1.1); ctx.restore(); }
  ctx.restore(); };

 // Cadena de evolución (rejilla 3×2): TELÉFONO ANTIGUO → IDEA → INALÁMBRICO → BOLSILLO → SMARTPHONE → VIDEOLLAMADA (o.steps).
 // k (0..n) = cuántos pasos están encendidos (fraccional anima el último). Iconos dibujados, textos ≥ 32 px.
 P.evoGrid = (ctx, cx, y, t, k, o = {}) => { const steps = o.steps || ['TELÉFONO ANTIGUO', 'IDEA', 'INALÁMBRICO', 'BOLSILLO', 'SMARTPHONE', 'VIDEOLLAMADA'], cw = 342, ch = 210, gx = 10;
  const icon = (i, x, yy, c) => { ctx.save(); ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath();
   if (i === 0) { ctx.moveTo(x - 26, yy + 34); ctx.lineTo(x + 26, yy + 34); ctx.moveTo(x, yy + 30); ctx.lineTo(x, yy - 24); ctx.moveTo(x - 14, yy - 30); ctx.lineTo(x + 14, yy - 30); ctx.moveTo(x + 22, yy - 10); ctx.lineTo(x + 22, yy + 20); ctx.stroke(); }
   else if (i === 1) { ctx.arc(x, yy - 8, 24, Math.PI * 0.8, Math.PI * 2.2); ctx.lineTo(x + 10, yy + 26); ctx.lineTo(x - 10, yy + 26); ctx.closePath(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x - 9, yy + 36); ctx.lineTo(x + 9, yy + 36); ctx.stroke(); }
   else if (i === 2) { ctx.arc(x, yy + 24, 5, 0, TAU); ctx.fill(); for (const r of [20, 36, 52]) { ctx.beginPath(); ctx.arc(x, yy + 24, r, -Math.PI * 0.75, -Math.PI * 0.25); ctx.stroke(); } }
   else if (i === 3) { ctx.moveTo(x - 30, yy - 10); ctx.lineTo(x - 26, yy + 32); ctx.lineTo(x + 26, yy + 32); ctx.lineTo(x + 30, yy - 10); ctx.stroke(); ctx.beginPath(); ctx.roundRect(x - 12, yy - 36, 24, 40, 5); ctx.stroke(); }
   else if (i === 4) { ctx.roundRect(x - 20, yy - 36, 40, 72, 8); ctx.stroke(); ctx.beginPath(); ctx.arc(x, yy - 28, 3, 0, TAU); ctx.fill(); }
   else { ctx.roundRect(x - 34, yy - 20, 46, 40, 8); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x + 16, yy - 4); ctx.lineTo(x + 34, yy - 16); ctx.lineTo(x + 34, yy + 16); ctx.lineTo(x + 16, yy + 4); ctx.closePath(); ctx.stroke(); }
   ctx.restore(); };
  steps.forEach((s, i) => { const row = Math.floor(i / 3), c = i % 3, x = cx + (c - 1) * (cw + gx), yy = y + row * (ch + 26), on = cl(k - i), a = 0.35 + 0.65 * on, era = i / (steps.length - 1), ac = P.mixc('#C6A06B', '#48D5F2', era);
   ctx.save(); ctx.globalAlpha *= a; P.rr(ctx, x - cw / 2, yy, cw, ch, 26, on > 0 ? P.mixc('#493627', '#101F37', era) : 'rgba(20,24,32,0.75)', { shadow: false, rim: false }); if (on > 0) { ctx.strokeStyle = ac; ctx.lineWidth = 4; ctx.beginPath(); ctx.roundRect(x - cw / 2, yy, cw, ch, 26); ctx.stroke(); }
   icon(i, x, yy + 74, on > 0 ? ac : '#8E9EA9'); ctx.font = '800 32px Nunito'; ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, yy + 168); ctx.restore();
   if (i < steps.length - 1 && c < 2) { ctx.save(); ctx.globalAlpha *= 0.3 + 0.7 * cl(k - i - 0.5); ctx.fillStyle = ac; ctx.beginPath(); ctx.moveTo(x + cw / 2 + 2, yy + 66); ctx.lineTo(x + cw / 2 + gx - 2, yy + 74); ctx.lineTo(x + cw / 2 + 2, yy + 82); ctx.closePath(); ctx.fill(); ctx.restore(); } });
  return { h: 2 * ch + 26 };
 };

 // Rótulo de época (cápsula) estilo 1926 o estilo hoy según era 0..1: fondo sepia oscuro → azul noche, texto papel → blanco.
 P.eraLabel = (ctx, s, cx, cy, px, t, t0, era = 0, o = {}) => { const a = sm(t0, t0 + 0.3, t) * (o.t1 ? 1 - sm(o.t1 - 0.3, o.t1, t) : 1); if (a <= 0) return null; ctx.save(); ctx.globalAlpha *= a; ctx.font = `${o.w || 800} ${px}px ${era < 0.5 ? 'Fraunces' : 'Nunito'}`; const tw = ctx.measureText(s).width, w = tw + px * 1.2, h = px * 1.7, y0 = cy - h / 2 + (1 - E.out(sm(t0, t0 + 0.35, t))) * 12;
  ctx.fillStyle = era < 0.5 ? 'rgba(32,32,33,0.86)' : 'rgba(12,20,33,0.88)'; ctx.beginPath(); ctx.roundRect(cx - w / 2, y0, w, h, era < 0.5 ? 6 : h / 2); ctx.fill(); ctx.strokeStyle = era < 0.5 ? '#C6A06B' : '#48D5F2'; ctx.lineWidth = 3; ctx.stroke(); ctx.fillStyle = era < 0.5 ? '#E1C9A1' : '#F5F7FA'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, cx, y0 + h / 2 + 2); ctx.restore(); return { x: cx - w / 2, y: y0, w, h }; };

 // ---------------- v1.19 · módulo ALMACENAMIENTO (IBM 350 de 1956 → HDD → flash → microSD) ----------------
 // Unidades del mundo 3D en CENTÍMETROS (y hacia arriba), para que la cámara P.cam3 pueda entrar entre los discos sin errores de
 // proyección. Medidas aproximadas del IBM 350 (unidad de discos del sistema IBM 305 RAMAC, 1956): armario ≈ 152 × 172 × 74 cm,
 // 50 discos de 24 pulgadas (61 cm) sobre un eje vertical, 1.200 rpm, un carro de acceso que sube/baja para elegir disco y un brazo
 // que entra en radial para elegir pista (100 pistas por cara), cabezas que flotan sobre un colchón de aire (sin tocar el disco).
 P.RM = { fondo: '#111A21', gris: '#7B8585', metal: '#A5ABA5', metalD: '#4A5559', madera: '#81674B', calida: '#D8AD72', disco: '#A7B3B9', capa: '#8a7766', brazo: '#D1C6B4', azul: '#176CB4', cian: '#4BD4F1', datos: '#7CE6E2', moderno: '#0B1424', oro: '#FFD447', blanco: '#F5F7F8' };
 const R350 = { W: 152, H: 172, D: 74, xs: -30, zs: 0, R: 30.5, y0: 60, pitch: 1.5, n: 50, th: 0.4, colX: 12, top: 0 };
 R350.top = R350.y0 + R350.pitch * (R350.n - 1); P.R350 = R350;
 // altura del disco k (0 = el de abajo) y del hueco entre k y k+1
 P.r350y = (k) => R350.y0 + R350.pitch * k;
 const rmShade = (hex, k) => { const [r, g, b] = H.hex(hex); return `rgb(${cl(r * k, 0, 255) | 0},${cl(g * k, 0, 255) | 0},${cl(b * k, 0, 255) | 0})`; };
 const poly3 = (ctx, cam, pts, fill, o = {}) => { const P2 = cam.clip(pts, o.near ?? 1); if (P2.length < 3) return null; ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (o.stroke) { ctx.strokeStyle = o.stroke; ctx.lineWidth = o.lw || 1; ctx.stroke(); } return P2; };
 const faceVis = (cam, n, c) => (cam.pos[0] - c[0]) * n[0] + (cam.pos[1] - c[1]) * n[1] + (cam.pos[2] - c[2]) * n[2] > 0;
 // caja con caras sombreadas; o.only: 'back' | 'front' (caras ocultas/visibles), o.alpha, o.k (luz por cara)
 P.box3 = (ctx, cam, x0, x1, y0, y1, z0, z1, col, o = {}) => { const F = [[[0, 1, 0], [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]], 1.12], [[0, -1, 0], [[x0, y0, z0], [x0, y0, z1], [x1, y0, z1], [x1, y0, z0]], 0.55], [[0, 0, 1], [[x0, y0, z1], [x0, y1, z1], [x1, y1, z1], [x1, y0, z1]], 1.0], [[0, 0, -1], [[x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z0]], 0.7], [[1, 0, 0], [[x1, y0, z1], [x1, y1, z1], [x1, y1, z0], [x1, y0, z0]], 0.82], [[-1, 0, 0], [[x0, y0, z0], [x0, y1, z0], [x0, y1, z1], [x0, y0, z1]], 0.88]];
  ctx.save(); if (o.alpha != null) ctx.globalAlpha *= o.alpha; for (const [n, pts, k] of F) { const c = pts.reduce((s, p) => [s[0] + p[0] / 4, s[1] + p[1] / 4, s[2] + p[2] / 4], [0, 0, 0]), v = faceVis(cam, n, c); if (o.only === 'back' ? v : o.only === 'front' ? !v : !v) continue; poly3(ctx, cam, pts, rmShade(col, (o.k ?? 1) * k), { stroke: o.edge, lw: o.lw }); } ctx.restore(); };
 // disco del IBM 350 (v1.19.1): anillo de óxido marrón con canto metálico claro y GRAN agujero central (≈ 0,49 R, como la pieza real)
 // ocupado por el cubo; brillo fijo y marcas que giran.
 const disk3 = (ctx, cam, cx, cz, y, R, th, ang, o = {}) => { const N = o.N || 44, ring = (rr, yy) => { const a = []; for (let i = 0; i < N; i++) { const q = (i / N) * TAU; a.push([cx + rr * Math.cos(q), yy, cz + rr * Math.sin(q)]); } return a; }, above = cam.pos[1] > y;
  const fy = above ? y + th / 2 : y - th / 2, by = above ? y - th / 2 : y + th / 2; poly3(ctx, cam, ring(R, by), o.edge || '#b9c2c6');
  const face = poly3(ctx, cam, ring(R, fy), o.col || '#8a6a4a', { stroke: 'rgba(225,232,235,0.55)', lw: 1.1 }); if (!face) return;
  if (o.hl) { ctx.save(); ctx.globalAlpha *= o.hl; poly3(ctx, cam, ring(R, fy), 'rgba(255,212,71,0.55)'); ctx.restore(); }
  ctx.save(); ctx.globalAlpha *= o.detail ?? 1; const ptsA = [], ptsB = []; for (let i = -6; i <= 6; i++) { const q = -0.9 + i * 0.07; ptsA.push([cx + R * 0.98 * Math.cos(q), fy, cz + R * 0.98 * Math.sin(q)]); ptsB.unshift([cx + R * 0.52 * Math.cos(q), fy, cz + R * 0.52 * Math.sin(q)]); } poly3(ctx, cam, [...ptsA, ...ptsB], 'rgba(255,236,210,0.14)');
  for (let m = 0; m < 3; m++) { const q0 = ang + m * TAU / 3, arc = []; for (let i = 0; i <= 6; i++) { const q = q0 + i * 0.05; arc.push(cam.clip([[cx + R * 0.76 * Math.cos(q), fy, cz + R * 0.76 * Math.sin(q)]], 1)[0]); } if (arc.some((p) => !p)) continue; ctx.strokeStyle = 'rgba(40,24,12,0.35)'; ctx.lineWidth = 1.2; ctx.beginPath(); arc.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); }
  ctx.restore(); poly3(ctx, cam, ring(R * 0.49, fy + (above ? 0.05 : -0.05)), '#c4c8c3'); };
 const cyl3 = (ctx, cam, cx, cz, y0, y1, r, col, N = 16) => { const pts = []; for (let i = 0; i < N; i++) { const q = (i / N) * TAU, q2 = ((i + 1) / N) * TAU, n = [Math.cos(q + Math.PI / N), 0, Math.sin(q + Math.PI / N)], c = [cx + n[0] * r, (y0 + y1) / 2, cz + n[2] * r]; if (!faceVis(cam, n, c)) continue; const k = 0.7 + 0.35 * Math.max(0, n[0] * 0.6 + n[2] * 0.8); poly3(ctx, cam, [[cx + r * Math.cos(q), y0, cz + r * Math.sin(q)], [cx + r * Math.cos(q2), y0, cz + r * Math.sin(q2)], [cx + r * Math.cos(q2), y1, cz + r * Math.sin(q2)], [cx + r * Math.cos(q), y1, cz + r * Math.sin(q)]], rmShade(col, k)); } };
 // Sala informática de 1956 (recreación): suelo de baldosas, paredes con zócalo, puerta de referencia (≈ 2,1 m), ventana alta, luz cálida.
 // o: { warm 0..1, door (x de la puerta en la pared del fondo), back (z de la pared del fondo) }
 P.room1956 = (ctx, cam, t, o = {}) => { const bz = o.back ?? -170, lx = o.left ?? -420, rx = o.right ?? 420, fz = o.front ?? 420, H2 = 300; ctx.save();
  const g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, '#2a2620'); g.addColorStop(1, '#141310'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH);
  poly3(ctx, cam, [[lx, H2, bz], [rx, H2, bz], [rx, 0, bz], [lx, 0, bz]], '#8c8272'); poly3(ctx, cam, [[lx, H2, fz], [lx, H2, bz], [lx, 0, bz], [lx, 0, fz]], '#6f675b'); poly3(ctx, cam, [[rx, H2, bz], [rx, H2, fz], [rx, 0, fz], [rx, 0, bz]], '#776e61');
  poly3(ctx, cam, [[lx, 32, bz + 0.5], [rx, 32, bz + 0.5], [rx, 0, bz + 0.5], [lx, 0, bz + 0.5]], '#4a4239');
  const dx = o.door ?? 230; poly3(ctx, cam, [[dx - 50, 212, bz + 0.6], [dx + 50, 212, bz + 0.6], [dx + 50, 0, bz + 0.6], [dx - 50, 0, bz + 0.6]], '#5c4a36'); poly3(ctx, cam, [[dx - 44, 205, bz + 1], [dx + 44, 205, bz + 1], [dx + 44, 0, bz + 1], [dx - 44, 0, bz + 1]], '#81674B'); poly3(ctx, cam, [[dx - 34, 190, bz + 1.4], [dx + 34, 190, bz + 1.4], [dx + 34, 120, bz + 1.4], [dx - 34, 120, bz + 1.4]], '#6e573f'); const kn = cam.clip([[dx + 34, 100, bz + 2]], 1)[0]; if (kn) { ctx.fillStyle = '#D8AD72'; ctx.beginPath(); ctx.arc(kn[0], kn[1], Math.max(1.5, 600 / kn[2]), 0, TAU); ctx.fill(); }
  for (const wx of [-300, -120]) { poly3(ctx, cam, [[wx - 70, 270, bz + 0.6], [wx + 70, 270, bz + 0.6], [wx + 70, 200, bz + 0.6], [wx - 70, 200, bz + 0.6]], '#d8c9a6'); }
  const ts = 60; for (let x = lx; x < rx; x += ts) for (let z = bz; z < fz; z += ts) { const k = ((Math.round(x / ts) + Math.round(z / ts)) & 1) ? '#5d574d' : '#686155'; poly3(ctx, cam, [[x, 0, z], [x + ts, 0, z], [x + ts, 0, z + ts], [x, 0, z + ts]], k); }
  const L = cam.clip([[0, 290, -40]], 1)[0]; if (L) { const gl = ctx.createRadialGradient(L[0], L[1], 10, L[0], L[1], 1100); gl.addColorStop(0, `rgba(216,173,114,${0.22 * (o.warm ?? 1)})`); gl.addColorStop(1, 'rgba(216,173,114,0)'); ctx.fillStyle = gl; ctx.fillRect(0, 0, W, HH); }
  ctx.restore(); };
 // Técnico de los años 50 (v1.19.1): proporciones reales (cabeza ≈ 1/7,6 de la altura), hombros, codos, manos con pulgar, cinturón,
 // camisa remetida con sombreado lateral, corbata, zapatos con tacón, balanceo de peso sutil y gesto opcional de señalar (o.point 0..1).
 // Devuelve { foot, head, hand (mano derecha en pantalla), px }.
 P.worker1956 = (ctx, cam, foot, t, o = {}) => { const A = cam.clip([foot], 1)[0], B = cam.clip([[foot[0], foot[1] + (o.h || 175), foot[2]]], 1)[0]; if (!A || !B) return null; const h = A[1] - B[1]; if (h < 4) return null; const x = A[0], y = A[1], u = h / 175, v = o.var ?? 0, dir = o.dir ?? 1;
  const skin = ['#c99a74', '#a8764f', '#e0b48e'][v % 3], skD = H.rgba(H.mix(skin, '#3a1e10', 0.25)), trou = ['#30353a', '#3b3328', '#2a2f3a'][v % 3], trouD = H.rgba(H.mix(trou, '#000000', 0.35)), tie = ['#6a2c2c', '#2a3a5a', '#3a4a2a'][v % 3], hair = ['#2a1e16', '#14100c', '#5a4632'][v % 3], shirt = '#eeede6', shirtD = '#c9c8bf';
  const sw = Math.sin(t * 0.9 + v) * 1.1, g = E.inOut(cl(o.point ?? (o.pose === 'point' ? 1 : 0)));
  ctx.save(); ctx.translate(x, y); ctx.scale(u * dir, u); const S = (pts, c) => { ctx.fillStyle = c; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); };
  const sh = ctx.createRadialGradient(0, 0, 2, 0, 0, 34); sh.addColorStop(0, 'rgba(0,0,0,0.45)'); sh.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = sh; ctx.beginPath(); ctx.ellipse(0, 0, 34, 7, 0, 0, TAU); ctx.fill();
  // zapatos y piernas (pantalón con raya y caída hacia el zapato)
  ctx.fillStyle = '#141210'; ctx.beginPath(); ctx.moveTo(-15, 0); ctx.lineTo(-15, -6); ctx.quadraticCurveTo(-9, -9, -3, -6); ctx.lineTo(-1, 0); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(2, 0); ctx.lineTo(3, -6); ctx.quadraticCurveTo(10, -9, 16, -6); ctx.lineTo(17, 0); ctx.closePath(); ctx.fill();
  S([[-16, -6], [-17.5 + sw * 0.3, -50], [-16 + sw * 0.5, -90], [-1, -90], [-1.5, -50], [-3, -6]], trou); S([[3, -6], [1.5, -50], [1, -90], [16 + sw * 0.5, -90], [17 + sw * 0.3, -50], [16, -6]], trou); S([[-16, -6], [-17.5 + sw * 0.3, -50], [-16 + sw * 0.5, -90], [-12, -90], [-13, -50], [-12, -6]], trouD);
  ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(-9, -8); ctx.lineTo(-9.5, -86); ctx.moveTo(9.5, -8); ctx.lineTo(9, -86); ctx.stroke();
  // camisa (hombros caídos, cintura remetida) con sombreado lateral, cinturón, corbata, cuello, bolsillo
  S([[-16 + sw * 0.5, -91], [-18.5, -122], [-21, -139], [-15, -145], [-5, -148], [5, -148], [15, -145], [21, -139], [18.5, -122], [16 + sw * 0.5, -91]], shirt); S([[-16 + sw * 0.5, -91], [-18.5, -122], [-21, -139], [-15, -145], [-11, -146], [-12, -122], [-10, -91]], shirtD);
  ctx.fillStyle = '#1d1a17'; ctx.fillRect(-16.5 + sw * 0.5, -94, 33, 4.5); ctx.fillStyle = '#b8a15a'; ctx.fillRect(-2, -93.5, 4, 3.5);
  S([[-2.2, -145], [2.2, -145], [3.2, -104], [0, -99], [-3.2, -104]], tie); S([[-5, -148], [0, -142], [-2, -138], [-7, -145]], '#f8f7f2'); S([[5, -148], [0, -142], [2, -138], [7, -145]], '#f8f7f2'); ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 0.8; ctx.strokeRect(6, -133, 7, 7);
  // brazos: izquierdo relajado; derecho con gesto de señalar (hombro → codo → muñeca → mano)
  const arm = (sx, sy, ex, ey, wx, wy, side) => { ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = side < 0 ? shirtD : shirt; ctx.lineWidth = 8.5; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.lineTo(lerp(ex, wx, 0.55), lerp(ey, wy, 0.55)); ctx.stroke(); ctx.strokeStyle = side < 0 ? skD : skin; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(lerp(ex, wx, 0.5), lerp(ey, wy, 0.5)); ctx.lineTo(wx, wy); ctx.stroke(); const an = Math.atan2(wy - ey, wx - ex); ctx.save(); ctx.translate(wx, wy); ctx.rotate(an - Math.PI / 2); ctx.fillStyle = side < 0 ? skD : skin; ctx.beginPath(); ctx.ellipse(0, 4, 3.6, 5, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(side * -2.6, 1.5, 1.4, 3.2, side * 0.5, 0, TAU); ctx.fill(); ctx.restore(); return [wx + Math.cos(an) * 8, wy + Math.sin(an) * 8]; };
  arm(-19, -141, -23, -114 + sw * 0.3, -21.5, -88, -1); const hand = arm(19, -141, lerp(23, 34, g), lerp(-114, -127, g), lerp(21.5, 52, g), lerp(-88, -138, g), 1);
  // cuello y cabeza (orejas, pelo con raya, cejas, ojos, nariz, boca)
  ctx.fillStyle = skD; ctx.fillRect(-3.6, -154, 7.2, 8); const hx = g * 1.5; ctx.save(); ctx.translate(hx, 0); ctx.fillStyle = skin; ctx.beginPath(); ctx.moveTo(-9, -163); ctx.quadraticCurveTo(-9.5, -153, -4, -151); ctx.quadraticCurveTo(0, -149.5, 4, -151); ctx.quadraticCurveTo(9.5, -153, 9, -163); ctx.quadraticCurveTo(9, -175, 0, -175); ctx.quadraticCurveTo(-9, -175, -9, -163); ctx.fill(); ctx.beginPath(); ctx.ellipse(-9.4, -162, 1.8, 3, 0, 0, TAU); ctx.ellipse(9.4, -162, 1.8, 3, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = hair; ctx.beginPath(); ctx.moveTo(-9.6, -162); ctx.quadraticCurveTo(-11, -177, 0, -177.5); ctx.quadraticCurveTo(10.5, -177, 9.6, -163); ctx.quadraticCurveTo(7, -170, -3, -171); ctx.quadraticCurveTo(-7, -168, -9.6, -162); ctx.fill();
  ctx.fillStyle = '#1b1410'; ctx.beginPath(); ctx.ellipse(-3.4 + g, -163, 1, 1.1, 0, 0, TAU); ctx.ellipse(3.4 + g, -163, 1, 1.1, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = hair; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-5.2, -166); ctx.lineTo(-1.8, -166.4); ctx.moveTo(1.8, -166.4); ctx.lineTo(5.2, -166); ctx.stroke(); ctx.strokeStyle = 'rgba(90,50,30,0.5)'; ctx.beginPath(); ctx.moveTo(0.5, -162); ctx.lineTo(-0.3, -158.5); ctx.lineTo(1, -158.3); ctx.moveTo(-2.2, -155.2); ctx.quadraticCurveTo(0, -154.3, 2.2, -155.2); ctx.stroke(); ctx.restore();
  ctx.restore(); return { foot: [x, y], head: [x, y - h], hand: [x + hand[0] * u * dir, y + hand[1] * u], px: h };
 };
 // IBM 350 en 3D con cámara P.cam3 (cm) — v1.19.1, rediseñado con la fotografía histórica (IBM 305 RAMAC, BRL 1961): armario gris
 // con zócalo oscuro, panel inferior macizo, GRAN VENTANA DE INSPECCIÓN con marco fino, panel derecho con rejillas y pilotos y banda
 // superior oscura. Dentro: pila de 50 discos (anillos de óxido marrón con canto metálico y gran agujero central ocupado por el cubo),
 // motor bajo la pila, mecanismo de acceso con dos guías verticales, carro, cable con polea y brazo radial con dos cabezas.
 // o: { rot, open 0..1 (retira el cristal frontal), xray 0..1, arm: { k (hueco 0..48), ext 0..1 }, hl: { k, a }, count 0..50,
 //      lights, x, z } — misma firma que v1.19 (extract se mantiene por compatibilidad).
 P.ibm350 = (ctx, cam, t, o = {}) => { const ox = o.x || 0, oz = o.z || 0, Wd = R350.W / 2, Dd = R350.D / 2, xs = R350.xs + ox, zs = R350.zs + oz, R = R350.R, rot = o.rot ?? 0, xr = cl(o.xray || 0), op = cl(o.open || 0), armK = o.arm?.k ?? 24, ext = cl(o.arm?.ext ?? 0), ya = P.r350y(armK) + R350.pitch / 2;
  const colP = '#7B8585', colF = '#A5ABA5', colD = '#4A5559', x0 = ox - Wd, x1 = ox + Wd, z0 = oz - Dd, z1 = oz + Dd, wx0 = x0 + 6, wx1 = x0 + 108, wy0 = 52, wy1 = 150, HB = 152;
  ctx.save();
  poly3(ctx, cam, [[x0 - 8, 0.2, z0 - 8], [x1 + 8, 0.2, z0 - 8], [x1 + 8, 0.2, z1 + 10], [x0 - 8, 0.2, z1 + 10]], 'rgba(0,0,0,0.38)');
  P.box3(ctx, cam, x0 + 3, x1 - 3, 0, 12, z0 + 3, z1 - 3, '#2f3638');
  P.box3(ctx, cam, x0, x1, 12, R350.H, z0, z1, '#2b3236', { only: 'back', k: 0.85 });
  // interior: suelo interno, motor, cubo, núcleo oscuro (huecos), discos, mecanismo de acceso
  poly3(ctx, cam, [[wx0, 13, z0 + 2], [wx1, 13, z0 + 2], [wx1, 13, z1 - 2], [wx0, 13, z1 - 2]], '#3a4246');
  P.box3(ctx, cam, xs - 18, xs + 18, 13, R350.y0 - 4, zs - 18, zs + 18, '#56626a'); cyl3(ctx, cam, xs, zs, R350.y0 - 4, R350.y0 - 1, 16, '#7d878c', 20);
  cyl3(ctx, cam, xs, zs, R350.y0, R350.top, R * 0.95, '#15191b', 32);
  const colX = xs + R + 11.5, colZ = zs; const colDepth = cam.depth([colX, ya, colZ]), stackDepth = cam.depth([xs, ya, zs]);
  const drawMech = () => { for (const dz of [-4.5, 4.5]) P.box3(ctx, cam, colX - 1.1, colX + 1.1, R350.y0 - 10, R350.top + 14, colZ + dz - 1.1, colZ + dz + 1.1, '#9aa3a6'); P.box3(ctx, cam, colX - 2.5, colX + 2.5, R350.top + 14, R350.top + 17, colZ - 7, colZ + 7, '#6d777c'); cyl3(ctx, cam, colX + 3, colZ, R350.top + 17, R350.top + 19, 4.5, '#b6bdc0', 12);
   P.box3(ctx, cam, colX - 4.5, colX + 6.5, ya - 3.2, ya + 3.2, colZ - 6.5, colZ + 6.5, '#c9bfae'); P.box3(ctx, cam, colX + 6.5, colX + 9, ya - 1.5, ya + 1.5, colZ - 3, colZ + 3, '#6d777c');
   const cab = []; for (let i = 0; i <= 12; i++) { const u = i / 12, p0 = [colX + 2, ya + 3.2, colZ + 2], p1 = [colX + 16, R350.top + 30, colZ + 2], p2 = [colX + 30, R350.top + 8, colZ - 4], a = (1 - u) ** 2, b = 2 * u * (1 - u), c = u * u; cab.push([a * p0[0] + b * p1[0] + c * p2[0], a * p0[1] + b * p1[1] + c * p2[1], a * p0[2] + b * p1[2] + c * p2[2]]); } const C2 = cab.map((p) => cam.clip([p], 1)[0]); if (C2.every(Boolean)) { ctx.strokeStyle = '#1b1f22'; ctx.lineWidth = Math.max(1.5, 1100 / C2[0][2]); ctx.beginPath(); C2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); } };
  if (colDepth > stackDepth) drawMech();
  const camY = cam.pos[1], order = []; for (let k = 0; k < R350.n; k++) order.push({ y: P.r350y(k), k }); order.push({ y: ya, arm: true }); order.sort((a, b) => Math.abs(b.y - camY) - Math.abs(a.y - camY));
  const tipX = lerp(xs + R + 5, xs + R * 0.56, E.inOut(ext)), cnt = o.count ?? 0;
  for (const it of order) { if (it.arm) { P.box3(ctx, cam, tipX, colX - 4.5, ya - 0.3, ya + 0.3, colZ - 2, colZ + 2, P.RM.brazo); P.box3(ctx, cam, tipX - 1.2, tipX + 2.2, ya - 0.62, ya - 0.3, colZ - 1.4, colZ + 1.4, '#2e2a26'); P.box3(ctx, cam, tipX - 1.2, tipX + 2.2, ya + 0.3, ya + 0.62, colZ - 1.4, colZ + 1.4, '#2e2a26'); continue; }
   const k = it.k, ex = o.extract && o.extract.k === k ? E.inOut(cl(o.extract.u)) * 95 : 0, hl = (o.hl && o.hl.k === k ? o.hl.a : 0) + (cnt > k ? 0.55 * (1 - cl(cnt - k - 1)) + 0.12 : 0);
   disk3(ctx, cam, xs, zs + ex, it.y, R, R350.th, rot + k * 0.37, { hl: Math.min(1, hl), N: o.N || 44, detail: o.detail }); }
  if (colDepth <= stackDepth) drawMech();
  // cubo superior (blanco en la fotografía) sobre el último disco
  if (cam.pos[1] > R350.top + 1) cyl3(ctx, cam, xs, zs, R350.top, R350.top + 5, R * 0.47, '#d4d7d2', 24);
  // armario: techo, laterales, frente con ventana (el cristal se retira con open) y panel derecho
  const ca = 1 - xr * 0.88; if (ca > 0.01) { ctx.save(); ctx.globalAlpha *= ca;
   for (const [n, pts, k] of [[[0, 1, 0], [[x0, R350.H, z0], [x1, R350.H, z0], [x1, R350.H, z1], [x0, R350.H, z1]], 1.12], [[1, 0, 0], [[x1, 12, z1], [x1, R350.H, z1], [x1, R350.H, z0], [x1, 12, z0]], 0.78], [[-1, 0, 0], [[x0, 12, z0], [x0, R350.H, z0], [x0, R350.H, z1], [x0, 12, z1]], 0.86]]) { const c = pts.reduce((s, p) => [s[0] + p[0] / 4, s[1] + p[1] / 4, s[2] + p[2] / 4], [0, 0, 0]); if (faceVis(cam, n, c)) { poly3(ctx, cam, pts, rmShade(colP, k)); if (n[1] === 0) { const xx = pts[0][0]; poly3(ctx, cam, [[xx, HB, z1], [xx, R350.H, z1], [xx, R350.H, z0], [xx, HB, z0]], rmShade(colD, k * 1.1)); } } }
   if (faceVis(cam, [0, 0, 1], [ox, 90, z1])) { const F = (a, b, c, d, col) => poly3(ctx, cam, [[a, c, z1], [a, d, z1], [b, d, z1], [b, c, z1]], col);
    F(x0, x1, 12, wy0, rmShade(colP, 1)); F(x0, wx0, wy0, HB, rmShade(colP, 1)); F(wx1, x1, wy0, HB, rmShade(colP, 0.96)); F(x0, x1, HB, R350.H, rmShade(colD, 1.15)); F(wx0, wx1, wy1, HB, rmShade(colP, 1));
    const fa = 1 - op, gz = z1 + op * 120; if (fa > 0.01) { ctx.save(); ctx.globalAlpha *= fa; poly3(ctx, cam, [[wx0, wy0, gz + 0.2], [wx0, wy1, gz + 0.2], [wx1, wy1, gz + 0.2], [wx1, wy0, gz + 0.2]], 'rgba(185,210,220,0.10)', { stroke: rmShade(colF, 1.15), lw: 2.5 }); const gl = cam.clip([[wx0 + 14, wy1 - 6, gz + 0.3], [wx0 + 34, wy1 - 6, gz + 0.3], [wx0 + 8, wy0 + 20, gz + 0.3], [wx0 - 4, wy0 + 20, gz + 0.3]], 1); if (gl.length > 2) { ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.beginPath(); gl.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); } ctx.restore(); }
    poly3(ctx, cam, [[wx0, wy0, z1 + 0.4], [wx0, wy1, z1 + 0.4], [wx1, wy1, z1 + 0.4], [wx1, wy0, z1 + 0.4]], null, { stroke: rmShade(colF, 1.1), lw: 3 });
    for (let k = 0; k < 10; k++) { const yy = 60 + k * 7.5; poly3(ctx, cam, [[wx1 + 8, yy, z1 + 0.4], [x1 - 8, yy, z1 + 0.4], [x1 - 8, yy + 2.6, z1 + 0.4], [wx1 + 8, yy + 2.6, z1 + 0.4]], rmShade(colD, 1.05)); }
    poly3(ctx, cam, [[wx1 + 8, 130, z1 + 0.4], [x1 - 8, 130, z1 + 0.4], [x1 - 8, 144, z1 + 0.4], [wx1 + 8, 144, z1 + 0.4]], '#262c30');
    for (let k = 0; k < 4; k++) { const L = cam.clip([[wx1 + 13 + k * 7, 137, z1 + 0.6]], 1)[0]; if (!L) continue; const on = (o.lights ?? 1) && Math.sin(t * (1.3 + k * 0.7) + k) > 0; ctx.fillStyle = on ? (k % 2 ? '#ffcf6a' : '#e86a4a') : '#5a4a3a'; ctx.beginPath(); ctx.arc(L[0], L[1], Math.max(1.5, 900 / L[2]), 0, TAU); ctx.fill(); }
    const hd = cam.clip([[x0 + 4, 158, z1 + 0.5], [x1 - 4, 158, z1 + 0.5]], 1); if (hd.length === 2) { ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hd[0][0], hd[0][1]); ctx.lineTo(hd[1][0], hd[1][1]); ctx.stroke(); } }
   ctx.restore(); }
  if (xr > 0) { ctx.save(); ctx.globalAlpha *= xr * 0.9; ctx.strokeStyle = 'rgba(75,212,241,0.55)'; ctx.lineWidth = 1.5; const E2 = [[x0, 12, z0], [x1, 12, z0], [x1, 12, z1], [x0, 12, z1], [x0, R350.H, z0], [x1, R350.H, z0], [x1, R350.H, z1], [x0, R350.H, z1]]; for (const [a, b] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) { const A2 = cam.clip([E2[a]], 1)[0], B2 = cam.clip([E2[b]], 1)[0]; if (!A2 || !B2) continue; ctx.beginPath(); ctx.moveTo(A2[0], A2[1]); ctx.lineTo(B2[0], B2[1]); ctx.stroke(); } ctx.restore(); }
  ctx.restore();
  const pj = (p) => cam.clip([p], 1)[0]; return { stackTop: pj([xs, R350.top, zs]), stackBot: pj([xs, R350.y0, zs]), stackCenter: pj([xs, (R350.y0 + R350.top) / 2, zs + R]), rim: pj([xs + R, (R350.y0 + R350.top) / 2, zs]), armTip: pj([tipX, ya, colZ]), column: pj([colX, R350.top + 14, colZ]), top: pj([ox, R350.H, z1]), front: pj([ox, R350.H * 0.5, z1]), window: pj([(wx0 + wx1) / 2, wy1, z1]), disk: (k) => pj([xs, P.r350y(k), zs + R]) };
 };
 // Otras unidades del sistema IBM 305 RAMAC (recreación genérica): armario de proceso, consola con máquina de escribir e impresora.
 P.ramac305 = (ctx, cam, t, o = {}) => { const ox = o.x ?? 0, oz = o.z ?? 0; P.box3(ctx, cam, ox - 60, ox + 60, 0, 180, oz - 38, oz + 38, P.RM.metal, { k: 0.95 }); for (let k = 0; k < 3; k++) { const L = cam.clip([[ox - 30 + k * 30, 140, oz + 38.5]], 1)[0]; if (L) { ctx.fillStyle = Math.sin(t * 2 + k * 1.7) > 0 ? '#ffcf6a' : '#5a4a3a'; ctx.beginPath(); ctx.arc(L[0], L[1], Math.max(1.5, 900 / L[2]), 0, TAU); ctx.fill(); } }
  const cx = ox + (o.consoleDx ?? 170); P.box3(ctx, cam, cx - 70, cx + 70, 0, 74, oz - 30, oz + 40, P.RM.madera); P.box3(ctx, cam, cx - 70, cx + 70, 74, 78, oz - 32, oz + 42, '#9a7f60'); P.box3(ctx, cam, cx - 25, cx + 25, 78, 96, oz - 10, oz + 20, '#3a3f42'); P.box3(ctx, cam, cx + 30, cx + 66, 78, 132, oz - 30, oz - 8, P.RM.gris); };
 // Cota con flechas y rótulo (px ≥ 32). o: { col, px, off (desplazamiento perpendicular del texto), a }
 P.dimLine = (ctx, x0, y0, x1, y1, label, o = {}) => { const a = o.a ?? 1; if (a <= 0) return; const c = o.col || '#FFD447', an = Math.atan2(y1 - y0, x1 - x0), L = Math.hypot(x1 - x0, y1 - y0), u = E.out(cl(a)); ctx.save(); ctx.globalAlpha *= cl(a * 1.5); ctx.translate((x0 + x1) / 2, (y0 + y1) / 2); ctx.rotate(an); ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 4; const h = (L / 2) * u; ctx.beginPath(); ctx.moveTo(-h, 0); ctx.lineTo(h, 0); ctx.moveTo(-L / 2, -16); ctx.lineTo(-L / 2, 16); ctx.moveTo(L / 2, -16); ctx.lineTo(L / 2, 16); ctx.stroke(); for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * h, 0); ctx.lineTo(s * (h - 18), -9); ctx.lineTo(s * (h - 18), 9); ctx.closePath(); ctx.fill(); }
  if (label) { ctx.rotate(Math.abs(an) > Math.PI / 2 ? Math.PI : 0); const px = o.px || 40; ctx.font = `800 ${px}px Nunito`; const tw = ctx.measureText(label).width; ctx.fillStyle = 'rgba(11,20,36,0.85)'; ctx.beginPath(); ctx.roundRect(-tw / 2 - 16, (o.off ?? -46) - px * 0.75, tw + 32, px * 1.5, 12); ctx.fill(); ctx.fillStyle = '#F5F7F8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, 0, (o.off ?? -46) + 2); } ctx.restore(); };
 // Tarjeta microSD con su forma real (11 × 15 mm, escalón lateral, contactos). mm = px por milímetro. o: { rot, back (contactos), glow }
 P.microSD = (ctx, cx, cy, mm, o = {}) => { const w = 11 * mm, h = 15 * mm; ctx.save(); ctx.translate(cx, cy); if (o.rot) ctx.rotate(o.rot); if (o.tilt) ctx.transform(1, 0, o.tilt, 1, 0, 0);
  const path = () => { ctx.beginPath(); ctx.moveTo(-w / 2 + mm * 0.5, -h / 2); ctx.lineTo(w / 2 - mm * 1.2, -h / 2); ctx.lineTo(w / 2, -h / 2 + mm * 1.2); ctx.lineTo(w / 2, -h / 2 + mm * 5.2); ctx.lineTo(w / 2 - mm * 0.8, -h / 2 + mm * 5.9); ctx.lineTo(w / 2 - mm * 0.8, -h / 2 + mm * 7.4); ctx.lineTo(w / 2, -h / 2 + mm * 8); ctx.lineTo(w / 2, h / 2 - mm * 0.5); ctx.quadraticCurveTo(w / 2, h / 2, w / 2 - mm * 0.5, h / 2); ctx.lineTo(-w / 2 + mm * 0.5, h / 2); ctx.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - mm * 0.5); ctx.lineTo(-w / 2, -h / 2 + mm * 0.5); ctx.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + mm * 0.5, -h / 2); ctx.closePath(); };
  ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = mm * 1.2; ctx.shadowOffsetY = mm * 0.5; path(); ctx.fillStyle = '#16191e'; ctx.fill(); ctx.shadowColor = 'transparent';
  if (o.back) { ctx.fillStyle = '#c9a646'; for (let k = 0; k < 8; k++) { const x = -w / 2 + mm * (0.9 + k * 1.15); ctx.beginPath(); ctx.roundRect(x, -h / 2 + mm * 0.8, mm * 0.8, mm * 3.2, mm * 0.2); ctx.fill(); } }
  else { const g = ctx.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2); g.addColorStop(0, '#2f3d52'); g.addColorStop(1, '#176CB4'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-w / 2 + mm * 0.7, -h / 2 + mm * 3.6, w - mm * 2.2, h - mm * 4.4, mm * 0.4); ctx.fill(); ctx.strokeStyle = 'rgba(245,247,248,0.35)'; ctx.lineWidth = Math.max(1, mm * 0.12); for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(-w / 2 + mm * 1.5, -h / 2 + mm * (9 + k * 1.3)); ctx.lineTo(w / 2 - mm * 2.4, -h / 2 + mm * (9 + k * 1.3)); ctx.stroke(); } }
  ctx.strokeStyle = 'rgba(245,247,248,0.25)'; ctx.lineWidth = Math.max(1, mm * 0.1); path(); ctx.stroke();
  if (o.glow) { ctx.globalAlpha = o.glow; ctx.shadowColor = '#4BD4F1'; ctx.shadowBlur = mm * 4; ctx.strokeStyle = '#4BD4F1'; ctx.lineWidth = Math.max(2, mm * 0.2); path(); ctx.stroke(); }
  ctx.restore(); return { w, h };
 };
 // Mano con la palma hacia arriba en perspectiva, índice extendido y la microSD apoyada en la yema (v1.19.2): UNA SOLA SILUETA continua
 // (índice + palma + nudillos de los dedos flexionados + pulgar) rellenada de una vez —sin costuras entre piezas—, con volumen por
 // sombreado interior, pliegues de las falanges, uña visible solo como un filo dentro de la punta y la palma que sale del cuadro.
 // (cx, tipY) = centro de la yema; fw = ancho del dedo en px (≈ 17 mm; la tarjeta mide 11 × 15 mm a la misma escala). o: { skin, card, cardRot, glow, ang }
 let HAND_RIM = null;
 P.fingertip = (ctx, cx, tipY, fw, t, o = {}) => { const sk = o.skin || '#d29a76', dk = H.rgba(H.mix(sk, '#3a1e10', 0.3)), dk2 = H.rgba(H.mix(sk, '#3a1e10', 0.5)), lt = H.rgba(H.mix(sk, '#fff1e6', 0.3)), mm = fw / 17, an = o.ang ?? 0.42, L = fw * 4.4;
  const hp = new Path2D();
  // índice (punta redondeada → base dentro de la palma)
  hp.moveTo(-fw * 0.5, fw * 0.5); hp.bezierCurveTo(-fw * 0.52, -fw * 0.16, fw * 0.52, -fw * 0.16, fw * 0.5, fw * 0.5); hp.lineTo(fw * 0.6, L * 1.02); hp.lineTo(-fw * 0.62, L * 1.02); hp.closePath();
  // palma y muñeca (salen del cuadro), con el borde superior a la altura de los nudillos
  hp.moveTo(-fw * 0.6, L * 0.95); hp.lineTo(fw * 2.9, L * 0.95); hp.quadraticCurveTo(fw * 3.7, L * 0.98, fw * 4.0, L * 1.3); hp.lineTo(fw * 4.3, L * 6); hp.lineTo(-fw * 1.3, L * 6); hp.lineTo(-fw * 1.55, L * 1.5); hp.quadraticCurveTo(-fw * 1.35, L * 1.12, -fw * 0.6, L * 0.95); hp.closePath();
  // dedos flexionados: nudillos y falanges dobladas, solapados entre sí y con la palma
  for (let k = 0; k < 3; k++) { const bx = fw * (1.08 + k * 0.92), by = L * (0.93 + k * 0.035), w2 = fw * (1.02 - k * 0.07); hp.roundRect(bx - w2 / 2, by - fw * 0.52, w2, fw * 1.7, w2 * 0.5); }
  // pulgar: nace de la palma (su base queda dentro) y descansa a lo largo, hacia el índice
  const th = new Path2D(); th.roundRect(-fw * 0.55, -fw * 1.55, fw * 1.1, fw * 2.6, fw * 0.54); const mT = new DOMMatrix().translate(-fw * 0.98, L * 1.22).rotate(20); hp.addPath(th, mT);
  ctx.save(); ctx.translate(cx, tipY); ctx.rotate(an);
  const g = ctx.createLinearGradient(-fw * 1.6, 0, fw * 3.8, 0); g.addColorStop(0, dk); g.addColorStop(0.24, sk); g.addColorStop(0.32, lt); g.addColorStop(0.5, sk); g.addColorStop(1, dk); ctx.fillStyle = g; ctx.fill(hp);
  { const Lr = HAND_RIM || (HAND_RIM = H.layer(W, HH)), c2 = Lr.getContext('2d'), M = ctx.getTransform(); c2.setTransform(1, 0, 0, 1, 0, 0); c2.globalCompositeOperation = 'source-over'; c2.clearRect(0, 0, W, HH); c2.fillStyle = dk2; c2.fillRect(0, 0, W, HH); c2.globalCompositeOperation = 'destination-out'; c2.setTransform(M); c2.fill(hp); c2.globalCompositeOperation = 'source-over'; c2.setTransform(1, 0, 0, 1, 0, 0); const sc = Math.hypot(M.a, M.b); ctx.save(); ctx.clip(hp); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha *= 0.55; ctx.filter = `blur(${Math.max(1, fw * 0.1 * sc)}px)`; ctx.drawImage(Lr, 0, 0); ctx.restore(); }
  ctx.save(); ctx.clip(hp); ctx.globalAlpha = 0.1; ctx.filter = `blur(${Math.max(1, fw * 0.15)}px)`; ctx.fillStyle = '#3a1e10'; ctx.beginPath(); ctx.ellipse(fw * 1.9, L * 1.12, fw * 2.0, fw * 0.3, 0, 0, TAU); ctx.fill(); ctx.restore();
  ctx.strokeStyle = 'rgba(60,30,15,0.35)'; ctx.lineWidth = Math.max(1, fw * 0.02); ctx.lineCap = 'round';
  for (let k = 0; k < 3; k++) { const bx = fw * (1.08 + k * 0.92), by = L * (0.93 + k * 0.035), w2 = fw * (1.02 - k * 0.07); ctx.beginPath(); ctx.moveTo(bx - w2 * 0.32, by + fw * 0.5); ctx.quadraticCurveTo(bx, by + fw * 0.58, bx + w2 * 0.32, by + fw * 0.5); ctx.stroke(); if (k < 2) { ctx.beginPath(); ctx.moveTo(bx + w2 * 0.5, by - fw * 0.3); ctx.lineTo(bx + w2 * 0.5, by + fw * 0.35); ctx.stroke(); } }
  ctx.beginPath(); ctx.moveTo(fw * 0.62, L * 0.98); ctx.lineTo(fw * 0.62, L * 1.2); ctx.stroke();
  for (const yy of [1.45, 1.58, 2.85, 2.98]) { ctx.beginPath(); ctx.moveTo(-fw * 0.4, fw * yy); ctx.quadraticCurveTo(0, fw * (yy + 0.07), fw * 0.4, fw * yy); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(-fw * 0.9, L * 1.42); ctx.quadraticCurveTo(fw * 1.2, L * 1.18, fw * 3.5, L * 1.36); ctx.stroke();
  ctx.save(); ctx.translate(-fw * 0.98, L * 1.22); ctx.rotate(20 * Math.PI / 180); ctx.beginPath(); ctx.moveTo(-fw * 0.42, fw * 0.1); ctx.quadraticCurveTo(0, fw * 0.18, fw * 0.42, fw * 0.1); ctx.stroke(); ctx.globalAlpha = 0.55; ctx.fillStyle = H.rgba(H.mix(sk, '#f6d3c6', 0.4)); ctx.beginPath(); ctx.ellipse(-fw * 0.12, -fw * 1.18, fw * 0.17, fw * 0.24, 0.1, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.restore();
  // uña: solo un filo claro dentro de la punta (vista desde la palma) + brillo de la yema
  ctx.save(); ctx.clip(hp); ctx.strokeStyle = H.rgba(H.mix(sk, '#f8ddd2', 0.6)); ctx.lineWidth = fw * 0.07; ctx.beginPath(); ctx.ellipse(0, fw * 0.36, fw * 0.43, fw * 0.43, 0, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke(); ctx.fillStyle = 'rgba(255,200,180,0.18)'; ctx.beginPath(); ctx.ellipse(0, fw * 0.62, fw * 0.34, fw * 0.48, 0, 0, TAU); ctx.fill(); ctx.restore();
  ctx.restore();
  let card = null; if (o.card !== false) { const c0 = [cx - Math.sin(an) * fw * 0.62, tipY + Math.cos(an) * fw * 0.62]; ctx.save(); ctx.fillStyle = 'rgba(60,25,10,0.4)'; ctx.filter = `blur(${Math.max(1, mm * 0.7)}px)`; ctx.beginPath(); ctx.ellipse(c0[0] + mm * 0.6, c0[1] + mm * 0.8, mm * 5.8, mm * 7.8, an + (o.cardRot ?? -0.1), 0, TAU); ctx.fill(); ctx.restore(); P.microSD(ctx, c0[0], c0[1], mm, { rot: an + (o.cardRot ?? -0.1), glow: o.glow }); card = c0; }
  return { card, mm };
 };
 // Miniatura de fotografía (paisaje estilizado, determinista por seed) — visualización conceptual del contenido.
 P.photoTile = (ctx, x, y, s, seed, o = {}) => { const R = H.rng(seed * 13 + 1), skies = [['#5fa8d8', '#bfe3f2'], ['#e7905a', '#f6d79a'], ['#2b3f6b', '#7d8fc0'], ['#7cc4c0', '#e6f4ee']], sk = skies[seed % 4]; ctx.save(); ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot); ctx.fillStyle = '#F5F7F8'; ctx.beginPath(); ctx.roundRect(-s / 2 - s * 0.05, -s / 2 - s * 0.05, s * 1.1, s * 1.1, s * 0.08); ctx.fill(); ctx.beginPath(); ctx.rect(-s / 2, -s / 2, s, s); ctx.clip(); const g = ctx.createLinearGradient(0, -s / 2, 0, s / 2); g.addColorStop(0, sk[0]); g.addColorStop(1, sk[1]); ctx.fillStyle = g; ctx.fillRect(-s / 2, -s / 2, s, s);
  ctx.fillStyle = seed % 4 === 2 ? '#f5f0d0' : '#ffe08a'; ctx.beginPath(); ctx.arc(-s * 0.2 + R() * s * 0.4, -s * 0.2, s * 0.09, 0, TAU); ctx.fill(); ctx.fillStyle = ['#3d6b4a', '#6b4a3d', '#2d3550', '#4a7a6a'][seed % 4]; ctx.beginPath(); ctx.moveTo(-s / 2, s / 2); ctx.lineTo(-s / 2, s * 0.15); ctx.lineTo(-s * 0.15, -s * 0.05 - R() * s * 0.1); ctx.lineTo(s * 0.1, s * 0.12); ctx.lineTo(s * 0.3, -s * 0.02); ctx.lineTo(s / 2, s * 0.18); ctx.lineTo(s / 2, s / 2); ctx.closePath(); ctx.fill(); ctx.restore(); };
 // Disco del IBM 350 visto de frente/inclinado (2D): aluminio con recubrimiento magnético, agujero central, pistas y brillo. r en px.
 P.platterFace = (ctx, cx, cy, r, t, o = {}) => { const tilt = o.tilt ?? 0.32, rot = o.rot ?? t * 0.6; ctx.save(); ctx.translate(cx, cy); ctx.scale(1, tilt); ctx.fillStyle = '#5f6b72'; ctx.beginPath(); ctx.arc(0, 18 / tilt * (o.th ?? 0.3), r, 0, TAU); ctx.fill(); const g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r); g.addColorStop(0, '#a08c78'); g.addColorStop(1, '#6f5f50'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill(); ctx.strokeStyle = '#A7B3B9'; ctx.lineWidth = r * 0.02; ctx.stroke();
  ctx.strokeStyle = 'rgba(30,22,16,0.18)'; ctx.lineWidth = 1.5; for (let k = 0; k < 14; k++) { ctx.beginPath(); ctx.arc(0, 0, r * (0.3 + k * 0.048), 0, TAU); ctx.stroke(); } ctx.strokeStyle = 'rgba(30,22,16,0.4)'; ctx.lineWidth = 3; for (let m = 0; m < 3; m++) { ctx.beginPath(); ctx.arc(0, 0, r * 0.72, rot + m * TAU / 3, rot + m * TAU / 3 + 0.3); ctx.stroke(); }
  ctx.fillStyle = 'rgba(255,240,220,0.16)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, r, -2.4, -1.9); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#3d4549'; ctx.beginPath(); ctx.arc(0, 0, r * 0.14, 0, TAU); ctx.fill(); ctx.fillStyle = '#111A21'; ctx.beginPath(); ctx.arc(0, 0, r * 0.06, 0, TAU); ctx.fill(); ctx.restore(); };
 // Superficie magnética en primer plano (macro conceptual): pistas concéntricas que pasan (rotación) con regiones magnetizadas
 // N→ / ←S como flechas didácticas. o: { speed (px/s), rows, write: { row, x (cabezal), t0 } (las regiones cambian al pasar bajo el cabezal), a }
 P.magSurface = (ctx, x, y, w, h, t, o = {}) => { const rows = o.rows || 6, rh = h / rows, cw = rh * 1.1, sp = o.speed ?? 120; ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); const g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, '#7d6b5a'); g.addColorStop(1, '#5e5044'); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  for (let r = 0; r < rows; r++) { const yy = y + r * rh, off = (t * sp * (1 - r * 0.04)) % cw; ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(x, yy + rh - 3, w, 3); const wr = o.write && o.write.row === r;
   for (let i = -1; i < w / cw + 2; i++) { const cx = x + i * cw + off, idx = Math.floor((t * sp * (1 - r * 0.04)) / cw) - i; let bit = (H.rng(idx * 7 + r * 131)() > 0.5) ? 1 : 0; if (wr && cx > o.write.x && t > o.write.t0) { bit = (H.rng(idx * 11 + 5)() > 0.45) ? 1 : 0; }
    const fresh = wr && cx > o.write.x && t > o.write.t0; ctx.fillStyle = bit ? (fresh ? 'rgba(75,212,241,0.42)' : 'rgba(75,212,241,0.18)') : (fresh ? 'rgba(255,170,90,0.42)' : 'rgba(255,170,90,0.16)'); ctx.fillRect(cx + 3, yy + 6, cw - 6, rh - 14);
    ctx.strokeStyle = bit ? '#7CE6E2' : '#ffc98a'; ctx.fillStyle = ctx.strokeStyle; ctx.lineWidth = Math.max(2, rh * 0.07); const ay = yy + rh / 2 - 3, d = bit ? 1 : -1, ax0 = cx + cw / 2 - d * cw * 0.28, ax1 = cx + cw / 2 + d * cw * 0.28; ctx.globalAlpha = o.a ?? 1; ctx.beginPath(); ctx.moveTo(ax0, ay); ctx.lineTo(ax1 - d * rh * 0.12, ay); ctx.stroke(); ctx.beginPath(); ctx.moveTo(ax1, ay); ctx.lineTo(ax1 - d * rh * 0.18, ay - rh * 0.12); ctx.lineTo(ax1 - d * rh * 0.18, ay + rh * 0.12); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1; } }
  ctx.restore(); };
 // Corte del disco: sustrato de aluminio + recubrimiento magnético de óxido de hierro con regiones magnetizadas (didáctico). Devuelve puntos para rótulos.
 P.magSection = (ctx, x, y, w, h, t, o = {}) => { const ch = h * 0.3, sy = y + ch; ctx.save(); const g = ctx.createLinearGradient(0, sy, 0, y + h); g.addColorStop(0, '#c3c9cc'); g.addColorStop(1, '#8a9397'); ctx.fillStyle = g; ctx.fillRect(x, sy, w, h - ch); ctx.strokeStyle = 'rgba(255,255,255,0.25)'; for (let k = 0; k < 6; k++) { ctx.beginPath(); ctx.moveTo(x, sy + 20 + k * (h - ch) / 6); ctx.lineTo(x + w, sy + 16 + k * (h - ch) / 6); ctx.stroke(); }
  ctx.fillStyle = '#6e4f3c'; ctx.fillRect(x, y, w, ch); const n = o.n || 10, cw = w / n, sp = o.speed ?? 0; for (let i = -1; i <= n; i++) { const xx = x + i * cw + ((t * sp) % cw), bit = H.rng(Math.floor(i - (t * sp) / cw) * 5 + 3)() > 0.5; ctx.fillStyle = bit ? 'rgba(75,212,241,0.25)' : 'rgba(255,170,90,0.22)'; ctx.fillRect(xx + 2, y + 4, cw - 4, ch - 8); ctx.strokeStyle = bit ? '#7CE6E2' : '#ffc98a'; ctx.fillStyle = ctx.strokeStyle; ctx.lineWidth = 5; const d = bit ? 1 : -1, ay = y + ch / 2, a0 = xx + cw / 2 - d * cw * 0.3, a1 = xx + cw / 2 + d * cw * 0.3; ctx.beginPath(); ctx.moveTo(a0, ay); ctx.lineTo(a1 - d * 14, ay); ctx.stroke(); ctx.beginPath(); ctx.moveTo(a1, ay); ctx.lineTo(a1 - d * 20, ay - 12); ctx.lineTo(a1 - d * 20, ay + 12); ctx.closePath(); ctx.fill(); }
  ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 3; ctx.strokeRect(x, y, w, h); ctx.beginPath(); ctx.moveTo(x, sy); ctx.lineTo(x + w, sy); ctx.stroke(); ctx.restore(); return { coat: [x + w, y + ch / 2], sub: [x + w, sy + (h - ch) / 2] };
 };
 // Cabezal de lectura/escritura sobre una pista (vista lateral didáctica): el disco pasa por debajo (de izquierda a derecha según
 // la rotación), la cabeza FLOTA sobre un colchón de aire (hueco visible, nunca toca). mode 'write' (las regiones cambian al salir del
 // cabezal) | 'read' (los cambios generan una señal eléctrica que se convierte en bits). Devuelve la posición del cabezal.
 P.headTrack = (ctx, x, y, w, h, t, o = {}) => { const mode = o.mode || 'write', hx = x + w * 0.5, sy = y + h * 0.55, ch = h * 0.16, cw = ch * 1.3, sp = o.speed ?? 140, a = o.a ?? 1; ctx.save(); ctx.globalAlpha *= a;
  ctx.fillStyle = '#c3c9cc'; ctx.fillRect(x, sy + ch, w, h * 0.16); ctx.fillStyle = '#6e4f3c'; ctx.fillRect(x, sy, w, ch);
  for (let i = -1; i < w / cw + 2; i++) { const off = (t * sp) % cw, xx = x + i * cw + off, idx = Math.floor((t * sp) / cw) - i, old = H.rng(idx * 7 + 1)() > 0.5, nw = H.rng(idx * 13 + 9)() > 0.5, bit = mode === 'write' && xx + cw / 2 > hx ? nw : (mode === 'read' ? nw : old);
   ctx.fillStyle = bit ? 'rgba(75,212,241,0.3)' : 'rgba(255,170,90,0.28)'; ctx.fillRect(xx + 2, sy + 3, cw - 4, ch - 6); ctx.strokeStyle = bit ? '#7CE6E2' : '#ffc98a'; ctx.fillStyle = ctx.strokeStyle; ctx.lineWidth = 4; const d = bit ? 1 : -1, ay = sy + ch / 2, a0 = xx + cw / 2 - d * cw * 0.3, a1 = xx + cw / 2 + d * cw * 0.3; ctx.beginPath(); ctx.moveTo(a0, ay); ctx.lineTo(a1 - d * 10, ay); ctx.stroke(); ctx.beginPath(); ctx.moveTo(a1, ay); ctx.lineTo(a1 - d * 15, ay - 9); ctx.lineTo(a1 - d * 15, ay + 9); ctx.closePath(); ctx.fill(); }
  // brazo y cabeza (con bobina) separados por el colchón de aire
  const gap = ch * 0.35, hy = sy - gap; ctx.fillStyle = '#D1C6B4'; ctx.fillRect(hx - w * 0.6, hy - h * 0.2, w * 0.6 - cw * 0.3, h * 0.07); ctx.fillStyle = '#2e2a26'; ctx.beginPath(); ctx.moveTo(hx - cw * 0.5, hy - h * 0.2); ctx.lineTo(hx + cw * 0.5, hy - h * 0.2); ctx.lineTo(hx + cw * 0.35, hy); ctx.lineTo(hx - cw * 0.35, hy); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#d8a85a'; ctx.lineWidth = 3; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.ellipse(hx, hy - h * 0.16 + k * h * 0.026, cw * 0.32, h * 0.01, 0, 0, TAU); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(245,247,248,0.5)'; ctx.setLineDash([6, 6]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hx - cw, hy + gap * 0.5); ctx.lineTo(hx + cw, hy + gap * 0.5); ctx.stroke(); ctx.setLineDash([]);
  if (mode === 'write') { ctx.strokeStyle = 'rgba(255,212,71,0.8)'; ctx.lineWidth = 3; for (let k = 0; k < 3; k++) { const r = ((t * 2 + k / 3) % 1) * ch * 0.9; ctx.globalAlpha = a * (1 - ((t * 2 + k / 3) % 1)); ctx.beginPath(); ctx.ellipse(hx, sy, cw * 0.4 + r, r * 0.6, 0, Math.PI, TAU); ctx.stroke(); } ctx.globalAlpha = a; }
  if (mode === 'read') { const by = y + h * 0.12, bx0 = x + w * 0.08, bx1 = x + w * 0.92; ctx.strokeStyle = '#4BD4F1'; ctx.lineWidth = 4; ctx.beginPath(); for (let px = bx0; px <= bx1; px += 3) { const s = (px - bx0) / (bx1 - bx0), idx = Math.floor((t * sp + (hx - (bx0 + s * (bx1 - bx0))) * 0) / cw); const ph = ((t * sp) + (px - bx0)) / cw, k = Math.floor(ph), fr = ph - k, b1 = H.rng(k * 13 + 9)() > 0.5, b0 = H.rng((k - 1) * 13 + 9)() > 0.5, pulse = b1 !== b0 ? Math.exp(-Math.pow((fr - 0.0) * 8, 2)) * (b1 ? 1 : -1) : 0; const yy = by + h * 0.05 - pulse * h * 0.05; px === bx0 ? ctx.moveTo(px, yy) : ctx.lineTo(px, yy); } ctx.stroke(); ctx.strokeStyle = 'rgba(75,212,241,0.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hx, hy - h * 0.2); ctx.lineTo(hx, by + h * 0.1); ctx.stroke(); }
  ctx.restore(); return { head: [hx, hy], track: [hx, sy + ch / 2] };
 };
 // Barras comparativas de capacidad (escala lineal): items [{ label, mb, col }]; max en MB. u 0..1 anima el crecimiento.
 P.capBars = (ctx, x, y, w, items, max, u, o = {}) => { const bh = o.bh || 70, gap = o.gap || 40; items.forEach((it, i) => { const yy = y + i * (bh + gap), L = w * cl(it.mb / max) * E.out(cl(u * 1.2 - i * 0.2)); ctx.fillStyle = 'rgba(245,247,248,0.08)'; ctx.beginPath(); ctx.roundRect(x, yy, w, bh, 12); ctx.fill(); ctx.fillStyle = it.col || '#4BD4F1'; ctx.beginPath(); ctx.roundRect(x, yy, Math.max(12, L), bh, 12); ctx.fill(); ctx.font = '800 36px Nunito'; ctx.fillStyle = '#F5F7F8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(it.label, x + 18, yy - 30); }); };
 // Disco duro moderno de 3,5" ABIERTO, vista superior (genérico): carcasa, plato, eje, brazo PIVOTANTE con cabeza, imán del actuador.
 // s = px por mm (la unidad mide 101,6 × 147 mm). o: { rot, arm (rad del brazo), cover 0..1 (tapa), plate 0..1 (opacidad del plato) }
 P.hdd35 = (ctx, cx, cy, s, t, o = {}) => { const w = 101.6 * s, h = 147 * s; ctx.save(); ctx.translate(cx, cy); if (o.angle) ctx.rotate(o.angle); ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 20 * s; ctx.shadowOffsetY = 6 * s; ctx.fillStyle = '#7f8a90'; ctx.beginPath(); ctx.roundRect(-w / 2, -h / 2, w, h, 4 * s); ctx.fill(); ctx.shadowColor = 'transparent'; ctx.fillStyle = '#9aa5ab'; ctx.beginPath(); ctx.roundRect(-w / 2 + 3 * s, -h / 2 + 3 * s, w - 6 * s, h - 6 * s, 3 * s); ctx.fill();
  const pc = [0, -h / 2 + 52 * s], pr = 47.5 * s; if ((o.plate ?? 1) > 0) { ctx.save(); ctx.globalAlpha *= o.plate ?? 1; const g = ctx.createRadialGradient(pc[0] - pr * 0.4, pc[1] - pr * 0.4, pr * 0.1, pc[0], pc[1], pr); g.addColorStop(0, '#e9eef1'); g.addColorStop(0.6, '#b8c3c9'); g.addColorStop(1, '#8e9aa1'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(pc[0], pc[1], pr, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.moveTo(pc[0], pc[1]); ctx.arc(pc[0], pc[1], pr, -2.5, -2.0); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(pc[0], pc[1]); ctx.arc(pc[0], pc[1], pr, 0.65, 1.15); ctx.closePath(); ctx.fill(); const rr = o.rot ?? t * 3; ctx.strokeStyle = 'rgba(40,50,56,0.25)'; ctx.lineWidth = 1.5 * s; ctx.beginPath(); ctx.arc(pc[0], pc[1], pr * 0.7, rr, rr + 0.4); ctx.stroke(); ctx.restore(); }
  ctx.fillStyle = '#5c666b'; ctx.beginPath(); ctx.arc(pc[0], pc[1], 13 * s, 0, TAU); ctx.fill(); ctx.fillStyle = '#c5ccd0'; for (let k = 0; k < 6; k++) { const q = k * TAU / 6; ctx.beginPath(); ctx.arc(pc[0] + Math.cos(q) * 8 * s, pc[1] + Math.sin(q) * 8 * s, 1.4 * s, 0, TAU); ctx.fill(); }
  const pv = [w / 2 - 20 * s, h / 2 - 40 * s]; ctx.fillStyle = '#3d4549'; ctx.beginPath(); ctx.moveTo(pv[0] - 18 * s, pv[1] + 6 * s); ctx.quadraticCurveTo(pv[0] + 4 * s, pv[1] + 36 * s, pv[0] + 18 * s, pv[1] + 6 * s); ctx.lineTo(pv[0] + 10 * s, pv[1] + 24 * s); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#6b757a'; ctx.beginPath(); ctx.ellipse(pv[0], pv[1] + 20 * s, 22 * s, 14 * s, 0, 0, TAU); ctx.fill();
  const arm = o.arm ?? 0.18 * Math.sin(t * 1.3); ctx.save(); ctx.translate(pv[0], pv[1]); ctx.rotate(Math.atan2(pc[1] - pv[1], pc[0] - pv[0]) - Math.PI / 2 + 0.32 + arm); ctx.fillStyle = '#c9ced1'; ctx.beginPath(); ctx.moveTo(-4 * s, 0); ctx.lineTo(-2.2 * s, 50 * s); ctx.lineTo(2.2 * s, 50 * s); ctx.lineTo(4 * s, 0); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#2e2a26'; ctx.fillRect(-2 * s, 48 * s, 4 * s, 5 * s); ctx.restore(); ctx.fillStyle = '#d9dcde'; ctx.beginPath(); ctx.arc(pv[0], pv[1], 6 * s, 0, TAU); ctx.fill();
  if (o.cover) { ctx.globalAlpha = o.cover; ctx.fillStyle = '#a9b3b8'; ctx.beginPath(); ctx.roundRect(-w / 2, -h / 2, w, h, 4 * s); ctx.fill(); ctx.globalAlpha = 1; }
  ctx.restore(); return { platter: [cx + pc[0], cy + pc[1]], pr, w, h, pivot: [cx + pv[0], cy + pv[1]] };
 };
 // Unidades cerradas para la línea de evolución (genéricas, sin marca): kind '1970' (armario de discos removibles, ≈ 100 cm de alto),
 // '525' (5,25" de PC, 146 × 203 mm), '35' (3,5": 102 × 147 mm), '25' (2,5" de portátil: 70 × 100 mm). s = px por mm.
 P.driveBox = (ctx, cx, baseY, s, kind, t, o = {}) => { ctx.save(); const dims = { '1970': [760, 1000], '525': [146, 41], '35': [101.6, 26.1], '25': [69.9, 9.5] }, [w0, h0] = dims[kind], w = w0 * s, h = h0 * s;
  if (kind === '1970') { ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(cx - w / 2 - 10 * s, baseY - 4 * s, w + 20 * s, 8 * s); ctx.fillStyle = '#b9b3a4'; ctx.fillRect(cx - w / 2, baseY - h, w, h); ctx.fillStyle = '#8d877a'; ctx.fillRect(cx - w / 2, baseY - h, w, h * 0.08); ctx.fillStyle = '#2e3336'; ctx.fillRect(cx - w * 0.38, baseY - h * 0.9, w * 0.76, h * 0.07); ctx.fillStyle = 'rgba(120,150,160,0.35)'; ctx.fillRect(cx - w * 0.38, baseY - h * 0.8, w * 0.76, h * 0.32); const pc = baseY - h * 0.64; for (let k = 0; k < 6; k++) { ctx.fillStyle = '#7d6b5a'; ctx.fillRect(cx - w * 0.3, pc + k * h * 0.035, w * 0.6, h * 0.01); } ctx.fillStyle = '#e86a4a'; ctx.beginPath(); ctx.arc(cx + w * 0.3, baseY - h * 0.86, 8 * s, 0, TAU); ctx.fill(); }
  else { const ang = 0.5, dpt = (kind === '525' ? 203 : kind === '35' ? 147 : 100) * s * 0.35; ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx + dpt * 0.4, baseY, w * 0.6 + dpt * 0.5, h * 0.3 + 6, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#6f7a80'; ctx.beginPath(); ctx.moveTo(cx - w / 2, baseY - h); ctx.lineTo(cx - w / 2 + dpt, baseY - h - dpt * ang); ctx.lineTo(cx + w / 2 + dpt, baseY - h - dpt * ang); ctx.lineTo(cx + w / 2, baseY - h); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#8b969c'; ctx.fillRect(cx - w / 2, baseY - h, w, h); ctx.fillStyle = '#566065'; ctx.beginPath(); ctx.moveTo(cx + w / 2, baseY); ctx.lineTo(cx + w / 2 + dpt, baseY - dpt * ang); ctx.lineTo(cx + w / 2 + dpt, baseY - h - dpt * ang); ctx.lineTo(cx + w / 2, baseY - h); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#2f5a3a'; ctx.fillRect(cx - w * 0.4, baseY - h * 0.35, w * 0.8, h * 0.2); }
  ctx.restore(); return { w, h, top: [cx, baseY - h] };
 };
 // Chip de memoria flash sobre placa (genérico): encapsulado negro con patas, placa verde con pistas. s = px por mm (chip 12 × 18 mm).
 // o: { die 0..1 (abre el encapsulado y muestra la matriz de celdas), glow }
 P.flashChip = (ctx, cx, cy, s, t, o = {}) => { const w = 12 * s, h = 18 * s; ctx.save(); ctx.fillStyle = '#123d2e'; ctx.fillRect(cx - w * 1.6, cy - h * 1.1, w * 3.2, h * 2.2); ctx.strokeStyle = 'rgba(214,180,90,0.5)'; ctx.lineWidth = Math.max(1, s * 0.25); for (let k = 0; k < 10; k++) { const yy = cy - h * 0.9 + k * h * 0.2; ctx.beginPath(); ctx.moveTo(cx - w * 1.6, yy); ctx.lineTo(cx - w * 0.7, yy); ctx.moveTo(cx + w * 0.7, yy); ctx.lineTo(cx + w * 1.6, yy + (k % 3 - 1) * s * 2); ctx.stroke(); }
  ctx.fillStyle = '#c8cdd0'; for (let k = 0; k < 12; k++) { const yy = cy - h * 0.44 + k * h * 0.08; ctx.fillRect(cx - w / 2 - s * 1.4, yy, s * 1.6, s * 0.6); ctx.fillRect(cx + w / 2 - s * 0.2, yy, s * 1.6, s * 0.6); }
  ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = s * 2; ctx.fillStyle = '#1b1e22'; ctx.beginPath(); ctx.roundRect(cx - w / 2, cy - h / 2, w, h, s * 0.6); ctx.fill(); ctx.shadowColor = 'transparent'; ctx.fillStyle = '#2a2e33'; ctx.beginPath(); ctx.arc(cx - w * 0.32, cy - h * 0.4, s * 0.8, 0, TAU); ctx.fill();
  const d = cl(o.die || 0); if (d > 0) { ctx.globalAlpha = d; ctx.fillStyle = '#2b3946'; ctx.fillRect(cx - w * 0.38, cy - h * 0.35, w * 0.76, h * 0.7); const n = 8, m = 12; for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) { const on = H.rng(i * 31 + j * 7 + Math.floor(t * 2))() > 0.5; ctx.fillStyle = on ? '#4BD4F1' : '#1d5f8a'; ctx.fillRect(cx - w * 0.34 + i * w * 0.68 / n, cy - h * 0.31 + j * h * 0.62 / m, w * 0.68 / n - s * 0.2, h * 0.62 / m - s * 0.2); } ctx.globalAlpha = 1; }
  if (o.glow) { ctx.globalAlpha = o.glow; ctx.strokeStyle = '#4BD4F1'; ctx.lineWidth = Math.max(2, s * 0.3); ctx.shadowColor = '#4BD4F1'; ctx.shadowBlur = s * 3; ctx.beginPath(); ctx.roundRect(cx - w / 2, cy - h / 2, w, h, s * 0.6); ctx.stroke(); }
  ctx.restore(); return { w, h };
 };
 // Celdas de memoria flash (conceptual): rejilla de celdas con puerta flotante que retiene o no electrones (carga = 0/1).
 // Sin piezas móviles ni platos. o: { cols, rows, prog 0..1 (programación de celdas), sel (celda resaltada) }
 P.flashCells = (ctx, x, y, w, h, t, o = {}) => { const C = o.cols || 4, Rw = o.rows || 3, cw = w / C, ch = h / Rw; ctx.save(); ctx.fillStyle = '#0f1d2e'; ctx.fillRect(x, y, w, h);
  for (let i = 0; i < C; i++) for (let j = 0; j < Rw; j++) { const cx = x + i * cw + cw / 2, cy = y + j * ch + ch / 2, k = i + j * C, on = H.rng(k * 17 + 3)() > 0.45, pr = cl((o.prog ?? 1) * C * Rw - k), bw = cw * 0.7, bh = ch * 0.62;
   ctx.fillStyle = '#1b2f45'; ctx.beginPath(); ctx.roundRect(cx - bw / 2, cy - bh / 2, bw, bh, 10); ctx.fill(); ctx.fillStyle = '#5f6b72'; ctx.fillRect(cx - bw * 0.4, cy - bh * 0.4, bw * 0.8, bh * 0.14); ctx.fillStyle = '#2f5d86'; ctx.fillRect(cx - bw * 0.4, cy - bh * 0.18, bw * 0.8, bh * 0.2); ctx.fillStyle = '#3a4a3a'; ctx.fillRect(cx - bw * 0.45, cy + bh * 0.2, bw * 0.9, bh * 0.16);
   if (on && pr > 0) { ctx.fillStyle = '#FFD447'; for (let e = 0; e < 5; e++) { const ex = cx - bw * 0.32 + e * bw * 0.16, ey = cy - bh * 0.08 + Math.sin(t * 3 + e + k) * 2 + (1 - pr) * bh * 0.4; ctx.beginPath(); ctx.arc(ex, ey, Math.max(3, bw * 0.035), 0, TAU); ctx.fill(); } }
   ctx.font = `800 ${Math.max(32, ch * 0.2) | 0}px "IBM Plex Mono"`; ctx.fillStyle = on && pr > 0.5 ? '#FFD447' : '#7CE6E2'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(on && pr > 0.5 ? '0' : '1', cx, cy + bh * 0.62); }
  ctx.restore(); };
 // Disquete de 3,5" (90 × 94 mm): carcasa, persiana metálica, etiqueta, muesca de protección. s = px por mm. o: { rot, shutter 0..1 }
 P.floppy35 = (ctx, cx, cy, s, o = {}) => { const w = 90 * s, h = 94 * s; ctx.save(); ctx.translate(cx, cy); if (o.rot) ctx.rotate(o.rot); ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 8 * s; ctx.shadowOffsetY = 3 * s; ctx.fillStyle = o.col || '#2b2f36'; ctx.beginPath(); ctx.moveTo(-w / 2, -h / 2); ctx.lineTo(w / 2 - 4 * s, -h / 2); ctx.lineTo(w / 2, -h / 2 + 4 * s); ctx.lineTo(w / 2, h / 2); ctx.lineTo(-w / 2, h / 2); ctx.closePath(); ctx.fill(); ctx.shadowColor = 'transparent';
  const sh = (o.shutter ?? 0) * 18 * s; ctx.fillStyle = '#1b1e22'; ctx.fillRect(-12 * s, -h / 2 + 4 * s, 18 * s, 26 * s); ctx.fillStyle = '#7d6b5a'; ctx.fillRect(-9 * s, -h / 2 + 6 * s, 12 * s, 22 * s); const g = ctx.createLinearGradient(-26 * s, 0, 26 * s, 0); g.addColorStop(0, '#9aa3a8'); g.addColorStop(0.5, '#dfe4e6'); g.addColorStop(1, '#9aa3a8'); ctx.fillStyle = g; ctx.fillRect(-26 * s + sh, -h / 2, 50 * s, 32 * s); ctx.fillStyle = '#1b1e22'; ctx.fillRect(-12 * s + sh, -h / 2 + 4 * s, 9 * s, 22 * s);
  ctx.fillStyle = '#ece7da'; ctx.beginPath(); ctx.roundRect(-36 * s, -6 * s, 72 * s, 46 * s, 2 * s); ctx.fill(); ctx.strokeStyle = 'rgba(80,80,80,0.35)'; ctx.lineWidth = Math.max(1, s * 0.4); for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(-30 * s, 6 * s + k * 8 * s); ctx.lineTo(30 * s, 6 * s + k * 8 * s); ctx.stroke(); }
  ctx.fillStyle = '#16181c'; ctx.fillRect(-w / 2 + 4 * s, h / 2 - 10 * s, 5 * s, 6 * s); ctx.restore(); return { w, h };
 };
 // Regla graduada (cm) para comparar tamaños: L = largo en cm, s = px por cm.
 P.rulerCm = (ctx, x, y, L, s, o = {}) => { ctx.save(); ctx.fillStyle = o.col || '#D8AD72'; ctx.beginPath(); ctx.roundRect(x, y, L * s, Math.max(36, 4 * s), 6); ctx.fill(); ctx.strokeStyle = '#3a2c1c'; ctx.fillStyle = '#3a2c1c'; ctx.lineWidth = 2; ctx.font = '700 32px Nunito'; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; for (let c = 0; c <= L; c++) { const xx = x + c * s, big = c % 10 === 0; ctx.beginPath(); ctx.moveTo(xx, y); ctx.lineTo(xx, y + (big ? 22 : c % 5 === 0 ? 15 : 9)); ctx.stroke(); if (big && c > 0 && c < L) ctx.fillText(String(c), xx, y + 2 + Math.max(36, 4 * s) * 0.45); } ctx.restore(); };
 // ---------------- v1.19.1 · fotografías documentales, escritura/lectura y celda flash ----------------
 // Tarjeta documental para una FOTOGRAFÍA REAL (v1.19.1): esquinas redondeadas, marco fino, sombra moderada, entrada 96 % → 100 % con
 // desplazamiento sutil, acercamiento lento dentro del marco (o.zoom), rótulo superior (o.tag), pie (o.label) y crédito (o.credit, ≥ 32 px).
 // Proporción original conservada y sin alterar el contenido. Devuelve el rectángulo de la imagen.
 P.photoCard = (ctx, img, cx, cy, maxW, maxH, t, t0, t1, o = {}) => { if (!img || !img.width || t < t0 - 0.01 || t > t1 + 0.01) return null; const ia = img.width / img.height; let w = maxW, h = w / ia; if (h > maxH) { h = maxH; w = h * ia; }
  const a = sm(t0, t0 + 0.55, t) * (1 - sm(t1 - 0.5, t1, t)), e = E.out(sm(t0, t0 + 0.8, t)), s = 0.96 + 0.04 * e, dy = (1 - e) * 22; if (a <= 0) return null; const r = o.radius ?? 22;
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(cx, cy + dy); ctx.scale(s, s);
  ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 36; ctx.shadowOffsetY = 16; ctx.fillStyle = 'rgba(245,247,248,0.92)'; ctx.beginPath(); ctx.roundRect(-w / 2 - 5, -h / 2 - 5, w + 10, h + 10, r + 4); ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.save(); ctx.beginPath(); ctx.roundRect(-w / 2, -h / 2, w, h, r); ctx.clip(); const zm = o.zoom || [0.5, 0.5, 1, 0.5, 0.5, 1.05], u = E.inOut(win(t, t0, t1)), zx = lerp(zm[0], zm[3], u), zy = lerp(zm[1], zm[4], u), zz = lerp(zm[2], zm[5], u), dw = w * zz, dh = h * zz; ctx.drawImage(img, -w / 2 - (dw - w) * zx, -h / 2 - (dh - h) * zy, dw, dh); ctx.restore();
  ctx.font = '700 32px "IBM Plex Mono"'; const tg = o.tag || 'FOTOGRAFÍA REAL', tw = ctx.measureText(tg).width; ctx.fillStyle = 'rgba(11,20,36,0.92)'; ctx.beginPath(); ctx.roundRect(-w / 2 + 18, -h / 2 - 26, tw + 32, 50, 12); ctx.fill(); ctx.fillStyle = '#FFD447'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(tg, -w / 2 + 34, -h / 2 - 1);
  let yy = h / 2 + 22; if (o.label) { ctx.font = '800 38px Nunito'; const lw = ctx.measureText(o.label).width; ctx.fillStyle = 'rgba(11,20,36,0.92)'; ctx.beginPath(); ctx.roundRect(-lw / 2 - 22, yy, lw + 44, 60, 30); ctx.fill(); ctx.fillStyle = '#F5F7F8'; ctx.textAlign = 'center'; ctx.fillText(o.label, 0, yy + 31); yy += 68; }
  if (o.credit) { ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(217,233,240,0.85)'; ctx.textAlign = 'center'; ctx.fillText(o.credit, 0, yy + 22); }
  ctx.restore(); return { x: cx - w / 2, y: cy - h / 2, w, h };
 };
 // Pista magnética GRANDE para explicar escribir y leer (v1.19.1). Regiones del recubrimiento como bloques imantados (azul → / naranja ←)
 // que pasan bajo la cabeza (el disco gira hacia la derecha). La cabeza flota sobre un hueco de aire visible.
 //  · mode 'write': la cabeza de escritura (núcleo en C con bobina) cambia la magnetización de cada región al pasar; lo no escrito se ve tenue.
 //  · mode 'read': la cabeza de lectura detecta los CAMBIOS entre regiones → pulsos de señal eléctrica → bits (cambio = 1, sin cambio = 0;
 //    codificación simplificada para divulgación).
 // o: { mode, speed (px/s), bw (ancho de región) }. Devuelve { head, track, signalY, bitsY }.
 P.magTrack = (ctx, x, y, w, h, t, o = {}) => { const mode = o.mode || 'write', sp = o.speed ?? 110, bw = o.bw || h * 0.2, hx = x + w * 0.42, ty = y + h * 0.56, th = h * 0.2, gap = h * 0.045, sigY = y + h * 0.13, bitY = y + h * 0.93;
  const nb = (m) => H.rng(m * 13 + 9)() > 0.5, ob = (m) => H.rng(m * 7 + 1)() > 0.5, X = (m) => x + m * bw + t * sp, m0 = Math.floor(-t * sp / bw) - 1, m1 = m0 + Math.ceil(w / bw) + 3;
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.fillStyle = '#c3c9cc'; ctx.fillRect(x, ty + th, w, h * 0.09); ctx.fillStyle = '#5a4434'; ctx.fillRect(x, ty, w, th);
  for (let m = m0; m <= m1; m++) { const xx = X(m), c = xx + bw / 2, written = mode === 'read' || c > hx, bit = written ? nb(m) : ob(m), al = written ? 1 : 0.32;
   ctx.globalAlpha = al; ctx.fillStyle = bit ? '#1f6f8f' : '#a0582c'; ctx.fillRect(xx + 3, ty + 4, bw - 6, th - 8); ctx.fillStyle = bit ? '#4BD4F1' : '#ff9f5a'; const d = bit ? 1 : -1, ay = ty + th / 2, a0 = c - d * bw * 0.32, a1 = c + d * bw * 0.32, aw = th * 0.16; ctx.beginPath(); ctx.moveTo(a0, ay - aw / 2); ctx.lineTo(a1 - d * aw * 1.6, ay - aw / 2); ctx.lineTo(a1 - d * aw * 1.6, ay - aw * 1.25); ctx.lineTo(a1, ay); ctx.lineTo(a1 - d * aw * 1.6, ay + aw * 1.25); ctx.lineTo(a1 - d * aw * 1.6, ay + aw / 2); ctx.lineTo(a0, ay + aw / 2); ctx.closePath(); ctx.fill();
   ctx.globalAlpha = 1; }
  // cabeza: núcleo en C con bobina; el hueco queda a «gap» sobre la pista (no la toca)
  const hb = ty - gap, hw = bw * 0.9, hh2 = h * 0.26; ctx.fillStyle = '#D1C6B4'; ctx.fillRect(x - 10, hb - hh2 - h * 0.05, hx - x - hw * 0.4, h * 0.04); ctx.fillStyle = '#3a3f44'; ctx.beginPath(); ctx.moveTo(hx - hw / 2, hb); ctx.lineTo(hx - hw / 2, hb - hh2); ctx.lineTo(hx + hw / 2, hb - hh2); ctx.lineTo(hx + hw / 2, hb); ctx.lineTo(hx + hw * 0.08, hb); ctx.lineTo(hx + hw * 0.08, hb - hh2 * 0.62); ctx.lineTo(hx - hw * 0.08, hb - hh2 * 0.62); ctx.lineTo(hx - hw * 0.08, hb); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#d8a85a'; ctx.lineWidth = Math.max(3, h * 0.008); for (let k = 0; k < 6; k++) { const yy = hb - hh2 * 0.92 + k * hh2 * 0.07; ctx.beginPath(); ctx.ellipse(hx - hw * 0.5, yy, hw * 0.14, hh2 * 0.025, 0, 0, TAU); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(245,247,248,0.7)'; ctx.setLineDash([8, 8]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hx - hw, ty - gap / 2); ctx.lineTo(hx + hw, ty - gap / 2); ctx.stroke(); ctx.setLineDash([]);
  const mU = Math.floor((hx - x - t * sp) / bw), cur = nb(mU);
  if (mode === 'write') { ctx.strokeStyle = 'rgba(255,212,71,0.85)'; ctx.lineWidth = 3; for (let k = 0; k < 3; k++) { const q = (t * 1.6 + k / 3) % 1; ctx.globalAlpha = 1 - q; ctx.beginPath(); ctx.ellipse(hx, ty + th * 0.15, hw * 0.12 + q * hw * 0.45, th * (0.15 + q * 0.4), 0, Math.PI, TAU); ctx.stroke(); } ctx.globalAlpha = 1; ctx.fillStyle = cur ? '#4BD4F1' : '#ff9f5a'; ctx.font = `900 ${Math.round(h * 0.06)}px Nunito`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(cur ? '→' : '←', hx - hw * 0.5, hb - hh2 - h * 0.075); }
  else { const base = sigY; ctx.strokeStyle = 'rgba(245,247,248,0.25)'; ctx.lineWidth = 2; ctx.setLineDash([6, 8]); ctx.beginPath(); ctx.moveTo(x, base); ctx.lineTo(hx, base); ctx.stroke(); ctx.setLineDash([]); ctx.strokeStyle = '#4BD4F1'; ctx.lineWidth = Math.max(4, h * 0.008); ctx.beginPath(); for (let px = hx; px <= x + w; px += 3) { let v = 0; for (let m = m0; m <= m1; m++) { const bx = X(m); if (nb(m) !== nb(m - 1)) v += (nb(m) ? 1 : -1) * Math.exp(-Math.pow((px - bx) / (bw * 0.09), 2)); } const yy = base - v * h * 0.075; px === hx ? ctx.moveTo(px, yy) : ctx.lineTo(px, yy); } ctx.stroke();
   ctx.strokeStyle = 'rgba(75,212,241,0.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hx, hb - hh2); ctx.lineTo(hx, base + h * 0.09); ctx.stroke();
   ctx.font = `800 ${Math.max(32, Math.round(h * 0.07))}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; for (let m = m0; m <= m1; m++) { const bx = X(m); if (bx < hx || bx > x + w) continue; const one = nb(m) !== nb(m - 1); ctx.fillStyle = one ? '#FFD447' : '#7CE6E2'; ctx.fillText(one ? '1' : '0', bx, bitY); } }
  ctx.restore(); return { head: [hx, hb - hh2], track: [hx, ty + th / 2], signalY: sigY, bitsY: bitY };
 };
 // Celda de memoria flash en corte (v1.19.1): transistor de puerta flotante. Sustrato, fuente y drenador, óxido túnel, PUERTA FLOTANTE
 // (con electrones atrapados según o.charge 0..1), óxido y PUERTA DE CONTROL. Sin carga → el canal conduce; con carga → no conduce.
 // Devuelve puntos para rótulos { cg, fg, ch, src, drn }.
 P.flashCell = (ctx, x, y, w, h, t, o = {}) => { const q = cl(o.charge ?? 0), cx = x + w / 2; ctx.save(); ctx.fillStyle = '#2b3a4a'; ctx.fillRect(x, y + h * 0.55, w, h * 0.45); ctx.fillStyle = '#3f6e8f'; ctx.beginPath(); ctx.roundRect(x + w * 0.04, y + h * 0.55, w * 0.24, h * 0.18, 10); ctx.fill(); ctx.beginPath(); ctx.roundRect(x + w * 0.72, y + h * 0.55, w * 0.24, h * 0.18, 10); ctx.fill();
  const on = 1 - q; if (on > 0.05) { ctx.fillStyle = `rgba(75,212,241,${0.55 * on})`; ctx.fillRect(x + w * 0.26, y + h * 0.555, w * 0.48, h * 0.035); for (let k = 0; k < 6; k++) { const ex = x + w * 0.27 + ((t * 0.5 + k / 6) % 1) * w * 0.46; ctx.fillStyle = `rgba(124,230,226,${on})`; ctx.beginPath(); ctx.arc(ex, y + h * 0.572, Math.max(3, h * 0.012), 0, TAU); ctx.fill(); } }
  ctx.fillStyle = '#8fa0aa'; ctx.fillRect(x + w * 0.26, y + h * 0.52, w * 0.48, h * 0.03); ctx.fillStyle = '#1d2a36'; ctx.beginPath(); ctx.roundRect(x + w * 0.27, y + h * 0.36, w * 0.46, h * 0.16, 8); ctx.fill(); ctx.strokeStyle = '#4BD4F1'; ctx.lineWidth = 3; ctx.stroke();
  const ne = Math.round(q * 10); for (let k = 0; k < ne; k++) { const ex = x + w * 0.31 + (k % 5) * w * 0.095, ey = y + h * (0.405 + Math.floor(k / 5) * 0.065) + Math.sin(t * 3 + k) * 2; ctx.fillStyle = '#FFD447'; ctx.beginPath(); ctx.arc(ex, ey, Math.max(5, h * 0.018), 0, TAU); ctx.fill(); ctx.fillStyle = '#0B1424'; ctx.fillRect(ex - Math.max(3, h * 0.01), ey - 1, Math.max(6, h * 0.02), 2); }
  ctx.fillStyle = '#8fa0aa'; ctx.fillRect(x + w * 0.27, y + h * 0.33, w * 0.46, h * 0.03); ctx.fillStyle = '#9aa6ad'; ctx.beginPath(); ctx.roundRect(x + w * 0.25, y + h * 0.16, w * 0.5, h * 0.17, 8); ctx.fill(); ctx.fillStyle = '#c8cdd0'; ctx.fillRect(cx - w * 0.02, y, w * 0.04, h * 0.16); ctx.fillRect(x + w * 0.15, y + h * 0.38, w * 0.03, h * 0.17); ctx.fillRect(x + w * 0.82, y + h * 0.38, w * 0.03, h * 0.17);
  ctx.restore(); return { cg: [x + w * 0.75, y + h * 0.245], fg: [x + w * 0.73, y + h * 0.44], ch: [cx, y + h * 0.6], src: [x + w * 0.16, y + h * 0.64], drn: [x + w * 0.84, y + h * 0.64] };
 };
 // ---------------- v1.20 · módulo YAKHCHAL (arquitectura pasiva del desierto: congelar en invierno, conservar hasta el verano) ----------------
 // MODELO MAESTRO ÚNICO en decímetros (dm). Ejes: x = ESTE, z = SUR, y = arriba. La cúpula está en el origen con la entrada al SUR;
 // el camino lleva al estanque, que queda AL NORTE del muro de sombra (muro al sur, orientado ESTE–OESTE); el canal llega desde el
 // OESTE. Proporciones aproximadas (reconstrucción didáctica, sin planos de un yakhchal concreto). Todas las vistas (3D, sección,
 // pruebas automáticas) leen YK, de modo que nada cambia de tamaño ni de lugar entre planos.
 const YK = { R0: 100, H: 175, n: 11, wall0: 20, wall1: 7, pitR: 72, pitD: 60, entW: 16, entH: 24,
  pond: { x0: -300, x1: 300, z0: 190, z1: 300, d: 1 }, swall: { x0: -380, x1: 380, z0: 318, z1: 334, h: 120 }, path: { w: 22, z0: 100, z1: 190 }, canal: { x0: -700, x1: -300, z: 245, w: 14 } };
 P.YK = YK;
 // radio exterior escalonado a la altura y (banda j) y radio interior (pared que se adelgaza hacia arriba)
 P.ykR = (y) => { const j = Math.min(YK.n - 1, Math.max(0, Math.floor((y / YK.H) * YK.n))); return YK.R0 * (1 - 0.86 * Math.pow(j / YK.n, 1.05)); };
 P.ykWall = (y) => lerp(YK.wall0, YK.wall1, cl(y / YK.H));
 P.ykRin = (y) => Math.max(0, P.ykR(y) - P.ykWall(y) - (y > YK.H * 0.86 ? (y - YK.H * 0.86) * 2.2 : 0));
 // vector unitario hacia el sol: elevación (grados) y acimut desde el NORTE hacia el ESTE (180 = sur)
 P.ykSun = (elev, az = 180) => { const e = elev * Math.PI / 180, a = az * Math.PI / 180; return [Math.sin(a) * Math.cos(e), Math.sin(e), -Math.cos(a) * Math.cos(e)]; };
 // sombra de un punto sobre el suelo (y = 0) según el sol
 P.ykShadow = (p, sun) => { const k = p[1] / Math.max(0.05, sun[1]); return [p[0] - sun[0] * k, 0, p[2] - sun[2] * k]; };
 const ykShade = (hex, n, sun, amb = 0.55, night = 0) => { const d = Math.max(0, n[0] * sun[0] + n[1] * sun[1] + n[2] * sun[2]), k = (amb + (1 - amb) * d) * (1 - 0.55 * night), [r, g, b] = H.hex(hex), nb = night * 0.35; return `rgb(${cl(r * k * (1 - nb) + 20 * nb, 0, 255) | 0},${cl(g * k * (1 - nb * 0.6) + 30 * nb, 0, 255) | 0},${cl(b * k + 70 * nb, 0, 255) | 0})`; };
 // envolvente convexa 2D (para sombras)
 const hull2 = (pts) => { const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]), cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = []; for (const q of p) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); } for (let i = p.length - 1; i >= 0; i--) { const q = p[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); } return lo.slice(0, -1).concat(up.slice(0, -1)); };
 // Cúpula escalonada en 3D (bandas con cornisa, entrada en arco al sur, remate). o: { sun, night, cut (0..1 retira la mitad sur para ver dentro) }
 P.ykDome = (ctx, cam, t, o = {}) => { const sun = o.sun || P.ykSun(45), N = 40, col = o.col || '#cfae84', night = o.night || 0, cutz = o.cut ? lerp(YK.R0 + 5, 0, cl(o.cut)) : 1e9;
  for (let j = 0; j < YK.n; j++) { const y0 = (YK.H * j) / YK.n, y1 = (YK.H * (j + 1)) / YK.n, r = P.ykR(y0 + 0.1), rn = j < YK.n - 1 ? P.ykR(y1 + 0.1) : r * 0.55;
   for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU, am = (a0 + a1) / 2, n = [Math.cos(am), 0, Math.sin(am)], c = [r * n[0], (y0 + y1) / 2, r * n[2]]; if (c[2] > cutz) continue; if (!faceVis(cam, n, c)) continue; poly3(ctx, cam, [[r * Math.cos(a0), y0, r * Math.sin(a0)], [r * Math.cos(a1), y0, r * Math.sin(a1)], [r * Math.cos(a1), y1, r * Math.sin(a1)], [r * Math.cos(a0), y1, r * Math.sin(a0)]], ykShade(col, [n[0] * 0.9, 0.3, n[2] * 0.9], sun, 0.66, night)); }
   if (cam.pos[1] > y1) for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU; if (Math.sin((a0 + a1) / 2) * r > cutz) continue; poly3(ctx, cam, [[rn * Math.cos(a0), y1, rn * Math.sin(a0)], [rn * Math.cos(a1), y1, rn * Math.sin(a1)], [r * Math.cos(a1), y1, r * Math.sin(a1)], [r * Math.cos(a0), y1, r * Math.sin(a0)]], ykShade(o.ledge || '#dcc19d', [0, 1, 0], sun, 0.62, night)); }
   if (j === 0 && cutz > r) { const ap = []; for (let k = 0; k <= 12; k++) { const u = k / 12, x = lerp(-YK.entW / 2, YK.entW / 2, u), yy = k === 0 || k === 12 ? 0 : YK.entH * 0.62 + Math.sin(Math.PI * u) * YK.entH * 0.38; ap.push([x, yy, Math.sqrt(Math.max(0, r * r - x * x)) + 0.3]); } if (faceVis(cam, [0, 0, 1], [0, 10, r])) poly3(ctx, cam, ap, night > 0.5 ? '#1a140f' : '#2b2017'); }
   // marcas de la escalera de servicio (como en las fotos): pequeños huecos
   if (j > 1 && j < YK.n - 1 && faceVis(cam, [0.4, 0, 0.92], [r * 0.4, y0, r * 0.92])) { const a = 1.16 + j * 0.05, pp = [r * Math.cos(a), y0 + (y1 - y0) * 0.55, r * Math.sin(a) + 0.2]; const Q = cam.clip([pp], 1)[0]; if (Q) { ctx.fillStyle = 'rgba(60,40,25,0.55)'; ctx.beginPath(); ctx.arc(Q[0], Q[1], Math.max(1, 700 / Q[2]), 0, TAU); ctx.fill(); } } }
  const top = cam.clip([[0, YK.H + 4, 0]], 1)[0]; return { top, entrance: cam.clip([[0, YK.entH * 0.5, P.ykR(1) + 1]], 1)[0], base: cam.clip([[0, 0, P.ykR(1)]], 1)[0] };
 };
 // Escena completa del complejo en 3D (cámara P.cam3 en dm): cielo, desierto, canal, estanque (agua → hielo por capas, corte en bloques),
 // camino, sombras calculadas con el sol, muro de sombra este–oeste, cúpula y casas lejanas.
 // o: { sun, night 0..1, water 0..1, ice 0..1, blocks 0..1 (cuadrícula de corte y bloques retirados), dome:{cut}, town, sky ('day'|'night'|'dusk') }
 P.ykWorld = (ctx, cam, t, o = {}) => { const sun = o.sun || P.ykSun(45), night = cl(o.night || 0), Y = YK;
  const sky = ctx.createLinearGradient(0, 0, 0, HH); sky.addColorStop(0, P.mixc('#2f7fd6', '#060d1f', night)); sky.addColorStop(0.55, P.mixc('#9cc8ea', '#14284a', night)); sky.addColorStop(1, P.mixc('#e9d8b4', '#1d2a44', night)); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, HH);
  if (night > 0.05) { const R = H.rng(31); ctx.save(); for (let i = 0; i < 160; i++) { ctx.globalAlpha = night * (0.3 + R() * 0.7); ctx.fillStyle = '#e8f0ff'; const x = R() * W, y = R() * HH * 0.55; ctx.fillRect(x, y, 2, 2); } ctx.restore(); }
  const G = 4000; poly3(ctx, cam, [[-G, 0, -G], [G, 0, -G], [G, 0, G], [-G, 0, G]], ykShade('#d7b98a', [0, 1, 0], sun, 0.62, night));
  const R2 = H.rng(7); for (let i = 0; i < 70; i++) { const x = R2.range(-1800, 1800), z = R2.range(-1800, 1500), s = R2.range(20, 60); if (Math.abs(x) < 450 && z > -150 && z < 360) continue; if (Math.hypot(x - cam.pos[0], z - cam.pos[2]) < 500) continue; poly3(ctx, cam, [[x - s, 0.2, z], [x, 0.2, z - s * 0.4], [x + s, 0.2, z], [x, 0.2, z + s * 0.4]], ykShade(R2() > 0.5 ? '#cfae7f' : '#dcc196', [0, 1, 0], sun, 0.62, night)); }
  // canal desde el oeste y estanque con borde
  const cw = Y.canal.w / 2; poly3(ctx, cam, [[Y.canal.x0, 0.3, Y.canal.z - cw - 4], [Y.canal.x1, 0.3, Y.canal.z - cw - 4], [Y.canal.x1, 0.3, Y.canal.z + cw + 4], [Y.canal.x0, 0.3, Y.canal.z + cw + 4]], ykShade('#b89468', [0, 1, 0], sun, 0.6, night)); poly3(ctx, cam, [[Y.canal.x0, 0.5, Y.canal.z - cw], [Y.canal.x1, 0.5, Y.canal.z - cw], [Y.canal.x1, 0.5, Y.canal.z + cw], [Y.canal.x0, 0.5, Y.canal.z + cw]], P.mixc('#4a86a8', '#1c3550', night));
  const p = Y.pond, rim = 6; poly3(ctx, cam, [[p.x0 - rim, 0.6, p.z0 - rim], [p.x1 + rim, 0.6, p.z0 - rim], [p.x1 + rim, 0.6, p.z1 + rim], [p.x0 - rim, 0.6, p.z1 + rim]], ykShade('#c4a173', [0, 1, 0], sun, 0.6, night)); poly3(ctx, cam, [[p.x0, 0.7, p.z0], [p.x1, 0.7, p.z0], [p.x1, 0.7, p.z1], [p.x0, 0.7, p.z1]], P.mixc('#9c8060', '#3e3328', night));
  const wa = cl(o.water ?? 0), ia = cl(o.ice ?? 0); if (wa > 0) { const xw = lerp(p.x0, p.x1, wa); poly3(ctx, cam, [[p.x0, 0.9, p.z0], [xw, 0.9, p.z0], [xw, 0.9, p.z1], [p.x0, 0.9, p.z1]], H.rgba(H.mix(H.mix('#3f86ad', '#cfeaf4', ia * 0.85), '#173455', night * (1 - ia * 0.6)))); if (ia > 0) { ctx.save(); ctx.globalAlpha = ia * 0.5; const R3 = H.rng(5); for (let k = 0; k < 40; k++) { const x = R3.range(p.x0, xw), z = R3.range(p.z0, p.z1); const A2 = cam.clip([[x, 1, z], [x + R3.range(10, 40), 1, z + R3.range(-8, 8)]], 1); if (A2.length === 2) { ctx.strokeStyle = 'rgba(245,252,255,0.8)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } ctx.restore(); } }
  const bl = cl(o.blocks || 0); if (bl > 0 && wa > 0) { ctx.save(); ctx.strokeStyle = 'rgba(40,70,90,0.6)'; ctx.lineWidth = 1.5; for (let x = p.x0; x <= p.x1; x += 30) { const A2 = cam.clip([[x, 1.1, p.z0], [x, 1.1, lerp(p.z0, p.z1, cl(bl * 1.5))]], 1); if (A2.length === 2) { ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } for (let z = p.z0; z <= p.z1; z += 30) { const A2 = cam.clip([[p.x0, 1.1, z], [lerp(p.x0, p.x1, cl(bl * 1.5)), 1.1, z]], 1); if (A2.length === 2) { ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } ctx.restore(); const nRem = Math.floor(cl(bl * 2 - 0.6) * 20); for (let k = 0; k < nRem; k++) { const x = -30 + (k % 4) * 30 - 60, z = p.z0 + Math.floor(k / 4) * 30; poly3(ctx, cam, [[x, 1.2, z], [x + 30, 1.2, z], [x + 30, 1.2, z + 30], [x, 1.2, z + 30]], P.mixc('#9c8060', '#3e3328', night)); } }
  // camino de la entrada al estanque
  const pw = Y.path.w / 2; poly3(ctx, cam, [[-pw, 0.4, Y.path.z0], [pw, 0.4, Y.path.z0], [pw, 0.4, Y.path.z1], [-pw, 0.4, Y.path.z1]], ykShade('#e2c9a0', [0, 1, 0], sun, 0.62, night));
  // sombras sobre el suelo (calculadas con el mismo vector del sol que ilumina las caras)
  const sa = 0.3 * (1 - night) * cl(sun[1] * 6); if (sa > 0.01 && sun[1] > 0.02) { ctx.save(); ctx.globalAlpha = sa; ctx.fillStyle = '#3a2a1a'; const s = Y.swall, wp = [[s.x0, s.h, s.z0], [s.x1, s.h, s.z0], [s.x1, s.h, s.z1], [s.x0, s.h, s.z1]].map((q) => P.ykShadow(q, sun)), base = [[s.x0, 0, s.z0], [s.x1, 0, s.z0], [s.x1, 0, s.z1], [s.x0, 0, s.z1]], hw = hull2([...wp, ...base].map((q) => [q[0], q[2]])); poly3(ctx, cam, hw.map((q) => [q[0], 1.4, q[1]]), 'rgba(58,42,26,1)');
   const dp = []; for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU; dp.push([YK.R0 * Math.cos(a), YK.R0 * Math.sin(a)]); } const ap = P.ykShadow([0, YK.H, 0], sun); dp.push([ap[0], ap[2]]); poly3(ctx, cam, hull2(dp).map((q) => [q[0], 1.4, q[1]]), 'rgba(58,42,26,1)'); ctx.restore(); }
  // casas lejanas (contexto), muro de sombra y cúpula ordenados por profundidad
  if (o.town) { const R4 = H.rng(19); for (let i = 0; i < 14; i++) { const x = R4.range(-1600, 1600), z = R4.range(-1500, -500), w2 = R4.range(40, 90), h2 = R4.range(30, 60); if (Math.hypot(x - cam.pos[0], z - cam.pos[2]) < 900) continue; P.box3(ctx, cam, x - w2, x + w2, 0, h2, z - w2, z + w2, night > 0.5 ? '#5d5246' : '#c9a979', {}); } }
  const s = Y.swall, items = [{ d: cam.depth([0, 60, (s.z0 + s.z1) / 2]), f: () => { P.box3(ctx, cam, s.x0, s.x1, 0, s.h, s.z0, s.z1, night > 0.5 ? '#6b5a48' : '#c9a777', {}); } }, { d: cam.depth([0, 60, 0]), f: () => P.ykDome(ctx, cam, t, { sun, night, cut: o.dome?.cut }) }]; items.sort((a, b) => b.d - a.d); let dr = null; for (const it of items) { const r = it.f(); if (r) dr = r; }
  return { dome: dr, pondC: cam.clip([[0, 1, (p.z0 + p.z1) / 2]], 1)[0], wallC: cam.clip([[0, s.h, s.z0]], 1)[0], canalC: cam.clip([[Y.canal.x0 * 0.6, 1, Y.canal.z]], 1)[0], pr: (q) => cam.clip([q], 1)[0] };
 };
 // Brújula para vistas aéreas: N apunta hacia −z del modelo proyectado con la cámara.
 P.ykCompass = (ctx, cam, x, y, r = 46) => { const a = cam.clip([[0, 0, 0]], 1)[0], b = cam.clip([[0, 0, -100]], 1)[0]; if (!a || !b) return; const an = Math.atan2(b[1] - a[1], b[0] - a[0]); ctx.save(); ctx.translate(x, y); ctx.fillStyle = 'rgba(11,20,36,0.85)'; ctx.beginPath(); ctx.arc(0, 0, r + 14, 0, TAU); ctx.fill(); ctx.rotate(an + Math.PI / 2); ctx.fillStyle = '#e8505b'; ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(10, 0); ctx.lineTo(-10, 0); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#F5F7F8'; ctx.beginPath(); ctx.moveTo(0, r); ctx.lineTo(10, 0); ctx.lineTo(-10, 0); ctx.closePath(); ctx.fill(); ctx.restore(); ctx.font = '800 32px Nunito'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#FFD447'; ctx.fillText('N', x + Math.cos(an) * (r + 40), y + Math.sin(an) * (r + 40)); };
 // SECCIÓN TÉCNICA norte–sur (2D ortográfica) derivada de YK: ox = x de pantalla del eje de la cúpula, gy = y de pantalla del suelo,
 // s = px/dm, eje horizontal = z (sur a la DERECHA). Muestra terreno, envolvente de adobe con su espesor, cámara interior, depósito
 // excavado con bloques de hielo, escalera de acceso de los trabajadores, sumidero de drenaje del agua de fusión, y (o.site) camino,
 // estanque y muro de sombra en su posición real, con la sombra según el sol.
 // o: { ice 0..1, melt 0..1, heat 0..1, site, sun, night, cut 0..1 (revela la sección con un barrido) }
 P.ykSection = (ctx, ox, gy, s, t, o = {}) => { const Y = YK, X = (z) => ox + (o.flip ? -z : z) * s, Yp = (y) => gy - y * s, night = o.night || 0, sun = o.sun || P.ykSun(40);
  ctx.save();
  // terreno con estratos
  const g = ctx.createLinearGradient(0, gy, 0, gy + 90 * s); g.addColorStop(0, P.mixc('#b48c5e', '#4a3a2c', night)); g.addColorStop(1, P.mixc('#7d5e3e', '#2c241c', night)); ctx.fillStyle = g; ctx.fillRect(0, gy, W, HH - gy); ctx.strokeStyle = 'rgba(60,40,20,0.25)'; ctx.lineWidth = 2; for (let k = 1; k < 6; k++) { ctx.beginPath(); for (let x = 0; x <= W; x += 30) { const yy = gy + k * 16 * s + Math.sin(x * 0.01 + k) * 4; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); } ctx.stroke(); }
  // depósito excavado (pozo) con revestimiento y sumidero
  ctx.fillStyle = P.mixc('#3a2c22', '#15110d', night); ctx.fillRect(ox - Y.pitR * s, gy, Y.pitR * 2 * s, Y.pitD * s); ctx.strokeStyle = '#8a6a48'; ctx.lineWidth = Math.max(2, 2.5 * s); ctx.strokeRect(ox - Y.pitR * s, gy, Y.pitR * 2 * s, Y.pitD * s);
  ctx.fillStyle = '#211a14'; ctx.fillRect(ox - 6 * s, Yp(-Y.pitD), 12 * s, 8 * s); const mlt = cl(o.melt || 0); if (mlt > 0) { ctx.fillStyle = 'rgba(80,160,200,0.85)'; ctx.fillRect(ox - 6 * s, Yp(-Y.pitD - 8 + 8 * mlt), 12 * s, 8 * mlt * s); }
  // bloques de hielo apilados en el pozo (hasta la altura indicada)
  const ih = cl(o.ice || 0) * (Y.pitD + 30), bw = 14, bh = 9; for (let r = 0; r * bh < ih; r++) { const yb = -Y.pitD + r * bh, hh = Math.min(bh, ih - r * bh); for (let c = 0; c < Math.floor((Y.pitR * 2 - 6) / bw); c++) { const z0 = -Y.pitR + 3 + c * bw + (r % 2) * 3; if (z0 + bw > Y.pitR - 3) continue; if (Math.abs(z0 + bw / 2) < 9 && r === 0) continue; const x0 = Math.min(X(z0), X(z0 + bw)) + 1.5, y0 = Yp(yb + hh) + 1.5; const gi = ctx.createLinearGradient(x0, y0, x0 + bw * s, y0 + hh * s); gi.addColorStop(0, '#e6f6fb'); gi.addColorStop(1, '#9fd0e3'); ctx.fillStyle = gi; ctx.fillRect(x0, y0, bw * s - 3, hh * s - 3); ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1; ctx.strokeRect(x0, y0, bw * s - 3, hh * s - 3); } }
  // escalera de acceso (lado sur, desde la entrada al fondo del pozo)
  ctx.strokeStyle = '#6b4f33'; ctx.lineWidth = Math.max(2, 1.6 * s); for (let k = 0; k < 9; k++) { const z = Y.pitR - 4 - k * 4.2, y = -k * (Y.pitD / 9); ctx.beginPath(); ctx.moveTo(X(z), Yp(y)); ctx.lineTo(X(z - 4.2), Yp(y)); ctx.lineTo(X(z - 4.2), Yp(y - Y.pitD / 9)); ctx.stroke(); }
  // envolvente de adobe: perfil escalonado exterior, pared con espesor y cámara interior (ambos lados del eje)
  const prof = (side) => { const out = [], inn = []; for (let j = 0; j <= Y.n; j++) { const y0 = (Y.H * j) / Y.n, y1 = (Y.H * (j + 1)) / Y.n, r = j < Y.n ? P.ykR(y0 + 0.1) : 0; if (j < Y.n) { out.push([side * r, y0], [side * r, Math.min(y1, Y.H)]); } } out.push([0, Y.H + 4]); for (let y = Y.H - 8; y >= 0; y -= 4) inn.push([side * P.ykRin(y), y]); return { out, inn }; };
  for (const side of [-1, 1]) { const { out, inn } = prof(side); ctx.beginPath(); out.forEach((q, i) => (i ? ctx.lineTo(X(q[0]), Yp(q[1])) : ctx.moveTo(X(q[0]), Yp(q[1])))); inn.forEach((q) => ctx.lineTo(X(q[0]), Yp(q[1]))); ctx.closePath(); const ga = ctx.createLinearGradient(X(side * Y.R0), 0, X(0), 0); ga.addColorStop(0, P.mixc('#d4b185', '#5d4d3c', night)); ga.addColorStop(1, P.mixc('#b8946a', '#4d3f31', night)); ctx.fillStyle = ga; ctx.fill(); ctx.save(); ctx.clip(); ctx.strokeStyle = 'rgba(90,60,35,0.25)'; ctx.lineWidth = 1.5; for (let y = 0; y < Y.H; y += 6) { ctx.beginPath(); ctx.moveTo(X(-Y.R0), Yp(y)); ctx.lineTo(X(Y.R0), Yp(y)); ctx.stroke(); } ctx.restore(); ctx.strokeStyle = 'rgba(70,45,25,0.6)'; ctx.lineWidth = 2; ctx.stroke(); }
  // cámara interior (aire) sobre el pozo
  ctx.beginPath(); for (let y = 0; y <= Y.H - 8; y += 4) { const r = P.ykRin(y); y ? ctx.lineTo(X(r), Yp(y)) : ctx.moveTo(X(r), Yp(y)); } for (let y = Y.H - 8; y >= 0; y -= 4) ctx.lineTo(X(-P.ykRin(y)), Yp(y)); ctx.closePath(); ctx.fillStyle = P.mixc('#4a3a2c', '#1b1611', night); ctx.fill();
  // entrada al sur (hueco en la pared a ras de suelo) y suelo interior alrededor del pozo
  ctx.fillStyle = P.mixc('#4a3a2c', '#1b1611', night); { const xa = Math.min(X(P.ykRin(2) - 1), X(P.ykR(1) + 1)), xb = Math.max(X(P.ykRin(2) - 1), X(P.ykR(1) + 1)); ctx.fillRect(xa, Yp(Y.entH), xb - xa, Y.entH * s); } ctx.fillStyle = '#8a6a48'; ctx.fillRect(ox - P.ykRin(1) * s, gy - 2, (P.ykRin(1) - Y.pitR) * s, 4); ctx.fillRect(ox + Y.pitR * s, gy - 2, (P.ykRin(1) - Y.pitR) * s, 4);
  // calor: flechas naranjas exteriores (sol) que se acortan al atravesar la pared; dentro casi no llegan
  const ha = cl(o.heat || 0); if (ha > 0) { ctx.save(); ctx.globalAlpha = ha; for (const [side, yy] of [[-1, 40], [-1, 95], [1, 40], [1, 95], [1, 140]]) { const r = P.ykR(yy), ri = P.ykRin(yy), ph = (t * 0.8 + yy * 0.01) % 1; const ax0 = X(side * (r + 34)), ax1 = X(side * (r + 2)), ay = Yp(yy), sg = Math.sign(ax0 - ax1); ctx.strokeStyle = '#FF8A3D'; ctx.fillStyle = '#FF8A3D'; ctx.lineWidth = Math.max(4, 2.2 * s); ctx.beginPath(); ctx.moveTo(ax0, ay); ctx.lineTo(ax1 + sg * 10, ay); ctx.stroke(); ctx.beginPath(); ctx.moveTo(ax1, ay); ctx.lineTo(ax1 + sg * 22, ay - 11); ctx.lineTo(ax1 + sg * 22, ay + 11); ctx.closePath(); ctx.fill(); ctx.globalAlpha = ha * 0.55; ctx.lineWidth = Math.max(2, 1.2 * s); ctx.setLineDash([8, 8]); ctx.lineDashOffset = -ph * 32; ctx.beginPath(); ctx.moveTo(X(side * r), ay); ctx.lineTo(X(side * lerp(r, ri, 0.7)), ay); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = ha; } ctx.restore(); }
  // sitio: camino, estanque y muro de sombra en su posición real (al sur del eje) y sombra del muro según el sol
  if (o.site) { const pd = Y.pond, sw = Y.swall; ctx.fillStyle = '#e2c9a0'; const RX = (z0, z1, y0, y1) => { const xa = Math.min(X(z0), X(z1)), xb = Math.max(X(z0), X(z1)); ctx.fillRect(xa, Math.min(y0, y1), xb - xa, Math.abs(y1 - y0)); }; RX(Y.path.z0, Y.path.z1, gy - 3, gy); ctx.fillStyle = '#8a6a48'; RX(pd.z0 - 6, pd.z1 + 6, gy - 3, gy); ctx.fillStyle = P.mixc('#3f86ad', '#9fd3e6', cl(o.pondIce || 0)); RX(pd.z0, pd.z1, gy - 5, gy); ctx.fillStyle = P.mixc('#c9a777', '#5d4d3c', night); RX(sw.z0, sw.z1, Yp(sw.h), gy); ctx.strokeStyle = 'rgba(70,45,25,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(Math.min(X(sw.z0), X(sw.z1)), Yp(sw.h), (sw.z1 - sw.z0) * s, sw.h * s);
   if (sun[1] > 0.02 && night < 0.5 && sun[2] > 0) { const L = sw.h / Math.tan(Math.asin(sun[1])); ctx.fillStyle = 'rgba(40,28,16,0.38)'; RX(sw.z0 - L, sw.z0, gy - 5, gy + 6); ctx.strokeStyle = 'rgba(255,212,71,0.7)'; ctx.setLineDash([10, 10]); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(X(sw.z0 + 140 * sun[2] / sun[1] * 0.35), Yp(sw.h + 140 * 0.35)); ctx.lineTo(X(sw.z0), Yp(sw.h)); ctx.lineTo(X(sw.z0 - L), gy); ctx.stroke(); ctx.setLineDash([]); } }
  ctx.restore(); return { X, Yp, top: [X(0), Yp(Y.H + 4)], wall: [X(Y.R0 - 8), Yp(40)], pit: [X(-Y.pitR * 0.5), Yp(-Y.pitD * 0.5)], drain: [X(0), Yp(-Y.pitD - 4)], entrance: [X(P.ykR(1)), Yp(Y.entH * 0.5)], chamber: [X(0), Yp(Y.H * 0.45)], pond: [X((Y.pond.z0 + Y.pond.z1) / 2), gy], swall: [X(Y.swall.z0), Yp(Y.swall.h)] };
 };
 // Estanque en corte (detalle): lámina de agua poco profunda (grosor EXAGERADO para verla), frente de hielo que crece desde la
 // superficie, capas de noches anteriores apiladas y transferencia de energía térmica hacia el cielo y el aire (flechas naranjas).
 // o: { water 0..1 (llenado), freeze 0..1 (capa actual), layers (capas anteriores), loss 0..1 (flechas), night }
 P.pondSection = (ctx, x, y, w, h, t, o = {}) => { ctx.save(); const base = y + h, layH = h * 0.16, nL = o.layers || 0, ice0 = base - nL * layH; ctx.fillStyle = '#7d5e3e'; ctx.fillRect(x - 30, base, w + 60, h * 0.5); ctx.fillStyle = '#9c8060'; ctx.fillRect(x - 30, base - 6, 30, 6 + h * 0.5); ctx.fillRect(x + w, base - 6, 30, 6 + h * 0.5); ctx.fillRect(x - 30, y - 10, 30, h + 10); ctx.fillRect(x + w, y - 10, 30, h + 10);
  for (let k = 0; k < nL; k++) { const yy = base - (k + 1) * layH; const g = ctx.createLinearGradient(0, yy, 0, yy + layH); g.addColorStop(0, '#e9f7fc'); g.addColorStop(1, '#a9d6e8'); ctx.fillStyle = g; ctx.fillRect(x, yy, w, layH - 2); ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, yy + 1); ctx.lineTo(x + w, yy + 1); ctx.stroke(); }
  const wf = cl(o.water ?? 1); if (wf > 0) { const xw = x + w * wf, top = ice0 - layH; ctx.fillStyle = 'rgba(63,134,173,0.9)'; ctx.fillRect(x, top, xw - x, layH); const fz = cl(o.freeze || 0); if (fz > 0) { const fh = layH * fz; const g = ctx.createLinearGradient(0, top, 0, top + fh); g.addColorStop(0, '#eaf8fd'); g.addColorStop(1, '#b6def0'); ctx.fillStyle = g; ctx.fillRect(x, top, xw - x, fh); const R = H.rng(3); ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 2; for (let k = 0; k < 26; k++) { const cx = x + R() * (xw - x), cy = top + R() * fh, L = 8 + R() * 18; for (let a = 0; a < 3; a++) { const an = a * Math.PI / 3 + R(); ctx.beginPath(); ctx.moveTo(cx - Math.cos(an) * L / 2, cy - Math.sin(an) * L / 2); ctx.lineTo(cx + Math.cos(an) * L / 2, cy + Math.sin(an) * L / 2); ctx.stroke(); } } } ctx.strokeStyle = 'rgba(200,235,250,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(xw, top); ctx.stroke(); }
  const ls = cl(o.loss || 0); if (ls > 0) { const top = ice0 - layH; ctx.globalAlpha = ls; for (let k = 0; k < 6; k++) { const ax = x + w * (0.1 + k * 0.16), ph = (t * 0.7 + k * 0.17) % 1, len = h * 0.5; const ay0 = top - 8 - ph * len * 0.6, ay1 = ay0 - len * 0.5; ctx.globalAlpha = ls * Math.sin(Math.PI * ph); ctx.strokeStyle = '#FF8A3D'; ctx.fillStyle = '#FF8A3D'; ctx.lineWidth = 6; const dx = k % 2 ? 0 : 18; ctx.beginPath(); ctx.moveTo(ax, ay0); ctx.lineTo(ax + dx, ay1 + 14); ctx.stroke(); ctx.beginPath(); ctx.moveTo(ax + dx, ay1); ctx.lineTo(ax + dx - 12, ay1 + 20); ctx.lineTo(ax + dx + 12, ay1 + 20); ctx.closePath(); ctx.fill(); } ctx.globalAlpha = 1; }
  ctx.restore(); return { surface: [x + w / 2, ice0 - layH], layerY: (k) => base - (k + 0.5) * layH };
 };
 // Bloque de hielo 2D (translúcido, con aristas claras); melt 0..1 lo redondea y encoge; o.side = cara lateral visible
 P.iceBlock = (ctx, x, y, w, h, o = {}) => { const m = cl(o.melt || 0), ww = w * (1 - m * 0.4), hh = h * (1 - m * 0.5), r = Math.min(ww, hh) * (0.06 + m * 0.3); ctx.save(); ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(0, hh / 2 + 4, ww * 0.55, 6, 0, 0, TAU); ctx.fill(); const g = ctx.createLinearGradient(-ww / 2, -hh / 2, ww / 2, hh / 2); g.addColorStop(0, '#f2fbfe'); g.addColorStop(0.5, '#c4e6f2'); g.addColorStop(1, '#8cc4dc'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-ww / 2, -hh / 2, ww, hh, r); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = Math.max(1.5, w * 0.03); ctx.stroke(); ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = Math.max(1, w * 0.02); ctx.beginPath(); ctx.moveTo(-ww * 0.32, -hh * 0.28); ctx.lineTo(ww * 0.1, -hh * 0.28); ctx.moveTo(-ww * 0.32, -hh * 0.12); ctx.lineTo(-ww * 0.05, -hh * 0.12); ctx.stroke(); if (m > 0) { ctx.fillStyle = 'rgba(120,190,220,0.6)'; ctx.beginPath(); ctx.ellipse(0, hh / 2 + 3, ww * 0.6 * m + 6, 4, 0, 0, TAU); ctx.fill(); } ctx.restore(); };
 // Trabajador persa (vista lateral, vestimenta plausible genérica: túnica larga con faja, pantalón amplio, gorro de tela) con
 // articulaciones (cinemática inversa en brazos y piernas). El pie de apoyo toca y. Poses: 'walk', 'stand', 'pick' (pico a dos manos,
 // lift 0..1), 'carry' (bloque sobre la espalda sujeto con las dos manos, cuerpo inclinado por el peso), 'lower' (agachado, bloque en
 // las manos), 'rake' (empuja el agua con un rastrillo largo). o: { pose, ph (fase de paso), lift, dir, var, block (dibuja el bloque) }
 P.persianWorker = (ctx, x, y, h, t, o = {}) => { const pose = o.pose || 'stand', d = o.dir ?? 1, v = o.var ?? 0, u = h / 170, ph = o.ph ?? 0, lift = cl(o.lift ?? 0);
  const tun = ['#7a5a3a', '#4f5a4a', '#6b4a3a', '#5a5048'][v % 4], tunD = H.rgba(H.mix(tun, '#000000', 0.3)), trou = ['#d8ccb4', '#cbbfa6', '#bfb39a'][v % 3], cap = ['#e9e1cf', '#8a6a4a', '#d9cfb6'][v % 3], skin = ['#b07a52', '#9a6a46', '#c08a60'][v % 3], sash = ['#a4473a', '#2f4a5e', '#8a7a4a'][v % 3];
  const IK = (sx, sy, tx, ty, l1, l2, bend) => { const dx = tx - sx, dy = ty - sy, dd = Math.min(l1 + l2 - 0.01, Math.max(0.01, Math.hypot(dx, dy))), a = Math.atan2(dy, dx), c = Math.acos(cl((l1 * l1 + dd * dd - l2 * l2) / (2 * l1 * dd), -1, 1)), ea = a + bend * c; return [sx + Math.cos(ea) * l1, sy + Math.sin(ea) * l1, sx + Math.cos(a) * dd, sy + Math.sin(a) * dd]; };
  const lean = pose === 'carry' ? 0.38 : pose === 'lower' ? 0.55 : pose === 'pick' ? 0.12 + 0.2 * (1 - lift) : pose === 'rake' ? 0.22 : 0.03, crouch = pose === 'lower' ? 22 : pose === 'pick' ? 6 * (1 - lift) : 0;
  const hip = [0, -86 + crouch], sh = [hip[0] + Math.sin(lean) * 60, hip[1] - Math.cos(lean) * 60], head = [sh[0] + Math.sin(lean) * 15, sh[1] - Math.cos(lean) * 15 - 6];
  const walk = pose === 'walk' || pose === 'carry'; const ft = [0, 1].map((k) => { if (walk) { const f = ph * TAU + k * Math.PI; return [Math.sin(f) * 20, -Math.max(0, Math.cos(f)) * 7]; } return pose === 'lower' ? [k ? 22 : -14, 0] : pose === 'pick' ? [k ? 24 : -20, 0] : [k ? 8 : -6, 0]; });
  const mins = Math.min(...ft.map((f) => f[1])); ctx.save(); ctx.translate(x, y); ctx.scale(u * d, u);
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(4, 0, 30, 5, 0, 0, TAU); ctx.fill();
  const leg = (k, col) => { const f = ft[k], kn = IK(hip[0], hip[1], f[0], f[1] - mins * 0 - 4, 44, 43, -1); ctx.strokeStyle = col; ctx.lineWidth = 13; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(kn[0], kn[1]); ctx.lineTo(kn[2], kn[3]); ctx.stroke(); ctx.fillStyle = '#3a2a1c'; ctx.beginPath(); ctx.ellipse(kn[2] + 6, kn[3] + 2, 11, 5, 0, 0, TAU); ctx.fill(); };
  leg(1, H.rgba(H.mix(trou, '#000000', 0.15))); leg(0, trou);
  // túnica (hasta la rodilla) y faja
  ctx.fillStyle = tun; ctx.beginPath(); ctx.moveTo(sh[0] - 16, sh[1] + 2); ctx.quadraticCurveTo(hip[0] - 22, hip[1] - 10, hip[0] - 24, hip[1] + 36); ctx.lineTo(hip[0] + 26, hip[1] + 36); ctx.quadraticCurveTo(hip[0] + 22, hip[1] - 10, sh[0] + 16, sh[1] + 2); ctx.closePath(); ctx.fill(); ctx.fillStyle = tunD; ctx.beginPath(); ctx.moveTo(hip[0] - 24, hip[1] + 36); ctx.lineTo(hip[0] - 4, hip[1] + 36); ctx.lineTo(hip[0] - 6, hip[1]); ctx.closePath(); ctx.fill(); ctx.strokeStyle = sash; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(hip[0] - 20 + Math.sin(lean) * 8, hip[1] - 6); ctx.lineTo(hip[0] + 20 + Math.sin(lean) * 8, hip[1] - 6); ctx.stroke();
  // objetivos de las manos según la pose
  let hA, hB, tool = null, blk = null; const sw = Math.sin(ph * TAU);
  if (pose === 'pick') { const a = lerp(-2.2, 0.55, lift ** 1.5), L = 70; const hp = [sh[0] + 26, sh[1] + 18]; hA = [hp[0] + Math.cos(a) * 14, hp[1] + Math.sin(a) * 14]; hB = [hp[0] + Math.cos(a) * 34, hp[1] + Math.sin(a) * 34]; tool = { kind: 'pick', p0: [hp[0] - Math.cos(a) * 6, hp[1] - Math.sin(a) * 6], p1: [hp[0] + Math.cos(a) * L, hp[1] + Math.sin(a) * L], a }; }
  else if (pose === 'carry') { blk = { x: sh[0] - 14, y: sh[1] - 6, w: 34, h: 24, rot: lean - 0.15 }; hA = [sh[0] + 10, sh[1] - 18]; hB = [sh[0] - 4, sh[1] - 26]; }
  else if (pose === 'lower') { blk = { x: sh[0] + 30, y: hip[1] + 26 - lift * 10, w: 34, h: 24, rot: 0 }; hA = [blk.x - 15, blk.y - 2]; hB = [blk.x + 15, blk.y - 4]; }
  else if (pose === 'rake') { const k = 0.5 + 0.5 * Math.sin(t * 2.2 + v); hA = [sh[0] + 20 + k * 16, sh[1] + 30]; hB = [sh[0] + 40 + k * 20, sh[1] + 44]; tool = { kind: 'rake', p0: [hA[0] - 20, hA[1] - 18], p1: [hA[0] + 80 + k * 10, 0], a: 0 }; }
  else if (walk) { hA = [sh[0] + sw * 18, sh[1] + 52]; hB = [sh[0] - sw * 18, sh[1] + 52]; } else { hA = [sh[0] + 6, sh[1] + 56]; hB = [sh[0] - 4, sh[1] + 56]; }
  const arm = (hp, col, bend) => { const e = IK(sh[0], sh[1] + 4, hp[0], hp[1], 30, 28, bend); ctx.strokeStyle = col; ctx.lineWidth = 11; ctx.beginPath(); ctx.moveTo(sh[0], sh[1] + 4); ctx.lineTo(e[0], e[1]); ctx.lineTo(e[2], e[3]); ctx.stroke(); ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(e[2], e[3], 6, 0, TAU); ctx.fill(); return [e[2], e[3]]; };
  if (blk && pose === 'carry') { ctx.save(); ctx.translate(blk.x, blk.y); ctx.rotate(blk.rot); P.iceBlock(ctx, 0, 0, blk.w, blk.h, {}); ctx.restore(); }
  const back = arm(hB, tunD, 1);
  if (tool) { ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(tool.p0[0], tool.p0[1]); ctx.lineTo(tool.p1[0], tool.p1[1]); ctx.stroke(); if (tool.kind === 'pick') { ctx.save(); ctx.translate(tool.p1[0], tool.p1[1]); ctx.rotate(tool.a); ctx.fillStyle = '#5a5f63'; ctx.beginPath(); ctx.moveTo(-4, -16); ctx.quadraticCurveTo(10, -4, 4, 18); ctx.lineTo(0, 18); ctx.quadraticCurveTo(4, -2, -8, -14); ctx.closePath(); ctx.fill(); ctx.restore(); } else { ctx.fillStyle = '#6b4a2c'; ctx.fillRect(tool.p1[0] - 2, -14, 6, 14); ctx.fillRect(tool.p1[0] - 14, -4, 30, 4); } }
  ctx.fillStyle = tun; ctx.beginPath(); ctx.ellipse(sh[0], sh[1] + 10, 17, 22, lean, 0, TAU); ctx.fill();
  ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(head[0], head[1], 10.5, 12.5, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(head[0] + 9, head[1] - 2); ctx.lineTo(head[0] + 14, head[1] + 2); ctx.lineTo(head[0] + 9, head[1] + 4); ctx.fill(); ctx.fillStyle = '#2a1e16'; ctx.beginPath(); ctx.moveTo(head[0] - 9, head[1] + 2); ctx.quadraticCurveTo(head[0] + 2, head[1] + 18, head[0] + 10, head[1] + 6); ctx.lineTo(head[0] + 4, head[1] + 4); ctx.quadraticCurveTo(head[0], head[1] + 9, head[0] - 6, head[1]); ctx.closePath(); ctx.fill();
  ctx.fillStyle = cap; ctx.beginPath(); ctx.ellipse(head[0] - 1, head[1] - 9, 12, 7, 0, Math.PI, TAU); ctx.fill(); ctx.fillRect(head[0] - 13, head[1] - 10, 25, 4); ctx.fillStyle = '#1b1410'; ctx.beginPath(); ctx.arc(head[0] + 5, head[1] - 2, 1.5, 0, TAU); ctx.fill();
  const front = arm(hA, tun, 1);
  if (blk && pose === 'lower') { P.iceBlock(ctx, blk.x, blk.y, blk.w, blk.h, {}); ctx.fillStyle = skin; for (const hp of [hA, hB]) { ctx.beginPath(); ctx.arc(hp[0], hp[1], 6, 0, TAU); ctx.fill(); } }
  ctx.restore(); const M = (p) => [x + p[0] * u * d, y + p[1] * u]; return { hands: [M(front), M(back)], head: M(head), toolTip: tool ? M(tool.p1) : null, block: blk ? M([blk.x, blk.y]) : null };
 };
 // Indicador de estaciones (círculo con invierno/primavera/verano/otoño y aguja). u 0..1 recorre el año desde el invierno.
 P.seasonDial = (ctx, cx, cy, r, u, o = {}) => { const S = [['INVIERNO', '#7cc4e8'], ['PRIMAVERA', '#8fd18a'], ['VERANO', '#ffb347'], ['OTOÑO', '#d9935a']]; ctx.save(); ctx.fillStyle = 'rgba(11,20,36,0.88)'; ctx.beginPath(); ctx.arc(cx, cy, r + 16, 0, TAU); ctx.fill(); S.forEach(([n, c], i) => { ctx.strokeStyle = c; ctx.lineWidth = 16; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2 + i * Math.PI / 2 + 0.06, -Math.PI / 2 + (i + 1) * Math.PI / 2 - 0.06); ctx.stroke(); }); const a = -Math.PI / 2 + u * TAU + Math.PI / 4; ctx.strokeStyle = '#F5F7F8'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * r * 0.78, cy + Math.sin(a) * r * 0.78); ctx.stroke(); ctx.fillStyle = '#F5F7F8'; ctx.beginPath(); ctx.arc(cx, cy, 8, 0, TAU); ctx.fill(); const i = Math.floor(((u % 1) + 1) % 1 * 4); ctx.font = '800 34px Nunito'; ctx.fillStyle = S[i][1]; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(o.label || S[i][0], cx, cy + r + 50); ctx.restore(); };
 // Desierto 2D del yakhchal (gancho): cielo de calor, sol, dunas en capas, reverberación determinista. o: { heat 0..1, horizon, seed }
 P.ykDesert = (ctx, t, o = {}) => { const hz = o.horizon ?? 1080, g = ctx.createLinearGradient(0, 0, 0, hz); g.addColorStop(0, '#3d86d2'); g.addColorStop(1, '#f2d9a4'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); P.glow(ctx, o.sunX ?? 820, o.sunY ?? 330, 420, '255,220,140', 0.55); ctx.fillStyle = '#fff7df'; ctx.beginPath(); ctx.arc(o.sunX ?? 820, o.sunY ?? 330, 70, 0, TAU); ctx.fill();
  const L = [['#e8c58e', 0], ['#ddb377', 140], ['#cf9f62', 330], ['#c08d52', 560]]; L.forEach(([c, dy], k) => { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(0, HH); for (let x = 0; x <= W; x += 20) ctx.lineTo(x, hz + dy - 40 * Math.sin(x * 0.004 + k * 1.7 + t * 0.02) - 22 * Math.sin(x * 0.011 + k)); ctx.lineTo(W, HH); ctx.closePath(); ctx.fill(); });
  const he = cl(o.heat ?? 1); if (he > 0) { ctx.save(); ctx.globalAlpha = 0.18 * he; ctx.strokeStyle = '#fff3d6'; ctx.lineWidth = 3; for (let k = 0; k < 9; k++) { const yy = hz - 40 + k * 12; ctx.beginPath(); for (let x = 0; x <= W; x += 16) { const v = Math.sin(x * 0.03 + t * 6 + k) * 4; x ? ctx.lineTo(x, yy + v) : ctx.moveTo(x, yy + v); } ctx.stroke(); } ctx.restore(); } };
 // ---------------- v1.21 · YAKHCHAL fiel a la fotografía (cúpula curva de adobe, depósito 3D, estanque histórico) ----------------
 // Bloques NUEVOS (los de v1.20 quedan intactos para la retrocompatibilidad). Mismo modelo maestro P.YK (dm; x = este, z = sur).
 // Perfil exterior PARABÓLICO medido sobre la fotografía de Meybod: r(y) = R0·√(1 − y/H) (cono de flancos convexos y remate redondeado,
 // sin escalones). Interior con la misma ley (R0 − pared en la base, 12 dm de bóveda en el remate) → espesor real de 12–20 dm.
 const YK2 = { ent: { w: 28, h: 20, vault: 14, z0: 84, z1: 118, door: 8, doorH: 17 }, pitR0: 72, pitR1: 64, top: 12, cut: { X: 118, Z: 112, D: 74 }, stair: { a0: Math.PI * 0.5, a1: Math.PI * 0.8, w: 13 } };
 P.YK2 = YK2;
 // v1.21.1: perfil ajustado por mínimos cuadrados a la silueta medida en la foto de Meybod (vista desde la cámara de la transición)
 const ykGb = (h) => Math.pow(1 - h, 0.7) * (1 + 0.22 * Math.sin(Math.PI * h)), ykGc = ykGb(0.84) / Math.sqrt(0.16), ykG = (h) => { h = cl(h); const w = H.smooth(0.78, 0.93, h); return lerp(ykGb(h), ykGc * Math.sqrt(1 - h), w); }; // remate redondeado (parabólico) como en la foto
 P.ykR2 = (y) => (y < 0 ? YK.R0 : YK.R0 * ykG(y / YK.H));
 P.ykRin2 = (y) => { const Hi = YK.H - YK2.top; return y < 0 ? YK.R0 - YK.wall0 : (YK.R0 - YK.wall0) * ykG(y / Hi); };
 P.ykPitR = (y) => lerp(YK2.pitR0, YK2.pitR1, cl(-y / YK.pitD)); // muro de contención ligeramente ataluzado (y ≤ 0)
 const ykN2 = (a, y, s = 1) => { const h = cl(y / YK.H, 0, 0.995), dr = YK.R0 * (ykG(h + 0.002) - ykG(h - 0.002)) / 0.004 / YK.H, l = Math.hypot(1, dr); return [s * Math.cos(a) / l, -s * dr / l, s * Math.sin(a) / l]; };
 // textura mineral determinista (manchas suaves, desgaste de la base, grano por cara)
 const ykHash = (i, j) => { const s = Math.sin(i * 127.1 + j * 311.7) * 43758.5453; return s - Math.floor(s); };
 const ykTex = (a, y, i, j) => 1 + 0.03 * (Math.sin(a * 7 + y * 0.13) + Math.sin(a * 13 - y * 0.07 + 1.3)) / 2 + 0.007 * (ykHash(i, j) - 0.5) - 0.07 * (1 - cl(y / 28)) - 0.03 * Math.max(0, Math.sin(a * 23 + 0.7)) * (1 - cl(y / 90));
 const ykHex = (a) => '#' + a.map((v) => cl(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
 const ykK = (hex, k) => { const [r, g, b] = H.hex(hex); return [r * k, g * k, b * k]; };
 const ykShadeA = (hex, n, sun, amb, night, mul) => { const s = ykShade(hex, n, sun, amb, night), m = s.match(/\d+/g).map(Number); return `rgb(${cl(m[0] * mul, 0, 255) | 0},${cl(m[1] * mul, 0, 255) | 0},${cl(m[2] * mul, 0, 255) | 0})`; };
 const ykRings = (n = 34) => { const r = []; for (let i = 0; i <= n; i++) r.push(YK.H * (1 - Math.pow(1 - i / n, 1.7))); return r; };
 // Vestíbulo de entrada al SUR: bóveda de cañón de adobe que atraviesa la pared y lleva al rellano del depósito
 const ykVestibule = (ctx, cam, sun, night, col) => { const e = YK2.ent, hw = e.w / 2, F = [];
  const vault = (z) => { const p = []; for (let k = 0; k <= 10; k++) { const q = Math.PI * (k / 10); p.push([hw * Math.cos(q), e.h + e.vault * Math.sin(q) * 0.85, z]); } return p; };
  for (let k = 0; k < 10; k++) { const q0 = Math.PI * k / 10, q1 = Math.PI * (k + 1) / 10, qm = (q0 + q1) / 2, n = [Math.cos(qm), Math.sin(qm), 0], c = [hw * Math.cos(qm), e.h + e.vault * Math.sin(qm) * 0.85, (e.z0 + e.z1) / 2]; if (!faceVis(cam, n, c)) continue; poly3(ctx, cam, [[hw * Math.cos(q0), e.h + e.vault * Math.sin(q0) * 0.85, e.z0], [hw * Math.cos(q1), e.h + e.vault * Math.sin(q1) * 0.85, e.z0], [hw * Math.cos(q1), e.h + e.vault * Math.sin(q1) * 0.85, e.z1], [hw * Math.cos(q0), e.h + e.vault * Math.sin(q0) * 0.85, e.z1]], ykShade(col, n, sun, 0.6, night), { stroke: ykShade(col, n, sun, 0.6, night), lw: 1 }); }
  for (const sx of [-1, 1]) { const n = [sx, 0, 0], c = [sx * hw, e.h / 2, (e.z0 + e.z1) / 2]; if (faceVis(cam, n, c)) poly3(ctx, cam, [[sx * hw, 0, e.z0], [sx * hw, 0, e.z1], [sx * hw, e.h, e.z1], [sx * hw, e.h, e.z0]], ykShade(col, n, sun, 0.6, night)); }
  if (faceVis(cam, [0, 0, 1], [0, 10, e.z1])) { poly3(ctx, cam, [[-hw, 0, e.z1], [hw, 0, e.z1], ...vault(e.z1)], ykShade(col, [0, 0, 1], sun, 0.6, night)); const d = []; for (let k = 0; k <= 12; k++) { const q = Math.PI * (k / 12); d.push([e.door * Math.cos(q), e.doorH - e.door * 0.6 + e.door * 0.6 * Math.sin(q) + (k === 0 || k === 12 ? -(e.doorH - e.door * 0.6) : 0), e.z1 + 0.3]); } d[0][1] = 0; d[12][1] = 0; poly3(ctx, cam, d, night > 0.5 ? '#120e0a' : '#241a12'); poly3(ctx, cam, [[-e.door, 0.2, e.z1 + 0.3], [e.door, 0.2, e.z1 + 0.3], [e.door * 0.8, 0.2, e.z1 + 4], [-e.door * 0.8, 0.2, e.z1 + 4]], 'rgba(30,20,12,0.35)'); } };
 // Cúpula curva de adobe en 3D (fiel a la fotografía): sombreado suave por cara con normal del perfil, textura mineral, hiladas tenues,
 // muescas de la escalera de mantenimiento en el flanco oeste, agujeros del remate, vestíbulo al sur y sombra de contacto.
 // o: { sun, night, col, cutx (retira las caras con x > cutx: corte visto desde el este), noVest }
 P.ykDome2 = (ctx, cam, t, o = {}) => { const sun = o.sun || P.ykSun(45), night = cl(o.night || 0), col = o.col || '#f2e2c6', N = o.N || 84, rings = ykRings(o.rings || 34), cutz = o.cutx ?? 1e9;
  ctx.save(); for (const [r0, r1, a] of [[YK.R0 - 1, YK.R0 + 6, 0.28], [YK.R0 + 6, YK.R0 + 16, 0.12]]) { ctx.globalAlpha = a * (1 - night * 0.6); for (let i = 0; i < 48; i++) { const q0 = (i / 48) * TAU, q1 = ((i + 1) / 48) * TAU; if (Math.cos((q0 + q1) / 2) * r0 > cutz) continue; poly3(ctx, cam, [[r0 * Math.cos(q0), 0.8, r0 * Math.sin(q0)], [r0 * Math.cos(q1), 0.8, r0 * Math.sin(q1)], [r1 * Math.cos(q1), 0.8, r1 * Math.sin(q1)], [r1 * Math.cos(q0), 0.8, r1 * Math.sin(q0)]], '#3a2a1a'); } } ctx.restore();
  const ve = YK2.ent, vC = [0, 20, (ve.z0 + ve.z1) / 2], vestFirst = !o.noVest && cutz > 1e8 && cam.depth(vC) > cam.depth([0, 40, 0]); if (vestFirst) ykVestibule(ctx, cam, sun, night, col);
  for (let j = 0; j < rings.length - 1; j++) { const y0 = rings[j], y1 = rings[j + 1], r0 = P.ykR2(y0), r1 = P.ykR2(y1), ym = (y0 + y1) / 2;
   for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU, am = (a0 + a1) / 2, n = ykN2(am, ym), rm = P.ykR2(ym), c = [rm * Math.cos(am), ym, rm * Math.sin(am)]; if (Math.min(r0, r1) * Math.cos(am) > cutz) continue; if (!faceVis(cam, n, c)) continue;
    const f = ykShadeA(col, n, sun, o.amb ?? 0.6, night, ykTex(am, ym, i, j)); poly3(ctx, cam, [[r0 * Math.cos(a0), y0, r0 * Math.sin(a0)], [r0 * Math.cos(a1), y0, r0 * Math.sin(a1)], [r1 * Math.cos(a1), y1, r1 * Math.sin(a1)], [r1 * Math.cos(a0), y1, r1 * Math.sin(a0)]], f, { stroke: f, lw: 1.2 }); } }
  // hiladas tenues (detalle del material, no escalones) y muescas de la escalera en el flanco oeste (como en la fotografía)
  ctx.save(); ctx.lineWidth = 1.4; for (const yc of [22, 41, 58, 77, 96, 113, 131, 148]) { const r = P.ykR2(yc), pts = []; for (let i = 0; i <= 60; i++) { const a = (i / 60) * TAU, n = ykN2(a, yc), c = [r * Math.cos(a), yc, r * Math.sin(a)]; if (r * Math.cos(a) > cutz || !faceVis(cam, n, c)) { if (pts.length > 1) { ctx.strokeStyle = `rgba(110,85,60,${0.16 * (1 - night * 0.5)})`; ctx.beginPath(); pts.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); } pts.length = 0; continue; } const Q = cam.clip([[c[0] * 1.002, yc, c[2] * 1.002]], 1)[0]; if (Q) pts.push(Q); } if (pts.length > 1) { ctx.strokeStyle = `rgba(110,85,60,${0.16 * (1 - night * 0.5)})`; ctx.beginPath(); pts.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); } }
  for (let k = 0; k < 16; k++) { const y = 64 + k * 5.2, a = Math.PI * 0.78 - k * 0.035, r = P.ykR2(y), n = ykN2(a, y); if (r * Math.cos(a) > cutz || !faceVis(cam, n, [r * Math.cos(a), y, r * Math.sin(a)])) continue; const da = 2.6 / r, p = (rr, yy, aa) => [rr * Math.cos(aa), yy, rr * Math.sin(aa)]; poly3(ctx, cam, [p(r + 0.4, y, a - da), p(r + 0.4, y, a + da), p(r + 2.6, y + 0.4, a + da), p(r + 2.6, y + 0.4, a - da)], ykShadeA(col, [0, 1, 0], sun, 0.62, night, 1.04)); poly3(ctx, cam, [p(r + 0.4, y - 2.2, a - da), p(r + 0.4, y - 2.2, a + da), p(r + 2.6, y + 0.4, a + da), p(r + 2.6, y + 0.4, a - da)], ykShadeA(col, n, sun, 0.5, night, 0.9)); }
  for (let k = 0; k < 7; k++) for (const da of [-0.06, 0.06]) { const y = 150 + k * 3.4, a = Math.PI / 2 + da + (k % 2) * 0.02, r = P.ykR2(y), n = ykN2(a, y), q = [r * Math.cos(a), y, r * Math.sin(a)]; if (q[0] > cutz || !faceVis(cam, n, q)) continue; const Q = cam.clip([q], 1)[0]; if (Q) { ctx.fillStyle = `rgba(70,50,32,${0.6 * (1 - night * 0.4)})`; ctx.beginPath(); ctx.arc(Q[0], Q[1], Math.max(1, 520 / Q[2]), 0, TAU); ctx.fill(); } } ctx.restore();
  if (!o.noVest && !vestFirst && cutz > 1e8) ykVestibule(ctx, cam, sun, night, col);
  return { top: cam.clip([[0, YK.H, 0]], 1)[0], entrance: cam.clip([[0, ve.doorH * 0.5, ve.z1]], 1)[0], base: cam.clip([[0, 0, YK.R0]], 1)[0], wallPt: (y, a = Math.PI / 2) => cam.clip([[P.ykR2(y) * Math.cos(a), y, P.ykR2(y) * Math.sin(a)]], 1)[0] };
 };
 // Bloque de hielo 3D: caras translúcidas con borde claro (inserto más claro), burbujas y fisuras deterministas, línea de contacto.
 // o: { seed, melt 0..1 (redondea y encoge), dim (luz interior), straw (estera de paja encima, en dm) }
 P.iceBox3 = (ctx, cam, x0, x1, y0, y1, z0, z1, o = {}) => { const m = cl(o.melt || 0), dim = o.dim ?? 1, R = H.rng(o.seed || 1); if (m > 0) { const sx = (x1 - x0) * m * 0.22, sz = (z1 - z0) * m * 0.22; x0 += sx; x1 -= sx; z0 += sz; z1 -= sz; y1 -= (y1 - y0) * m * 0.35; }
  // v1.21.1: material de hielo sólido (blanco azulado poco saturado, núcleo lechoso, canto translúcido, burbujas sutiles) y aristas
  // irregulares (las esquinas superiores se desplazan un poco; la base queda plana para que el bloque apoye)
  const jt = Math.min(x1 - x0, z1 - z0) * (0.05 + m * 0.08), J = () => R.range(-jt, jt), T = [[x0 + J(), y1 + J() * 0.6, z0 + J()], [x1 + J(), y1 + J() * 0.6, z0 + J()], [x1 + J(), y1 + J() * 0.6, z1 + J()], [x0 + J(), y1 + J() * 0.6, z1 + J()]], Bt = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]];
  const F = [[[0, 1, 0], [T[0], T[1], T[2], T[3]], 1.08], [[0, 0, 1], [Bt[3], Bt[2], T[2], T[3]], 0.94], [[0, 0, -1], [Bt[1], Bt[0], T[0], T[1]], 0.8], [[1, 0, 0], [Bt[2], Bt[1], T[1], T[2]], 0.86], [[-1, 0, 0], [Bt[0], Bt[3], T[3], T[0]], 0.9]];
  for (const [n, pts, k] of F) { const c = pts.reduce((s, p) => [s[0] + p[0] / 4, s[1] + p[1] / 4, s[2] + p[2] / 4], [0, 0, 0]); if (!faceVis(cam, n, c)) continue; const kk = k * dim, top = n[1] > 0; const P2 = poly3(ctx, cam, pts, top ? `rgba(${cl(206 * kk, 0, 255) | 0},${cl(220 * kk, 0, 255) | 0},${cl(226 * kk, 0, 255) | 0},0.96)` : `rgba(${cl(150 * kk, 0, 255) | 0},${cl(174 * kk, 0, 255) | 0},${cl(186 * kk, 0, 255) | 0},0.9)`); if (!P2 || P2.length < 3) continue;
   const cx = P2.reduce((s, p) => s + p[0], 0) / P2.length, cy = P2.reduce((s, p) => s + p[1], 0) / P2.length, area = Math.abs(P2.reduce((s, p, i) => { const q = P2[(i + 1) % P2.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0)) / 2, sz2 = Math.sqrt(area);
   ctx.save(); ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.clip();
   if (!top && sz2 > 6) { const g = ctx.createRadialGradient(cx + R.range(-0.15, 0.15) * sz2, cy + R.range(-0.1, 0.15) * sz2, 0, cx, cy, sz2 * 0.7); g.addColorStop(0, `rgba(238,244,246,${0.38 * dim})`); g.addColorStop(1, 'rgba(238,244,246,0)'); ctx.fillStyle = g; ctx.fillRect(cx - sz2, cy - sz2, 2 * sz2, 2 * sz2); }
   ctx.strokeStyle = `rgba(225,236,240,${0.22 * dim})`; ctx.lineWidth = Math.max(2, sz2 * 0.16); ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke();
   if (area > 1500 && P2.length === 4 && !top) { const nb = Math.min(5, 1 + (area / 5000) | 0); for (let b = 0; b < nb; b++) { const u = 0.2 + R() * 0.6, v = 0.25 + R() * 0.6, A2 = [lerp(P2[0][0], P2[1][0], u), lerp(P2[0][1], P2[1][1], u)], B2 = [lerp(P2[3][0], P2[2][0], u), lerp(P2[3][1], P2[2][1], u)], x = lerp(A2[0], B2[0], v), y = lerp(A2[1], B2[1], v), rr = Math.max(0.8, sz2 * (0.006 + R() * 0.01)); ctx.fillStyle = `rgba(250,252,253,${0.32 * dim})`; for (let q = 0; q < 4; q++) { ctx.beginPath(); ctx.ellipse(x, y - q * rr * 3.2, rr * 0.7, rr * 1.3, 0, 0, TAU); ctx.fill(); } } if (R() < 0.5) { ctx.strokeStyle = `rgba(245,250,252,${0.22 * dim})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx - sz2 * 0.2, cy - sz2 * 0.15); ctx.lineTo(cx + sz2 * R.range(-0.1, 0.25), cy + sz2 * 0.12); ctx.stroke(); } }
   ctx.restore(); ctx.strokeStyle = `rgba(240,247,250,${0.38 * dim})`; ctx.lineWidth = 1; ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke();
   if (!top) { ctx.strokeStyle = `rgba(18,24,30,${0.55 * dim})`; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(P2[0][0], P2[0][1]); ctx.lineTo(P2[1][0], P2[1][1]); ctx.stroke(); } }
  if (o.straw) { const s = o.straw; P.box3(ctx, cam, x0 - 0.5, x1 + 0.5, y1, y1 + s, z0 - 0.5, z1 + 0.5, '#a08a62', { k: dim * 0.95 }); } };
 // Pila de bloques del depósito (variados, estables, con separadores de paja entre capas cuando o.straw). Devuelve la lista de bloques
 // { x0,x1,y0,y1,z0,z1,seed } para dibujarlos ordenados por profundidad junto con otros objetos. fill 0..1 = altura de la pila.
 P.ykIceStack = (o = {}) => { const R = H.rng(o.seed || 11), out = [], st = o.straw ?? 1.2, fill = cl(o.fill ?? 1), Hmax = YK.pitD * fill, sa = YK2.stair; let y = -YK.pitD + 1, layer = 0;
  while (y < -YK.pitD + Hmax - 2) { const bh = Math.min(R.range(7.5, 10.5), -YK.pitD + Hmax - y), rx = R.range(-7, 7); for (let z = -YK2.pitR0 + 2, zr = 0; z < YK2.pitR0 - 2; zr++) { const bd = 10 + 5 * ykHash(zr, 7); for (let x = -YK2.pitR0 + 2 + rx; x < YK2.pitR0 - 2;) { const bw = R.range(11, 18), x0 = x + 0.6, x1 = x + bw - 0.6, z0 = z + 0.6, z1 = z + bd - 0.6, rP = P.ykPitR(y + bh) - 3; const corners = [[x0, z0], [x1, z0], [x0, z1], [x1, z1]]; const inside = corners.every(([cx, cz]) => Math.hypot(cx, cz) < rP); const inStair = corners.some(([cx, cz]) => { const a = (Math.atan2(cz, cx) + TAU) % TAU; return Math.hypot(cx, cz) > rP - sa.w - 4 && a > sa.a0 - 0.12 && a < sa.a1 + 0.12; }); const sup = layer === 0 || out.some((c) => c.layer === layer - 1 && Math.max(0, Math.min(c.x1, x1) - Math.max(c.x0, x0)) * Math.max(0, Math.min(c.z1, z1) - Math.max(c.z0, z0)) > 0.4 * (x1 - x0) * (z1 - z0)); if (inside && !inStair && sup) out.push({ x0, x1, y0: y, y1: y + bh - (o.straw === 0 ? 0 : 0.3), z0, z1, seed: (layer * 977 + out.length * 31) | 0, layer }); x += bw; } z += bd; } y += bh + st; layer++; }
  return out; };
 const ykDrawList = (ctx, cam, list) => { list.sort((a, b) => b.d - a.d); for (const it of list) it.f(); };
 // Dibuja el DEPÓSITO excavado y la cúpula en CORTE por el plano x = c (vista desde el ESTE: sur a la izquierda, norte a la derecha,
 // igual que la sección técnica). Incluye: cara interior de la bóveda (luz indirecta y oclusión cerca del suelo), sección de la pared
 // con su espesor, paso de la entrada sur atravesando la pared, rellano interior, muro de contención ataluzado con revestimiento de
 // adobe, escalera tallada en el muro (desde la entrada, sector sur → oeste, fuera del hielo), suelo con sumidero y canal de drenaje
 // hacia el norte, pila de hielo variada con paja y caras de corte del terreno. o: { c, ice (fill), melt, straw, actors:[{d,f}], night,
 // sun, warm, dim, seed, stack }
 P.ykCutawayRaw = (ctx, cam, t, o = {}) => { const c = o.c ?? 0, night = cl(o.night || 0), sun = o.sun || P.ykSun(45), N = 72, rings = ykRings(28), dimIn = (o.dim ?? 1) * (1 - night * 0.45), warm = o.warm || 0;
  const inC = (y, k) => { const b = ykK('#a88a64', k * dimIn); return `rgb(${cl(b[0] + warm * 18, 0, 255) | 0},${cl(b[1] + warm * 6, 0, 255) | 0},${cl(b[2] - warm * 6, 0, 255) | 0})`; };
  const q = (r, a, y) => [Math.min(c, r * Math.cos(a)), y, r * Math.sin(a)], gone = (r0, r1, a) => Math.min(r0, r1) * Math.cos(a) > c;
  // 1 · cara interior de la bóveda (mitad oeste)
  for (let j = 0; j < rings.length - 1; j++) { const y0 = rings[j] * (1 - YK2.top / YK.H), y1 = rings[j + 1] * (1 - YK2.top / YK.H), r0 = P.ykRin2(y0), r1 = P.ykRin2(y1), ym = (y0 + y1) / 2; for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU, am = (a0 + a1) / 2; if (gone(r0, r1, am)) continue; const rm = P.ykRin2(ym), n = ykN2(am, ym, -1), cc = [rm * Math.cos(am), ym, rm * Math.sin(am)]; if (!faceVis(cam, n, cc)) continue; const k = (0.42 + 0.4 * cl(ym / 120) + 0.15 * Math.max(0, -Math.cos(am))) * ykTex(am, ym + 40, i, j), f = inC(ym, k); poly3(ctx, cam, [q(r0, a0, y0), q(r0, a1, y0), q(r1, a1, y1), q(r1, a0, y1)], f, { stroke: f, lw: 1.1 }); } }
  // 2 · rellano interior (anillo entre el pozo y la pared)
  for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU; if (gone(YK2.pitR0, YK2.pitR0, (a0 + a1) / 2)) continue; const ro = P.ykRin2(0), f = inC(0, 0.62); poly3(ctx, cam, [q(YK2.pitR0, a0, 0.2), q(YK2.pitR0, a1, 0.2), q(ro, a1, 0.2), q(ro, a0, 0.2)], f, { stroke: f, lw: 1 }); }
  // 3 · muro de contención (cara interior) con revestimiento de adobe y juntas
  const NP = 64, pr = [0, -12, -24, -36, -48, -YK.pitD]; for (let j = 0; j < pr.length - 1; j++) { const y0 = pr[j], y1 = pr[j + 1]; for (let i = 0; i < NP; i++) { const a0 = (i / NP) * TAU, a1 = ((i + 1) / NP) * TAU, am = (a0 + a1) / 2; if (gone(YK2.pitR1, YK2.pitR1, am)) continue; const n = [-Math.cos(am), 0, -Math.sin(am)], rr = P.ykPitR((y0 + y1) / 2), cc = [rr * Math.cos(am), (y0 + y1) / 2, rr * Math.sin(am)]; if (!faceVis(cam, n, cc)) continue; const k = (0.36 + 0.3 * (1 + (y0 + y1) / 2 / YK.pitD)) * (0.95 + 0.1 * ykHash(i, j)); poly3(ctx, cam, [q(P.ykPitR(y0), a0, y0), q(P.ykPitR(y0), a1, y0), q(P.ykPitR(y1), a1, y1), q(P.ykPitR(y1), a0, y1)], inC(0, k * 1.1), { stroke: `rgba(60,42,28,${0.5 * dimIn})`, lw: 1 }); } }
  // 4 · suelo del pozo, sumidero central y canal de drenaje hacia el norte
  { const pts = []; for (let i = 0; i <= 40; i++) { const a = Math.PI / 2 + (i / 40) * Math.PI; pts.push(q(YK2.pitR1, a, -YK.pitD)); } poly3(ctx, cam, pts, inC(0, 0.34)); const fy = -YK.pitD + 0.1, sq = (x0, x1, z0, z1, f) => poly3(ctx, cam, [[x0, fy, z0], [Math.min(c, x1), fy, z0], [Math.min(c, x1), fy, z1], [x0, fy, z1]], f); sq(-3, 3, -YK2.pitR1, -7, 'rgba(20,14,10,0.85)'); sq(-7, 7, -7, 7, '#140f0b'); const ml = cl(o.melt || 0); if (ml > 0) { sq(-6, 6, -6, 6, `rgba(90,160,200,${0.5 + 0.4 * ml})`); sq(-2, 2, -YK2.pitR1, -7, `rgba(90,160,200,${0.35 + 0.4 * ml})`); } }
  // 5 · escalera tallada en el muro: baja desde el rellano de la entrada (sur) girando hacia el oeste; el hielo no la invade
  // v1.21.1: cada peldaño es un bloque MACIZO de adobe que baja hasta el fondo y se apoya en el muro (sin peldaños suspendidos), con
  // sombra de contacto bajo la nariz del peldaño superior y canto iluminado
  const list = [], sa = YK2.stair, NS = 14; for (let k = 0; k < NS; k++) { const a0 = lerp(sa.a0, sa.a1, k / NS), a1 = lerp(sa.a0, sa.a1, (k + 1) / NS), yT = -(k + 1) * (YK.pitD / NS), rO = P.ykPitR(yT) + 1.5, rI = rO - sa.w, am = (a0 + a1) / 2; if (rI * Math.cos(am) > c) continue;
   list.push({ d: cam.depth([(rI + sa.w / 2) * Math.cos(am), yT - 6, (rI + sa.w / 2) * Math.sin(am)]), f: () => { const yB = -YK.pitD, sd2 = (aa, sg) => { const n = [-Math.sin(aa) * sg, 0, Math.cos(aa) * sg]; if (faceVis(cam, n, [(rI + 2) * Math.cos(aa), yT - 3, (rI + 2) * Math.sin(aa)])) poly3(ctx, cam, [q(rI, aa, yT), q(rO, aa, yT), q(rO, aa, yB), q(rI, aa, yB)], inC(0, 0.58), { stroke: inC(0, 0.58), lw: 1 }); };
    sd2(a0, -1); sd2(a1, 1); const nI = [-Math.cos(am), 0, -Math.sin(am)]; if (faceVis(cam, nI, [rI * Math.cos(am), yT - 6, rI * Math.sin(am)])) { poly3(ctx, cam, [q(rI, a0, yT), q(rI, a1, yT), q(rI, a1, yB), q(rI, a0, yB)], inC(0, 0.5), { stroke: inC(0, 0.5), lw: 1 }); poly3(ctx, cam, [q(rI, a0, yT), q(rI, a1, yT), q(rI, a1, yT - 1.2), q(rI, a0, yT - 1.2)], inC(0, 0.95)); }
    poly3(ctx, cam, [q(rI, a0, yT), q(rO, a0, yT), q(rO, a1, yT), q(rI, a1, yT)], inC(0, 0.9), { stroke: `rgba(60,42,28,${0.55 * dimIn})`, lw: 1 }); const as = lerp(a0, a1, 0.28); poly3(ctx, cam, [q(rI, a0, yT + 0.05), q(rO, a0, yT + 0.05), q(rO, as, yT + 0.05), q(rI, as, yT + 0.05)], `rgba(30,20,12,${0.35 * dimIn})`); } }); }
  // 6 · hielo (bloques variados, apilados y estables; la capa superior se funde primero con o.melt)
  const stack = o.stack || P.ykIceStack({ fill: o.ice ?? 1, straw: o.straw ?? 1.2, seed: o.seed || 11 }), ml = cl(o.melt || 0), topL = stack.reduce((s, b) => Math.max(s, b.layer), 0), st = o.straw ?? 1.2;
  for (const b of stack) { if (b.x0 > c) continue; const x1 = Math.min(c, b.x1), lm = ml > 0 ? cl((ml * (topL + 1.5) - (topL - b.layer)) / 1.5) : 0; if (lm >= 0.999) continue; const d = cam.depth([(b.x0 + x1) / 2, (b.y0 + b.y1) / 2, (b.z0 + b.z1) / 2]); list.push({ d, f: () => P.iceBox3(ctx, cam, b.x0, x1, b.y0, b.y1, b.z0, b.z1, { seed: b.seed, melt: lm, dim: (0.8 + 0.25 * cl(1 + b.y1 / YK.pitD)) * dimIn, straw: b.layer < topL && st > 0 && lm === 0 ? st - 0.3 : 0 }) }); }
  for (const a of o.actors || []) list.push(a); ykDrawList(ctx, cam, list);
  // 6b · cámara dentro de la cúpula: el rellano cercano tapa lo que queda bajo su borde
  if (c > 1e8 && cam.pos[1] > 0) { const d0 = cam.depth([0, 0, 0]); for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU, am = (a0 + a1) / 2, ro = P.ykRin2(0); if (cam.depth([76 * Math.cos(am), 0, 76 * Math.sin(am)]) > d0) continue; const f = inC(0, 0.62); poly3(ctx, cam, [q(YK2.pitR0, a0, 0.2), q(YK2.pitR0, a1, 0.2), q(ro, a1, 0.2), q(ro, a0, 0.2)], f, { stroke: f, lw: 1 }); } }
  // 7 · caras de corte (plano x = c): terreno con estratos, revestimiento, zanja de corte y sección de la envolvente con la entrada
  const X = YK2.cut.X, D = YK2.cut.D, Z = YK2.cut.Z, P3 = (z, y) => [c, y, z]; if (faceVis(cam, [1, 0, 0], [c, -10, 0])) {
   const half = Math.sqrt(Math.max(0, YK2.pitR0 ** 2 - c * c)), halfB = Math.sqrt(Math.max(0, YK2.pitR1 ** 2 - c * c)); const P1 = cam.clip([P3(-X, 0), P3(X, 0), P3(X, -D), P3(-X, -D)], 1), P2 = cam.clip([P3(-half, 0), P3(-halfB, -YK.pitD), P3(halfB, -YK.pitD), P3(half, 0)], 1);
   if (P1.length > 2) { ctx.save(); ctx.beginPath(); P1.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); if (half > 0 && P2.length > 2) { P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); } const g0 = cam.clip([P3(0, 0)], 1)[0], g1 = cam.clip([P3(0, -D)], 1)[0]; const g = ctx.createLinearGradient(0, g0 ? g0[1] : 0, 0, g1 ? g1[1] : 1); g.addColorStop(0, P.mixc('#b08a5c', '#4a3a2c', night)); g.addColorStop(1, P.mixc('#6e5236', '#2c241c', night)); ctx.fillStyle = g; ctx.fill('evenodd'); ctx.clip('evenodd'); ctx.strokeStyle = 'rgba(60,40,20,0.22)'; ctx.lineWidth = 2; for (let k = 1; k < 7; k++) { const yy = -k * D / 7, A2 = cam.clip([P3(-X, yy), P3(X, yy)], 1); if (A2.length === 2) { ctx.beginPath(); for (let s = 0; s <= 20; s++) { const x = lerp(A2[0][0], A2[1][0], s / 20), y = lerp(A2[0][1], A2[1][1], s / 20) + Math.sin(s * 1.3 + k) * 3; s ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke(); } } const R5 = H.rng(77); ctx.fillStyle = 'rgba(70,48,28,0.3)'; for (let k = 0; k < 90; k++) { const Q = cam.clip([P3(R5.range(-X, X), -R5.range(2, D))], 1)[0]; if (Q) { ctx.beginPath(); ctx.arc(Q[0], Q[1], 1 + R5() * 2.5, 0, TAU); ctx.fill(); } } ctx.restore();
    if (half > 0) for (const sx of [-1, 1]) poly3(ctx, cam, [P3(sx * half, 0), P3(sx * (half + 4), 0), P3(sx * (halfB + 4), -YK.pitD - 4), P3(sx * halfB, -YK.pitD)], P.mixc('#9c7a52', '#3e3328', night), { stroke: 'rgba(60,40,22,0.6)', lw: 1 }); }
   { const tf = P.mixc('#c2a072', '#3a2e24', night); poly3(ctx, cam, [[c, -D, -X], [c, -D, X], [Z, -D, X], [Z, -D, -X]], tf); for (const sz of [-1, 1]) if (faceVis(cam, [0, 0, -sz], [(c + Z) / 2, -D / 2, sz * X])) { const PP = poly3(ctx, cam, [[c, 0, sz * X], [Z, 0, sz * X], [Z, -D, sz * X], [c, -D, sz * X]], P.mixc('#a8845a', '#3a2e24', night)); if (PP) { ctx.save(); ctx.strokeStyle = 'rgba(60,40,20,0.2)'; ctx.lineWidth = 2; for (let k = 1; k < 6; k++) { const A2 = cam.clip([[c, -k * D / 6, sz * X], [Z, -k * D / 6, sz * X]], 1); if (A2.length === 2) { ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } ctx.restore(); } } }
   // sección de la envolvente (polígono único: exterior por arriba, interior por abajo)
   const out = [], inn = []; for (let y = 0; y <= YK.H; y += 2.5) { const zo = Math.sqrt(Math.max(0, P.ykR2(y) ** 2 - c * c)); if (zo <= 0) break; out.push([zo, y]); } const outL = out.map(([z, y]) => [-z, y]).concat(out.slice().reverse()); for (let y = 0; y <= YK.H; y += 2.5) { const zi = Math.sqrt(Math.max(0, P.ykRin2(y) ** 2 - c * c)); if (zi <= 0) break; inn.push([zi, y]); }
   const Ppts = outL.concat(inn).concat(inn.slice().reverse().map(([z, y]) => [-z, y])); const S = cam.clip(Ppts.map(([z, y]) => P3(z, y)), 1); if (S.length > 2) { ctx.save(); ctx.beginPath(); S.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = ykShade('#c4a47c', [1, 0, 0], sun, 0.75, night); ctx.fill(); ctx.clip(); const R6 = H.rng(5); ctx.fillStyle = 'rgba(90,62,38,0.22)'; for (let k = 0; k < 140; k++) { const y = R6() * YK.H, zo = P.ykR2(y), Q = cam.clip([P3(R6.range(-zo, zo), y)], 1)[0]; if (Q) { ctx.beginPath(); ctx.arc(Q[0], Q[1], 1 + R6() * 2, 0, TAU); ctx.fill(); } } ctx.strokeStyle = 'rgba(110,80,52,0.25)'; ctx.lineWidth = 1.2; for (let y = 4; y < YK.H; y += 5) { const zo = P.ykR2(y), A2 = cam.clip([P3(-zo, y), P3(zo, y)], 1); if (A2.length === 2) { ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } ctx.restore(); ctx.strokeStyle = 'rgba(70,45,25,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); S.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke(); }
   // vestíbulo y paso de la entrada (sur) en sección: bóveda de adobe y hueco que atraviesa la pared hasta el rellano
   const e = YK2.ent; if (Math.abs(c) < e.w / 2) { const vt = []; for (let k = 0; k <= 12; k++) { const u = k / 12; vt.push(P3(lerp(e.z1, P.ykRin2(0) - 2, u), 0)); } const vs = [P3(P.ykR2(e.h + e.vault) - 1, e.h + e.vault * 0.85), P3(e.z1, e.h + e.vault * 0.85), P3(e.z1, 0), P3(P.ykR2(0) - 1, 0)]; poly3(ctx, cam, vs, ykShade('#c4a47c', [1, 0, 0], sun, 0.75, night), { stroke: 'rgba(70,45,25,0.7)', lw: 2 }); const dp = []; for (let k = 0; k <= 10; k++) { const u = k / 10; dp.push(P3(lerp(e.z1 + 0.5, P.ykRin2(0) - 3, u), e.doorH)); } poly3(ctx, cam, [P3(e.z1 + 0.5, 0.3), P3(P.ykRin2(0) - 3, 0.3), ...dp.reverse()], night > 0.5 ? '#16110c' : '#4a3a2a', { stroke: 'rgba(40,28,18,0.7)', lw: 1.5 }); }
  }
  return { pit: cam.clip([[Math.min(c, 0) - 10, -YK.pitD * 0.5, 0]], 1)[0], drain: cam.clip([[0, -YK.pitD, 0]], 1)[0], wall: cam.clip([P3((P.ykR2(30) + P.ykRin2(30)) / 2, 30)], 1)[0], wallN: cam.clip([P3(-(P.ykR2(30) + P.ykRin2(30)) / 2, 30)], 1)[0], entrance: cam.clip([P3(YK2.ent.z1 - 10, YK2.ent.doorH * 0.5)], 1)[0], chamber: cam.clip([[c - 30, 70, 0]], 1)[0], stairPt: (k) => { const a = lerp(sa.a0, sa.a1, (k + 0.5) / NS), y = -(k + 1) * (YK.pitD / NS), r = P.ykPitR(y) + 0.5 - sa.w / 2; return [r * Math.cos(a), y, r * Math.sin(a)]; }, landing: [Math.min(c, -4), 0.2, YK2.pitR0 + 4] };
 };
 // Estanque histórico en 3D: excavación poco profunda con bordes de tierra/adobe (caballón), taludes interiores, lámina de agua con
 // volumen (oscurece hacia el centro), ondas, y cristales de hielo que crecen desde las orillas y se extienden (o.ice 0..1).
 // o: { water 0..1, ice 0..1, night, sun, t, ripple 0..1, thick (capas visibles en el borde), dry (verano: fondo agrietado) }
 const ykPond3 = (ctx, cam, t, o = {}) => { const p = YK.pond, sun = o.sun, night = o.night || 0, d = 4, lv = 2.4, b = 7, earth = '#c4a173';
  const lev = [[p.x0 - b, p.x1 + b, p.z0 - b, p.z0], [p.x0 - b, p.x1 + b, p.z1, p.z1 + b], [p.x0 - b, p.x0, p.z0, p.z1], [p.x1, p.x1 + b, p.z0, p.z1]];
  const levCol = ykHex(H.mix(earth, '#2a2420', night * 0.6)); const drawLev = (L) => P.box3(ctx, cam, L[0], L[1], 0, lv, L[2], L[3], levCol, { k: 0.95 });
  const near = lev.map((L) => ({ L, d: cam.depth([(L[0] + L[1]) / 2, 1, (L[2] + L[3]) / 2]) })).sort((a2, b2) => b2.d - a2.d); const cz = (p.z0 + p.z1) / 2, cx = 0;
  const far = near.filter((q) => q.d > cam.depth([cx, 0, cz])), nearL = near.filter((q) => q.d <= cam.depth([cx, 0, cz])); for (const q of far) drawLev(q.L);
  // taludes interiores (visibles los que miran a la cámara) y fondo
  const ins = 5, sl = [[[p.x0, 0, p.z0], [p.x1, 0, p.z0], [p.x1 - ins, -d, p.z0 + ins], [p.x0 + ins, -d, p.z0 + ins], [0, 0.6, 0.8]], [[p.x1, 0, p.z1], [p.x0, 0, p.z1], [p.x0 + ins, -d, p.z1 - ins], [p.x1 - ins, -d, p.z1 - ins], [0, 0.6, -0.8]], [[p.x0, 0, p.z1], [p.x0, 0, p.z0], [p.x0 + ins, -d, p.z0 + ins], [p.x0 + ins, -d, p.z1 - ins], [0.8, 0.6, 0]], [[p.x1, 0, p.z0], [p.x1, 0, p.z1], [p.x1 - ins, -d, p.z1 - ins], [p.x1 - ins, -d, p.z0 + ins], [-0.8, 0.6, 0]]];
  for (const s of sl) { const n = s[4]; if (faceVis(cam, n, [(s[0][0] + s[2][0]) / 2, -d / 2, (s[0][2] + s[2][2]) / 2])) poly3(ctx, cam, s.slice(0, 4), o.dry ? ykShade('#b89668', n, sun, 0.6, night) : ykShade('#8a6a48', n, sun, 0.55, night)); }
  poly3(ctx, cam, [[p.x0 + ins, -d, p.z0 + ins], [p.x1 - ins, -d, p.z0 + ins], [p.x1 - ins, -d, p.z1 - ins], [p.x0 + ins, -d, p.z1 - ins]], o.dry ? ykShade('#c9a979', [0, 1, 0], sun, 0.62, night) : '#5e4a36');
  if (o.dry) { const R = H.rng(41); ctx.save(); ctx.strokeStyle = 'rgba(90,64,40,0.5)'; ctx.lineWidth = 1.3; for (let k = 0; k < 70; k++) { let x = R.range(p.x0 + 10, p.x1 - 10), z = R.range(p.z0 + 10, p.z1 - 10); const pts = [[x, -d + 0.1, z]]; for (let s = 0; s < 4; s++) { x += R.range(-14, 14); z += R.range(-8, 8); pts.push([x, -d + 0.1, z]); } const Q = pts.map((q) => cam.clip([q], 1)[0]); if (Q.some((q) => !q)) continue; ctx.beginPath(); Q.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.stroke(); } ctx.restore(); }
  // agua (se llena desde el canal del oeste) con volumen: más oscura en el centro
  const wa = cl(o.water ?? 0), ia = cl(o.ice ?? 0), wy = -1.4, wi = ins * (1 - (d + wy) / d); if (wa > 0) { const xw = lerp(p.x0 + wi, p.x1 - wi, wa), wc = night > 0.5 ? '#1d3a58' : '#3f86ad'; const PW = poly3(ctx, cam, [[p.x0 + wi, wy, p.z0 + wi], [xw, wy, p.z0 + wi], [xw, wy, p.z1 - wi], [p.x0 + wi, wy, p.z1 - wi]], P.mixc(wc, '#0d1b2e', night * 0.5));
   if (PW) { const A2 = cam.clip([[0, wy, p.z0 + 10]], 1)[0], B2 = cam.clip([[0, wy, p.z1 - 10]], 1)[0]; if (A2 && B2) { ctx.save(); ctx.beginPath(); PW.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.clip(); const g = ctx.createLinearGradient(0, A2[1], 0, B2[1]); g.addColorStop(0, `rgba(255,255,255,${0.12 * (1 - night)})`); g.addColorStop(0.5, 'rgba(0,10,30,0.18)'); g.addColorStop(1, `rgba(255,255,255,${0.1 + 0.08 * night})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); ctx.restore(); } }
   // ondas (antes de congelarse)
   const rp = cl(o.ripple ?? (1 - ia * 3)); if (rp > 0) { ctx.save(); for (let k = 0; k < 9; k++) { const R = H.rng(200 + k), x0 = R.range(p.x0 + 30, Math.max(p.x0 + 31, xw - 30)), z0 = R.range(p.z0 + 20, p.z1 - 20), ph = ((t || 0) * 0.45 + R()) % 1, rr = 4 + ph * 34; const pts = []; for (let i = 0; i <= 28; i++) { const a = (i / 28) * TAU; pts.push([x0 + Math.cos(a) * rr * 1.4, wy + 0.05, z0 + Math.sin(a) * rr * 0.8]); } const Q = pts.map((q) => cam.clip([q], 1)[0]); if (Q.some((q) => !q)) continue; ctx.strokeStyle = `rgba(220,240,255,${0.45 * rp * (1 - ph)})`; ctx.lineWidth = 1.6; ctx.beginPath(); Q.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.stroke(); } ctx.restore(); }
   // cristales que crecen desde las orillas (celdas con umbral = distancia a la orilla + ruido)
   if (ia > 0) { const NX = 80, NZ = 18, R = H.rng(9); for (let ix = 0; ix < NX; ix++) for (let iz = 0; iz < NZ; iz++) { const x0 = lerp(p.x0 + wi, p.x1 - wi, ix / NX), x1 = lerp(p.x0 + wi, p.x1 - wi, (ix + 1) / NX); if (x0 > xw) continue; const z0 = lerp(p.z0 + wi, p.z1 - wi, iz / NZ), z1 = lerp(p.z0 + wi, p.z1 - wi, (iz + 1) / NZ), de = Math.min(ix + 0.5, NX - ix - 0.5, (iz + 0.5) * NX / NZ * 0.5, (NZ - iz - 0.5) * NX / NZ * 0.5) / (NX * 0.5), th = 0.7 * de + 0.12 * (Math.sin(ix * 0.37 + iz * 0.9) * 0.5 + 0.5) + 0.1 * ykHash(ix, iz), f = cl((ia - th) / 0.3); if (f <= 0) continue;
     poly3(ctx, cam, [[x0, wy + 0.08, z0], [Math.min(xw, x1), wy + 0.08, z0], [Math.min(xw, x1), wy + 0.08, z1], [x0, wy + 0.08, z1]], `rgba(${night > 0.5 ? '170,205,225' : '214,236,246'},${0.85 * f})`, { stroke: `rgba(${night > 0.5 ? '170,205,225' : '214,236,246'},${0.85 * f})`, lw: 0.8 });
     const Rc = H.rng(ix * 31 + iz * 7 + 3), nC = (ix + iz) % 3 === 0 ? 1 : 0; ctx.strokeStyle = `rgba(250,253,255,${0.65 * f})`; ctx.lineWidth = 1.1; for (let k = 0; k < nC; k++) { const cx2 = Rc.range(x0, x1), cz2 = Rc.range(z0, z1), L = Rc.range(6, 14) * f; for (let a = 0; a < 3; a++) { const an = a * Math.PI / 3 + Rc() * 0.4, Q = cam.clip([[cx2 - Math.cos(an) * L, wy + 0.1, cz2 - Math.sin(an) * L * 0.6], [cx2 + Math.cos(an) * L, wy + 0.1, cz2 + Math.sin(an) * L * 0.6]], 1); if (Q.length === 2) { ctx.beginPath(); ctx.moveTo(Q[0][0], Q[0][1]); ctx.lineTo(Q[1][0], Q[1][1]); ctx.stroke(); } } } } } }
  for (const q of nearL) drawLev(q.L);
 };
 P.ykPond3 = ykPond3;
 // Muro de sombra de adobe (este–oeste) con hiladas y contrafuertes; sombra de contacto incluida
 const ykShadowWall = (ctx, cam, sun, night) => { const s = YK.swall, col = night > 0.5 ? '#6b5a48' : '#cdb08a'; P.box3(ctx, cam, s.x0, s.x1, 0, s.h, s.z0, s.z1, col, { k: 1 });
  const fN = faceVis(cam, [0, 0, -1], [0, s.h / 2, s.z0]), z = fN ? s.z0 - 0.3 : s.z1 + 0.3; ctx.save(); ctx.strokeStyle = `rgba(90,64,40,${0.28 * (1 - night * 0.5)})`; ctx.lineWidth = 1.2; for (let y = 6; y < s.h; y += 6) { const A2 = cam.clip([[s.x0, y, z], [s.x1, y, z]], 1); if (A2.length === 2) { ctx.beginPath(); ctx.moveTo(A2[0][0], A2[0][1]); ctx.lineTo(A2[1][0], A2[1][1]); ctx.stroke(); } } ctx.restore();
  const top = []; for (let x = s.x0; x <= s.x1; x += 20) top.push([x, s.h + (((x / 20) | 0) % 2 ? 2 : 0.5)]); };
 // Rayos del sol (amarillos, discontinuos y en movimiento) que rozan la arista superior del muro y marcan el borde de la sombra;
 // los rayos más bajos chocan con la cara sur del muro. o: { a (alfa), xs (posiciones x), L (largo) }
 P.ykSunRays = (ctx, cam, sun, t, o = {}) => { const s = YK.swall, a = o.a ?? 1, L = o.L ?? 520; if (a <= 0 || sun[1] <= 0.02) return null; ctx.save(); ctx.globalAlpha *= a; ctx.lineCap = 'round'; const xs = o.xs || [-260, -130, 0, 130, 260]; let edge = null;
  for (const x of xs) { const pTop = [x, s.h, s.z1], pN = [x, s.h, s.z0], g = P.ykShadow(pN, sun), src = [pTop[0] + sun[0] * L, pTop[1] + sun[1] * L, pTop[2] + sun[2] * L]; const Q = cam.clip([src, pTop], 1), Q2 = cam.clip([pN, g], 1);
   if (Q.length === 2) { ctx.strokeStyle = 'rgba(255,212,71,0.95)'; ctx.lineWidth = 4; ctx.setLineDash([18, 12]); ctx.lineDashOffset = -(t || 0) * 60; ctx.beginPath(); ctx.moveTo(Q[0][0], Q[0][1]); ctx.lineTo(Q[1][0], Q[1][1]); ctx.stroke(); }
   if (Q2.length === 2) { ctx.beginPath(); ctx.moveTo(Q2[0][0], Q2[0][1]); ctx.lineTo(Q2[1][0], Q2[1][1]); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#FFD447'; ctx.beginPath(); ctx.arc(Q2[1][0], Q2[1][1], 6, 0, TAU); ctx.fill(); edge = edge || Q2[1]; }
   const low = [x + 40, s.h * 0.45, s.z1], srcL = [low[0] + sun[0] * L * 0.8, low[1] + sun[1] * L * 0.8, low[2] + sun[2] * L * 0.8], QL = cam.clip([srcL, low], 1); if (QL.length === 2) { ctx.setLineDash([18, 12]); ctx.strokeStyle = 'rgba(255,212,71,0.75)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(QL[0][0], QL[0][1]); ctx.lineTo(QL[1][0], QL[1][1]); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = 'rgba(255,170,80,0.8)'; ctx.beginPath(); ctx.arc(QL[1][0], QL[1][1], 5, 0, TAU); ctx.fill(); } }
  ctx.setLineDash([]); ctx.restore(); return { edge }; };
 // Escena completa v1.21 (sustituye a ykWorld en los episodios nuevos): cielo, terreno con relieve lejano, canal, estanque histórico,
 // camino desde el vestíbulo, sombras de muro y cúpula (silueta completa), muro de adobe, cúpula curva, casas lejanas y, si o.cut,
 // el DEPÓSITO en corte (zanja de corte |x| ≤ 170, z = c … 150, profundidad 95 dm). o como ykWorld + { cut:{c,...}, rays, dry, ripple,
 // skyTop/skyMid (colores de cielo), haze, actors (objetos 3D ordenados con la cúpula: [{d,f}]) }
 // v1.21.1: con transparencia global (fundidos entre planos) la escena se dibuja opaca en una capa y se funde entera; así las juntas
 // entre caras no aparecen como una malla durante el fundido
 let ykOff = null; const ykLayer = (ctx, fn) => { if (ctx.globalAlpha > 0.999 || typeof document === 'undefined') return fn(ctx); if (!ykOff) { ykOff = document.createElement('canvas'); ykOff.width = W; ykOff.height = HH; } const c2 = ykOff.getContext('2d'); c2.setTransform(1, 0, 0, 1, 0, 0); c2.clearRect(0, 0, W, HH); c2.globalAlpha = 1; c2.setTransform(ctx.getTransform()); const r = fn(c2); ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(ykOff, 0, 0); ctx.restore(); return r; };
 P.ykWorld2 = (ctx, cam, t, o = {}) => ykLayer(ctx, (c) => ykWorld2i(c, cam, t, o));
 P.ykCutaway = (ctx, cam, t, o = {}) => ykLayer(ctx, (c) => P.ykCutawayRaw(c, cam, t, o));
 const ykWorld2i = (ctx, cam, t, o = {}) => { const sun = o.sun || P.ykSun(45), night = cl(o.night || 0), Y = YK, cut = o.cut || null;
  const sky = ctx.createLinearGradient(0, 0, 0, HH); sky.addColorStop(0, o.skyTop || P.mixc('#1f6fd0', '#060d1f', night)); sky.addColorStop(0.55, o.skyMid || P.mixc('#8fc0ea', '#14284a', night)); sky.addColorStop(1, P.mixc('#eedcb6', '#1d2a44', night)); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, HH);
  if (night > 0.05) { const R = H.rng(31); ctx.save(); for (let i = 0; i < 200; i++) { ctx.globalAlpha = night * (0.25 + R() * 0.75); ctx.fillStyle = '#e8f0ff'; const x = R() * W, y = R() * HH * 0.6, s = R() < 0.1 ? 3 : 2; ctx.fillRect(x, y, s, s); } ctx.restore(); }
  // montañas lejanas (profundidad) y terreno
  const G = 6000; { const R = H.rng(3), ridge = []; for (let i = 0; i <= 24; i++) { const a = (i / 24) * TAU; ridge.push([Math.cos(a) * 5200, 120 + 160 * Math.abs(Math.sin(a * 3 + 1)) + R() * 90, Math.sin(a) * 5200]); } for (let i = 0; i < 24; i++) { const A2 = ridge[i], B2 = ridge[i + 1]; poly3(ctx, cam, [[A2[0], 0, A2[2]], [B2[0], 0, B2[2]], [B2[0], B2[1], B2[2]], [A2[0], A2[1], A2[2]]], ykHex(H.mix(H.mix('#c9a27a', '#b9c6d6', 0.45), '#141c2c', night)), { near: 1 }); } }
  const gc = ykShade('#d7b98a', [0, 1, 0], sun, 0.62, night); if (!cut) poly3(ctx, cam, [[-G, 0, -G], [G, 0, -G], [G, 0, G], [-G, 0, G]], gc); else { const c = cut.c ?? 0, X = YK2.cut.X, Z = YK2.cut.Z; for (const q of [[-G, G, -G, -X], [-G, G, X, G], [-G, c, -X, X], [Z, G, -X, X]]) poly3(ctx, cam, [[q[0], 0, q[2]], [q[1], 0, q[2]], [q[1], 0, q[3]], [q[0], 0, q[3]]], gc, { stroke: gc, lw: 1 }); }
  const R2 = H.rng(7); for (let i = 0; i < 90; i++) { const x = R2.range(-2200, 2200), z = R2.range(-2200, 1900), s = R2.range(20, 70); if (Math.abs(x) < 460 && z > -160 && z < 380) continue; if (Math.hypot(x - cam.pos[0], z - cam.pos[2]) < 500) continue; poly3(ctx, cam, [[x - s, 0.2, z], [x, 0.2, z - s * 0.4], [x + s, 0.2, z], [x, 0.2, z + s * 0.4]], ykShade(R2() > 0.5 ? '#cfae7f' : '#dcc196', [0, 1, 0], sun, 0.62, night)); }
  const cw = Y.canal.w / 2; poly3(ctx, cam, [[Y.canal.x0, 0.3, Y.canal.z - cw - 5], [Y.canal.x1 - 7, 0.3, Y.canal.z - cw - 5], [Y.canal.x1 - 7, 0.3, Y.canal.z + cw + 5], [Y.canal.x0, 0.3, Y.canal.z + cw + 5]], ykShade('#b89468', [0, 1, 0], sun, 0.6, night)); poly3(ctx, cam, [[Y.canal.x0, 0.5, Y.canal.z - cw], [Y.canal.x1 - 7, 0.5, Y.canal.z - cw], [Y.canal.x1 - 7, 0.5, Y.canal.z + cw], [Y.canal.x0, 0.5, Y.canal.z + cw]], o.dry ? ykShade('#b89668', [0, 1, 0], sun, 0.6, night) : P.mixc('#4a86a8', '#1c3550', night));
  const pw = Y.path.w / 2; const pwx = cut ? Math.min(pw, cut.c ?? 0) : pw; if (pwx > -pw) poly3(ctx, cam, [[-pw, 0.4, YK2.ent.z1], [pwx, 0.4, YK2.ent.z1], [pwx, 0.4, Y.path.z1], [-pw, 0.4, Y.path.z1]], ykShade('#e4cda6', [0, 1, 0], sun, 0.62, night));
  // sombras proyectadas (muro y silueta completa de la cúpula) con el mismo vector solar
  const sa = 0.32 * (1 - night) * cl(sun[1] * 6); if (sa > 0.01 && sun[1] > 0.02) { ctx.save(); ctx.globalAlpha = sa; const s = Y.swall, wp = [[s.x0, s.h, s.z0], [s.x1, s.h, s.z0], [s.x1, s.h, s.z1], [s.x0, s.h, s.z1]].map((q) => P.ykShadow(q, sun)), base = [[s.x0, 0, s.z0], [s.x1, 0, s.z0], [s.x1, 0, s.z1], [s.x0, 0, s.z1]]; poly3(ctx, cam, hull2([...wp, ...base].map((q) => [q[0], q[2]])).map((q) => [q[0], 1.6, q[1]]), '#3a2a1a');
   const dp = []; for (const yy of [0, 30, 60, 90, 120, 145, 160, 172]) { const r = P.ykR2(yy); for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU, q = P.ykShadow([r * Math.cos(a), yy, r * Math.sin(a)], sun); dp.push([q[0], q[2]]); } } if (!cut) poly3(ctx, cam, hull2(dp).map((q) => [q[0], 1.6, q[1]]), '#3a2a1a'); ctx.restore(); }
  ykPond3(ctx, cam, t, { water: o.water, ice: o.ice, night, sun, ripple: o.ripple, dry: o.dry });
  if (o.town) { const R4 = H.rng(19); for (let i = 0; i < 16; i++) { const x = R4.range(-1800, 1800), z = R4.range(-1700, -560), w2 = R4.range(40, 90), h2 = R4.range(30, 60); if (Math.hypot(x - cam.pos[0], z - cam.pos[2]) < 900) continue; P.box3(ctx, cam, x - w2, x + w2, 0, h2, z - w2, z + w2, night > 0.5 ? '#5d5246' : '#c9a979', {}); if (R4() < 0.4) { const r = w2 * 0.8, pts = []; for (let k = 0; k <= 8; k++) { const q = Math.PI * k / 8; pts.push([x + r * Math.cos(q), h2 + r * 0.8 * Math.sin(q), z + w2]); } if (faceVis(cam, [0, 0, 1], [x, h2, z + w2])) poly3(ctx, cam, pts, night > 0.5 ? '#5d5246' : '#d4b689'); } } }
  const s = Y.swall, items = [{ d: cam.depth([0, 60, (s.z0 + s.z1) / 2]), f: () => ykShadowWall(ctx, cam, sun, night) }, { d: cam.depth([0, 60, 0]), f: () => { if (!cut) return P.ykDome2(ctx, cam, t, { sun, night }); const r = P.ykDome2(ctx, cam, t, { sun, night, cutx: cut.c ?? 0, noVest: true }); P.ykCutaway(ctx, cam, t, { ...cut, night, sun }); return r; } }];
  for (const a of o.actors || []) items.push(a); items.sort((a, b) => b.d - a.d); let dr = null; for (const it of items) { const r = it.f(); if (r && r.top !== undefined) dr = r; }
  if (o.rays) P.ykSunRays(ctx, cam, sun, t, { a: o.rays });
  return { dome: dr, pondC: cam.clip([[0, 1, (YK.pond.z0 + YK.pond.z1) / 2]], 1)[0], wallC: cam.clip([[0, s.h, s.z0]], 1)[0], canalC: cam.clip([[Y.canal.x0 * 0.6, 1, Y.canal.z]], 1)[0], pr: (q) => cam.clip([q], 1)[0] };
 };
 // SECCIÓN TÉCNICA v1.21 (2D ortográfica, mismo modelo): perfil curvo exterior e interior con espesor real, revoque de barro y paja
 // (capa exterior clara), núcleo de adobe con hiladas, vestíbulo y paso de la entrada al sur, rellano, pozo ataluzado con revestimiento,
 // escalera en el lado de la entrada (fuera del hielo), sumidero y drenaje al norte, hielo variado con paja, calor cualitativo que se
 // atenúa en la pared (no es una barrera perfecta: llega una pequeña parte), y (o.site) camino, estanque con taludes y muro de sombra.
 // ox = x de pantalla del eje, gy = suelo, s = px/dm. o: { flip (norte a la derecha), ice, melt, heat, site, sun, night, straw, seed,
 // pondIce, grad (gradiente térmico en la pared 0..1), tint (aire interior frío 0..1) }
 P.ykSection2 = (ctx, ox, gy, s, t, o = {}) => { const Y = YK, X = (z) => ox + (o.flip ? -z : z) * s, Yp = (y) => gy - y * s, night = o.night || 0, sun = o.sun || P.ykSun(40), sd = o.flip ? -1 : 1;
  ctx.save();
  const g = ctx.createLinearGradient(0, gy, 0, gy + 100 * s); g.addColorStop(0, P.mixc('#b48c5e', '#4a3a2c', night)); g.addColorStop(1, P.mixc('#6e5236', '#2c241c', night)); ctx.fillStyle = g; ctx.fillRect(0, gy, W, HH - gy); ctx.strokeStyle = 'rgba(60,40,20,0.22)'; ctx.lineWidth = 2; for (let k = 1; k < 7; k++) { ctx.beginPath(); for (let x = 0; x <= W; x += 30) { const yy = gy + k * 15 * s + Math.sin(x * 0.01 + k) * 4; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); } ctx.stroke(); } { const R = H.rng(12); ctx.fillStyle = 'rgba(70,48,28,0.28)'; for (let k = 0; k < 160; k++) { ctx.beginPath(); ctx.arc(R() * W, gy + 6 + R() * 100 * s, 1 + R() * 2.4, 0, TAU); ctx.fill(); } }
  // pozo ataluzado: revestimiento (4 dm) y excavación
  const pit = (gr) => { ctx.beginPath(); ctx.moveTo(X(-YK2.pitR0 - gr), gy); ctx.lineTo(X(-YK2.pitR1 - gr), Yp(-Y.pitD - gr)); ctx.lineTo(X(YK2.pitR1 + gr), Yp(-Y.pitD - gr)); ctx.lineTo(X(YK2.pitR0 + gr), gy); ctx.closePath(); };
  pit(4); ctx.fillStyle = P.mixc('#9c7a52', '#3e3328', night); ctx.fill(); ctx.save(); pit(4); ctx.clip(); ctx.strokeStyle = 'rgba(60,40,22,0.45)'; ctx.lineWidth = 1; for (let y = 0; y > -Y.pitD - 4; y -= 2.2) { ctx.beginPath(); ctx.moveTo(0, Yp(y)); ctx.lineTo(W, Yp(y)); ctx.stroke(); } ctx.restore();
  pit(0); const pg = ctx.createLinearGradient(0, gy, 0, Yp(-Y.pitD)); pg.addColorStop(0, P.mixc('#5a4836', '#1b1611', night)); pg.addColorStop(1, P.mixc('#3a2e22', '#100c09', night)); ctx.fillStyle = pg; ctx.fill(); if (o.tint) { ctx.fillStyle = `rgba(120,180,215,${0.12 * o.tint})`; ctx.fill(); }
  // sumidero y drenaje al norte (−z)
  ctx.fillStyle = '#140f0b'; ctx.fillRect(Math.min(X(-6), X(6)), Yp(-Y.pitD), 12 * s, 8 * s); ctx.strokeStyle = 'rgba(20,14,10,0.9)'; ctx.lineWidth = Math.max(3, 2.2 * s); ctx.beginPath(); ctx.moveTo(X(-6), Yp(-Y.pitD - 6)); ctx.lineTo(X(-YK2.pitR1 - 30), Yp(-Y.pitD - 14)); ctx.stroke(); const mlt = cl(o.melt || 0); if (mlt > 0) { ctx.fillStyle = 'rgba(80,160,200,0.85)'; ctx.fillRect(Math.min(X(-6), X(6)), Yp(-Y.pitD - 8 + 8 * mlt), 12 * s, 8 * mlt * s); ctx.strokeStyle = `rgba(80,160,200,${0.5 + 0.4 * mlt})`; ctx.lineWidth = Math.max(2, 1.4 * s); ctx.setLineDash([10, 8]); ctx.lineDashOffset = -(t || 0) * 30; ctx.beginPath(); ctx.moveTo(X(-6), Yp(-Y.pitD - 6)); ctx.lineTo(X(-YK2.pitR1 - 30), Yp(-Y.pitD - 14)); ctx.stroke(); ctx.setLineDash([]); }
  // escalera en el lado de la entrada (sur): franja tallada en el talud con peldaños (en alzado), separada del hielo por un murete
  const sz = (y) => P.ykPitR(y), sw0 = YK2.stair.w, mz = sz(-Y.pitD) - sw0 - 2; { ctx.beginPath(); ctx.moveTo(X(sz(0)), gy); ctx.lineTo(X(sz(0) - sw0), gy); ctx.lineTo(X(sz(-Y.pitD) - sw0), Yp(-Y.pitD)); ctx.lineTo(X(sz(-Y.pitD)), Yp(-Y.pitD)); ctx.closePath(); ctx.fillStyle = P.mixc('#7a5c3e', '#30261d', night); ctx.fill(); const NS = 12; for (let k = 0; k < NS; k++) { const y1 = -(k + 1) * Y.pitD / NS, za = sz(y1), zb = za - sw0; ctx.fillStyle = P.mixc('#b08a60', '#4a3a2c', night); ctx.fillRect(Math.min(X(za), X(zb)), Yp(y1) - 2, Math.abs(X(za) - X(zb)), Math.max(3, 0.9 * s)); ctx.fillStyle = 'rgba(30,20,12,0.35)'; ctx.fillRect(Math.min(X(za), X(zb)), Yp(y1) + Math.max(3, 0.9 * s) - 2, Math.abs(X(za) - X(zb)), Math.max(4, 1.6 * s)); } }
  ctx.fillStyle = P.mixc('#a8875e', '#3e3328', night); ctx.fillRect(Math.min(X(mz), X(mz - 2.5)), Yp(-Y.pitD + Y.pitD * 0.92), 2.5 * s, Y.pitD * 0.92 * s); ctx.strokeStyle = 'rgba(40,28,18,0.6)'; ctx.lineWidth = 1.2; ctx.strokeRect(Math.min(X(mz), X(mz - 2.5)), Yp(-Y.pitD + Y.pitD * 0.92), 2.5 * s, Y.pitD * 0.92 * s);
  // hielo variado (en el plano x = 0) con paja entre capas y junto al muro
  const R = H.rng(o.seed || 23), st = o.straw ?? 1.2, Hmax = Y.pitD * cl(o.ice ?? 0) + (o.ice > 0.98 ? 0 : 0); let y = -Y.pitD + 0.8, L = 0; const rows = []; while (y < -Y.pitD + Hmax - 2) { const bh = Math.min(R.range(7.5, 10.5), -Y.pitD + Hmax - y); rows.push([y, bh]); y += bh + st; L++; }
  const ml = mlt, nKeep = rows.length - Math.floor(ml * rows.length * 0.999); rows.forEach(([y0, bh], k) => { if (k >= Math.max(0, nKeep + (ml > 0 ? 1 : 0))) return; const part = ml > 0 && k === nKeep ? 1 - ((ml * rows.length) % 1) : 1; if (part <= 0.05) return; const zN = -P.ykPitR(y0 + bh) + 2.2, zS = mz - 1.5; let z = zN + R.range(0, 4); while (z < zS - 4) { const bw = Math.min(R.range(10, 17), zS - z), bhh = bh * (k === nKeep && ml > 0 ? part : 1), x0 = Math.min(X(z), X(z + bw)) + 1.2, yb = Yp(y0 + bhh), w2 = bw * s - 2.4, h2 = bhh * s - 1.2, rr = Math.max(0, Math.min(w2, h2) * (k === nKeep && ml > 0 ? 0.25 : 0.06)); if (w2 <= 1 || h2 <= 1) { z += bw; continue; }
    const gi = ctx.createLinearGradient(x0, yb, x0 + w2, yb + h2); gi.addColorStop(0, '#e9f0f2'); gi.addColorStop(0.55, '#c2d4dc'); gi.addColorStop(1, '#9db6c2'); ctx.fillStyle = gi; ctx.beginPath(); ctx.roundRect(x0, yb, w2, h2, rr); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.55)'; for (let b = 0; b < 4; b++) { ctx.beginPath(); ctx.arc(x0 + R() * w2, yb + R() * h2, 0.8 + R() * 0.25 * s, 0, TAU); ctx.fill(); } ctx.strokeStyle = 'rgba(20,40,55,0.45)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x0, yb + h2); ctx.lineTo(x0 + w2, yb + h2); ctx.stroke(); z += bw; }
   if (st > 0 && k < Math.min(nKeep, rows.length) - 1) { ctx.fillStyle = '#c4a058'; const ya = Yp(y0 + bh + st * 0.85); ctx.fillRect(Math.min(X(zN), X(zS)), ya, Math.abs(X(zS) - X(zN)), st * s * 0.7); ctx.strokeStyle = 'rgba(120,90,40,0.6)'; ctx.lineWidth = 1; for (let xx = Math.min(X(zN), X(zS)); xx < Math.max(X(zN), X(zS)); xx += 7) { ctx.beginPath(); ctx.moveTo(xx, ya); ctx.lineTo(xx + 4, ya + st * s * 0.7); ctx.stroke(); } } });
  // envolvente: núcleo de adobe + revoque exterior claro, perfil curvo con espesor
  const side = (sg) => { ctx.beginPath(); for (let y2 = 0; y2 <= Y.H; y2 += 2) ctx[y2 ? 'lineTo' : 'moveTo'](X(sg * P.ykR2(y2)), Yp(y2)); for (let y2 = Y.H - YK2.top; y2 >= 0; y2 -= 2) ctx.lineTo(X(sg * P.ykRin2(y2)), Yp(y2)); ctx.closePath(); };
  ctx.beginPath(); for (let y2 = 0; y2 <= Y.H; y2 += 2) ctx[y2 ? 'lineTo' : 'moveTo'](X(-P.ykR2(y2)), Yp(y2)); for (let y2 = Y.H; y2 >= 0; y2 -= 2) ctx.lineTo(X(P.ykR2(y2)), Yp(y2)); for (let y2 = 0; y2 <= Y.H - YK2.top; y2 += 2) ctx.lineTo(X(P.ykRin2(y2)), Yp(y2)); for (let y2 = Y.H - YK2.top; y2 >= 0; y2 -= 2) ctx.lineTo(X(-P.ykRin2(y2)), Yp(y2)); ctx.closePath(); const env = new Path2D(); { for (let y2 = 0; y2 <= Y.H; y2 += 2) env[y2 ? 'lineTo' : 'moveTo'](X(-P.ykR2(y2)), Yp(y2)); for (let y2 = Y.H; y2 >= 0; y2 -= 2) env.lineTo(X(P.ykR2(y2)), Yp(y2)); for (let y2 = 0; y2 <= Y.H - YK2.top; y2 += 2) env.lineTo(X(P.ykRin2(y2)), Yp(y2)); for (let y2 = Y.H - YK2.top; y2 >= 0; y2 -= 2) env.lineTo(X(-P.ykRin2(y2)), Yp(y2)); env.closePath(); }
  ctx.fillStyle = P.mixc('#c2a07a', '#4d3f31', night); ctx.fill(env); ctx.save(); ctx.clip(env); ctx.strokeStyle = 'rgba(100,70,44,0.28)'; ctx.lineWidth = 1.3; for (let y2 = 2; y2 < Y.H; y2 += 4.5) { ctx.beginPath(); ctx.moveTo(0, Yp(y2)); ctx.lineTo(W, Yp(y2)); ctx.stroke(); } const R2 = H.rng(8); ctx.fillStyle = 'rgba(90,62,38,0.22)'; for (let k = 0; k < 240; k++) { const yy = R2() * Y.H, zz = R2.range(-P.ykR2(yy), P.ykR2(yy)); ctx.beginPath(); ctx.arc(X(zz), Yp(yy), 0.6 + R2() * 1.8, 0, TAU); ctx.fill(); }
   const gr = cl(o.grad || 0); if (gr > 0) { for (const sg of [-1, 1]) { for (let y2 = 0; y2 < Y.H - YK2.top; y2 += 4) { const r0 = P.ykR2(y2), r1 = P.ykRin2(y2), gg = ctx.createLinearGradient(X(sg * r0), 0, X(sg * r1), 0); gg.addColorStop(0, `rgba(255,120,50,${0.5 * gr})`); gg.addColorStop(0.55, `rgba(255,150,80,${0.12 * gr})`); gg.addColorStop(1, `rgba(120,190,230,${0.25 * gr})`); ctx.fillStyle = gg; ctx.fillRect(Math.min(X(sg * r0), X(sg * r1)), Yp(y2 + 4), Math.abs(X(sg * r0) - X(sg * r1)), 4 * s + 1); } } }
   ctx.restore();
  ctx.save(); ctx.clip(env); ctx.lineWidth = Math.max(5, 3.4 * s); ctx.strokeStyle = P.mixc('#ecdcbf', '#6b5a48', night); ctx.beginPath(); for (let y2 = 0; y2 <= Y.H; y2 += 2) ctx[y2 ? 'lineTo' : 'moveTo'](X(-P.ykR2(y2)), Yp(y2)); for (let y2 = Y.H; y2 >= 0; y2 -= 2) ctx.lineTo(X(P.ykR2(y2)), Yp(y2)); ctx.stroke(); ctx.lineWidth = Math.max(1.5, 0.5 * s); ctx.strokeStyle = 'rgba(120,90,60,0.55)'; ctx.setLineDash([6, 5]); ctx.stroke(); ctx.setLineDash([]); ctx.restore(); ctx.strokeStyle = 'rgba(70,45,25,0.7)'; ctx.lineWidth = 2; ctx.stroke(env);
  // cámara interior (aire)
  ctx.beginPath(); for (let y2 = 0; y2 <= Y.H - YK2.top; y2 += 2) ctx[y2 ? 'lineTo' : 'moveTo'](X(P.ykRin2(y2)), Yp(y2)); for (let y2 = Y.H - YK2.top; y2 >= 0; y2 -= 2) ctx.lineTo(X(-P.ykRin2(y2)), Yp(y2)); ctx.closePath(); const ig = ctx.createLinearGradient(0, Yp(Y.H), 0, gy); ig.addColorStop(0, P.mixc('#8a7056', '#1b1611', night)); ig.addColorStop(0.6, P.mixc('#6a5440', '#16120e', night)); ig.addColorStop(1, P.mixc('#4e3e2e', '#120e0b', night)); ctx.fillStyle = ig; ctx.fill(); if (o.tint) { ctx.fillStyle = `rgba(120,180,215,${0.1 * o.tint})`; ctx.fill(); }
  // rellano interior y vestíbulo con el paso de la entrada (sur)
  ctx.fillStyle = P.mixc('#8a6a48', '#3a2e24', night); for (const sg of [-1, 1]) ctx.fillRect(Math.min(X(sg * YK2.pitR0), X(sg * P.ykRin2(0))), gy - 2, Math.abs(X(sg * P.ykRin2(0)) - X(sg * YK2.pitR0)), 4);
  const e = YK2.ent; ctx.beginPath(); ctx.moveTo(X(P.ykR2(e.h + e.vault * 0.85) - 1), Yp(e.h + e.vault * 0.85)); ctx.lineTo(X(e.z1), Yp(e.h + e.vault * 0.85)); ctx.lineTo(X(e.z1), gy); ctx.lineTo(X(P.ykR2(0) - 2), gy); ctx.closePath(); ctx.fillStyle = P.mixc('#c2a07a', '#4d3f31', night); ctx.fill(); ctx.strokeStyle = 'rgba(70,45,25,0.7)'; ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = P.mixc('#2a2016', '#120e0a', night); ctx.fillRect(Math.min(X(e.z1 + 0.5), X(P.ykRin2(0) - 2)), Yp(e.doorH), Math.abs(X(e.z1 + 0.5) - X(P.ykRin2(0) - 2)), e.doorH * s);
  // calor cualitativo: llega al exterior soleado, se atenúa al atravesar el espesor; una pequeña parte alcanza el interior
  // calor cualitativo (v1.21.1): flechas PERPENDICULARES a la superficie soleada que llegan al exterior; dentro del espesor, puntos que
  // avanzan despacio y se apagan; una flecha pequeña y tenue alcanza el interior (entra lentamente, no queda bloqueado del todo)
  const ha = cl(o.heat || 0); if (ha > 0) { ctx.save(); const nrm = (y) => { const d = (P.ykR2(y + 0.5) - P.ykR2(y - 0.5)), l = Math.hypot(1, d); return [1 / l, -d / l]; };
   for (const [sg, yy] of [[1, 22], [1, 62], [1, 102], [1, 138], [-1, 40], [-1, 92]]) { const r = P.ykR2(yy), [nz, ny] = nrm(yy), Th = (r - P.ykRin2(yy)) * nz, O = [sg * r, yy], N = [sg * nz, ny], at = (k) => [X(O[0] + N[0] * k), Yp(O[1] + N[1] * k)], ph = ((t || 0) * 0.35 + yy * 0.013) % 1;
    const p0 = at(44), p1 = at(1.5), an = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]); ctx.globalAlpha = ha; ctx.strokeStyle = '#FF8A3D'; ctx.fillStyle = '#FF8A3D'; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(6, 2.4 * s); ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.lineTo(p1[0] - Math.cos(an) * 16, p1[1] - Math.sin(an) * 16); ctx.stroke(); ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p1[0] - Math.cos(an - 0.5) * 26, p1[1] - Math.sin(an - 0.5) * 26); ctx.lineTo(p1[0] - Math.cos(an + 0.5) * 26, p1[1] - Math.sin(an + 0.5) * 26); ctx.closePath(); ctx.fill();
    for (let k = 0; k < 4; k++) { const u = (ph + k / 4) % 1, pp = at(-Th * u); ctx.globalAlpha = ha * (1 - u * 0.85) * 0.95; ctx.beginPath(); ctx.arc(pp[0], pp[1], Math.max(3.5, 1.5 * s) * (1 - u * 0.5), 0, TAU); ctx.fill(); }
    if (yy === 62 || yy === 40) { const q0 = at(-Th - 2), q1 = at(-Th - 12), a2 = Math.atan2(q1[1] - q0[1], q1[0] - q0[0]); ctx.globalAlpha = ha * 0.5; ctx.lineWidth = Math.max(2.5, s); ctx.beginPath(); ctx.moveTo(q0[0], q0[1]); ctx.lineTo(q1[0] - Math.cos(a2) * 8, q1[1] - Math.sin(a2) * 8); ctx.stroke(); ctx.beginPath(); ctx.moveTo(q1[0], q1[1]); ctx.lineTo(q1[0] - Math.cos(a2 - 0.5) * 13, q1[1] - Math.sin(a2 - 0.5) * 13); ctx.lineTo(q1[0] - Math.cos(a2 + 0.5) * 13, q1[1] - Math.sin(a2 + 0.5) * 13); ctx.closePath(); ctx.fill(); } } ctx.restore(); }
  // sitio: camino, estanque con taludes y caballón, muro de sombra y su sombra según el sol
  if (o.site) { const pd = Y.pond, sw = Y.swall, RX = (z0, z1, y0, y1, f) => { const xa = Math.min(X(z0), X(z1)), xb = Math.max(X(z0), X(z1)); ctx.fillStyle = f; ctx.fillRect(xa, Math.min(y0, y1), xb - xa, Math.abs(y1 - y0)); };
   RX(YK2.ent.z1, Y.path.z1, gy - 3, gy, '#e2c9a0'); const dd = 4 * s * 1.6; ctx.fillStyle = '#8a6a48'; ctx.beginPath(); ctx.moveTo(X(pd.z0), gy); ctx.lineTo(X(pd.z0 + 5), gy + dd); ctx.lineTo(X(pd.z1 - 5), gy + dd); ctx.lineTo(X(pd.z1), gy); ctx.closePath(); ctx.fill(); ctx.fillStyle = P.mixc(P.mixc('#3f86ad', '#9fd3e6', cl(o.pondIce || 0)), '#1d3a58', night * (1 - cl(o.pondIce || 0))); ctx.beginPath(); ctx.moveTo(X(pd.z0 + 1.5), gy + dd * 0.25); ctx.lineTo(X(pd.z0 + 5), gy + dd); ctx.lineTo(X(pd.z1 - 5), gy + dd); ctx.lineTo(X(pd.z1 - 1.5), gy + dd * 0.25); ctx.closePath(); ctx.fill(); RX(pd.z0 - 7, pd.z0, gy - 2.4 * s, gy, '#b8946a'); RX(pd.z1, pd.z1 + 7, gy - 2.4 * s, gy, '#b8946a');
   RX(sw.z0, sw.z1, Yp(sw.h), gy, P.mixc('#cdb08a', '#5d4d3c', night)); ctx.strokeStyle = 'rgba(70,45,25,0.6)'; ctx.lineWidth = 2; ctx.strokeRect(Math.min(X(sw.z0), X(sw.z1)), Yp(sw.h), (sw.z1 - sw.z0) * s, sw.h * s);
   if (sun[1] > 0.02 && night < 0.5 && sun[2] > 0) { const L2 = sw.h * Math.hypot(sun[0], sun[2]) / sun[1] * (sun[2] / Math.hypot(sun[0], sun[2])); ctx.fillStyle = 'rgba(40,28,16,0.35)'; RX(sw.z0 - L2, sw.z0, gy - 6, gy + 6, 'rgba(40,28,16,0.35)'); } }
  ctx.restore(); return { X, Yp, top: [X(0), Yp(Y.H)], wall: [X(sd * 0 + (P.ykR2(40) + P.ykRin2(40)) / 2), Yp(40)], wallN: [X(-(P.ykR2(40) + P.ykRin2(40)) / 2), Yp(40)], plaster: [X(P.ykR2(90)), Yp(90)], pit: [X(-YK2.pitR0 * 0.4), Yp(-Y.pitD * 0.5)], drain: [X(-YK2.pitR1 - 24), Yp(-Y.pitD - 13)], sump: [X(0), Yp(-Y.pitD - 4)], stair: [X(YK2.pitR0 - 8), Yp(-Y.pitD * 0.45)], entrance: [X(YK2.ent.z1 - 4), Yp(YK2.ent.doorH * 0.5)], chamber: [X(0), Yp(Y.H * 0.45)], pond: [X((Y.pond.z0 + Y.pond.z1) / 2), gy], swall: [X(Y.swall.z0), Yp(Y.swall.h)] };
 };
 // Etiqueta editorial (v1.21): punto en el objeto, guía fina y texto blanco (≥ 32 px) sobre una píldora translúcida. Aparece y se va
 // con fundido; no tapa la arquitectura (el texto se coloca en x, y). o: { px, col, al ('left'|'right'|'center'), sub (2.ª línea) }
 P.ykLabel = (ctx, s, anchor, x, y, t, t0, t1, o = {}) => { const a = sm(t0, t0 + 0.35, t) * (t1 ? 1 - sm(t1 - 0.3, t1, t) : 1); if (a <= 0) return; ctx.save(); ctx.globalAlpha *= a; const px = o.px || 34, al = o.al || 'center'; ctx.font = `800 ${px}px Nunito`; const tw = ctx.measureText(s).width; let tw2 = 0; if (o.sub) { ctx.font = `600 ${Math.max(32, px - 2)}px Nunito`; tw2 = ctx.measureText(o.sub).width; } const bw = Math.max(tw, tw2) + 40, bh = o.sub ? px * 2.5 : px * 1.55, bx = al === 'left' ? x : al === 'right' ? x - bw : x - bw / 2, by = y - bh / 2;
  if (anchor) { const ax = al === 'left' ? bx : al === 'right' ? bx + bw : x, ay = anchor[1] < by ? by : anchor[1] > by + bh ? by + bh : y, e = E.out(cl((t - t0) / 0.45)); ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(anchor[0], anchor[1]); ctx.lineTo(lerp(anchor[0], ax, e), lerp(anchor[1], ay, e)); ctx.stroke(); ctx.fillStyle = o.col || '#FFD447'; ctx.beginPath(); ctx.arc(anchor[0], anchor[1], 8, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.fillStyle = 'rgba(10,16,26,0.8)'; ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, bh * 0.22); ctx.fill(); ctx.fillStyle = o.col || '#FFD447'; ctx.fillRect(bx, by + bh * 0.2, 5, bh * 0.6); ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#F5F7F8'; ctx.font = `800 ${px}px Nunito`; ctx.fillText(s, bx + 22, o.sub ? by + bh * 0.32 : y + 1); if (o.sub) { ctx.fillStyle = 'rgba(245,247,248,0.78)'; ctx.font = `600 ${Math.max(32, px - 2)}px Nunito`; ctx.fillText(o.sub, bx + 22, by + bh * 0.7); } ctx.restore(); };
 // Rótulo de capítulo discreto (v1.21): número + palabra en la esquina superior izquierda con filete amarillo; sustituye a los títulos
 // grandes centrados. o: { y, sub }
 P.ykKicker = (ctx, num, s, t, t0, t1, o = {}) => { const a = sm(t0, t0 + 0.4, t) * (t1 ? 1 - sm(t1 - 0.35, t1, t) : 1); if (a <= 0) return; const y = o.y ?? 150, e = E.out(cl((t - t0) / 0.6)); ctx.save(); ctx.globalAlpha *= a; const g = ctx.createLinearGradient(0, 0, 0, y + 120); g.addColorStop(0, 'rgba(0,0,0,0.38)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, y + 120); ctx.fillStyle = '#FFD447'; ctx.fillRect(64, y - 34, 6, 68); ctx.font = '700 32px "IBM Plex Mono"'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = '#FFD447'; ctx.fillText(num, 88, y - 16); ctx.font = '900 46px Nunito'; ctx.fillStyle = '#F5F7F8'; ctx.letterSpacing = '2px'; ctx.save(); ctx.beginPath(); ctx.rect(80, y - 60, 960 * e, 140); ctx.clip(); ctx.fillText(s, 88, y + 22); ctx.restore(); if (o.sub) { ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,248,0.8)'; ctx.fillText(o.sub, 88, y + 66); } ctx.restore(); };
 // Sello pequeño «RECONSTRUCCIÓN» (esquina inferior derecha, sobre la franja de subtítulos) para distinguir lo recreado de lo real.
 P.ykRecon = (ctx, t, t0, t1, o = {}) => { const a = sm(t0, t0 + 0.3, t) * (t1 ? 1 - sm(t1 - 0.3, t1, t) : 1); if (a <= 0) return; ctx.save(); ctx.globalAlpha *= a * 0.92; ctx.font = '700 32px "IBM Plex Mono"'; const s = o.s || 'RECONSTRUCCIÓN', tw = ctx.measureText(s).width, x = o.x ?? 1016 - tw, y = o.y ?? 1392; ctx.fillStyle = 'rgba(10,16,26,0.55)'; ctx.beginPath(); ctx.roundRect(x - 16, y - 24, tw + 32, 48, 10); ctx.fill(); ctx.fillStyle = '#9fd3ee'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillText(s, x, y + 1); ctx.restore(); };
 // Hielo en macro (gancho): superficie cristalina con fracturas internas, burbujas atrapadas, escarcha en el borde, gotas de
 // condensación con reflejo y una gota que resbala; luz cálida del exterior en una esquina (contraste hielo/calor).
 // o: { warm 0..1, drip (fase 0..1 de la gota que resbala), zoom }
 P.iceMacro = (ctx, t, o = {}) => { const R = H.rng(o.seed || 4), z = o.zoom ?? 1; ctx.save(); ctx.translate(540, 960); ctx.scale(z, z); ctx.translate(-540, -960);
  const g = ctx.createLinearGradient(0, 0, W, HH); g.addColorStop(0, '#d9f1fa'); g.addColorStop(0.45, '#8fc7df'); g.addColorStop(1, '#3d7ea3'); ctx.fillStyle = g; ctx.fillRect(-200, -200, W + 400, HH + 400);
  for (let k = 0; k < 7; k++) { const x = R.range(-100, W + 100), y = R.range(-100, HH + 100), r = R.range(250, 600), gg = ctx.createRadialGradient(x, y, 0, x, y, r); gg.addColorStop(0, `rgba(255,255,255,${R.range(0.08, 0.22)})`); gg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = gg; ctx.fillRect(x - r, y - r, 2 * r, 2 * r); }
  ctx.lineCap = 'round'; for (let k = 0; k < 22; k++) { let x = R.range(0, W), y = R.range(0, HH); const a0 = R.range(0, TAU); ctx.strokeStyle = `rgba(255,255,255,${R.range(0.18, 0.5)})`; ctx.lineWidth = R.range(1, 3.5); ctx.beginPath(); ctx.moveTo(x, y); for (let s = 0; s < 6; s++) { x += Math.cos(a0 + R.range(-0.5, 0.5)) * R.range(30, 90); y += Math.sin(a0 + R.range(-0.5, 0.5)) * R.range(30, 90); ctx.lineTo(x, y); } ctx.stroke(); }
  for (let k = 0; k < 70; k++) { const x = R.range(0, W), y = R.range(0, HH), r = R.range(3, 26) * (R() < 0.15 ? 2 : 1); ctx.fillStyle = `rgba(255,255,255,${R.range(0.12, 0.3)})`; ctx.beginPath(); ctx.ellipse(x, y, r, r * R.range(0.8, 1), R.range(0, 3), 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.65)'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.arc(x - r * 0.35, y - r * 0.35, r * 0.22, 0, TAU); ctx.fill(); }
  ctx.save(); for (let k = 0; k < 120; k++) { const x = R.range(-20, W + 20), y = R.range(HH * 0.78, HH + 40), L = R.range(10, 34); ctx.strokeStyle = `rgba(255,255,255,${R.range(0.4, 0.85)})`; ctx.lineWidth = 2; for (let a = 0; a < 3; a++) { const an = a * Math.PI / 3 + R(); ctx.beginPath(); ctx.moveTo(x - Math.cos(an) * L / 2, y - Math.sin(an) * L / 2); ctx.lineTo(x + Math.cos(an) * L / 2, y + Math.sin(an) * L / 2); ctx.stroke(); } } ctx.restore();
  const drop = (x, y, r) => { ctx.fillStyle = 'rgba(20,60,90,0.25)'; ctx.beginPath(); ctx.ellipse(x + r * 0.25, y + r * 0.3, r, r * 1.05, 0, 0, TAU); ctx.fill(); const dg = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r); dg.addColorStop(0, 'rgba(255,255,255,0.95)'); dg.addColorStop(0.35, 'rgba(200,236,250,0.55)'); dg.addColorStop(1, 'rgba(90,150,185,0.6)'); ctx.fillStyle = dg; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(40,90,120,0.45)'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.14, -0.6, 0, TAU); ctx.fill(); };
  for (let k = 0; k < 46; k++) drop(R.range(40, W - 40), R.range(80, HH * 0.75), R.range(6, 30));
  const dp = cl(o.drip ?? 0); if (dp > 0) { const x = 700, y0 = 420, y = y0 + E.inOut(dp) * 760; ctx.strokeStyle = 'rgba(230,248,255,0.35)'; ctx.lineWidth = 16; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x + 6, y - 30); ctx.stroke(); drop(x + 6, y, 38); }
  const wm = cl(o.warm ?? 0.6); if (wm > 0) { const wg = ctx.createRadialGradient(W * 0.95, 80, 0, W * 0.95, 80, 900); wg.addColorStop(0, `rgba(255,190,90,${0.55 * wm})`); wg.addColorStop(0.5, `rgba(255,140,60,${0.18 * wm})`); wg.addColorStop(1, 'rgba(255,140,60,0)'); ctx.fillStyle = wg; ctx.fillRect(-200, -200, W + 400, HH + 400); }
  ctx.restore(); };
 // Bloque de hielo 2D v1.21 (sin sombra propia, para llevarlo en las manos o apilarlo): cara translúcida con canto claro, burbujas,
 // fisura y cara superior en perspectiva leve. o: { seed, melt, top (alto de la cara superior en px) }
 P.iceSlab2 = (ctx, x, y, w, h, o = {}) => { const R = H.rng(o.seed || 1), m = cl(o.melt || 0), ww = w * (1 - m * 0.3), hh = h * (1 - m * 0.4), r = Math.min(ww, hh) * (0.08 + m * 0.3), tp = o.top ?? hh * 0.22; ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = 'rgba(222,232,236,0.92)'; ctx.beginPath(); ctx.moveTo(-ww / 2, -hh / 2); ctx.lineTo(-ww / 2 + tp * 0.8, -hh / 2 - tp); ctx.lineTo(ww / 2 + tp * 0.8, -hh / 2 - tp); ctx.lineTo(ww / 2, -hh / 2); ctx.closePath(); ctx.fill();
  const g = ctx.createLinearGradient(-ww / 2, -hh / 2, ww / 2, hh / 2); g.addColorStop(0, 'rgba(232,240,243,0.96)'); g.addColorStop(0.5, 'rgba(190,210,218,0.94)'); g.addColorStop(1, 'rgba(150,176,188,0.94)'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-ww / 2, -hh / 2, ww, hh, r); ctx.fill();
  ctx.fillStyle = 'rgba(245,248,250,0.2)'; ctx.beginPath(); ctx.roundRect(-ww / 2 + ww * 0.1, -hh / 2 + hh * 0.12, ww * 0.8, hh * 0.76, r); ctx.fill(); ctx.strokeStyle = 'rgba(240,246,248,0.6)'; ctx.lineWidth = Math.max(1.2, w * 0.025); ctx.beginPath(); ctx.roundRect(-ww / 2, -hh / 2, ww, hh, r); ctx.stroke();
  for (let k = 0; k < 6; k++) { ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(R.range(-ww * 0.4, ww * 0.4), R.range(-hh * 0.35, hh * 0.35), Math.max(0.8, w * R.range(0.012, 0.03)), 0, TAU); ctx.fill(); }
  ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = Math.max(1, w * 0.015); ctx.beginPath(); ctx.moveTo(-ww * 0.2, -hh * 0.4); ctx.lineTo(-ww * 0.05, -hh * 0.05); ctx.lineTo(ww * 0.12, hh * 0.1); ctx.stroke(); ctx.strokeStyle = 'rgba(30,60,80,0.4)'; ctx.lineWidth = Math.max(1, w * 0.02); ctx.beginPath(); ctx.moveTo(-ww / 2 + r, hh / 2); ctx.lineTo(ww / 2 - r, hh / 2); ctx.stroke(); ctx.restore(); };
 // Trabajador persa v1.21 (vista lateral): proporciones mejores (cuello, hombros, extremidades que se afinan, manos orientadas con el
 // antebrazo, calzado plano apoyado), cinemática inversa y poses de trabajo con el peso del bloque. Pies en y (suelo) salvo o.feet.
 // Poses: 'stand', 'walk', 'pry' (barra metida en la junta; lift 0..1 = hace palanca), 'lift' (en cuclillas → de pie con el bloque),
 // 'carry' (bloque a la altura del pecho, cuerpo echado atrás por el peso), 'descend' (como carry, pies en peldaños: o.feet),
 // 'place' (inclinado, deja el bloque sobre o.surf; lift 1 → 0 baja), 'rake'. o: { pose, ph, lift, dir, var, feet:[[x,y],[x,y]],
 // surf (y local de la superficie para 'place'), block:{w,h} (unidades de figura: 170 = altura), release 0..1 }
 // Devuelve { hands, head, tip (punta de la herramienta), block:{x,y,w,h} en pantalla }.
 P.persianWorker2 = (ctx, x, y, h, t, o = {}) => { const pose = o.pose || 'stand', d = o.dir ?? 1, v = o.var ?? 0, u = h / 170, ph = o.ph ?? 0, lift = cl(o.lift ?? 0), bw = o.block?.w ?? 44, bh = o.block?.h ?? 30;
  const tun = ['#7a5a3a', '#556050', '#6b4a3a', '#5e5248'][v % 4], tunD = ykHex(H.mix(tun, '#000000', 0.32)), trou = ['#d8ccb4', '#cbbfa6', '#bfb39a'][v % 3], trouD = ykHex(H.mix(trou, '#000000', 0.18)), cap = ['#ece4d2', '#8a6a4a', '#d9cfb6'][v % 3], skin = ['#b07a52', '#9a6a46', '#c08a60'][v % 3], skinD = ykHex(H.mix(skin, '#000000', 0.22)), sash = ['#a4473a', '#2f4a5e', '#8a7a4a'][v % 3], shoe = '#3a2a1c';
  const IK = (sx, sy, tx, ty, l1, l2, bend) => { const dx = tx - sx, dy = ty - sy, dd = Math.min(l1 + l2 - 0.01, Math.max(0.01, Math.hypot(dx, dy))), a = Math.atan2(dy, dx), c = Math.acos(cl((l1 * l1 + dd * dd - l2 * l2) / (2 * l1 * dd), -1, 1)), ea = a + bend * c; return [sx + Math.cos(ea) * l1, sy + Math.sin(ea) * l1, sx + Math.cos(a) * dd, sy + Math.sin(a) * dd]; };
  const limb = (a, b, c2, w0, w1, w2, col) => { const seg = (p, q, wa, wb) => { const an = Math.atan2(q[1] - p[1], q[0] - p[0]), nx = -Math.sin(an), ny = Math.cos(an); ctx.beginPath(); ctx.moveTo(p[0] + nx * wa, p[1] + ny * wa); ctx.lineTo(q[0] + nx * wb, q[1] + ny * wb); ctx.lineTo(q[0] - nx * wb, q[1] - ny * wb); ctx.lineTo(p[0] - nx * wa, p[1] - ny * wa); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.arc(q[0], q[1], wb, 0, TAU); ctx.fill(); }; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(a[0], a[1], w0, 0, TAU); ctx.fill(); seg(a, b, w0, w1); seg(b, c2, w1, w2); };
  // parámetros de postura
  let lean = 0.04, crouch = 0, hipX = 0, blk = null, tool = null, hA, hB, feet; const walkPh = (k) => { const f = ph * TAU + k * Math.PI; return [Math.sin(f) * 19 + hipX, -Math.max(0, Math.cos(f)) * 7]; };
  if (pose === 'walk') { feet = [walkPh(0), walkPh(1)]; lean = 0.08; }
  else if (pose === 'carry' || pose === 'descend') { lean = -0.07; feet = o.feet || [walkPh(0).map((q, i) => (i ? q : q * 0.75)), walkPh(1).map((q, i) => (i ? q : q * 0.75))]; crouch = 3; }
  else if (pose === 'lift') { const e = E.inOut(lift); crouch = lerp(34, 2, e); lean = lerp(0.62, -0.06, e); hipX = lerp(-12, 0, e); feet = [[-10, 0], [16, 0]]; }
  else if (pose === 'place') { const e = E.inOut(lift); crouch = lerp(30, 4, e); lean = lerp(0.7, 0.05, e); hipX = lerp(-14, 0, e); feet = [[-12, 0], [18, 0]]; }
  else if (pose === 'pry') { const e = E.inOut(lift); lean = lerp(0.18, 0.5, e); crouch = lerp(4, 14, e); feet = [[-22, 0], [14, 0]]; }
  else if (pose === 'rake') { lean = 0.24; feet = [[-18, 0], [20, 0]]; }
  else feet = [[-7, 0], [9, 0]];
  if (o.feet) feet = o.feet; const fy = Math.max(feet[0][1], feet[1][1]);
  const hip = [hipX, Math.min(feet[0][1], feet[1][1]) * 0.5 + fy * 0.5 - 88 + crouch], sh = [hip[0] + Math.sin(lean) * 58, hip[1] - Math.cos(lean) * 58], neck = [sh[0] + Math.sin(lean) * 7, sh[1] - Math.cos(lean) * 7], head = [neck[0] + Math.sin(lean * 0.6) * 11 + 2, neck[1] - Math.cos(lean * 0.6) * 11];
  // objetivos de manos y objetos
  if (pose === 'lift' || pose === 'place') { const e = E.inOut(lift), surf = o.surf ?? 0; const by = lerp(surf - bh / 2, sh[1] + 34, e), bx = lerp(40, 30, e); blk = { x: bx, y: by }; const rel = cl(o.release || 0); hA = [bx - bw / 2 + 6 - rel * 10, by + bh / 2 - 5 - rel * 8]; hB = [bx - bw / 2 + 4 - rel * 10, by - 2 - rel * 6]; }
  else if (pose === 'carry' || pose === 'descend') { blk = { x: sh[0] + 26, y: sh[1] + 30 }; hA = [blk.x - bw / 2 + 7, blk.y + bh / 2 - 4]; hB = [blk.x + bw / 2 - 8, blk.y + bh / 2 - 3]; }
  else if (pose === 'pry') { const e = E.inOut(lift), tip = [o.tip?.[0] ?? 46, o.tip?.[1] ?? 6], tl = lerp(0.06, 0.44, e), L = 96, H0 = [tip[0] - Math.sin(tl) * L, tip[1] - Math.cos(tl) * L]; tool = { kind: 'bar', p0: H0, p1: tip }; hA = [lerp(H0[0], tip[0], 0.12), lerp(H0[1], tip[1], 0.12)]; hB = [lerp(H0[0], tip[0], 0.32), lerp(H0[1], tip[1], 0.32)]; }
  else if (pose === 'rake') { const k = 0.5 + 0.5 * Math.sin(t * 2.2 + v); hA = [sh[0] + 22 + k * 14, sh[1] + 30]; hB = [sh[0] + 42 + k * 18, sh[1] + 44]; tool = { kind: 'rake', p0: [hA[0] - 22, hA[1] - 20], p1: [hA[0] + 84 + k * 10, -2] }; }
  else if (pose === 'walk') { const sw = Math.sin(ph * TAU); hA = [sh[0] + sw * 16 + 2, sh[1] + 54]; hB = [sh[0] - sw * 16 + 2, sh[1] + 54]; }
  else { hA = [sh[0] + 5, sh[1] + 56]; hB = [sh[0] - 3, sh[1] + 56]; }
  ctx.save(); ctx.translate(x, y); ctx.scale(u * d, u); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  // sombra de contacto bajo los pies apoyados
  ctx.fillStyle = 'rgba(0,0,0,0.28)'; for (const f of feet) if (f[1] >= fy - 1) { ctx.beginPath(); ctx.ellipse(f[0] + 6, f[1] + 1, 16, 3.5, 0, 0, TAU); ctx.fill(); }
  const leg = (k, col) => { const f = feet[k], kn = IK(hip[0] + (k ? 4 : -4), hip[1], f[0], f[1] - 5, 45, 43, -1); limb([hip[0] + (k ? 4 : -4), hip[1]], [kn[0], kn[1]], [kn[2], kn[3]], 9, 7, 5.5, col); const grounded = f[1] >= fy - 1; ctx.save(); ctx.translate(kn[2], kn[3] + 2); ctx.rotate(grounded ? 0 : 0.25); ctx.fillStyle = shoe; ctx.beginPath(); ctx.moveTo(-6, -3); ctx.quadraticCurveTo(12, -6, 17, 1); ctx.lineTo(17, 3); ctx.lineTo(-7, 3); ctx.closePath(); ctx.fill(); ctx.restore(); };
  const arm = (hp, col, bend = 1) => { const s0 = [sh[0], sh[1] + 5], e = IK(s0[0], s0[1], hp[0], hp[1], 30, 28, bend); limb(s0, [e[0], e[1]], [e[2], e[3]], 6.5, 5, 4, col); const an = Math.atan2(e[3] - e[1], e[2] - e[0]); ctx.save(); ctx.translate(e[2], e[3]); ctx.rotate(an); ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(4, 0, 6.5, 4.6, 0, 0, TAU); ctx.fill(); ctx.fillStyle = skinD; ctx.beginPath(); ctx.ellipse(6.5, 2.2, 3.4, 2, 0.4, 0, TAU); ctx.fill(); ctx.restore(); return [e[2], e[3]]; };
  const drawBlock = () => { if (!blk || o.noBlock) return; P.iceSlab2(ctx, blk.x, blk.y, bw, bh, { seed: 3 + v }); };
  arm(hB, tunD, 1); leg(1, trouD);
  if (tool && tool.kind === 'bar') { ctx.strokeStyle = '#5b5f62'; ctx.lineWidth = 4.5; ctx.beginPath(); ctx.moveTo(tool.p0[0], tool.p0[1]); ctx.lineTo(tool.p1[0], tool.p1[1]); ctx.stroke(); ctx.fillStyle = '#4a4e50'; ctx.beginPath(); ctx.moveTo(tool.p1[0] - 3, tool.p1[1] - 10); ctx.lineTo(tool.p1[0] + 3, tool.p1[1] - 10); ctx.lineTo(tool.p1[0] + 1, tool.p1[1] + 2); ctx.lineTo(tool.p1[0] - 1, tool.p1[1] + 2); ctx.closePath(); ctx.fill(); }
  // torso: túnica hasta la rodilla con pliegues, faja y hombros
  ctx.fillStyle = tun; ctx.beginPath(); const sx2 = Math.cos(lean), sy2 = Math.sin(lean); ctx.moveTo(sh[0] - 15 * sx2, sh[1] - 15 * sy2 + 2); ctx.quadraticCurveTo(sh[0] - 17 * sx2 - 4, sh[1] + 10, hip[0] - 20, hip[1] - 2); ctx.lineTo(hip[0] - 24, hip[1] + 34); ctx.quadraticCurveTo(hip[0] + 2, hip[1] + 38, hip[0] + 26, hip[1] + 34); ctx.lineTo(hip[0] + 19, hip[1] - 2); ctx.quadraticCurveTo(sh[0] + 17 * sx2 + 4, sh[1] + 12, sh[0] + 14 * sx2, sh[1] + 14 * sy2 + 2); ctx.quadraticCurveTo(sh[0], sh[1] - 6, sh[0] - 15 * sx2, sh[1] - 15 * sy2 + 2); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = tunD; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hip[0] - 4, hip[1] + 4); ctx.lineTo(hip[0] - 8, hip[1] + 34); ctx.moveTo(hip[0] + 8, hip[1] + 4); ctx.lineTo(hip[0] + 12, hip[1] + 33); ctx.stroke();
  ctx.strokeStyle = sash; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(hip[0] - 19 + sy2 * 6, hip[1] - 6); ctx.lineTo(hip[0] + 19 + sy2 * 6, hip[1] - 6); ctx.stroke();
  // cuello, cabeza (perfil con nariz, barba) y gorro de tela
  limb(sh, neck, neck, 5.5, 5, 5, skin); ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(head[0], head[1], 10, 12, lean * 0.4, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(head[0] + 8.5, head[1] - 3); ctx.lineTo(head[0] + 13.5, head[1] + 2); ctx.lineTo(head[0] + 8.5, head[1] + 4); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#2a1e16'; ctx.beginPath(); ctx.moveTo(head[0] - 8, head[1] + 1); ctx.quadraticCurveTo(head[0] - 2, head[1] + 17, head[0] + 9, head[1] + 9); ctx.lineTo(head[0] + 7, head[1] + 5); ctx.quadraticCurveTo(head[0] + 1, head[1] + 8, head[0] - 5, head[1] - 1); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#1b1410'; ctx.beginPath(); ctx.arc(head[0] + 5, head[1] - 2.5, 1.4, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2a1e16'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(head[0] + 3, head[1] - 6); ctx.lineTo(head[0] + 8, head[1] - 6.5); ctx.stroke();
  ctx.fillStyle = cap; ctx.beginPath(); ctx.ellipse(head[0] - 1, head[1] - 8, 11.5, 7.5, 0, Math.PI, TAU); ctx.fill(); ctx.fillRect(head[0] - 12.5, head[1] - 9, 23, 4); ctx.fillStyle = ykHex(H.mix(cap, '#000000', 0.15)); ctx.fillRect(head[0] - 12.5, head[1] - 6, 23, 1.5);
  leg(0, trou);
  if (tool && tool.kind === 'rake') { ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = 4.5; ctx.beginPath(); ctx.moveTo(tool.p0[0], tool.p0[1]); ctx.lineTo(tool.p1[0], tool.p1[1]); ctx.stroke(); ctx.fillStyle = '#6b4a2c'; ctx.fillRect(tool.p1[0] - 2, tool.p1[1] - 12, 5, 12); ctx.fillRect(tool.p1[0] - 14, tool.p1[1] - 3, 30, 4); }
  drawBlock(); const front = arm(hA, tun, 1);
  ctx.restore(); const M = (p) => [x + p[0] * u * d, y + p[1] * u]; return { hands: [front, hB].map(M), head: M(head), tip: tool ? M(tool.p1) : null, block: blk ? { ...(() => { const q = M([blk.x, blk.y]); return { x: q[0], y: q[1] }; })(), w: bw * u, h: bh * u } : null };
 };
 // Estanque en CORTE LATERAL (v1.21): orillas de tierra con talud y caballón, capas de hielo de noches anteriores (grosor EXAGERADO y
 // rotulable), capa actual: lámina de agua con volumen que se congela DESDE LA SUPERFICIE con agujas de hielo que crecen hacia abajo,
 // flechas de pérdida de energía hacia el cielo (cualitativas), ranuras de corte. x0 = borde izquierdo, gy = nivel del terreno,
 // w = ancho, L = px por capa. o: { n (capas congeladas), water 0..1, freeze 0..1, loss 0..1, grooves [x px relativos], night, maxN }
 P.ykPondSide = (ctx, x0, gy, w, L, t, o = {}) => { const n = o.n || 0, maxN = o.maxN || 6, night = o.night || 0, depth = maxN * L + 14, base = gy + depth - 8, bank = 70; ctx.save();
  const g = ctx.createLinearGradient(0, gy, 0, gy + depth + 300); g.addColorStop(0, P.mixc('#a9845a', '#3a2e24', night)); g.addColorStop(1, P.mixc('#6e5236', '#211a14', night)); ctx.fillStyle = g; ctx.fillRect(0, gy - 1, W, HH); ctx.strokeStyle = 'rgba(50,34,20,0.22)'; ctx.lineWidth = 2; for (let k = 1; k < 8; k++) { ctx.beginPath(); for (let x = 0; x <= W; x += 30) { const yy = base + k * 34 + Math.sin(x * 0.012 + k) * 5; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); } ctx.stroke(); }
  const basin = new Path2D(); basin.moveTo(x0 - bank, gy); basin.lineTo(x0, base); basin.lineTo(x0 + w, base); basin.lineTo(x0 + w + bank, gy); basin.closePath(); ctx.fillStyle = P.mixc('#4c3a2a', '#1a140f', night); ctx.fill(basin);
  for (const [bx, sg] of [[x0 - bank, -1], [x0 + w + bank, 1]]) { ctx.fillStyle = P.mixc('#b8946a', '#4a3a2c', night); ctx.beginPath(); ctx.moveTo(bx - sg * 10, gy); ctx.quadraticCurveTo(bx + sg * 30, gy - 30, bx + sg * 80, gy); ctx.closePath(); ctx.fill(); }
  ctx.save(); ctx.clip(basin); const lay = (y0, y1, a = 1) => { const gi = ctx.createLinearGradient(0, y1, 0, y0); gi.addColorStop(0, `rgba(232,247,252,${a})`); gi.addColorStop(1, `rgba(160,208,228,${a})`); ctx.fillStyle = gi; ctx.fillRect(x0 - bank, y1, w + 2 * bank, y0 - y1); ctx.strokeStyle = `rgba(255,255,255,${0.85 * a})`; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x0 - bank, y1 + 1); ctx.lineTo(x0 + w + bank, y1 + 1); ctx.stroke(); const R = H.rng(Math.round(y0)); ctx.fillStyle = `rgba(255,255,255,${0.55 * a})`; for (let k = 0; k < 40; k++) { ctx.beginPath(); ctx.arc(R.range(x0, x0 + w), R.range(y1 + 3, y0 - 3), R.range(1, 3.2), 0, TAU); ctx.fill(); } };
  for (let k = 0; k < n; k++) lay(base - k * L, base - (k + 1) * L);
  const wa = cl(o.water ?? 0), fz = cl(o.freeze || 0), top0 = base - n * L; if (wa > 0) { const wt = top0 - L * wa; const gw = ctx.createLinearGradient(0, wt, 0, top0); gw.addColorStop(0, P.mixc('#4e93b8', '#2a5878', night * 0.7)); gw.addColorStop(1, P.mixc('#2c6a8e', '#173a55', night * 0.7)); ctx.fillStyle = gw; ctx.fillRect(x0 - bank, wt, w + 2 * bank, top0 - wt);
   if (fz > 0) { const fh = (top0 - wt) * fz; lay(wt + fh, wt, 0.95); const R = H.rng(17); ctx.strokeStyle = 'rgba(245,252,255,0.85)'; ctx.lineWidth = 2; for (let k = 0; k < 60; k++) { const xx = R.range(x0 - bank * 0.5, x0 + w + bank * 0.5), len = fh * R.range(0.6, 1.25), an = Math.PI / 2 + R.range(-0.35, 0.35); ctx.beginPath(); ctx.moveTo(xx, wt + fh - 2); ctx.lineTo(xx + Math.cos(an) * len * 0.5, wt + fh - 2 + Math.sin(an) * Math.min(len * 0.5, (top0 - wt - fh) + 2)); ctx.stroke(); } }
   ctx.strokeStyle = 'rgba(210,238,250,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); for (let x = x0 - bank; x <= x0 + w + bank; x += 12) { const yy = wt + (fz > 0.02 ? 0 : Math.sin(x * 0.05 + (t || 0) * 3) * 2.5); x === x0 - bank ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); } ctx.stroke(); }
  for (const gx of o.grooves || []) { const dpt = cl(o.cut ?? 1) * n * L; ctx.fillStyle = 'rgba(20,40,55,0.75)'; ctx.fillRect(x0 + gx - 2.5, top0, 5, dpt); }
  ctx.restore(); ctx.strokeStyle = 'rgba(40,28,18,0.5)'; ctx.lineWidth = 2; ctx.stroke(basin);
  const ls = cl(o.loss || 0), sTop = wa > 0 ? top0 - L * wa : top0; if (ls > 0) { ctx.save(); for (let k = 0; k < 6; k++) { const ax = x0 + w * (0.08 + k * 0.17), ph = ((t || 0) * 0.6 + k * 0.19) % 1, y0 = sTop - 16 - ph * 160, y1 = y0 - 90; ctx.globalAlpha = ls * Math.sin(Math.PI * ph) * 0.9; ctx.strokeStyle = '#FF8A3D'; ctx.fillStyle = '#FF8A3D'; ctx.lineWidth = 6; ctx.lineCap = 'round'; const dx = (k % 2 ? -1 : 1) * 14; ctx.beginPath(); ctx.moveTo(ax, y0); ctx.quadraticCurveTo(ax + dx, (y0 + y1) / 2, ax, y1 + 16); ctx.stroke(); ctx.beginPath(); ctx.moveTo(ax, y1); ctx.lineTo(ax - 12, y1 + 22); ctx.lineTo(ax + 12, y1 + 22); ctx.closePath(); ctx.fill(); } ctx.restore(); }
  ctx.restore(); return { top: sTop, iceTop: top0, base, layerY: (k) => base - (k + 0.5) * L, left: x0, right: x0 + w };
 };
 // Hielo NATURAL en primer plano (v1.21.1, gancho): la esquina de un bloque de hielo de estanque en la penumbra del depósito, con
 // superficie irregular (surcos de fusión), núcleo lechoso, columnas de burbujas alargadas, fracturas, canto translúcido, reflejos
 // discretos, escarcha cristalina en la arista superior y gotas de condensación (una resbala). o: { zoom, drip, warm, seed }
 P.iceMacro2 = (ctx, t, o = {}) => { const R = H.rng(o.seed || 21), z = o.zoom ?? 1; ctx.save(); ctx.translate(540, 960); ctx.scale(z, z); ctx.translate(-540, -960);
  const bg = ctx.createLinearGradient(0, 0, 0, HH); bg.addColorStop(0, '#3a2c1f'); bg.addColorStop(1, '#17110c'); ctx.fillStyle = bg; ctx.fillRect(-300, -300, W + 600, HH + 600); const wm = cl(o.warm ?? 0.7); P.glow(ctx, 980, 120, 700, '255,190,110', 0.45 * wm);
  const edge = (x0, y0, x1, y1, n, amp, sd) => { const Rr = H.rng(sd), out = []; for (let i = 0; i <= n; i++) { const u = i / n, nx = -(y1 - y0), ny = x1 - x0, l = Math.hypot(nx, ny), d = (Rr() - 0.5) * amp * Math.sin(Math.PI * u); out.push([lerp(x0, x1, u) + nx / l * d, lerp(y0, y1, u) + ny / l * d]); } return out; };
  const top = [...edge(90, 300, 640, 210, 14, 14, 3), ...edge(640, 210, 1120, 290, 12, 12, 4)], face = [[90, 300], ...edge(90, 300, 70, 1780, 24, 26, 5).slice(1), [1140, 1820], ...edge(1120, 1760, 1120, 290, 20, 20, 6).slice(1)];
  const fp = new Path2D(); face.forEach((p, i) => (i ? fp.lineTo(p[0], p[1]) : fp.moveTo(p[0], p[1]))); top.slice().reverse().forEach((p) => fp.lineTo(p[0], p[1])); fp.closePath();
  const tp = new Path2D(); top.forEach((p, i) => (i ? tp.lineTo(p[0], p[1]) : tp.moveTo(p[0], p[1]))); [[1120, 290], [1180, 170], [700, 70], [140, 160]].forEach((p) => tp.lineTo(p[0], p[1])); tp.closePath();
  const tg = ctx.createLinearGradient(0, 70, 0, 300); tg.addColorStop(0, 'rgba(214,226,232,0.9)'); tg.addColorStop(1, 'rgba(236,243,246,0.95)'); ctx.fillStyle = tg; ctx.fill(tp);
  const g = ctx.createLinearGradient(0, 220, 0, 1800); g.addColorStop(0, 'rgba(214,228,234,0.95)'); g.addColorStop(0.45, 'rgba(162,190,202,0.93)'); g.addColorStop(1, 'rgba(112,142,156,0.92)'); ctx.fillStyle = g; ctx.fill(fp);
  ctx.save(); ctx.clip(fp); const core = ctx.createRadialGradient(560, 900, 40, 560, 960, 520); core.addColorStop(0, 'rgba(242,246,247,0.55)'); core.addColorStop(1, 'rgba(242,246,247,0)'); ctx.fillStyle = core; ctx.fillRect(0, 0, W, HH);
  for (let k = 0; k < 9; k++) { const x = R.range(120, 1060), w2 = R.range(30, 90), gg = ctx.createLinearGradient(x - w2, 0, x + w2, 0); gg.addColorStop(0, 'rgba(255,255,255,0)'); gg.addColorStop(0.5, `rgba(${R() < 0.5 ? '255,255,255' : '60,90,105'},0.08)`); gg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = gg; ctx.fillRect(x - w2, 200, 2 * w2, 1700); }
  for (let k = 0; k < 26; k++) { const x = R.range(140, 1040), y0 = R.range(420, 1500), n = 4 + (R() * 9) | 0, sz = R.range(2.2, 5.5); for (let i = 0; i < n; i++) { const y = y0 - i * sz * R.range(3.2, 5), rx = sz * R.range(0.6, 1), ry = sz * R.range(1.4, 2.4); ctx.fillStyle = 'rgba(246,250,252,0.55)'; ctx.beginPath(); ctx.ellipse(x + Math.sin(i * 0.7 + k) * 2, y, rx, ry, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(70,100,115,0.35)'; ctx.lineWidth = 1; ctx.stroke(); } }
  for (let k = 0; k < 7; k++) { const x = R.range(200, 980), y = R.range(500, 1500), r = R.range(9, 22); ctx.fillStyle = 'rgba(240,246,248,0.4)'; ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.8, R(), 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(80,110,125,0.45)'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.3, r * 0.2, 0, TAU); ctx.fill(); }
  ctx.lineCap = 'round'; for (let k = 0; k < 6; k++) { let x = R.range(200, 1000), y = R.range(500, 1500); const a0 = R.range(-0.6, 0.6) + (R() < 0.5 ? 0 : Math.PI); ctx.strokeStyle = 'rgba(250,252,253,0.45)'; ctx.lineWidth = R.range(1.2, 2.4); ctx.beginPath(); ctx.moveTo(x, y); for (let s = 0; s < 5; s++) { x += Math.cos(a0 + R.range(-0.4, 0.4)) * R.range(40, 90); y += Math.sin(a0 + R.range(-0.4, 0.4)) * R.range(40, 90); ctx.lineTo(x, y); } ctx.stroke(); }
  ctx.strokeStyle = 'rgba(58,44,31,0.28)'; ctx.lineWidth = 46; ctx.stroke(fp); ctx.strokeStyle = 'rgba(232,240,243,0.35)'; ctx.lineWidth = 14; ctx.stroke(fp); ctx.restore();
  ctx.save(); ctx.globalAlpha = 0.35; const sp = ctx.createLinearGradient(700, 300, 900, 900); sp.addColorStop(0, 'rgba(255,255,255,0)'); sp.addColorStop(0.5, 'rgba(255,250,240,0.8)'); sp.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sp; ctx.beginPath(); ctx.moveTo(760, 320); ctx.lineTo(830, 320); ctx.lineTo(960, 1100); ctx.lineTo(900, 1100); ctx.closePath(); ctx.fill(); ctx.restore();
  for (let k = 0; k < 140; k++) { const u = R(), p = top[Math.min(top.length - 1, (u * top.length) | 0)], x = p[0] + R.range(-14, 14), y = p[1] + R.range(-50, 26), L = R.range(4, 12); ctx.strokeStyle = `rgba(255,255,255,${R.range(0.4, 0.85)})`; ctx.lineWidth = 1.4; for (let a = 0; a < 3; a++) { const an = a * Math.PI / 3 + R(); ctx.beginPath(); ctx.moveTo(x - Math.cos(an) * L / 2, y - Math.sin(an) * L / 2); ctx.lineTo(x + Math.cos(an) * L / 2, y + Math.sin(an) * L / 2); ctx.stroke(); } }
  const drop = (x, y, r) => { ctx.fillStyle = 'rgba(30,45,55,0.25)'; ctx.beginPath(); ctx.ellipse(x + r * 0.2, y + r * 0.3, r, r * 1.1, 0, 0, TAU); ctx.fill(); const dg = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r); dg.addColorStop(0, 'rgba(255,255,255,0.9)'); dg.addColorStop(0.4, 'rgba(210,226,232,0.45)'); dg.addColorStop(1, 'rgba(120,150,162,0.55)'); ctx.fillStyle = dg; ctx.beginPath(); ctx.ellipse(x, y, r, r * 1.08, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.4, r * 0.2, r * 0.13, -0.6, 0, TAU); ctx.fill(); };
  for (let k = 0; k < 18; k++) drop(R.range(160, 1040), R.range(340, 820), R.range(5, 15));
  const dp = cl(o.drip ?? 0); if (dp > 0) { const x = 660, y0 = 380, y = y0 + E.inOut(dp) * 820; ctx.strokeStyle = 'rgba(232,242,246,0.3)'; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x + 4, y - 26); ctx.stroke(); drop(x + 4, y, 22); }
  ctx.restore(); };
 // ---------------- v1.22 · VERNE / APOLO (1865 → 1969): documentos flotantes, grabado, Luna y Tierra 3D, Saturno V, Columbiad ----------------
 // Bloques nuevos para el episodio «Julio Verne imaginó los viajes a la Luna». Unidades 3D en METROS (P.cam3). Ninguno modifica bloques previos.
 // FOTOGRAFÍA / DOCUMENTO FLOTANTE: plano con perspectiva (giro en Y simulado por tiras), entrada lateral suave, paralaje, sombra
 // tenue, marco fino, etiqueta superior y pie (≥ 32 px). Proporción y contenido intactos (no se anima ni se deforma la imagen más allá
 // de la perspectiva del plano). o: { rotY (rad, + = borde derecho al fondo), from (-1 izquierda | 1 derecha), tag, label, sub, drift,
 // frame (px), alpha, shadow }. Devuelve { x0, y0, x1, y1 } aproximado.
 P.floatPhoto = (ctx, img, cx, cy, w, t, t0, t1, o = {}) => { if (!img || !img.width || t < t0 - 0.01 || t > t1 + 0.01) return null; const a = sm(t0, t0 + 0.55, t) * (1 - sm(t1 - 0.45, t1, t)); if (a <= 0) return null; const ein = E.out(sm(t0, t0 + 0.8, t)), eout = sm(t1 - 0.45, t1, t), fr = o.from ?? 1;
  const ry = (o.rotY ?? -0.18 * fr) + (1 - ein) * 0.38 * fr - eout * 0.2 * fr, sc = lerp(0.9, 1, ein) * (1 + 0.025 * win01(t, t0, t1)), dx = (1 - ein) * 240 * fr + eout * 120 * fr + Math.sin(t * 0.7) * (o.drift ?? 6), dy = Math.cos(t * 0.55) * (o.drift ?? 6) * 0.6;
  const ia = img.width / img.height, W2 = w * sc, H2 = W2 / ia, x = cx + dx, y = cy + dy, N = 40, k = 0.55, frw = o.frame ?? 7;
  const col = (u) => { const p = 1 + (u - 0.5) * Math.sin(ry) * k; return { x: x + (u - 0.5) * W2 * Math.cos(ry) / p, s: 1 / p }; };
  ctx.save(); ctx.globalAlpha *= a * (o.alpha ?? 1); const L = col(0), R = col(1), quad = (pad) => { ctx.beginPath(); ctx.moveTo(L.x - pad, y - (H2 / 2) * L.s - pad); ctx.lineTo(R.x + pad, y - (H2 / 2) * R.s - pad); ctx.lineTo(R.x + pad, y + (H2 / 2) * R.s + pad); ctx.lineTo(L.x - pad, y + (H2 / 2) * L.s + pad); ctx.closePath(); };
  if (o.shadow !== false) { ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 40; ctx.shadowOffsetX = 14 * fr * -1 + 10; ctx.shadowOffsetY = 22; ctx.fillStyle = 'rgba(0,0,0,0.35)'; quad(frw); ctx.fill(); ctx.restore(); }
  ctx.fillStyle = o.frameCol || 'rgba(240,236,226,0.95)'; quad(frw); ctx.fill();
  for (let i = 0; i < N; i++) { const u0 = i / N, u1 = (i + 1) / N, A = col(u0), B = col(u1), sm2 = (A.s + B.s) / 2, hh = H2 * sm2; ctx.drawImage(img, img.width * u0, 0, Math.max(1, img.width / N), img.height, A.x, y - hh / 2, B.x - A.x + 0.7, hh); }
  const g = ctx.createLinearGradient(L.x, 0, R.x, 0); g.addColorStop(0, `rgba(255,255,255,${0.06 + Math.max(0, -ry) * 0.12})`); g.addColorStop(1, `rgba(0,0,0,${0.05 + Math.max(0, ry) * 0.18})`); ctx.fillStyle = g; quad(0); ctx.fill();
  const top = Math.min(y - (H2 / 2) * L.s, y - (H2 / 2) * R.s), bot = Math.max(y + (H2 / 2) * L.s, y + (H2 / 2) * R.s);
  if (o.tag) { ctx.font = '700 32px "IBM Plex Mono"'; const tw = ctx.measureText(o.tag).width; ctx.fillStyle = 'rgba(11,16,26,0.88)'; ctx.beginPath(); ctx.roundRect(L.x - frw, top - frw - 58, tw + 30, 48, 10); ctx.fill(); ctx.fillStyle = '#FFD447'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(o.tag, L.x - frw + 15, top - frw - 33); }
  if (o.label) { ctx.font = '800 38px Nunito'; const lw = ctx.measureText(o.label).width; let sw2 = 0; if (o.sub) { ctx.font = '600 32px Nunito'; sw2 = ctx.measureText(o.sub).width; } const bw = Math.max(lw, sw2) + 44, bh = o.sub ? 104 : 62, bx = (L.x + R.x) / 2 - bw / 2, by = bot + frw + 16; ctx.fillStyle = 'rgba(11,16,26,0.86)'; ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 18); ctx.fill(); ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '800 38px Nunito'; ctx.fillText(o.label, bx + bw / 2, by + 32); if (o.sub) { ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.8)'; ctx.fillText(o.sub, bx + bw / 2, by + 74); } if (o.credit) { ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.7)'; ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 8; ctx.fillText(o.credit, bx + bw / 2, by + bh + 26); ctx.shadowBlur = 0; } }
  ctx.restore(); return { x0: L.x, x1: R.x, y0: top, y1: bot };
 };
 const win01 = (t, a, b) => cl((t - a) / Math.max(1e-6, b - a));
 // GRABADO DE ÉPOCA sobre lo ya dibujado: desatura, tiñe en papel/tinta, añade tramado de líneas finas, grano de papel y viñeta.
 // amt 0..1 (transición imagen moderna → ilustración del siglo XIX). o: { paper, ink, lines }
 let ENGR = null; P.engraveGrade = (ctx, amt, t, o = {}) => { amt = cl(amt); if (amt <= 0.002) return; if (!ENGR && typeof document !== 'undefined') { ENGR = document.createElement('canvas'); ENGR.width = 64; ENGR.height = 64; const g = ENGR.getContext('2d'); g.fillStyle = '#ffffff'; g.fillRect(0, 0, 64, 64); g.strokeStyle = 'rgba(40,30,22,0.55)'; g.lineWidth = 1.1; for (let y = 1; y < 64; y += 3.2) { g.beginPath(); g.moveTo(0, y); g.lineTo(64, y + 0.6); g.stroke(); } }
  ctx.save(); ctx.globalCompositeOperation = 'saturation'; ctx.globalAlpha = amt; ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, W, HH); ctx.globalCompositeOperation = 'multiply'; ctx.globalAlpha = amt * 0.85; ctx.fillStyle = o.paper || '#DEC9A8'; ctx.fillRect(0, 0, W, HH);
  if (ENGR) { ctx.globalAlpha = amt * (o.lines ?? 0.55); ctx.fillStyle = ctx.createPattern(ENGR, 'repeat'); ctx.fillRect(0, 0, W, HH); }
  ctx.globalCompositeOperation = 'source-over'; const R = H.rng(5); ctx.globalAlpha = amt * 0.18; ctx.fillStyle = '#5a4430'; for (let i = 0; i < 260; i++) ctx.fillRect(R() * W, R() * HH, 1 + R() * 2, 1 + R() * 2);
  const vg = ctx.createRadialGradient(540, 960, 500, 540, 960, 1250); vg.addColorStop(0, 'rgba(35,28,25,0)'); vg.addColorStop(1, `rgba(35,28,25,${0.55 * amt})`); ctx.globalAlpha = 1; ctx.fillStyle = vg; ctx.fillRect(0, 0, W, HH); ctx.restore(); };
 // Tronco de cono vertical en 3D (eje y): caras con color por ángulo/altura (colFn(a, y) → '#hex') y luz direccional. Base de los
 // cohetes y la cápsula. o: { N, L (luz), amb, x, z }
 const vFrustum = (...args) => vFrustum2(...args); // v1.22.1: delega en vFrustum2 (luz + brillo)
 // SATURNO V (Apolo 11) en 3D, proporciones históricas aproximadas (110,6 m con la torre de escape): S-IC con patrón de balanceo
 // negro y blanco y cuatro aletas, interetapa, S-II, adaptador, S-IVB, unidad de instrumentos, adaptador SLA, módulo de servicio,
 // módulo de mando y torre de escape (LES). Cinco motores F-1 bajo la base. base = [x, y, z] del fondo del S-IC (m).
 // o: { L, stage (0 completo, 1 sin S-IC, 2 sin S-II), les (true), engines (true) }
 const SV = { ic: 42, ii1: 67, ad1: 70, ivb: 87, iu: 88, sla: 96.5, sm: 100.4, cm: 103.9, les: 110.6, r1: 5.05, r3: 3.3, r5: 1.95 };
 P.SV = SV;
 // ESCAPE de los motores y humo de lanzamiento: chorro brillante desde las toberas, nube de vapor desviada por el foso a los lados y
 // columna de humo que crece con el tiempo desde el encendido (tg). Determinista. o: { tg (s desde el encendido), base (y del cohete),
 // power 0..1 }
 P.plume3 = (ctx, cam, nozzles, t, o = {}) => { const tg = Math.max(0, o.tg || 0), pw = cl(o.power ?? 1); if (pw <= 0) return; ctx.save(); const R = H.rng(77);
  for (let k = 0; k < 46; k++) { const side = R() < 0.5 ? -1 : 1, s = R(), age = tg - s * 2.5; if (age <= 0) continue; const dist = Math.min(1, age / 4), x = side * (12 + dist * R.range(40, 170)), z = R.range(-30, 40) + dist * 60, y = -6 + dist * R.range(4, 40) + age * R.range(1, 4), rad = 6 + dist * R.range(14, 34); const Q = cam.clip([[x, y, z]], 1)[0]; if (!Q) continue; const rp = rad * cam.f / Math.max(10, Q[2]), g = ctx.createRadialGradient(Q[0] - rp * 0.2, Q[1] - rp * 0.3, rp * 0.1, Q[0], Q[1], rp); g.addColorStop(0, `rgba(250,246,240,${0.85 * pw})`); g.addColorStop(0.7, `rgba(215,212,205,${0.6 * pw})`); g.addColorStop(1, 'rgba(200,198,190,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(Q[0], Q[1], rp, 0, TAU); ctx.fill(); }
  for (const N2 of nozzles) { if (!N2) continue; const len = (o.len ?? 280) * pw * (cam.f / Math.max(30, N2[2])) * 0.25, wd = 30 * (cam.f / Math.max(30, N2[2])) * 0.25; ctx.globalCompositeOperation = 'lighter'; const g = ctx.createLinearGradient(N2[0], N2[1], N2[0], N2[1] + len); g.addColorStop(0, `rgba(255,250,225,${0.95 * pw})`); g.addColorStop(0.3, `rgba(255,190,90,${0.8 * pw})`); g.addColorStop(1, 'rgba(255,120,40,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(N2[0] - wd * 0.5, N2[1]); ctx.lineTo(N2[0] + wd * 0.5, N2[1]); ctx.lineTo(N2[0] + wd * 1.4, N2[1] + len); ctx.lineTo(N2[0] - wd * 1.4, N2[1] + len); ctx.closePath(); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; P.glow(ctx, N2[0], N2[1] + len * 0.2, wd * 5, '255,170,80', 0.35 * pw); }
  ctx.restore(); };
 // COLUMBIAD de la novela (dispositivo FICTICIO, nunca construido): pozo vertical de ≈ 274 m (900 pies) excavado en Stone's Hill,
 // Florida; tubo de hierro fundido (ánima de ≈ 2,7 m) dentro de un revestimiento de mampostería. Vista exterior 3D: terreno de
 // Florida, brocal de piedra con el anillo de hierro, interior que se pierde en la profundidad (anillos que se alejan), andamio de
 // madera con polea y el proyectil colgado. o: { cap (altura del fondo del proyectil sobre el brocal, m; negativo = dentro), sky, palms }
 P.columbiad3 = (ctx, cam, t, o = {}) => { if (o.sky !== false) { const g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, '#6f8fae'); g.addColorStop(0.6, '#d9c9a4'); g.addColorStop(1, '#e8d9b8'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); }
  const G = 3000; poly3(ctx, cam, [[-G, 0, -G], [G, 0, -G], [G, 0, G], [-G, 0, G]], '#9c8f62'); const R2 = H.rng(11); for (let i = 0; i < 70; i++) { const x = R2.range(-600, 600), z = R2.range(-700, 300), s = R2.range(3, 9); if (Math.hypot(x, z) < 30) continue; poly3(ctx, cam, [[x - s, 0.05, z], [x, 0.05, z - s * 0.5], [x + s, 0.05, z], [x, 0.05, z + s * 0.5]], R2() < 0.5 ? '#8a7f55' : '#a89b6b'); }
  const ring = (r0, r1, y, col) => { const N = 48; for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU; poly3(ctx, cam, [[r0 * Math.cos(a0), y, r0 * Math.sin(a0)], [r0 * Math.cos(a1), y, r0 * Math.sin(a1)], [r1 * Math.cos(a1), y, r1 * Math.sin(a1)], [r1 * Math.cos(a0), y, r1 * Math.sin(a0)]], col(a0), { stroke: col(a0), lw: 1 }); } };
  ring(5.0, 8.5, 0.6, (a) => ((Math.floor(a / (TAU / 24)) % 2) ? '#b9ab8a' : '#a99c7c')); vFrustum(ctx, cam, 0, 0, 0, 0.6, 8.5, 8.5, () => '#a39677', { N: 48, amb: 0.5 });
  ring(1.37, 3.2, 0.62, () => '#3d3f41'); ring(3.2, 5.0, 0.61, () => '#8f846a');
  const hole = []; for (let i = 0; i < 48; i++) { const a = (i / 48) * TAU; hole.push([1.37 * Math.cos(a), 0.63, 1.37 * Math.sin(a)]); } poly3(ctx, cam, hole, '#0d0b0a');
  const HQ = cam.clip(hole, 1); if (cam.pos[1] > 2 && HQ.length > 2) { ctx.save(); ctx.beginPath(); HQ.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.clip(); for (const dd of [3, 8, 18, 40, 90, 200]) { const rp = []; for (let i = 0; i < 32; i++) { const a = (i / 32) * TAU; rp.push([1.37 * Math.cos(a), -dd, 1.37 * Math.sin(a)]); } const Q = cam.clip(rp, 1); if (Q.length > 2) { ctx.strokeStyle = `rgba(90,92,95,${0.5 - dd / 500})`; ctx.lineWidth = 1.5; ctx.beginPath(); Q.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.stroke(); } } ctx.restore(); }
  // andamio de madera con polea y proyectil
  const beam = (A, B, w) => { const Q = cam.clip([A, B], 1); if (Q.length < 2) return; ctx.strokeStyle = '#6b4f33'; ctx.lineWidth = Math.max(1.5, w * cam.f / Math.max(10, (Q[0][2] + Q[1][2]) / 2)); ctx.beginPath(); ctx.moveTo(Q[0][0], Q[0][1]); ctx.lineTo(Q[1][0], Q[1][1]); ctx.stroke(); };
  const top = [0, 16, 0], legs = [[-9, 0, -7], [9, 0, -7], [9, 0, 7], [-9, 0, 7]]; const cap = o.cap ?? 6, drawFrame = () => { for (const l of legs) beam(l, [l[0] * 0.25, 16, l[2] * 0.25], 0.35); beam([-2.2, 16, -1.7], [2.2, 16, 1.7], 0.3); const Q = cam.clip([[0, 16, 0]], 1)[0]; if (Q) { ctx.fillStyle = '#4a3a2a'; ctx.beginPath(); ctx.arc(Q[0], Q[1], Math.max(3, 0.8 * cam.f / Q[2]), 0, TAU); ctx.fill(); } };
  const capsule = () => { if (cap > -4.8) { const Qa = cam.clip([[0, 16, 0], [0, cap + 4.6, 0]], 1); if (Qa.length === 2) { ctx.strokeStyle = '#2a2420'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(Qa[0][0], Qa[0][1]); ctx.lineTo(Qa[1][0], Qa[1][1]); ctx.stroke(); } ctx.save(); if (cap < 0.6) { const clipP = cam.clip([[-60, 0.62, -60], [60, 0.62, -60], [60, 40, -60], [-60, 40, -60]], 1); } P.vCapsule3(ctx, cam, [0, Math.max(cap, -4.6), 0], t, { col: '#b5b9bb' }); ctx.restore(); } };
  if (cam.depth([0, 8, 0]) > 0) { drawFrame(); capsule(); }
  if (o.palms !== false) for (const [x, z] of [[-60, -80], [70, -120], [-110, -40], [130, -60], [-30, -160]]) { const a2 = cam.clip([[x, 0, z]], 1)[0], b2 = cam.clip([[x, 9, z]], 1)[0]; if (a2 && b2 && P.palm) P.palm(ctx, a2[0], a2[1], a2[1] - b2[1], t); }
  return { mouth: cam.clip([[0, 0.6, 0]], 1)[0], cap: cam.clip([[0, cap + 2, 0]], 1)[0] };
 };
 // ESTUDIO DE 1865 (recreación, 2,5D por capas con paralaje): pared con papel pintado y zócalo, ventana con luz cálida y haz de polvo,
 // estantería con libros, mapamundi en pie, escritorio de madera con lámpara de aceite, tintero, pluma y papeles; el escritor (figura
 // genérica, sin rostro identificable) escribe. cam = { x, y, z } (z > 1 acerca). o: { write 0..1, lamp }
 P.study1865 = (ctx, t, cam = {}, o = {}) => { const cx = cam.x || 0, cy = cam.y || 0, z = cam.z || 1, L = (k, f) => { ctx.save(); ctx.translate(540, 960); ctx.scale(lerp(1, z, k), lerp(1, z, k)); ctx.translate(-540 - cx * k, -960 - cy * k); f(); ctx.restore(); };
  L(0.55, () => { ctx.fillStyle = '#4a3527'; ctx.fillRect(-400, -400, W + 800, HH + 800); ctx.strokeStyle = 'rgba(120,90,60,0.18)'; ctx.lineWidth = 2; for (let x = -400; x < W + 400; x += 46) { ctx.beginPath(); ctx.moveTo(x, -400); ctx.lineTo(x, 1300); ctx.stroke(); for (let y = -380; y < 1300; y += 92) { ctx.beginPath(); ctx.arc(x + 23, y + ((x / 46) % 2) * 46, 7, 0, TAU); ctx.stroke(); } } ctx.fillStyle = '#3a281c'; ctx.fillRect(-400, 1180, W + 800, 140);
   ctx.fillStyle = '#2b1e15'; ctx.fillRect(640, 150, 360, 520); const wg = ctx.createLinearGradient(0, 170, 0, 650); wg.addColorStop(0, '#f6dca2'); wg.addColorStop(1, '#e7b56e'); ctx.fillStyle = wg; ctx.fillRect(662, 172, 316, 476); ctx.fillStyle = '#2b1e15'; ctx.fillRect(812, 172, 16, 476); ctx.fillRect(662, 400, 316, 14);
   ctx.save(); ctx.globalAlpha = 0.18; ctx.fillStyle = '#ffe2a8'; ctx.beginPath(); ctx.moveTo(662, 172); ctx.lineTo(978, 172); ctx.lineTo(620, 1300); ctx.lineTo(120, 1300); ctx.closePath(); ctx.fill(); ctx.restore();
   ctx.fillStyle = '#3d2a1c'; ctx.fillRect(60, 120, 470, 1060); const R = H.rng(18); for (let sh = 0; sh < 5; sh++) { const y0 = 160 + sh * 200; ctx.fillStyle = '#2a1c12'; ctx.fillRect(70, y0 + 170, 450, 16); let x = 84; while (x < 500) { const w = R.range(16, 34), h = R.range(120, 166); ctx.fillStyle = ['#6b2b20', '#2c3f5a', '#5a4a26', '#3d5a3a', '#7a5a2e'][(R() * 5) | 0]; ctx.fillRect(x, y0 + 170 - h, w - 2, h); ctx.fillStyle = 'rgba(230,200,120,0.5)'; ctx.fillRect(x + 3, y0 + 170 - h + 14, w - 8, 3); x += w; } } });
  L(0.8, () => { const gx = 860, gy2 = 980; ctx.strokeStyle = '#5a3d24'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(gx, gy2 + 70); ctx.lineTo(gx, gy2 + 260); ctx.moveTo(gx - 70, gy2 + 260); ctx.lineTo(gx + 70, gy2 + 260); ctx.stroke(); ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(gx, gy2, 82, -2.2, 1.1); ctx.stroke(); const gg = ctx.createRadialGradient(gx - 25, gy2 - 25, 10, gx, gy2, 72); gg.addColorStop(0, '#d9c08c'); gg.addColorStop(1, '#8a6a3c'); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(gx, gy2, 70, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(80,55,30,0.6)'; ctx.lineWidth = 2; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.ellipse(gx, gy2, 70, Math.abs(k) * 22 + 4, 0, 0, TAU); ctx.stroke(); } });
  L(1, () => { ctx.fillStyle = '#62472F'; ctx.fillRect(80, 1240, 920, 50); const dg = ctx.createLinearGradient(0, 1240, 0, 1290); dg.addColorStop(0, 'rgba(255,220,160,0.3)'); dg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = dg; ctx.fillRect(80, 1240, 920, 50); ctx.fillStyle = '#4b3523'; ctx.fillRect(120, 1290, 50, 420); ctx.fillRect(910, 1290, 50, 420); ctx.fillRect(140, 1290, 800, 120);
   ctx.fillStyle = '#efe3c7'; ctx.save(); ctx.translate(560, 1230); ctx.rotate(-0.06); ctx.fillRect(-150, -12, 290, 14); ctx.fillStyle = 'rgba(41,39,36,0.55)'; const wr = cl(o.write ?? 0.5); for (let k = 0; k < 8; k++) ctx.fillRect(-130, -9 + k * 1.4, 240 * (k < 7 ? 1 : wr), 0.8); ctx.restore();
   ctx.fillStyle = '#1f1b18'; ctx.beginPath(); ctx.ellipse(780, 1236, 26, 9, 0, 0, TAU); ctx.fill(); ctx.fillRect(758, 1204, 44, 32); ctx.fillStyle = '#3a2f26'; ctx.fillRect(764, 1196, 32, 10);
   const lx = 300, ly = 1236; ctx.fillStyle = '#B18A4C'; ctx.fillRect(lx - 34, ly - 14, 68, 14); ctx.fillRect(lx - 8, ly - 120, 16, 110); ctx.beginPath(); ctx.ellipse(lx, ly - 140, 30, 34, 0, 0, TAU); ctx.fillStyle = 'rgba(255,230,180,0.8)'; ctx.fill(); const fl = 0.85 + 0.15 * Math.sin(t * 13) * Math.sin(t * 7.3); P.glow(ctx, lx, ly - 150, 420, '255,190,110', 0.5 * fl * (o.lamp ?? 1)); ctx.fillStyle = `rgba(255,${200 + 30 * fl | 0},120,0.95)`; ctx.beginPath(); ctx.ellipse(lx, ly - 150, 7, 16, 0, 0, TAU); ctx.fill(); });
  return { desk: [560, 1230], window: [820, 400] };
 };
 // ESCRITOR DE 1865 (recreación genérica, de perfil, sentado escribiendo con pluma): silla, levita, pelo y barba claros, brazo que
 // traza renglones. x,y = punto de apoyo de la silla en el suelo; h = altura sentado. o: { write (fase), dir }
 P.writer1865 = (ctx, x, y, h, t, o = {}) => { const u = h / 300, d = o.dir ?? 1; ctx.save(); ctx.translate(x, y); ctx.scale(u * d, u); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = '#3a2618'; ctx.fillRect(-70, -150, 16, 150); ctx.fillRect(-70, -150, 110, 16); ctx.fillRect(28, -150, 12, 150); ctx.fillRect(-82, -330, 16, 200);
  ctx.strokeStyle = '#2a2a2e'; ctx.lineWidth = 26; ctx.beginPath(); ctx.moveTo(-20, -160); ctx.lineTo(70, -160); ctx.lineTo(74, -10); ctx.stroke(); ctx.fillStyle = '#151311'; ctx.beginPath(); ctx.ellipse(86, -6, 22, 8, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#29282c'; ctx.beginPath(); ctx.moveTo(-40, -150); ctx.quadraticCurveTo(-60, -260, -20, -330); ctx.quadraticCurveTo(20, -350, 40, -320); ctx.quadraticCurveTo(50, -240, 30, -150); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#efe7d6'; ctx.beginPath(); ctx.moveTo(18, -326); ctx.lineTo(40, -318); ctx.lineTo(30, -290); ctx.closePath(); ctx.fill();
  const wp = o.write ?? (t * 0.8 % 1), hx = 150 + Math.sin(wp * TAU * 4) * 6 + (wp % 1) * 40, hy = -205 + Math.sin(wp * TAU * 8) * 3; ctx.strokeStyle = '#29282c'; ctx.lineWidth = 22; ctx.beginPath(); ctx.moveTo(10, -310); ctx.quadraticCurveTo(70, -250, hx - 10, hy + 4); ctx.stroke(); ctx.fillStyle = '#e2bf9c'; ctx.beginPath(); ctx.ellipse(hx, hy, 13, 9, 0.3, 0, TAU); ctx.fill(); ctx.strokeStyle = '#efe7d6'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(hx + 4, hy + 4); ctx.lineTo(hx + 30, hy - 46); ctx.stroke(); ctx.fillStyle = 'rgba(245,240,228,0.9)'; ctx.beginPath(); ctx.moveTo(hx + 30, hy - 46); ctx.quadraticCurveTo(hx + 44, hy - 80, hx + 24, hy - 96); ctx.quadraticCurveTo(hx + 26, hy - 66, hx + 22, hy - 44); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#e2bf9c'; ctx.beginPath(); ctx.ellipse(20, -372, 30, 36, 0.15, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(46, -378); ctx.lineTo(58, -366); ctx.lineTo(46, -360); ctx.fill();
  ctx.fillStyle = '#d8d2c6'; ctx.beginPath(); ctx.moveTo(-6, -360); ctx.quadraticCurveTo(10, -300, 44, -340); ctx.quadraticCurveTo(52, -350, 46, -356); ctx.quadraticCurveTo(30, -340, 10, -352); ctx.closePath(); ctx.fill(); ctx.beginPath(); for (let k = 0; k < 8; k++) { const a = Math.PI * 0.95 + k / 7 * Math.PI * 1.15; ctx.arc(14 + Math.cos(a) * 30, -386 + Math.sin(a) * 28, 13, 0, TAU); } ctx.fill();
  ctx.restore(); return { hand: [x + hx * u * d, y + hy * u] };
 };
 // LIBRO DE 1865 (cubierta de época con título real de la novela y filetes dorados; sin texto inventado en el interior: renglones
 // ilegibles). o: { title, sub, year, open 0..1 (abre la tapa), rot }
 P.book1865 = (ctx, cx, cy, s, t, o = {}) => { ctx.save(); ctx.translate(cx, cy); ctx.rotate(o.rot ?? -0.05); ctx.scale(s, s); const op = cl(o.open || 0);
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.roundRect(-205, -275, 430, 570, 14); ctx.fill(); ctx.fillStyle = '#efe3c7'; ctx.fillRect(-196, -268, 400, 548); ctx.fillStyle = 'rgba(41,39,36,0.45)'; for (let k = 0; k < 22; k++) ctx.fillRect(-160, -220 + k * 22, k % 6 === 5 ? 180 : 330, 3);
  if (op < 1) { ctx.save(); ctx.scale(1 - op * 1.9, 1); ctx.translate(op * -10, 0); const g = ctx.createLinearGradient(-200, -270, 200, 270); g.addColorStop(0, '#7a2a1e'); g.addColorStop(1, '#4a1712'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-200, -272, 404, 556, 10); ctx.fill(); ctx.strokeStyle = '#d9b46a'; ctx.lineWidth = 4; ctx.strokeRect(-170, -242, 344, 496); ctx.lineWidth = 1.5; ctx.strokeRect(-158, -230, 320, 472);
   if (op < 0.4) { ctx.fillStyle = '#e8c87a'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 30px Fraunces, Georgia, serif'; ctx.fillText(o.top || 'JULES VERNE', 2, -170); ctx.font = '800 50px Fraunces, Georgia, serif'; const lines = (o.title || 'DE LA TERRE|À LA LUNE').split('|'); lines.forEach((l, i) => ctx.fillText(l, 2, -60 + i * 62)); ctx.beginPath(); ctx.arc(2, 110, 44, 0, TAU); ctx.lineWidth = 3; ctx.strokeStyle = '#e8c87a'; ctx.stroke(); ctx.beginPath(); ctx.arc(14, 104, 34, 0, TAU); ctx.fillStyle = '#5a1d15'; ctx.fill(); ctx.fillStyle = '#e8c87a'; ctx.font = '700 30px Fraunces, Georgia, serif'; ctx.fillText(o.year || '1865', 2, 210); }
   ctx.restore(); }
  ctx.restore(); };
 // MÁQUINA DE VAPOR de balancín (siglo XIX): cilindro, biela, balancín, volante que gira, caldera con humo. x,y = suelo. o: { rpm }
 P.steamEngine = (ctx, x, y, s, t, o = {}) => { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); const a = t * (o.rpm ?? 40) / 60 * TAU; ctx.fillStyle = '#3a2f28'; ctx.fillRect(-260, -30, 520, 30);
  ctx.fillStyle = '#5a4c40'; ctx.fillRect(-220, -260, 90, 230); ctx.fillStyle = '#B18A4C'; ctx.fillRect(-226, -270, 102, 14); ctx.fillRect(-226, -40, 102, 12); const py = -260 - 40 - Math.sin(a) * 40; ctx.strokeStyle = '#9aa0a4'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(-175, -260); ctx.lineTo(-175, py); ctx.stroke();
  ctx.strokeStyle = '#4a3f36'; ctx.lineWidth = 16; ctx.beginPath(); ctx.moveTo(-10, -30); ctx.lineTo(0, -400); ctx.stroke(); const bt = Math.sin(a) * 0.18; ctx.save(); ctx.translate(0, -400); ctx.rotate(bt); ctx.fillStyle = '#697178'; ctx.fillRect(-190, -12, 380, 24); ctx.restore();
  const bl = [-175 * Math.cos(bt), -400 - 175 * Math.sin(bt)], br = [175 * Math.cos(bt), -400 + 175 * Math.sin(bt)], wc = [175, -180], cr = [wc[0] + Math.cos(a) * 70, wc[1] + Math.sin(a) * 70]; ctx.strokeStyle = '#8a8f93'; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(br[0], br[1]); ctx.lineTo(cr[0], cr[1]); ctx.moveTo(bl[0], bl[1]); ctx.lineTo(-175, py); ctx.stroke();
  ctx.strokeStyle = '#2f2a26'; ctx.lineWidth = 16; ctx.beginPath(); ctx.arc(wc[0], wc[1], 150, 0, TAU); ctx.stroke(); ctx.lineWidth = 7; for (let k = 0; k < 6; k++) { const q = a + k * Math.PI / 3; ctx.beginPath(); ctx.moveTo(wc[0], wc[1]); ctx.lineTo(wc[0] + Math.cos(q) * 150, wc[1] + Math.sin(q) * 150); ctx.stroke(); } ctx.fillStyle = '#B18A4C'; ctx.beginPath(); ctx.arc(wc[0], wc[1], 18, 0, TAU); ctx.fill();
  const R = H.rng(4); for (let k = 0; k < 8; k++) { const ph = ((t * 0.4 + k / 8) % 1); ctx.fillStyle = `rgba(220,215,205,${0.4 * (1 - ph)})`; ctx.beginPath(); ctx.arc(-175 + Math.sin(k + t) * 20, -300 - ph * 300, 20 + ph * 50, 0, TAU); ctx.fill(); }
  ctx.restore(); };
 // MAPA DE EE. UU. inclinado (pseudo-3D con canto) con Florida resaltada y marcas. Contorno simplificado de los 48 estados contiguos.
 // o: { tilt 0..1, hl 0..1 (Florida), pins:[{lon,lat,label,sub,col,a}], era 0 (sepia) .. 1 (azul) }
 const USA = [[-124.7, 48.4], [-123, 46.2], [-124, 42], [-124.2, 40.4], [-122.4, 37.8], [-120.6, 34.6], [-117.1, 32.5], [-114.7, 32.7], [-111, 31.3], [-108.2, 31.3], [-106.5, 31.8], [-104.5, 29.7], [-103, 29], [-101.4, 29.8], [-99.5, 27.5], [-97.4, 25.9], [-97.4, 27.8], [-94.7, 29.3], [-93.8, 29.7], [-90.2, 29.1], [-89.4, 30.2], [-88, 30.4], [-86.5, 30.4], [-85, 29.7], [-84, 30.1], [-83, 29], [-82.6, 27.5], [-81.8, 26.1], [-81, 25.2], [-80.4, 25.2], [-80, 26.7], [-80.6, 28.6], [-81.3, 30.2], [-81.4, 31.4], [-80.9, 32], [-79.2, 33.2], [-77.9, 34], [-75.5, 35.3], [-76, 37], [-75.9, 38], [-74, 40.5], [-71.9, 41.3], [-70, 41.7], [-70.6, 42.7], [-70.2, 43.7], [-67, 44.8], [-67.8, 47.1], [-69.2, 47.4], [-71.5, 45], [-74.8, 45], [-76.5, 44.1], [-79.1, 43.3], [-79, 42.9], [-82.4, 41.7], [-83.4, 42.2], [-82.4, 43], [-82.7, 45.3], [-84.4, 46.5], [-88.4, 48.3], [-89.6, 48], [-95.2, 49], [-123.3, 49]];
 const FLA = [[-87.6, 31], [-85, 31], [-84.9, 30.7], [-82.2, 30.6], [-81.4, 30.7], [-81.3, 30.2], [-80.6, 28.6], [-80, 26.7], [-80.4, 25.2], [-81, 25.2], [-81.8, 26.1], [-82.6, 27.5], [-83, 29], [-84, 30.1], [-85, 29.7], [-86.5, 30.4], [-87.6, 30.3]];
 P.usMap = (ctx, cx, cy, w, t, o = {}) => { const k = w / 60, tilt = cl(o.tilt ?? 0.6), era = cl(o.era ?? 0), pr = (lo, la) => [cx + (lo + 96) * k * 0.8, cy - (la - 37) * k * lerp(1, 0.55, tilt)], th = 18 * tilt;
  const path = (pts, dy = 0) => { ctx.beginPath(); pts.forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y + dy) : ctx.moveTo(x, y + dy); }); ctx.closePath(); };
  ctx.save(); path(USA, th); ctx.fillStyle = P.mixc('#5a4630', '#0f2747', era); ctx.fill(); path(USA); ctx.fillStyle = P.mixc('#c9b086', '#1d4f86', era); ctx.fill(); ctx.strokeStyle = P.mixc('#6b5236', '#53C5E8', era); ctx.lineWidth = 3; ctx.stroke();
  const hl = cl(o.hl || 0); if (hl > 0) { path(FLA, -th * 0.6 * hl); ctx.fillStyle = `rgba(255,212,71,${0.9 * hl})`; ctx.fill(); ctx.strokeStyle = '#fff3c4'; ctx.lineWidth = 3; ctx.stroke(); const [fx, fy] = pr(-82, 28.5); P.glow(ctx, fx, fy, 160, '255,212,71', 0.35 * hl); }
  const out = {}; for (const pn of o.pins || []) { const a = cl(pn.a ?? 1); if (a <= 0) continue; const [x, y] = pr(pn.lon, pn.lat); out[pn.id || pn.label] = [x, y]; ctx.globalAlpha = a; ctx.fillStyle = pn.col || '#FFD447'; ctx.beginPath(); ctx.arc(x, y - 30, 14, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(x - 9, y - 26); ctx.lineTo(x + 9, y - 26); ctx.lineTo(x, y); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(x, y - 30, 5, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
  ctx.restore(); return { pr, pins: out };
 };
 // MÓDULO DE MANDO Y SERVICIO (Columbia): cono del módulo de mando, cilindro de servicio con tobera. x,y centro; ang (rad) dirección.
 P.csm = (ctx, x, y, s, ang, o = {}) => { ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.scale(s, s); ctx.fillStyle = '#8a8f93'; ctx.beginPath(); ctx.moveTo(-70, -12); ctx.lineTo(-96, -24); ctx.lineTo(-96, 24); ctx.lineTo(-70, 12); ctx.closePath(); ctx.fill(); const g = ctx.createLinearGradient(0, -34, 0, 34); g.addColorStop(0, '#e8ecea'); g.addColorStop(1, '#8f979c'); ctx.fillStyle = g; ctx.fillRect(-70, -34, 70, 68); ctx.fillStyle = '#c9ced0'; ctx.beginPath(); ctx.moveTo(0, -34); ctx.lineTo(46, -8); ctx.lineTo(46, 8); ctx.lineTo(0, 34); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#20262b'; ctx.fillRect(-50, -34, 10, 68); ctx.restore(); };
 // COMPARACIÓN CUALITATIVA de aceleración (sin cifras): dos curvas velocidad–tiempo en el mismo marco. Cañón: la velocidad se alcanza
 // en un instante (subida casi vertical en un recorrido corto). Cohete: crece durante varios minutos, con tramos de distinta pendiente
 // (la aceleración NO es constante; cambia con cada etapa). u 0..1 dibujo. o: { labels }
 P.accelCompare = (ctx, x, y, w, h, u, t, o = {}) => { ctx.save(); ctx.fillStyle = 'rgba(5,11,24,0.78)'; ctx.beginPath(); ctx.roundRect(x - 30, y - 70, w + 60, h + 180, 24); ctx.fill(); ctx.strokeStyle = 'rgba(245,247,250,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + h); ctx.lineTo(x + w, y + h); ctx.stroke();
  ctx.font = '700 32px Nunito'; ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText('velocidad', x + 10, y - 34); ctx.textAlign = 'right'; ctx.fillText('tiempo →', x + w, y + h + 40);
  const U = cl(u), cu = cl(U * 3), N = 80; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.strokeStyle = '#E7B56E'; ctx.beginPath(); ctx.moveTo(x, y + h); const xs = x + w * 0.04; ctx.lineTo(lerp(x, xs, cu), y + h - h * 0.92 * E.in(cu)); if (cu >= 1) ctx.lineTo(lerp(xs, x + w, (U - 1 / 3) / (2 / 3)), y + h * 0.08); ctx.stroke();
  const vr = (s) => { const s1 = 0.3, s2 = 0.72; if (s < s1) return 0.42 * Math.pow(s / s1, 1.6); if (s < s2) return 0.42 + 0.33 * Math.pow((s - s1) / (s2 - s1), 1.3); return 0.75 + 0.17 * Math.pow((s - s2) / (1 - s2), 1.2); }; ctx.strokeStyle = '#53C5E8'; ctx.beginPath(); for (let i = 0; i <= N * U; i++) { const s = i / N; ctx[i ? 'lineTo' : 'moveTo'](x + w * s, y + h - h * 0.92 * vr(s) + 6); } ctx.stroke();
  const la = cl((U - 0.15) * 4); if (la > 0 && o.labels !== false) { ctx.globalAlpha = la; ctx.textAlign = 'left'; ctx.font = '800 34px Nunito'; ctx.fillStyle = '#E7B56E'; ctx.fillText('CAÑÓN: DE GOLPE', x + w * 0.08, y + h * 0.08 + 44); ctx.fillStyle = '#53C5E8'; ctx.fillText('COHETE: VARIOS MINUTOS', x + w * 0.42, y + h * 0.86); ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.75)'; ctx.fillText('esquema cualitativo · sin escala', x, y + h + 86); }
  ctx.restore(); };
 // ---- v1.22.1 · rediseños: proyectil maestro, Tierra con continentes reales, Luna con relieve ----
 // Tronco de cono 3D v2 (sustituye a vFrustum): luz difusa + brillo especular metálico (o.spec, o.shin) y variación de color por cara
 // (o.vary(i, j) → factor). Mantiene la firma anterior.
 const vFrustum2 = (ctx, cam, x0, z0, y0, y1, r0, r1, colFn, o = {}) => { const N = o.N || 40, L = o.L || [0.6, 0.35, 0.72], ll = Math.hypot(...L), Ln = [L[0] / ll, L[1] / ll, L[2] / ll], amb = o.amb ?? 0.42, slope = (r0 - r1) / Math.max(1e-6, y1 - y0), sp = o.spec || 0, sh = o.shin || 22;
  for (let i = 0; i < N; i++) { const a0 = (i / N) * TAU, a1 = ((i + 1) / N) * TAU, am = (a0 + a1) / 2, nl = Math.hypot(1, slope), n = [Math.cos(am) / nl, slope / nl, Math.sin(am) / nl], rm = (r0 + r1) / 2, c = [x0 + rm * Math.cos(am), (y0 + y1) / 2, z0 + rm * Math.sin(am)]; if (!faceVis(cam, n, c)) continue;
   const dif = Math.max(0, n[0] * Ln[0] + n[1] * Ln[1] + n[2] * Ln[2]); let k = (amb + (1 - amb) * dif) * (o.vary ? o.vary(i, am, (y0 + y1) / 2) : 1); let f;
   if (sp > 0) { const V = [cam.pos[0] - c[0], cam.pos[1] - c[1], cam.pos[2] - c[2]], vl = Math.hypot(...V), Hh = [Ln[0] + V[0] / vl, Ln[1] + V[1] / vl, Ln[2] + V[2] / vl], hl = Math.hypot(...Hh), s = sp * Math.pow(Math.max(0, (n[0] * Hh[0] + n[1] * Hh[1] + n[2] * Hh[2]) / hl), sh), [r, g, b] = H.hex(colFn(am, (y0 + y1) / 2)); f = `rgb(${cl(r * k + 255 * s, 0, 255) | 0},${cl(g * k + 250 * s, 0, 255) | 0},${cl(b * k + 240 * s, 0, 255) | 0})`; } else f = rmShade(colFn(am, (y0 + y1) / 2), k);
   poly3(ctx, cam, [[x0 + r0 * Math.cos(a0), y0, z0 + r0 * Math.sin(a0)], [x0 + r0 * Math.cos(a1), y0, z0 + r0 * Math.sin(a1)], [x0 + r1 * Math.cos(a1), y1, z0 + r1 * Math.sin(a1)], [x0 + r1 * Math.cos(a0), y1, z0 + r1 * Math.sin(a0)]], f, { stroke: f, lw: 1 }); }
  if (cam.pos[1] > y1 && r1 > 0.01) { const pts = []; for (let i = 0; i < N; i++) { const a = (i / N) * TAU; pts.push([x0 + r1 * Math.cos(a), y1, z0 + r1 * Math.sin(a)]); } poly3(ctx, cam, pts, rmShade(colFn(0, y1), 1.05)); }
  if (o.under && cam.pos[1] < y0 && r0 > 0.01) { const pts = []; for (let i = 0; i < N; i++) { const a = (i / N) * TAU; pts.push([x0 + r0 * Math.cos(a), y0, z0 + r0 * Math.sin(a)]); } poly3(ctx, cam, pts, rmShade(colFn(0, y0), 0.5)); } };
 P.vFrustum = vFrustum2;
 // PROYECTIL DE VERNE — MODELO MAESTRO (ficción, 1865; inspirado en los grabados de la edición de 1868). Aluminio envejecido con
 // brillo moderado; brida de base de acero oscuro; cuerpo cilíndrico de 8 paneles con costuras remachadas; remate ojival con
 // escotilla de acceso atornillada y pomo; cuatro portillas con marco de bronce, cristal hundido y reflejo. Sin motores, alas ni
 // antenas. ≈ 2,74 m de diámetro y ≈ 4,6 m de alto. base = [x,y,z] (m). o: { L, rot (gira el modelo, rad), age (0..1) }
 const VC = { R: 1.37, base: 0.32, cyl: 2.75, top: 4.6, win: [[0.35, 1.75], [1.92, 1.75], [3.49, 1.75], [5.06, 1.75]] };
 const vcProf = () => { const p = [[VC.cyl, VC.R]]; for (let k = 1; k <= 9; k++) { const u = k / 9, y = VC.cyl + (VC.top - VC.cyl) * u, r = VC.R * Math.sqrt(Math.max(0, 1 - Math.pow(u, 1.6))) * (1 - 0.12 * u * u); p.push([y, Math.max(0.06, r)]); } return p; };
 const VCP = vcProf();
 P.vCapsule3 = (ctx, cam, base, t, o = {}) => { const [bx, by, bz] = base, L = o.L || [-0.55, 0.45, 0.7], rot = o.rot || 0, alu = o.col || '#BCC2C6', steel = '#5d6468', R = VC.R;
  const vary = (i, a) => 1 + 0.035 * Math.sin((a + rot) * 4 + 1.3) + 0.02 * Math.sin((a + rot) * 13);
  vFrustum2(ctx, cam, bx, bz, by - 0.02, by + 0.12, R + 0.1, R + 0.12, () => steel, { N: 56, L, amb: 0.35, spec: 0.25, under: true });
  vFrustum2(ctx, cam, bx, bz, by + 0.12, by + VC.base, R + 0.12, R + 0.04, () => '#7a8287', { N: 56, L, amb: 0.38, spec: 0.3 });
  vFrustum2(ctx, cam, bx, bz, by + VC.base, by + VC.cyl, R, R, () => alu, { N: 64, L, amb: 0.36, spec: 0.55, shin: 28, vary });
  for (let k = 0; k < VCP.length - 1; k++) vFrustum2(ctx, cam, bx, bz, by + VCP[k][0], by + VCP[k + 1][0], VCP[k][1], VCP[k + 1][1], () => alu, { N: 64, L, amb: 0.36, spec: 0.55, shin: 28, vary });
  vFrustum2(ctx, cam, bx, bz, by + VC.top - 0.02, by + VC.top + 0.16, 0.13, 0.05, () => '#8a6d3a', { N: 18, L, amb: 0.4, spec: 0.4 });
  // superficie: costuras y remaches (solo en la parte visible y no rasante)
  const surf = (a, y, r, d = 0.012) => [bx + (r + d) * Math.cos(a), by + y, bz + (r + d) * Math.sin(a)], visA = (a, y, r) => { const n = [Math.cos(a), 0, Math.sin(a)], c = surf(a, y, r, 0); const V = [cam.pos[0] - c[0], cam.pos[1] - c[1], cam.pos[2] - c[2]], vl = Math.hypot(...V); return (n[0] * V[0] + n[2] * V[2]) / vl; };
  ctx.save(); ctx.lineCap = 'round'; const seamH = (y, r) => { let pts = []; const flush = () => { if (pts.length > 1) { ctx.strokeStyle = 'rgba(60,66,70,0.55)'; ctx.lineWidth = 1.4; ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.stroke(); } pts = []; }; for (let i = 0; i <= 72; i++) { const a = (i / 72) * TAU; if (visA(a, y, r) < 0.12) { flush(); continue; } const Q = cam.clip([surf(a, y, r)], 1)[0]; if (Q) pts.push(Q); } flush();
   for (let i = 0; i < 64; i++) { const a = (i / 64) * TAU + 0.05; const vv = visA(a, y, r); if (vv < 0.25) continue; const Q = cam.clip([surf(a, y + 0.06, r, 0.02)], 1)[0]; if (!Q) continue; const rr = Math.max(0.7, 0.028 * cam.f / Q[2]); ctx.fillStyle = `rgba(235,238,240,${0.55 * vv})`; ctx.beginPath(); ctx.arc(Q[0] - rr * 0.3, Q[1] - rr * 0.3, rr, 0, TAU); ctx.fill(); ctx.fillStyle = `rgba(50,55,58,${0.5 * vv})`; ctx.beginPath(); ctx.arc(Q[0] + rr * 0.25, Q[1] + rr * 0.25, rr * 0.8, 0, TAU); ctx.fill(); } };
  seamH(VC.base + 0.02, R); seamH(1.05, R); seamH(2.35, R); seamH(VC.cyl, R); seamH(3.55, VCP[4][1]);
  for (let k = 0; k < 8; k++) { const a = (k / 8) * TAU + rot + 0.2; if (visA(a, 1.5, R) < 0.15) continue; const A = cam.clip([surf(a, VC.base, R)], 1)[0], B2 = cam.clip([surf(a, VC.cyl, R)], 1)[0]; if (A && B2) { ctx.strokeStyle = 'rgba(70,76,80,0.45)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B2[0], B2[1]); ctx.stroke(); } }
  // portillas: marco de bronce (anillo), cristal hundido con borde interior en sombra y reflejo; profundidad según la vista
  const ell = (a, y, rad, d) => { const pts = []; for (let k = 0; k < 24; k++) { const q = (k / 24) * TAU, da = (Math.cos(q) * rad) / R, dy = Math.sin(q) * rad; pts.push(cam.clip([surf(a + da, y + dy, R, d)], 1)[0]); } return pts.every((p) => p) ? pts : null; };
  for (const [a0, y] of VC.win) { const a = a0 + rot, vv = visA(a, y, R); if (vv < 0.08) continue; const fr = ell(a, y, 0.34, 0.03), gl = ell(a, y, 0.24, 0.035), sh = ell(a, y, 0.24, -0.06); if (!fr || !gl || !sh) continue; const P2 = (pts, fill, st) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (st) { ctx.strokeStyle = st; ctx.lineWidth = 1.2; ctx.stroke(); } };
   P2(fr, '#8a6a36', 'rgba(40,30,15,0.7)'); P2(fr.map((p, i) => [lerp(p[0], gl[i][0], 0.5) - 1, lerp(p[1], gl[i][1], 0.5) - 1]), 'rgba(220,180,110,0.55)'); P2(gl, '#2a2018'); P2(sh, '#0f1a22'); const c0 = gl.reduce((s, p) => [s[0] + p[0] / gl.length, s[1] + p[1] / gl.length], [0, 0]), rr = Math.hypot(gl[0][0] - c0[0], gl[0][1] - c0[1]); const g = ctx.createRadialGradient(c0[0] - rr * 0.4, c0[1] - rr * 0.4, rr * 0.05, c0[0], c0[1], rr * 1.1); g.addColorStop(0, 'rgba(210,230,240,0.85)'); g.addColorStop(0.35, 'rgba(90,120,140,0.5)'); g.addColorStop(1, 'rgba(10,20,28,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c0[0], c0[1], rr * 0.9, 0, TAU); ctx.fill();
   for (let k = 0; k < 8; k++) { const p = fr[k * 3]; ctx.fillStyle = '#d9b46e'; ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(0.8, rr * 0.08), 0, TAU); ctx.fill(); } }
  // escotilla de acceso en la ojiva (atornillada) y asas
  { const a = 0.9 + rot, y = 3.25, rh = VCP[3][1], n = [Math.cos(a), 0.45, Math.sin(a)], c = [bx + rh * Math.cos(a), by + y, bz + rh * Math.sin(a)]; if (faceVis(cam, n, c)) { const pts = []; for (let k = 0; k < 20; k++) { const q = (k / 20) * TAU; pts.push(cam.clip([[bx + (rh + 0.03) * Math.cos(a + Math.cos(q) * 0.24), by + y + Math.sin(q) * 0.3, bz + (rh + 0.03) * Math.sin(a + Math.cos(q) * 0.24)]], 1)[0]); } if (pts.every((p) => p)) { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fillStyle = 'rgba(150,158,162,0.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(45,50,54,0.8)'; ctx.lineWidth = 2; ctx.stroke(); for (let k = 0; k < 20; k += 2) { ctx.fillStyle = '#e4e7e8'; ctx.beginPath(); ctx.arc(pts[k][0], pts[k][1], 1.6, 0, TAU); ctx.fill(); } } } }
  ctx.restore();
  return { top: cam.clip([[bx, by + VC.top, bz]], 1)[0], mid: cam.clip([[bx, by + 2, bz]], 1)[0], base: cam.clip([[bx, by, bz]], 1)[0] };
 };
 P.VC = VC;
 // El MISMO modelo en cualquier punto de la pantalla (iconos, esquemas): x,y = centro, hpx = alto en px, ang = giro en pantalla,
 // az = acimut de la vista (gira el volumen), el = elevación de la vista. o: { L }
 P.vCapsuleAt = (ctx, x, y, hpx, ang, t, o = {}) => { const d = 40, az = o.az ?? 0.6, el = o.el ?? 0.15, f = (hpx * d) / VC.top, cam = P.cam3([Math.cos(az) * d * Math.cos(el), 2.3 + Math.sin(el) * d, Math.sin(az) * d * Math.cos(el)], [0, 2.3, 0], f); ctx.save(); ctx.translate(x, y); ctx.rotate(ang || 0); ctx.translate(-540, -960); P.vCapsule3(ctx, cam, [0, 0, 0], t, { L: o.L, rot: o.rot }); ctx.restore(); };
 // TIERRA v2: continentes reales simplificados (contornos lon/lat rasterizados una vez), desiertos/vegetación/hielo, nubes
 // deterministas, terminador con lado nocturno, atmósfera. o: { rot (rad; 0 = meridiano 0 al centro), light, tilt }
 const LANDS = [[[-168, 66], [-162, 70], [-140, 70], [-125, 70], [-110, 73], [-95, 72], [-82, 70], [-80, 63], [-90, 58], [-78, 55], [-65, 60], [-60, 55], [-56, 50], [-66, 45], [-70, 42], [-75, 39], [-76, 35], [-81, 31], [-80, 26], [-82, 28], [-84, 30], [-90, 29], [-97, 27], [-97, 22], [-92, 19], [-87, 21], [-88, 16], [-83, 10], [-79, 9], [-80, 7], [-85, 11], [-92, 15], [-105, 20], [-110, 24], [-115, 30], [-118, 33], [-123, 38], [-124, 42], [-124, 48], [-130, 54], [-140, 59], [-150, 60], [-158, 57], [-165, 60]],
  [[-55, 60], [-44, 60], [-20, 70], [-20, 80], [-40, 83], [-60, 82], [-70, 78], [-58, 75], [-55, 68]],
  [[-80, 8], [-72, 12], [-62, 10], [-52, 5], [-50, 0], [-35, -5], [-35, -10], [-39, -15], [-41, -22], [-48, -26], [-53, -34], [-58, -38], [-65, -42], [-68, -50], [-70, -55], [-74, -50], [-74, -42], [-72, -30], [-71, -18], [-76, -14], [-81, -6], [-80, 0], [-78, 4]],
  [[-10, 36], [-9, 43], [-2, 44], [-5, 48], [0, 50], [5, 53], [8, 55], [12, 58], [5, 62], [15, 69], [28, 71], [40, 67], [45, 68], [60, 70], [70, 73], [80, 73], [100, 77], [110, 74], [130, 72], [150, 71], [170, 70], [180, 66], [175, 62], [163, 60], [160, 55], [142, 52], [141, 46], [135, 43], [129, 40], [126, 35], [121, 31], [122, 25], [115, 22], [108, 21], [106, 17], [109, 12], [105, 9], [103, 1], [100, 6], [98, 10], [98, 16], [94, 17], [92, 22], [88, 22], [80, 15], [77, 8], [73, 16], [70, 21], [66, 25], [57, 25], [56, 27], [50, 30], [48, 29], [51, 24], [56, 26], [59, 22], [52, 16], [43, 13], [39, 21], [35, 28], [33, 31], [35, 36], [30, 36], [27, 37], [26, 40], [23, 38], [20, 40], [16, 38], [12, 44], [10, 44], [3, 43], [-5, 36]],
  [[-17, 21], [-16, 28], [-10, 32], [-6, 36], [3, 37], [10, 37], [20, 33], [30, 31], [33, 31], [35, 24], [38, 18], [43, 12], [51, 12], [48, 5], [41, -2], [40, -10], [40, -16], [35, -24], [33, -28], [27, -34], [20, -35], [18, -30], [13, -20], [12, -12], [13, -5], [9, 0], [10, 4], [5, 5], [-2, 5], [-8, 4], [-13, 8], [-17, 14]],
  [[44, -25], [48, -25], [50, -15], [49, -12], [44, -16]], [[114, -22], [114, -34], [118, -35], [124, -33], [131, -31], [138, -35], [141, -38], [147, -38], [150, -37], [153, -28], [153, -25], [146, -19], [142, -11], [136, -12], [131, -11], [126, -14], [122, -18]],
  [[-5, 50], [2, 51], [-1, 55], [-3, 58], [-6, 57], [-5, 54]], [[109, 1], [117, 7], [119, 1], [116, -4], [110, -3]], [[95, 5], [104, -5], [106, -6], [100, 0]], [[130, 31], [135, 34], [141, 36], [142, 43], [140, 41], [135, 35], [131, 34]], [[-180, -68], [180, -68], [180, -90], [-180, -90]]];
 let EARTHT = null; const earthTex = () => { if (EARTHT || typeof document === 'undefined') return EARTHT; const Wt = 2048, Ht = 1024, c = document.createElement('canvas'); c.width = Wt; c.height = Ht; const g = c.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, Wt, Ht); g.fillStyle = '#fff'; for (const poly of LANDS) { g.beginPath(); poly.forEach(([lo, la], i) => { const x = ((lo + 180) / 360) * Wt, y = ((90 - la) / 180) * Ht; i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); g.fill(); } const d = g.getImageData(0, 0, Wt, Ht).data, land = new Float32Array(Wt * Ht); for (let i = 0; i < land.length; i++) land[i] = d[i * 4] / 255;
  const R = H.rng(7), G = 64, grid = new Float32Array(G * G * 4); for (let i = 0; i < grid.length; i++) grid[i] = R(); const vn = (x, y, s) => { const gx = ((x * s) % G + G) % G, gy = ((y * s) % G + G) % G, x0 = Math.floor(gx), y0 = Math.floor(gy), fx = gx - x0, fy = gy - y0, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy), v = (i, j) => grid[(((j % G) + G) % G) * G + (((i % G) + G) % G)]; return lerp(lerp(v(x0, y0), v(x0 + 1, y0), ux), lerp(v(x0, y0 + 1), v(x0 + 1, y0 + 1), ux), uy); }, fbm = (x, y) => vn(x, y, 1) * 0.5 + vn(x + 7, y + 3, 2) * 0.25 + vn(x + 2, y + 9, 4) * 0.15 + vn(x + 5, y + 1, 8) * 0.1;
  const Wc = 512, Hc = 256, cloud = new Float32Array(Wc * Hc), veg = new Float32Array(Wc * Hc); for (let y = 0; y < Hc; y++) for (let x = 0; x < Wc; x++) { const u = (x / Wc) * 16, v = (y / Hc) * 8, f = fbm(u, v), band = 0.5 + 0.5 * Math.cos(((y / Hc) - 0.5) * Math.PI * 6); cloud[y * Wc + x] = cl((f + band * 0.12 - 0.52) * 3.2); veg[y * Wc + x] = fbm(u * 1.7 + 30, v * 1.7); }
  EARTHT = { land, Wt, Ht, cloud, veg, Wc, Hc }; return EARTHT; };
 let EARTHC2 = null; P.earth3 = (ctx, cx, cy, r, t, o = {}) => { if (typeof document === 'undefined') return; const tex = earthTex(), RS = Math.round(cl(r * 1.8, 160, 1100)); if (!EARTHC2 || EARTHC2.width !== RS) { EARTHC2 = document.createElement('canvas'); EARTHC2.width = RS; EARTHC2.height = RS; } const g = EARTHC2.getContext('2d'), im = g.createImageData(RS, RS), L = o.light || [0.7, 0.3, 0.65], ll = Math.hypot(...L), rot = (o.rot ?? 0) - 1.6, tl = o.tilt ?? 0.35, ct = Math.cos(tl), st = Math.sin(tl), crot = (t || 0) * 0.004;
  const samp = (arr, W2, H2, u, v) => { const x = u * W2 - 0.5, y = v * H2 - 0.5, x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0, X0 = ((x0 % W2) + W2) % W2, X1 = (X0 + 1) % W2, Y0 = cl(y0, 0, H2 - 1), Y1 = cl(y0 + 1, 0, H2 - 1); return lerp(lerp(arr[Y0 * W2 + X0], arr[Y0 * W2 + X1], fx), lerp(arr[Y1 * W2 + X0], arr[Y1 * W2 + X1], fx), fy); };
  for (let py = 0; py < RS; py++) for (let px = 0; px < RS; px++) { const nx = (px + 0.5) / RS * 2 - 1, ny = 1 - (py + 0.5) / RS * 2, q = nx * nx + ny * ny, i4 = (py * RS + px) * 4; if (q > 1) { im.data[i4 + 3] = 0; continue; } const nzv = Math.sqrt(1 - q), y2 = ny * ct + nzv * st, z2 = -ny * st + nzv * ct, lat = Math.asin(cl(y2, -1, 1)), lon = Math.atan2(nx, z2) + rot, u = ((((lon / TAU) + 0.5) % 1) + 1) % 1, v = 0.5 - lat / Math.PI, la = Math.abs(lat);
   const ld = samp(tex.land, tex.Wt, tex.Ht, u, v), vg = samp(tex.veg, tex.Wc, tex.Hc, u, v), desert = cl((0.55 - vg) * 4) * cl(1 - Math.abs(la - 0.42) * 4), ice = cl((la - 1.12) * 8); let c = [14 + 10 * (1 - la), 52 + 30 * Math.cos(lat), 112 + 40 * Math.cos(lat)]; if (ld > 0.01) { const gr = [70 + vg * 40, 104 + vg * 26, 58 + vg * 10], ds = [194, 168, 120], lc = gr.map((x, k) => lerp(lerp(x, ds[k], desert), 236, ice)); c = c.map((x, k) => lerp(x, lc[k], ld)); }
   const cf = Math.min(0.9, samp(tex.cloud, tex.Wc, tex.Hc, (u + crot) % 1, v)); c = c.map((x) => lerp(x, 240, cf));
   const dif = (nx * L[0] + ny * L[1] + nzv * L[2]) / ll, day = cl(dif * 3 + 0.5), sh = 0.05 + 0.95 * Math.max(0, dif), rim = Math.pow(1 - nzv, 2.5);
   im.data[i4] = cl(c[0] * sh * day + 40 * rim * day, 0, 255); im.data[i4 + 1] = cl(c[1] * sh * day + 110 * rim * day + 4, 0, 255); im.data[i4 + 2] = cl(c[2] * sh * day + 230 * rim * day + 10, 0, 255); im.data[i4 + 3] = 255 * Math.min(1, (1 - q) * 40); }
  g.putImageData(im, 0, 0); P.glow(ctx, cx, cy, r * 1.22, '90,160,255', 0.2); ctx.drawImage(EARTHC2, cx - r, cy - r, 2 * r, 2 * r); ctx.save(); ctx.strokeStyle = 'rgba(120,180,255,0.35)'; ctx.lineWidth = Math.max(1.5, r * 0.025); ctx.beginPath(); ctx.arc(cx, cy, r * 1.005, 0, TAU); ctx.stroke(); ctx.restore(); };
 // LUNA v2: mapa de relieve (cráteres con cuenco y borde de tamaños en ley de potencia, menos densos en los mares, algunos jóvenes
 // con eyecta clara) y albedo de mares; sombreado por píxel con la normal perturbada por el relieve → sombras dentro de los cráteres
 // según la luz. o: { rot, light, glow, res, col }
 let MOONT2 = null; const moonTex2 = () => { if (MOONT2) return MOONT2; const Wt = 1024, Ht = 512, alb = new Float32Array(Wt * Ht), hgt = new Float32Array(Wt * Ht), R = H.rng(1969); for (let i = 0; i < alb.length; i++) { alb[i] = 0.7 + (R() - 0.5) * 0.04; }
  const idx = (x, y) => (((y % Ht) + Ht) % Ht) * Wt + (((x % Wt) + Wt) % Wt);
  for (const [lo, la, rl, rb] of [[-15, 33, 18, 13], [17, 28, 10, 9], [31, 9, 12, 9], [59, 17, 7, 6], [51, -4, 8, 9], [-17, -21, 10, 8], [-55, 20, 24, 30], [-40, -15, 12, 14], [-5, 10, 8, 6], [7, -20, 6, 6], [31, -15, 7, 6], [-25, 45, 14, 4], [-65, -5, 10, 18]]) { const x0 = Math.floor(((lo + 180) / 360) * Wt), y0 = Math.floor(((90 - la) / 180) * Ht), rx = Math.ceil(rl / 360 * Wt * 1.6), ry = Math.ceil(rb / 180 * Ht * 1.6); for (let y = y0 - ry; y <= y0 + ry; y++) for (let x = x0 - rx; x <= x0 + rx; x++) { const dl = ((x - x0) / Wt) * 360, db = ((y - y0) / Ht) * 180, wob = 1 + 0.07 * Math.sin(Math.atan2(db, dl) * 3 + lo) + 0.05 * Math.sin(Math.atan2(db, dl) * 7 + la); const qq = Math.hypot(dl / rl, db / rb) / wob; if (qq < 1.25) alb[idx(x, y)] -= 0.27 * cl((1.25 - qq) / 0.5); } }
  const crater = (lo, la, rad, young) => { const x0 = ((lo + 180) / 360) * Wt, y0 = ((90 - la) / 180) * Ht, ry = (rad / 180) * Ht, rx = ry / Math.max(0.2, Math.cos(la / 57.3)); for (let y = Math.floor(y0 - ry * 1.8); y <= Math.ceil(y0 + ry * 1.8); y++) for (let x = Math.floor(x0 - rx * 1.8); x <= Math.ceil(x0 + rx * 1.8); x++) { const q = Math.hypot((x - x0) / rx, (y - y0) / ry); if (q > 1.8) continue; const i = idx(x, y); let h = 0; if (q < 1) h = -(1 - q * q) * 0.9 + 0.25; else h = 0.25 * Math.exp(-((q - 1) * (q - 1)) / 0.08); hgt[i] += h * rad * 0.12; if (young && q < 1.6) alb[i] += 0.06 * (1.6 - q); } };
  for (let c = 0; c < 2200; c++) { const lo = R.range(-180, 180), la = Math.asin(R.range(-1, 1)) * 57.3, u = R(), rad = 0.35 * Math.pow(1 - u, -0.55); if (rad > 9) continue; const ia = idx(Math.floor(((lo + 180) / 360) * Wt), Math.floor(((90 - la) / 180) * Ht)); if (alb[ia] < 0.55 && R() < 0.75) continue; crater(lo, la, rad, R() < 0.03); }
  crater(-11, -43, 2.2, true); crater(-20, 10, 1.6, true); crater(-38, 8, 1.2, true);
  { const lo = -11, la = -43; for (let k2 = 0; k2 < 22; k2++) { const an = k2 / 22 * TAU + R() * 0.2; for (let s = 2; s < 50; s += 0.4) { const x = Math.floor(((lo + Math.cos(an) * s * 1.4 + 180) / 360) * Wt), y = Math.floor(((90 - (la + Math.sin(an) * s)) / 180) * Ht); if (y >= 0 && y < Ht) alb[idx(x, y)] += 0.035 * (1 - s / 50); } } }
  const gx = new Float32Array(Wt * Ht), gy = new Float32Array(Wt * Ht); for (let y = 0; y < Ht; y++) for (let x = 0; x < Wt; x++) { const i = y * Wt + x; gx[i] = (hgt[idx(x + 1, y)] - hgt[idx(x - 1, y)]) * 0.5; gy[i] = (hgt[idx(x, y - 1)] - hgt[idx(x, y + 1)]) * 0.5; }
  MOONT2 = { alb, gx, gy, Wt, Ht }; return MOONT2; };
 let MOONC2 = null; P.moon3 = (ctx, cx, cy, r, t, o = {}) => { if (typeof document === 'undefined') return; const tex = moonTex2(), RS = o.res || Math.round(cl(r * 1.6, 160, 960)); if (!MOONC2 || MOONC2.width !== RS) { MOONC2 = document.createElement('canvas'); MOONC2.width = RS; MOONC2.height = RS; } const g = MOONC2.getContext('2d'), im = g.createImageData(RS, RS), L = o.light || [0.75, 0.25, 0.6], ll = Math.hypot(...L), Ln = [L[0] / ll, L[1] / ll, L[2] / ll], rot = o.rot || 0, c0 = H.hex(o.col || '#a2a6a8'), kb = 9;
  for (let py = 0; py < RS; py++) for (let px = 0; px < RS; px++) { const nx = (px + 0.5) / RS * 2 - 1, ny = 1 - (py + 0.5) / RS * 2, q = nx * nx + ny * ny, i4 = (py * RS + px) * 4; if (q > 1) { im.data[i4 + 3] = 0; continue; } const nz = Math.sqrt(1 - q), lat = Math.asin(ny), l0 = Math.atan2(nx, nz), lon = l0 + rot; const tx = Math.floor(((((lon / TAU) + 0.5) % 1) + 1) % 1 * tex.Wt) % tex.Wt, ty = Math.min(tex.Ht - 1, Math.floor((0.5 - lat / Math.PI) * tex.Ht)), ti = ty * tex.Wt + tx;
   const ex = [Math.cos(l0), 0, -Math.sin(l0)], sl = Math.sin(lat), nv = [-sl * Math.sin(l0), Math.cos(lat), -sl * Math.cos(l0)], dx = tex.gx[ti] * kb, dy = tex.gy[ti] * kb; let mx = nx - dx * ex[0] - dy * nv[0], my = ny - dy * nv[1], mz = nz - dx * ex[2] - dy * nv[2]; const ml = Math.hypot(mx, my, mz); mx /= ml; my /= ml; mz /= ml;
   const dif = Math.max(0, mx * Ln[0] + my * Ln[1] + mz * Ln[2]), base = Math.max(0, nx * Ln[0] + ny * Ln[1] + nz * Ln[2]), sh = 0.025 + 0.975 * Math.pow(dif, 0.9) * cl(base * 6), alb = tex.alb[ti], edge = Math.min(1, (1 - q) * 40);
   im.data[i4] = cl(c0[0] * alb * sh * 1.5, 0, 255); im.data[i4 + 1] = cl(c0[1] * alb * sh * 1.5, 0, 255); im.data[i4 + 2] = cl(c0[2] * alb * sh * 1.5, 0, 255); im.data[i4 + 3] = 255 * edge; }
  g.putImageData(im, 0, 0); if (o.glow) P.glow(ctx, cx, cy, r * 1.3, '200,210,220', 0.1 * o.glow); ctx.drawImage(MOONC2, cx - r, cy - r, 2 * r, 2 * r); };
 // ENTORNO DE FLORIDA EN 1865 (estilizado): cielo con nubes suaves, línea de bosque lejana, terreno con manchas de arena y hierba,
 // matas y palmeras a varias distancias (profundidad). o: { sky (false = sin cielo), seed }
 P.florida1865 = (ctx, cam, t, o = {}) => { if (o.sky !== false) { const g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, '#5a7d9e'); g.addColorStop(0.55, '#c9c4a6'); g.addColorStop(1, '#e6d8b4'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); const R0 = H.rng(3); ctx.save(); for (let k = 0; k < 7; k++) { const x = R0() * W, y = 120 + R0() * 500, w = 200 + R0() * 300; ctx.globalAlpha = 0.18 + R0() * 0.12; ctx.fillStyle = '#f4efe2'; for (let j = 0; j < 5; j++) { ctx.beginPath(); ctx.ellipse(x + (j - 2) * w * 0.18, y + Math.sin(j) * 12, w * 0.22, 30 + R0() * 20, 0, 0, TAU); ctx.fill(); } } ctx.restore(); }
  const G = 4000; poly3(ctx, cam, [[-G, 0, -G], [G, 0, -G], [G, 0, G], [-G, 0, G]], '#a39a6c'); const R = H.rng(o.seed || 21);
  for (let i = 0; i < 140; i++) { const x = R.range(-500, 500), z = R.range(-900, 120), s = R.range(2, 9); if (Math.hypot(x, z) < 8) continue; poly3(ctx, cam, [[x - s, 0.02, z], [x, 0.02, z - s * 0.5], [x + s, 0.02, z], [x, 0.02, z + s * 0.5]], R() < 0.45 ? '#b8a978' : R() < 0.5 ? '#8c8a58' : '#97915f'); }
  const trees = []; for (let i = 0; i < 46; i++) trees.push([R.range(-900, 900), R.range(-1100, -700), R.range(10, 18)]); for (const [x, z, h] of trees) { const a = cam.clip([[x, 0, z]], 1)[0], b = cam.clip([[x, h, z]], 1)[0]; if (!a || !b) continue; const hp = a[1] - b[1]; ctx.fillStyle = '#5d6b43'; ctx.beginPath(); ctx.ellipse(a[0], a[1] - hp * 0.6, hp * 0.45, hp * 0.55, 0, 0, TAU); ctx.fill(); }
  const tufts = []; for (let i = 0; i < 90; i++) tufts.push([R.range(-60, 60), R.range(-140, 30)]); tufts.sort((p, q) => cam.depth([q[0], 0, q[1]]) - cam.depth([p[0], 0, p[1]])); for (const [x, z] of tufts) { if (Math.hypot(x, z) < 5) continue; const a = cam.clip([[x, 0, z]], 1)[0], b = cam.clip([[x, 0.5, z]], 1)[0]; if (!a || !b) continue; const hp = a[1] - b[1]; ctx.strokeStyle = 'rgba(92,98,58,0.85)'; ctx.lineWidth = Math.max(1, hp * 0.12); ctx.beginPath(); for (let k = -2; k <= 2; k++) { ctx.moveTo(a[0], a[1]); ctx.lineTo(a[0] + k * hp * 0.25, a[1] - hp * (1 - Math.abs(k) * 0.15)); } ctx.stroke(); }
  for (const [x, z, h] of o.palms || [[-26, -40, 9], [30, -70, 11], [-55, -18, 8], [60, -30, 10], [-12, -110, 12], [22, -160, 12], [-80, -90, 10]]) { const a = cam.clip([[x, 0, z]], 1)[0], b = cam.clip([[x, h, z]], 1)[0]; if (a && b && P.palm) P.palm(ctx, a[0], a[1], a[1] - b[1], t); } };
 // CUNA DE MADERA para el proyectil (vigas, travesaños y calzos curvos que abrazan la brida), con sombra de contacto en el suelo.
 // Devuelve la altura de apoyo (m) donde va la base del proyectil.
 P.capsuleCradle = (ctx, cam, t, o = {}) => { const top = 0.7; ctx.save(); ctx.fillStyle = 'rgba(40,30,18,0.35)'; poly3(ctx, cam, (() => { const p = []; for (let k = 0; k < 24; k++) { const a = k / 24 * TAU; p.push([2.6 * Math.cos(a) + 0.4, 0.01, 2.2 * Math.sin(a) + 0.3]); } return p; })(), 'rgba(40,30,18,0.32)'); ctx.restore();
  const wood = '#6b4c30', wood2 = '#7c5a3a'; for (const z of [-1.5, 1.2]) P.box3(ctx, cam, -2.3, 2.3, 0, 0.32, z, z + 0.32, wood, {}); for (const x of [-1.9, -0.6, 0.6, 1.9]) P.box3(ctx, cam, x - 0.16, x + 0.16, 0.32, 0.58, -1.7, 1.7, wood2, {});
  for (const [x, z] of [[-1.25, 0], [1.25, 0], [0, -1.25], [0, 1.25]]) P.box3(ctx, cam, x - 0.3, x + 0.3, 0.58, top, z - 0.3, z + 0.3, '#5a3f27', {}); return top; };
 // VIAJERO DE 1865 v2 (personajes de ficción; sustituye al anterior): proporciones más naturales, codos articulados, manos,
 // balanceo leve, ropa distinta por personaje (levita negra y chistera; abrigo gris y bombín; chaqueta clara y pelo revuelto).
 // Poses: 'stand', 'walk', 'point', 'wave', 'hat' (se quita el sombrero), 'talk'. o: { var, pose, ph, dir, look }
 P.traveler1865 = (ctx, x, y, h, t, o = {}) => { const v = o.var ?? 0, u = h / 180, d = o.dir ?? 1, pose = o.pose || 'stand', ph = o.ph ?? 0, sway = Math.sin(t * 1.3 + v * 2) * 1.5;
  const S = [{ coat: '#26252a', coat2: '#3a3940', vest: '#5a1f1a', pants: '#3c3a38', skin: '#e0b896', hair: '#4a3a2c', hat: 'top', beard: 'full', tall: 1 }, { coat: '#4a4c50', coat2: '#5c5e62', vest: '#2f3a52', pants: '#56524c', skin: '#d6a985', hair: '#7a6f64', hat: 'bowler', beard: 'mutton', tall: 0.96 }, { coat: '#8a6e4e', coat2: '#a08262', vest: '#c9b48a', pants: '#3f3a36', skin: '#e8c4a0', hair: '#b4572e', hat: 'none', beard: 'goatee', tall: 1.02 }][v % 3];
  ctx.save(); ctx.translate(x, y); ctx.scale(u * d * S.tall, u * S.tall); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(4, 1, 34, 6, 0, 0, TAU); ctx.fill();
  const sw = pose === 'walk' ? Math.sin(ph * TAU) : 0, hip = [sway * 0.3, -94], sh = [sway * 0.6, -150], legs = (k) => { const f = [(k ? 10 : -10) + sw * (k ? -16 : 16), -2], kn = [lerp(hip[0], f[0], 0.5) + 3, -50 - Math.abs(sw) * 3]; ctx.strokeStyle = k ? S.pants : ykHex(H.mix(S.pants, '#000000', 0.2)); ctx.lineWidth = 14; ctx.beginPath(); ctx.moveTo(hip[0] + (k ? 6 : -6), hip[1]); ctx.lineTo(kn[0] + (k ? 2 : -2), kn[1]); ctx.lineTo(f[0], f[1] - 6); ctx.stroke(); ctx.fillStyle = '#18140f'; ctx.beginPath(); ctx.ellipse(f[0] + 5, f[1] - 3, 12, 5, 0, 0, TAU); ctx.fill(); };
  legs(0); legs(1);
  ctx.fillStyle = S.coat; ctx.beginPath(); ctx.moveTo(sh[0] - 21, sh[1] + 2); ctx.quadraticCurveTo(sh[0] - 27, -108, hip[0] - 24, -54); ctx.lineTo(hip[0] - 4, -62); ctx.lineTo(hip[0] + 2, -96); ctx.lineTo(hip[0] + 8, -62); ctx.lineTo(hip[0] + 26, -54); ctx.quadraticCurveTo(sh[0] + 27, -108, sh[0] + 21, sh[1] + 2); ctx.quadraticCurveTo(sh[0], sh[1] - 8, sh[0] - 21, sh[1] + 2); ctx.closePath(); ctx.fill();
  ctx.fillStyle = S.vest; ctx.beginPath(); ctx.moveTo(sh[0] - 7, sh[1] + 2); ctx.lineTo(sh[0] + 7, sh[1] + 2); ctx.lineTo(hip[0] + 6, -98); ctx.lineTo(hip[0] - 6, -98); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#f2ece0'; ctx.beginPath(); ctx.moveTo(sh[0] - 5, sh[1] + 1); ctx.lineTo(sh[0] + 5, sh[1] + 1); ctx.lineTo(sh[0], sh[1] + 16); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#141316'; ctx.beginPath(); ctx.moveTo(sh[0] - 7, sh[1] + 1); ctx.lineTo(sh[0], sh[1] + 5); ctx.lineTo(sh[0] + 7, sh[1] + 1); ctx.lineTo(sh[0], sh[1] + 8); ctx.closePath(); ctx.fill();
  const arm = (side, hx, hy) => { const s0 = [sh[0] + side * 19, sh[1] + 6], dx = hx - s0[0], dy = hy - s0[1], dd = Math.min(66, Math.hypot(dx, dy)), a = Math.atan2(dy, dx), c = Math.acos(cl((34 * 34 + dd * dd - 32 * 32) / (2 * 34 * dd), -1, 1)), ea = a + side * -c * (d > 0 ? 1 : 1), el = [s0[0] + Math.cos(ea) * 34, s0[1] + Math.sin(ea) * 34]; ctx.strokeStyle = side < 0 ? ykHex(H.mix(S.coat, '#000000', 0.15)) : S.coat2; ctx.lineWidth = 11; ctx.beginPath(); ctx.moveTo(s0[0], s0[1]); ctx.lineTo(el[0], el[1]); ctx.lineTo(s0[0] + Math.cos(a) * dd, s0[1] + Math.sin(a) * dd); ctx.stroke(); ctx.fillStyle = '#efe7d6'; ctx.beginPath(); ctx.arc(s0[0] + Math.cos(a) * (dd - 4), s0[1] + Math.sin(a) * (dd - 4), 5.5, 0, TAU); ctx.fill(); ctx.fillStyle = S.skin; ctx.beginPath(); ctx.ellipse(s0[0] + Math.cos(a) * (dd + 3), s0[1] + Math.sin(a) * (dd + 3), 6.5, 5, a, 0, TAU); ctx.fill(); return [s0[0] + Math.cos(a) * (dd + 3), s0[1] + Math.sin(a) * (dd + 3)]; };
  const g1 = Math.sin(t * 2.2 + v) * 6; let hatHand = null; if (pose === 'point') { arm(-1, sh[0] - 22, -86); arm(1, sh[0] + 70, sh[1] - 16); } else if (pose === 'wave') { arm(-1, sh[0] - 22, -86); arm(1, sh[0] + 30 + g1, sh[1] - 60); } else if (pose === 'hat') { arm(-1, sh[0] - 22, -86); hatHand = arm(1, sh[0] + 26, sh[1] - 62); } else if (pose === 'talk') { arm(-1, sh[0] - 30 + g1 * 0.5, -104); arm(1, sh[0] + 36, -112 + g1); } else { arm(-1, sh[0] - 24 - sw * 10, -84); arm(1, sh[0] + 24 + sw * 10, -84); }
  const hd = [sh[0] + 1, sh[1] - 20]; ctx.fillStyle = S.skin; ctx.fillRect(hd[0] - 5, sh[1] - 8, 10, 10); ctx.beginPath(); ctx.ellipse(hd[0], hd[1], 12.5, 14.5, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(hd[0] + 10, hd[1] - 2); ctx.lineTo(hd[0] + 15, hd[1] + 3); ctx.lineTo(hd[0] + 10, hd[1] + 4); ctx.fill();
  ctx.fillStyle = S.hair; if (S.beard === 'full') { ctx.beginPath(); ctx.moveTo(hd[0] - 11, hd[1] + 1); ctx.quadraticCurveTo(hd[0] + 1, hd[1] + 24, hd[0] + 11, hd[1] + 3); ctx.lineTo(hd[0] + 9, hd[1] + 9); ctx.quadraticCurveTo(hd[0], hd[1] + 12, hd[0] - 9, hd[1] + 8); ctx.closePath(); ctx.fill(); } else if (S.beard === 'mutton') { ctx.beginPath(); ctx.ellipse(hd[0] - 10, hd[1] + 5, 4, 8, 0, 0, TAU); ctx.ellipse(hd[0] + 10, hd[1] + 5, 4, 8, 0, 0, TAU); ctx.fill(); ctx.fillRect(hd[0] - 6, hd[1] + 5, 12, 2.5); } else { ctx.beginPath(); ctx.moveTo(hd[0] - 4, hd[1] + 9); ctx.lineTo(hd[0] + 4, hd[1] + 9); ctx.lineTo(hd[0], hd[1] + 19); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#2a1e16'; ctx.beginPath(); ctx.arc(hd[0] - 4, hd[1] - 3, 1.6, 0, TAU); ctx.arc(hd[0] + 5, hd[1] - 3, 1.6, 0, TAU); ctx.fill(); ctx.strokeStyle = S.hair; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hd[0] - 7, hd[1] - 7); ctx.lineTo(hd[0] - 2, hd[1] - 7.5); ctx.moveTo(hd[0] + 2, hd[1] - 7.5); ctx.lineTo(hd[0] + 8, hd[1] - 7); ctx.stroke();
  ctx.fillStyle = S.hair; if (S.hat === 'none' || pose === 'hat') { ctx.beginPath(); for (let k = 0; k < 9; k++) { const a = Math.PI * 1.05 + k / 8 * Math.PI * 0.95; ctx.arc(hd[0] + Math.cos(a) * 13, hd[1] - 4 + Math.sin(a) * 12, S.hat === 'none' ? 6.5 : 4.5, 0, TAU); } ctx.fill(); }
  const drawHat = (cx2, cy2) => { ctx.fillStyle = '#121114'; if (S.hat === 'top') { ctx.fillRect(cx2 - 19, cy2, 38, 5); ctx.fillRect(cx2 - 12, cy2 - 34, 24, 35); ctx.fillStyle = '#3a2f2a'; ctx.fillRect(cx2 - 12, cy2 - 6, 24, 4); } else if (S.hat === 'bowler') { ctx.fillRect(cx2 - 17, cy2, 34, 4); ctx.beginPath(); ctx.ellipse(cx2, cy2, 13, 14, 0, Math.PI, TAU); ctx.fill(); } };
  if (S.hat !== 'none') { if (pose === 'hat' && hatHand) drawHat(hatHand[0], hatHand[1] - 4); else drawHat(hd[0], hd[1] - 12); }
  ctx.restore(); };
 // COLUMBIAD EN CORTE v2 (sustituye a columbiadSection): sillería de piedra en hiladas, tubo de hierro fundido con bridas cada 10 m
 // y pernos, ánima, cámara de carga con la carga propulsora (fardos), brocal de piedra sobre el suelo, gases que empujan al proyectil
 // (o.gas 0..1), proyectil (el MISMO modelo: perfil del maestro). Misma firma y retorno.
 P.columbiadSection = (ctx, ox, gy, s, t, o = {}) => { const D = 274, X = (x) => ox + x * s, Y = (y) => gy - y * s; ctx.save();
  const g = ctx.createLinearGradient(0, gy, 0, gy + D * s); g.addColorStop(0, '#a08860'); g.addColorStop(1, '#4e3d2a'); ctx.fillStyle = g; ctx.fillRect(0, gy, W, D * s + 600); ctx.strokeStyle = 'rgba(40,28,16,0.22)'; ctx.lineWidth = 2; for (let k = 1; k < 40; k++) { const yy = gy + k * 9 * s; if (yy > HH + 20) break; if (yy < -20) continue; ctx.beginPath(); for (let x = 0; x <= W; x += 30) ctx[x ? 'lineTo' : 'moveTo'](x, yy + Math.sin(x * 0.01 + k) * 5); ctx.stroke(); }
  const y0v = Math.max(gy, -10), y1v = Math.min(HH + 10, gy + D * s); ctx.fillStyle = '#a9997b'; ctx.fillRect(X(-5.2), y0v, 10.4 * s, y1v - y0v); ctx.save(); ctx.beginPath(); ctx.rect(X(-5.2), y0v, 10.4 * s, y1v - y0v); ctx.clip(); const bh = Math.max(5, 0.7 * s), bw = Math.max(10, 1.2 * s); ctx.strokeStyle = 'rgba(70,58,40,0.55)'; ctx.lineWidth = 1; for (let yy = gy; yy < y1v; yy += bh) { if (yy < y0v - bh) continue; ctx.beginPath(); ctx.moveTo(X(-5.2), yy); ctx.lineTo(X(5.2), yy); ctx.stroke(); const off = (Math.round((yy - gy) / bh) % 2) * bw / 2; for (let xx = X(-5.2) + off; xx < X(5.2); xx += bw) { ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx, yy + bh); ctx.stroke(); } } ctx.restore();
  const ig = ctx.createLinearGradient(X(-3.2), 0, X(3.2), 0); ig.addColorStop(0, '#2f3134'); ig.addColorStop(0.18, '#5a5e62'); ig.addColorStop(0.3, '#3d4044'); ig.addColorStop(0.7, '#3d4044'); ig.addColorStop(0.82, '#55595d'); ig.addColorStop(1, '#2a2c2f'); ctx.fillStyle = ig; ctx.fillRect(X(-3.2), y0v, 6.4 * s, y1v - y0v);
  for (let yy = 0; yy > -D; yy -= 10) { const sy = Y(yy); if (sy < -20 || sy > HH + 20) continue; ctx.fillStyle = '#6a6e72'; ctx.fillRect(X(-3.5), sy - 0.35 * s, 0.6 * s, 0.7 * s); ctx.fillRect(X(2.9), sy - 0.35 * s, 0.6 * s, 0.7 * s); ctx.fillStyle = 'rgba(220,224,226,0.6)'; ctx.fillRect(X(-3.35), sy - 0.1 * s, 0.25 * s, 0.2 * s); ctx.fillRect(X(3.1), sy - 0.1 * s, 0.25 * s, 0.2 * s); }
  const bg = ctx.createLinearGradient(X(-1.37), 0, X(1.37), 0); bg.addColorStop(0, '#060607'); bg.addColorStop(0.5, '#1b1c1e'); bg.addColorStop(1, '#060607'); ctx.fillStyle = bg; ctx.fillRect(X(-1.37), y0v, 2.74 * s, y1v - y0v);
  { const cy0 = Y(-D + 20), cy1 = Y(-D); if (cy0 < HH + 40) { ctx.fillStyle = '#4a3a28'; ctx.fillRect(X(-1.37), cy0, 2.74 * s, cy1 - cy0); ctx.strokeStyle = 'rgba(170,140,95,0.55)'; ctx.lineWidth = Math.max(1, 0.08 * s); for (let k = 0; k < 10; k++) { const yy = lerp(cy0, cy1, (k + 0.5) / 10); ctx.beginPath(); ctx.moveTo(X(-1.3), yy); ctx.lineTo(X(1.3), yy); ctx.stroke(); } } }
  ctx.fillStyle = '#b9ab8a'; ctx.fillRect(X(-9), gy - 1.2 * s, 3.8 * s, 1.2 * s + 1); ctx.fillRect(X(5.2), gy - 1.2 * s, 3.8 * s, 1.2 * s + 1); ctx.strokeStyle = 'rgba(70,58,40,0.6)'; ctx.lineWidth = 1; ctx.strokeRect(X(-9), gy - 1.2 * s, 3.8 * s, 1.2 * s); ctx.strokeRect(X(5.2), gy - 1.2 * s, 3.8 * s, 1.2 * s);
  const p = cl(o.p ?? 0), yb = -D + 20 + p * (D - 20), gas = cl(o.gas || 0); if (gas > 0) { const gy0 = Y(yb), gy1 = Y(-D + 20); const gg = ctx.createLinearGradient(0, gy0, 0, gy1); gg.addColorStop(0, `rgba(255,236,190,${0.9 * gas})`); gg.addColorStop(0.3, `rgba(255,170,90,${0.7 * gas})`); gg.addColorStop(1, `rgba(140,90,60,${0.4 * gas})`); ctx.fillStyle = gg; ctx.fillRect(X(-1.37), gy0, 2.74 * s, Math.max(0, gy1 - gy0)); }
  { const x0 = X(-1.37), w2 = 2.74 * s, sb = Y(yb), cg = ctx.createLinearGradient(x0, 0, x0 + w2, 0); cg.addColorStop(0, '#8d9397'); cg.addColorStop(0.35, '#e1e5e7'); cg.addColorStop(1, '#7c8286'); ctx.fillStyle = '#5d6468'; ctx.fillRect(x0 - 0.06 * s, sb - VC.base * s, w2 + 0.12 * s, VC.base * s); ctx.fillStyle = cg; ctx.beginPath(); ctx.moveTo(x0, sb - VC.base * s); ctx.lineTo(x0, Y(yb + VC.cyl)); for (let k = 1; k < VCP.length; k++) ctx.lineTo(X(-VCP[k][1]), Y(yb + VCP[k][0])); for (let k = VCP.length - 1; k >= 1; k--) ctx.lineTo(X(VCP[k][1]), Y(yb + VCP[k][0])); ctx.lineTo(x0 + w2, Y(yb + VC.cyl)); ctx.lineTo(x0 + w2, sb - VC.base * s); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(50,55,58,0.7)'; ctx.lineWidth = Math.max(1, 0.06 * s); ctx.stroke(); if (s > 6) { ctx.fillStyle = '#8a6a36'; ctx.beginPath(); ctx.arc(X(0.55), Y(yb + 1.75), 0.3 * s, 0, TAU); ctx.fill(); ctx.fillStyle = '#16222b'; ctx.beginPath(); ctx.arc(X(0.55), Y(yb + 1.75), 0.2 * s, 0, TAU); ctx.fill(); } }
  const fl = cl(o.flash || 0); if (fl > 0) P.glow(ctx, X(0), Y(yb - 2), 26 * s + 120, '255,190,90', 0.7 * fl);
  const arrow = (x, y0, len, col, w) => { if (len < 4) return; ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y0 - len + 18); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x, y0 - len); ctx.lineTo(x - 16, y0 - len + 26); ctx.lineTo(x + 16, y0 - len + 26); ctx.closePath(); ctx.fill(); };
  const yc = Y(yb + VC.top / 2); if (o.v) arrow(X(5.5) + 40, yc + 60, 280 * cl(o.v), '#53C5E8', 10); if (o.acc) arrow(X(-5.5) - 40, yc + 60, 280 * cl(o.acc), '#ff5a4a', 13);
  if (o.people) for (const k of [0, 1]) P.traveler1865(ctx, X(10 + k * 2.4), gy - 1.2 * s, 1.8 * s, t, { var: k });
  ctx.restore(); return { cap: [X(0), yc], mouth: [X(0), gy], bottom: [X(0), Y(-D + 10)], vArrow: [X(5.5) + 40, yc], aArrow: [X(-5.5) - 40, yc], charge: [X(0), Y(-D + 10)] };
 };
 // ACELERACIÓN EN DOS CARRILES (cualitativo, sin cifras): izquierda CAÑÓN FICTICIO (tramo corto: toda la velocidad en un instante,
 // aceleración en un pico enorme), derecha SATURNO V REAL (trayectoria larga: la velocidad crece durante minutos; la aceleración
 // cambia, sube en cada etapa y cae en cada separación). Abajo, velocidad (línea) y aceleración (área) separadas. u 0..1.
 P.accelLanes = (ctx, x, y, w, h, u, t, o = {}) => { ctx.save(); ctx.fillStyle = 'rgba(5,11,24,0.95)'; ctx.beginPath(); ctx.roundRect(x - 24, y - 24, w + 48, h + 48, 26); ctx.fill(); const U = cl(u), cw = w * 0.42, rw = w * 0.52, rx = x + w - rw, top = y + 70, laneH = h * 0.5;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '900 34px Nunito'; ctx.fillStyle = '#E7B56E'; ctx.fillText('CAÑÓN FICTICIO', x + cw / 2, y + 22); ctx.fillStyle = '#53C5E8'; ctx.fillText('SATURNO V REAL', rx + rw / 2, y + 22);
  const tubeH = laneH * 0.32, tx = x + cw * 0.5, ty1 = top + laneH, ty0 = ty1 - tubeH, cu = cl(U * 6); ctx.fillStyle = '#3d4044'; ctx.fillRect(tx - 30, ty0, 60, tubeH); ctx.fillStyle = '#0d0d0e'; ctx.fillRect(tx - 18, ty0, 36, tubeH); const cy = ty1 - E.in(cu) * tubeH - (U > 1 / 6 ? (U - 1 / 6) * laneH * 2.2 : 0); if (cy > top - 10) P.vCapsuleAt(ctx, tx, cy - 12, 26, 0, t, { az: 0.6 });
  ctx.font = '700 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.85)'; ctx.fillText('tramo corto', tx, ty1 + 30);
  ctx.strokeStyle = 'rgba(83,197,232,0.35)'; ctx.lineWidth = 4; ctx.setLineDash([10, 8]); const tr = (s) => [rx + 30 + rw * 0.75 * Math.pow(s, 1.6), top + laneH - s * laneH * 0.95]; ctx.beginPath(); for (let i = 0; i <= 40; i++) { const q = tr(i / 40); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); } ctx.stroke(); ctx.setLineDash([]);
  [[0, 0.38, '#FF9A42', 'S-IC'], [0.38, 0.78, '#FFD447', 'S-II'], [0.78, 1, '#53C5E8', 'S-IVB']].forEach(([a, b, c, n]) => { const s0 = a, s1 = Math.min(b, U); if (s1 <= s0) return; ctx.strokeStyle = c; ctx.lineWidth = 7; ctx.beginPath(); for (let i = 0; i <= 20; i++) { const q = tr(lerp(s0, s1, i / 20)); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); } ctx.stroke(); const m = tr((a + b) / 2); ctx.font = '700 32px "IBM Plex Mono"'; ctx.fillStyle = c; ctx.textAlign = 'left'; ctx.fillText(n, m[0] + 16, m[1] + 4); ctx.textAlign = 'center'; });
  { const q = tr(U); ctx.fillStyle = '#F5F7FA'; ctx.beginPath(); ctx.arc(q[0], q[1], 9, 0, TAU); ctx.fill(); P.glow(ctx, q[0], q[1] + 14, 40, '255,160,80', 0.6); }
  ctx.font = '700 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.85)'; ctx.fillText('varios minutos, por etapas', rx + rw / 2, top + laneH + 30);
  const gy0 = top + laneH + 70, rowH = (y + h - 50 - gy0) / 2, gh = rowH * 2.1, row = (yy, lab2) => { ctx.strokeStyle = 'rgba(245,247,250,0.45)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + w, yy); ctx.stroke(); ctx.font = '700 32px Nunito'; ctx.fillStyle = '#F5F7FA'; ctx.textAlign = 'left'; ctx.fillText(lab2, x, yy - rowH + 22); ctx.textAlign = 'center'; };
  const vY = gy0 + rowH, aY = gy0 + rowH * 2; row(vY, 'VELOCIDAD'); row(aY, 'ACELERACIÓN');
  const cX = (s) => x + cw * s, rX = (s) => rx + rw * s; ctx.lineWidth = 5; ctx.strokeStyle = '#E7B56E'; ctx.beginPath(); ctx.moveTo(cX(0), vY); ctx.lineTo(cX(0.08), vY); ctx.lineTo(cX(0.12), vY - gh * 0.3 * cl(U * 6)); if (U > 1 / 6) ctx.lineTo(cX(lerp(0.12, 1, cl((U - 1 / 6) * 2))), vY - gh * 0.3); ctx.stroke(); ctx.fillStyle = 'rgba(231,181,110,0.55)'; const ca = cl(U * 6); ctx.beginPath(); ctx.moveTo(cX(0.08), aY); ctx.lineTo(cX(0.09), aY - gh * 0.3 * ca); ctx.lineTo(cX(0.12), aY - gh * 0.3 * ca); ctx.lineTo(cX(0.125), aY); ctx.closePath(); ctx.fill();
  const vr = (s) => (s < 0.38 ? 0.4 * Math.pow(s / 0.38, 1.7) : s < 0.78 ? 0.4 + 0.35 * Math.pow((s - 0.38) / 0.4, 1.3) : 0.75 + 0.25 * Math.pow((s - 0.78) / 0.22, 1.2)), ar = (s) => (s < 0.38 ? 0.1 + 0.2 * (s / 0.38) : s < 0.4 ? 0.02 : s < 0.78 ? 0.08 + 0.1 * ((s - 0.4) / 0.38) : s < 0.8 ? 0.02 : 0.05 + 0.07 * ((s - 0.8) / 0.2));
  ctx.strokeStyle = '#53C5E8'; ctx.beginPath(); for (let i = 0; i <= 60 * U; i++) { const s2 = i / 60; ctx[i ? 'lineTo' : 'moveTo'](rX(s2), vY - gh * 0.3 * vr(s2)); } ctx.stroke(); ctx.fillStyle = 'rgba(83,197,232,0.45)'; ctx.beginPath(); ctx.moveTo(rX(0), aY); for (let i = 0; i <= 60 * U; i++) { const s2 = i / 60; ctx.lineTo(rX(s2), aY - gh * 0.3 * ar(s2)); } ctx.lineTo(rX(U), aY); ctx.closePath(); ctx.fill();
  ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,250,0.72)'; ctx.fillText('esquema cualitativo · sin escala', x + w / 2, y + h + 4); ctx.restore(); };
 // MAPA DE FLORIDA (estilizado, sin coordenadas en pantalla): costa peninsular con la bahía de Tampa y el saliente del cabo, lago
 // Okeechobee, límite con Georgia y Alabama, retícula tenue, barra de escala de 100 km y norte. Marcas: { id, lon, lat, col, a }.
 const FLA2 = [[-87.6, 31], [-87.6, 30.9], [-87.4, 30.45], [-86.5, 30.4], [-85.9, 30.2], [-85.4, 29.7], [-84.9, 29.7], [-84.3, 30.05], [-83.7, 29.9], [-83.2, 29.3], [-82.8, 28.9], [-82.75, 28.3], [-82.85, 27.85], [-82.62, 27.72], [-82.48, 27.92], [-82.6, 27.6], [-82.7, 27.4], [-82.4, 27.0], [-82.2, 26.7], [-81.9, 26.4], [-81.7, 25.9], [-81.3, 25.6], [-81.0, 25.2], [-80.6, 25.2], [-80.35, 25.4], [-80.2, 25.8], [-80.05, 26.5], [-80.1, 27.0], [-80.3, 27.5], [-80.5, 28.0], [-80.55, 28.35], [-80.6, 28.6], [-80.75, 28.8], [-81.0, 29.3], [-81.25, 29.9], [-81.4, 30.4], [-81.45, 30.7], [-82.0, 30.6], [-82.2, 30.57], [-83.0, 30.65], [-84.9, 30.7], [-85.0, 31.0]];
 P.floridaMap = (ctx, cx, cy, w, t, o = {}) => { const lon0 = -83.5, lat0 = 28, k = w / 9.5, cosl = Math.cos(28 / 57.3), pr = (lo, la) => [cx + (lo - lon0) * k * cosl, cy - (la - lat0) * k], era = cl(o.era ?? 0); ctx.save();
  const sea = P.mixc('#9fb3b4', '#0d3460', era), land = P.mixc('#ecdcb8', '#1f5a8c', era), edge = P.mixc('#6b5236', '#53C5E8', era); const [ax, ay] = pr(-88.2, 31.8), [bx, by] = pr(-78.8, 24.2); ctx.fillStyle = sea; ctx.fillRect(Math.min(ax, bx) - 400, ay - 400, Math.abs(bx - ax) + 800, by - ay + 800);
  ctx.strokeStyle = P.mixc('rgba(90,70,40,0.25)', 'rgba(83,197,232,0.18)', era); ctx.lineWidth = 1.5; for (let lo = -88; lo <= -79; lo++) { const [x1, y1] = pr(lo, 32), [x2, y2] = pr(lo, 24); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); } for (let la = 24; la <= 32; la++) { const [x1, y1] = pr(-88.5, la), [x2, y2] = pr(-78.5, la); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
  ctx.beginPath(); [[-88.5, 34], [-78.5, 34], [-78.5, 32.1], [-80.9, 32.0], [-81.45, 30.7], [-82.0, 30.6], [-83.0, 30.65], [-84.9, 30.7], [-85.0, 31.0], [-87.6, 31.0], [-87.6, 30.4], [-88.5, 30.3]].forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.closePath(); ctx.fillStyle = P.mixc('#c9b791', '#123d63', era); ctx.fill();
  ctx.beginPath(); FLA2.forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.closePath(); ctx.fillStyle = land; ctx.fill(); ctx.strokeStyle = edge; ctx.lineWidth = 3; ctx.stroke();
  const [lx, ly] = pr(-80.85, 26.95); ctx.fillStyle = sea; ctx.beginPath(); ctx.ellipse(lx, ly, 0.28 * k * cosl, 0.25 * k, 0, 0, TAU); ctx.fill();
  ctx.font = '700 32px Nunito'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = P.mixc('rgba(90,70,40,0.75)', 'rgba(220,240,255,0.7)', era); { const [x, y] = pr(-82.2, 27.9); ctx.fillText('FLORIDA', x + k * 0.6, y + k * 0.9); const [gx2, gy2] = pr(-84.2, 31.5); ctx.font = '600 32px Nunito'; ctx.fillText('Georgia', gx2, gy2); const [gm, gmy] = pr(-85.5, 27.2); ctx.fillText('golfo de México', gm, gmy); const [at, aty] = pr(-79.6, 29.6); ctx.fillText('Atlántico', at, aty); }
  { const [s0x, s0y] = pr(-87.5, 25.0), len = (100 / 111) * k * cosl * 1.0; ctx.strokeStyle = P.mixc('#3a2b1e', '#F5F7FA', era); ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(s0x, s0y); ctx.lineTo(s0x + len, s0y); ctx.moveTo(s0x, s0y - 10); ctx.lineTo(s0x, s0y + 10); ctx.moveTo(s0x + len, s0y - 10); ctx.lineTo(s0x + len, s0y + 10); ctx.stroke(); ctx.fillStyle = P.mixc('#3a2b1e', '#F5F7FA', era); ctx.font = '700 32px Nunito'; ctx.fillText('100 km', s0x + len / 2, s0y + 34); const [nx, ny] = pr(-79.3, 31.2); ctx.beginPath(); ctx.moveTo(nx, ny - 34); ctx.lineTo(nx + 12, ny); ctx.lineTo(nx - 12, ny); ctx.closePath(); ctx.fill(); ctx.fillText('N', nx, ny - 54); }
  const out = {}; for (const pn of o.pins || []) { const a = cl(pn.a ?? 1); if (a <= 0) continue; const [x, y] = pr(pn.lon, pn.lat); out[pn.id] = [x, y]; ctx.globalAlpha = a; P.glow(ctx, x, y, 70, pn.glow || '255,212,71', 0.4); ctx.fillStyle = pn.col || '#FFD447'; ctx.beginPath(); ctx.arc(x, y - 30, 15, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(x - 10, y - 25); ctx.lineTo(x + 10, y - 25); ctx.lineTo(x, y); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(x, y - 30, 5.5, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
  ctx.restore(); return { pr, pins: out }; };
 // SATURNO V v2 (sustituye a saturnV3; misma firma): metal con brillo, anillos de separación entre etapas, patrón de balanceo del
 // S-IC y del S-IVB, franjas del interetapa, rótulos «USA» (S-IC) y «UNITED STATES» (S-II) en rojo, unidad de instrumentos, SLA,
 // módulo de servicio plateado, módulo de mando, torre de escape de celosía con su motor, aletas y carenados, 5 F-1 con toberas.
 P.saturnV3 = (ctx, cam, base, t, o = {}) => { const [bx, by, bz] = base, L = o.L || [0.55, 0.45, 0.7], st = o.stage || 0, W1 = '#E8ECEA', K = '#24282C', sp = { spec: 0.32, shin: 18, N: 56, L, amb: 0.4 };
  const quad = (a, n) => (Math.floor(((a + TAU) % TAU) / (TAU / n)) % 2);
  const icCol = (a, y) => (y < 9.5 ? (quad(a + 0.4, 4) ? K : W1) : y > 30 && y < 35 ? (quad(a, 16) ? K : W1) : y > 38.6 && y < 40 ? K : W1);
  if (o.engines !== false && st === 0) { const eng = [[0, 0], [3, 3], [-3, 3], [3, -3], [-3, -3]].map(([ex, ez]) => ({ d: cam.depth([bx + ex, by - 3, bz + ez]), f: () => { vFrustum2(ctx, cam, bx + ex, bz + ez, by - 1.2, by - 0.1, 1.0, 0.8, () => '#2c2d2f', { N: 20, L, amb: 0.35 }); vFrustum2(ctx, cam, bx + ex, bz + ez, by - 5.8, by - 1.2, 1.85, 0.75, () => '#3b3c3e', { N: 24, L, amb: 0.3, spec: 0.25, shin: 10, under: true }); } })); ykDrawList(ctx, cam, eng); }
  const ring = (y, r) => vFrustum2(ctx, cam, bx, bz, by + y - 0.18, by + y + 0.18, r + 0.06, r + 0.06, () => '#9aa1a5', { N: 56, L, amb: 0.4, spec: 0.3 });
  if (st === 0) { vFrustum2(ctx, cam, bx, bz, by, by + SV.ic, SV.r1, SV.r1, icCol, sp);
   for (const an of [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4]) { const P0 = (rr, y) => [bx + rr * Math.cos(an), by + y, bz + rr * Math.sin(an)], n = [-Math.sin(an), 0, Math.cos(an)], vis = faceVis(cam, n, P0(SV.r1 + 1.5, 3)); vFrustum2(ctx, cam, bx + (SV.r1 - 0.1) * Math.cos(an), bz + (SV.r1 - 0.1) * Math.sin(an), by - 1.6, by + 7.5, 1.2, 0.35, () => '#dfe2df', { N: 18, L, amb: 0.4, spec: 0.3 }); poly3(ctx, cam, [P0(SV.r1 + 0.6, 0.2), P0(SV.r1 + 3.4, 0.2), P0(SV.r1 + 3.4, 2.8), P0(SV.r1 + 0.6, 8.6)], vis ? '#e1e4e0' : '#b6bab6', { stroke: '#7f8480', lw: 1 }); }
   ring(SV.ic, SV.r1); }
  if (st <= 1) { vFrustum2(ctx, cam, bx, bz, by + SV.ic, by + SV.ii1, SV.r1, SV.r1, (a, y) => (y < SV.ic + 0.9 ? K : W1), sp); ring(SV.ic + 5.5, SV.r1); vFrustum2(ctx, cam, bx, bz, by + SV.ii1, by + SV.ad1, SV.r1, SV.r3, () => W1, sp); ring(SV.ii1, SV.r1); }
  vFrustum2(ctx, cam, bx, bz, by + SV.ad1, by + SV.ivb, SV.r3, SV.r3, (a, y) => (y < SV.ad1 + 3.2 ? (quad(a + 0.4, 4) ? K : W1) : W1), sp); ring(SV.ad1, SV.r3);
  vFrustum2(ctx, cam, bx, bz, by + SV.ivb, by + SV.iu, SV.r3, SV.r3, (a) => (quad(a, 24) ? '#8e9599' : '#a9b0b4'), sp);
  vFrustum2(ctx, cam, bx, bz, by + SV.iu, by + SV.sla, SV.r3, SV.r5, () => W1, sp); vFrustum2(ctx, cam, bx, bz, by + SV.sla, by + SV.sm, SV.r5, SV.r5, () => '#cfd5d8', { ...sp, spec: 0.6, shin: 30 }); vFrustum2(ctx, cam, bx, bz, by + SV.sm, by + SV.cm, SV.r5, 0.35, () => '#eef1f0', sp);
  if (o.les !== false) { const tb = by + SV.cm, tt = tb + 4.2; ctx.save(); ctx.strokeStyle = '#c8432e'; for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + 0.4, A = cam.clip([[bx + 1.0 * Math.cos(a), tb - 0.2, bz + 1.0 * Math.sin(a)], [bx + 0.35 * Math.cos(a), tt, bz + 0.35 * Math.sin(a)]], 1); if (A.length === 2) { ctx.lineWidth = Math.max(1, 0.12 * cam.f / A[0][2]); ctx.beginPath(); ctx.moveTo(A[0][0], A[0][1]); ctx.lineTo(A[1][0], A[1][1]); ctx.stroke(); } } ctx.restore(); vFrustum2(ctx, cam, bx, bz, tt, by + SV.les - 0.7, 0.4, 0.4, () => '#e6e6e2', { N: 16, L, amb: 0.4, spec: 0.3 }); vFrustum2(ctx, cam, bx, bz, by + SV.les - 0.7, by + SV.les, 0.4, 0.05, () => '#e6e6e2', { N: 16, L, amb: 0.4 }); vFrustum2(ctx, cam, bx, bz, tt - 0.5, tt, 0.55, 0.4, () => '#5a5e62', { N: 16, L, amb: 0.4 }); }
  // rótulos verticales (rojos) en el meridiano que mira a la cámara
  const aC = Math.atan2(cam.pos[2] - bz, cam.pos[0] - bx) - 0.28, vtext = (s, y0, y1, r) => { const n = s.length; for (let i = 0; i < n; i++) { const yy = lerp(y1, y0, (i + 0.5) / n), Q = cam.clip([[bx + (r + 0.05) * Math.cos(aC), by + yy, bz + (r + 0.05) * Math.sin(aC)]], 1)[0]; if (!Q) continue; const px = (y1 - y0) / n * 0.8 * cam.f / Q[2]; if (px < 4) continue; ctx.save(); ctx.font = `800 ${px}px "Space Grotesk"`; ctx.fillStyle = '#b8281e'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s[i], Q[0], Q[1]); ctx.restore(); } };
  if (st === 0) vtext('USA', 12, 19, SV.r1); if (st <= 1) vtext('UNITED STATES', 48.5, 64, SV.r1);
  return { top: cam.clip([[bx, by + SV.les, bz]], 1)[0], base: cam.clip([[bx, by, bz]], 1)[0], nozzles: [[0, 0], [3, 3], [-3, 3], [3, -3], [-3, -3]].map(([ex, ez]) => cam.clip([[bx + ex, by - 5.8, bz + ez]], 1)[0]), mid: cam.clip([[bx, by + 20, bz]], 1)[0], ivb: cam.clip([[bx, by + 80, bz]], 1)[0] };
 };
 // PLATAFORMA 39A v2 (sustituye a pad39A; misma firma y retorno): Mobile Launcher con cubierta y brazos de sujeción, torre
 // umbilical de vigas en caja (postes, forjados cada 6 m, diagonales), 9 brazos de servicio en celosía (o.arms 1 = conectados,
 // 0 = retirados), grúa de martillo, foso de llamas y explanada.
 P.pad39A = (ctx, cam, t, o = {}) => { if (o.sky !== false) { const g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, o.skyTop || '#2f6fc0'); g.addColorStop(0.6, o.skyMid || '#a9cbe6'); g.addColorStop(1, '#e8eef0'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); }
  const G = 3000; poly3(ctx, cam, [[-G, -7.6, -G], [G, -7.6, -G], [G, -7.6, G], [-G, -7.6, G]], '#a39f76'); if (o.sea !== false) poly3(ctx, cam, [[-G, -7.55, -G], [G, -7.55, -G], [G, -7.55, -900], [-G, -7.55, -900]], '#3f78a8');
  poly3(ctx, cam, [[-130, -7.5, -100], [130, -7.5, -100], [130, -7.5, 100], [-130, -7.5, 100]], '#cfccc3'); poly3(ctx, cam, [[-9, -7.45, 20], [9, -7.45, 20], [9, -7.45, 140], [-9, -7.45, 140]], '#3e3b37');
  P.box3(ctx, cam, -24, 24, -7.6, 0, -20, 20, '#8a8e91', {}); P.box3(ctx, cam, -24, 24, 0, 0.6, -20, 20, '#9da1a4', {}); for (const an of [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4]) { const x = 6.6 * Math.cos(an), z = 6.6 * Math.sin(an); P.box3(ctx, cam, x - 0.9, x + 0.9, 0.6, 2.0, z - 0.9, z + 0.9, '#6f7376', {}); }
  const tw = { x0: 10, x1: 22, z0: -6, z1: 6, h: 120 }, arms = cl(o.arms ?? 1), RED = '#b8432a';
  const obox = (A, B, wd, hh, col) => { const dx = B[0] - A[0], dz = B[2] - A[2], l = Math.hypot(dx, dz) || 1, nx = -dz / l * wd / 2, nz = dx / l * wd / 2, p = (P0, s, up) => [P0[0] + nx * s, P0[1] + up, P0[2] + nz * s]; const faces = [[[p(A, -1, hh), p(B, -1, hh), p(B, 1, hh), p(A, 1, hh)], [0, 1, 0], 1.1], [[p(A, -1, 0), p(B, -1, 0), p(B, -1, hh), p(A, -1, hh)], [-nx, 0, -nz], 0.8], [[p(A, 1, 0), p(B, 1, 0), p(B, 1, hh), p(A, 1, hh)], [nx, 0, nz], 0.9]]; for (const [pts, n, k] of faces) { const c = pts.reduce((s, q) => [s[0] + q[0] / 4, s[1] + q[1] / 4, s[2] + q[2] / 4], [0, 0, 0]); if (faceVis(cam, n, c)) poly3(ctx, cam, pts, rmShade(col, k), { stroke: rmShade(col, 0.6), lw: 1 }); } };
  const tower = () => { const posts = [[tw.x0, tw.z0], [tw.x1, tw.z0], [tw.x1, tw.z1], [tw.x0, tw.z1]]; const far = posts.map((q) => ({ q, d: cam.depth([q[0], 60, q[1]]) })).sort((a, b) => b.d - a.d); const ln = (A, B, c, w) => { const Q = cam.clip([A, B], 1); if (Q.length < 2) return; ctx.strokeStyle = c; ctx.lineWidth = Math.max(1, w * cam.f / Math.max(30, (Q[0][2] + Q[1][2]) / 2)); ctx.beginPath(); ctx.moveTo(Q[0][0], Q[0][1]); ctx.lineTo(Q[1][0], Q[1][1]); ctx.stroke(); };
   for (let y = 0; y < tw.h; y += 6) for (let i = 0; i < 4; i++) { const A = posts[i], B = posts[(i + 1) % 4]; ln([A[0], y, A[1]], [B[0], y + 6, B[1]], '#963a22', 0.22); ln([B[0], y, B[1]], [A[0], y + 6, A[1]], '#963a22', 0.16); }
   for (const { q } of far) P.box3(ctx, cam, q[0] - 0.55, q[0] + 0.55, 0, tw.h, q[1] - 0.55, q[1] + 0.55, RED, {});
   for (let y = 6; y <= tw.h; y += 6) { P.box3(ctx, cam, tw.x0, tw.x1, y - 0.5, y, tw.z0 - 0.4, tw.z0 + 0.4, '#c25234', {}); P.box3(ctx, cam, tw.x0, tw.x1, y - 0.5, y, tw.z1 - 0.4, tw.z1 + 0.4, '#c25234', {}); P.box3(ctx, cam, tw.x0 - 0.4, tw.x0 + 0.4, y - 0.5, y, tw.z0, tw.z1, '#c25234', {}); }
   P.box3(ctx, cam, tw.x0 - 1, tw.x1 + 1, tw.h, tw.h + 3, -3, 3, '#c25234', {}); obox([tw.x1, tw.h + 3, 0], [tw.x0 - 16, tw.h + 3, 0], 1.6, 1.6, '#d9a42c');
   for (const ay of [20, 36, 49, 60, 67, 75, 84, 88, 97]) { const rr = ay > SV.iu ? SV.r5 : ay > SV.ad1 ? SV.r3 : SV.r1, ang = (1 - arms) * 1.25, L0 = tw.x0 - rr - 0.4, end = [tw.x0 - Math.cos(ang) * L0, ay, -Math.sin(ang) * L0]; obox([tw.x0, ay, 0], end, 2.2, 1.6, '#b04428'); }
  };
  return { tower, towerDepth: cam.depth([16, 60, 0]) };
 };
 // MÓDULO LUNAR «EAGLE» v2 (sustituye a eagleLM; misma firma): etapa de descenso octogonal con lámina dorada arrugada y paneles
 // negros, tobera de descenso; cuatro patas (puntal principal, puntales secundarios, platillo y sonda de contacto; la delantera con
 // escalerilla y porche); etapa de ascenso facetada gris y negra con ventanas triangulares, escotilla, túnel de acoplamiento,
 // cuatro grupos de propulsores RCS, antena de banda S orientable, radar de encuentro y antenas VHF. x,y = platillos en el suelo.
 P.eagleLM = (ctx, x, y, s, t, o = {}) => { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); const lg = cl(o.legs ?? 1), th = cl(o.thrust || 0), R = H.rng(5);
  if (th > 0) { const g = ctx.createLinearGradient(0, -60, 0, 60); g.addColorStop(0, `rgba(255,240,215,${0.55 * th})`); g.addColorStop(1, 'rgba(255,210,150,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-16, -66); ctx.lineTo(16, -66); ctx.lineTo(44, 40); ctx.lineTo(-44, 40); ctx.closePath(); ctx.fill(); }
  const strut = (A, B, w, c) => { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.stroke(); }, pad = (px, py, rx) => { ctx.fillStyle = '#c8a24e'; ctx.beginPath(); ctx.ellipse(px, py, rx, rx * 0.32, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#9a7a34'; ctx.beginPath(); ctx.ellipse(px, py + 2, rx, rx * 0.25, 0, 0, Math.PI); ctx.fill(); };
  for (const sd of [-1, 1]) { const fx = sd * lerp(78, 158, lg), fy = lerp(-40, 0, lg); strut([sd * 74, -128], [fx, fy - 8], 8, '#b89a52'); strut([sd * 62, -74], [fx - sd * 10, fy - 30], 4, '#9c8250'); strut([sd * 40, -70], [fx - sd * 14, fy - 26], 3, '#9c8250'); pad(fx, fy, 24); strut([fx, fy], [fx + sd * 4, fy + 34 * lg], 2, '#9aa0a2'); }
  const dg = ctx.createLinearGradient(-96, 0, 96, 0); dg.addColorStop(0, '#7a5a16'); dg.addColorStop(0.3, '#e8c560'); dg.addColorStop(0.55, '#f6dc86'); dg.addColorStop(0.8, '#b8902e'); dg.addColorStop(1, '#6a4c12'); ctx.fillStyle = dg; ctx.beginPath(); ctx.moveTo(-96, -150); ctx.lineTo(-70, -158); ctx.lineTo(70, -158); ctx.lineTo(96, -150); ctx.lineTo(92, -62); ctx.lineTo(-92, -62); ctx.closePath(); ctx.fill();
  for (let k = 0; k < 40; k++) { const xx = R.range(-88, 88), yy = R.range(-152, -66), L2 = R.range(6, 22), an = R.range(-0.6, 0.6); ctx.strokeStyle = R() < 0.5 ? 'rgba(255,245,200,0.55)' : 'rgba(90,60,10,0.45)'; ctx.lineWidth = R.range(1, 2.4); ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx + Math.cos(an) * L2, yy + Math.sin(an) * L2); ctx.stroke(); }
  ctx.fillStyle = 'rgba(20,20,22,0.85)'; ctx.fillRect(-34, -142, 68, 54); ctx.strokeStyle = 'rgba(200,170,90,0.6)'; ctx.lineWidth = 1.5; ctx.strokeRect(-34, -142, 68, 54); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(56, -156, 40, 94);
  ctx.fillStyle = '#2a2a2c'; ctx.beginPath(); ctx.moveTo(-18, -62); ctx.lineTo(18, -62); ctx.lineTo(26, -36); ctx.lineTo(-26, -36); ctx.closePath(); ctx.fill();
  { const fx = 0, fy = lerp(-40, 4, lg); strut([0, -96], [fx, fy - 8], 9, '#c4a65c'); for (let k = 0; k < 7; k++) { const yy = lerp(-90, fy - 18, k / 6); strut([-10, yy], [10, yy], 3, '#d8c08a'); } strut([-11, -92], [-11, fy - 14], 2.5, '#c4a65c'); strut([11, -92], [11, fy - 14], 2.5, '#c4a65c'); ctx.fillStyle = '#c9a85a'; ctx.fillRect(-24, -100, 48, 8); pad(fx, fy + 4, 30); }
  const ag = ctx.createLinearGradient(-80, 0, 80, 0); ag.addColorStop(0, '#6e7376'); ag.addColorStop(0.35, '#c9cdcf'); ag.addColorStop(0.6, '#b4b8bb'); ag.addColorStop(1, '#5f6467'); ctx.fillStyle = ag; ctx.beginPath(); ctx.moveTo(-76, -158); ctx.lineTo(-82, -214); ctx.lineTo(-58, -248); ctx.lineTo(-20, -266); ctx.lineTo(36, -266); ctx.lineTo(70, -240); ctx.lineTo(80, -200); ctx.lineTo(74, -158); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(40,44,48,0.6)'; ctx.lineWidth = 1.5; ctx.stroke();
  ctx.fillStyle = '#26292c'; ctx.beginPath(); ctx.moveTo(-82, -214); ctx.lineTo(-58, -248); ctx.lineTo(-48, -246); ctx.lineTo(-66, -206); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#8a6a34'; ctx.fillRect(40, -230, 30, 50); ctx.fillStyle = '#3a3e42'; ctx.fillRect(-60, -196, 34, 30);
  ctx.fillStyle = '#121a20'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx * 6 - 4, -250); ctx.lineTo(sx * 30 - 4, -244); ctx.lineTo(sx * 18 - 4, -222); ctx.closePath(); ctx.fill(); } ctx.fillStyle = 'rgba(160,200,230,0.35)'; ctx.beginPath(); ctx.moveTo(-28, -246); ctx.lineTo(-14, -244); ctx.lineTo(-20, -236); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#9da2a5'; ctx.fillRect(-26, -214, 44, 44); ctx.strokeStyle = '#4a4e52'; ctx.lineWidth = 2; ctx.strokeRect(-26, -214, 44, 44);
  ctx.fillStyle = '#b9bdbf'; ctx.fillRect(-10, -284, 28, 20); ctx.fillStyle = '#7e8386'; ctx.fillRect(-12, -288, 32, 6);
  for (const [qx, qy] of [[-84, -226], [80, -226]]) { ctx.fillStyle = '#c9a85a'; ctx.fillRect(qx - 6, qy - 6, 12, 12); ctx.fillStyle = '#3a3a3c'; for (const [dx, dy] of [[-10, 0], [10, 0], [0, -10], [0, 10]]) { ctx.beginPath(); ctx.moveTo(qx + dx * 0.6, qy + dy * 0.6); ctx.lineTo(qx + dx * 1.3 + dy * 0.3, qy + dy * 1.3 + dx * 0.3); ctx.lineTo(qx + dx * 1.3 - dy * 0.3, qy + dy * 1.3 - dx * 0.3); ctx.closePath(); ctx.fill(); } }
  strut([36, -266], [56, -296], 3, '#c9cdcf'); ctx.fillStyle = '#dfe2e3'; ctx.beginPath(); ctx.ellipse(62, -304, 16, 10, -0.5, 0, TAU); ctx.fill(); ctx.strokeStyle = '#8a8f92'; ctx.lineWidth = 1.5; ctx.stroke(); strut([-20, -266], [-30, -292], 3, '#c9cdcf'); ctx.fillStyle = '#e8eaeb'; ctx.beginPath(); ctx.ellipse(-32, -298, 11, 7, 0.4, 0, TAU); ctx.fill(); strut([-66, -230], [-96, -270], 1.5, '#c9cdcf'); strut([70, -238], [104, -262], 1.5, '#c9cdcf');
  ctx.restore(); };
 // ASTRONAUTA del Apolo (traje blanco, mochila PLSS, casco con visor dorado, botas grises), de perfil 3/4. x,y = pies. o: { dir, step, var }
 P.astronaut = (ctx, x, y, h, t, o = {}) => { const u = h / 180, d = o.dir ?? 1, st = Math.sin((o.step ?? t * 1.4) * TAU) * (o.walk ? 1 : 0); ctx.save(); ctx.translate(x, y); ctx.scale(u * d, u); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(30, 2, 46, 7, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#e9ebe9'; ctx.lineWidth = 22; ctx.beginPath(); ctx.moveTo(-8, -84); ctx.lineTo(-10 + st * 10, -10); ctx.moveTo(10, -84); ctx.lineTo(12 - st * 10, -10); ctx.stroke(); ctx.fillStyle = '#9aa0a2'; ctx.beginPath(); ctx.ellipse(-8 + st * 10, -6, 15, 8, 0, 0, TAU); ctx.ellipse(16 - st * 10, -6, 15, 8, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#d9dcda'; ctx.fillRect(-46, -150, 30, 62); ctx.fillStyle = '#c4c8c6'; ctx.fillRect(-48, -160, 34, 12);
  const g = ctx.createLinearGradient(-24, 0, 26, 0); g.addColorStop(0, '#c9ccca'); g.addColorStop(0.5, '#f4f5f4'); g.addColorStop(1, '#cfd2d0'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-24, -152, 48, 74, 14); ctx.fill(); ctx.fillStyle = '#6a7a8c'; ctx.fillRect(-14, -132, 26, 16); ctx.fillStyle = '#b8281e'; ctx.fillRect(14, -142, 8, 6);
  ctx.strokeStyle = '#e4e6e4'; ctx.lineWidth = 15; ctx.beginPath(); ctx.moveTo(18, -140); ctx.lineTo(30, -104); ctx.lineTo(28, -84); ctx.moveTo(-18, -140); ctx.lineTo(-26, -108); ctx.stroke(); ctx.fillStyle = '#5a5e60'; ctx.beginPath(); ctx.arc(28, -80, 7, 0, TAU); ctx.fill();
  ctx.fillStyle = '#eceeed'; ctx.beginPath(); ctx.arc(2, -170, 22, 0, TAU); ctx.fill(); const vg = ctx.createLinearGradient(-4, -184, 22, -158); vg.addColorStop(0, '#ffe39a'); vg.addColorStop(0.5, '#c8902e'); vg.addColorStop(1, '#6a4410'); ctx.fillStyle = vg; ctx.beginPath(); ctx.ellipse(8, -170, 15, 13, 0.2, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.ellipse(3, -176, 5, 3, -0.5, 0, TAU); ctx.fill();
  ctx.restore(); };
 // TRAYECTORIAS Tierra–Luna v2 (sustituye a lunarPath; misma firma): curvas suaves con tangentes continuas. 'apollo': órbita de
 // aparcamiento → inyección translunar → viaje → órbita lunar (o.lm: rama de descenso a la superficie). 'verne': salida → rodeo de
 // la Luna (sin posarse) → regreso hacia la Tierra. ESQUEMA, no a escala.
 P.lunarPath = (ctx, mode, earth, moon, u, t, o = {}) => { const [ex, ey, er] = earth, [mx, my, mr] = moon, pts = [], bez = (p0, c1, c2, p1, n) => { for (let i = 1; i <= n; i++) { const s = i / n, q = 1 - s; pts.push([q * q * q * p0[0] + 3 * q * q * s * c1[0] + 3 * q * s * s * c2[0] + s * s * s * p1[0], q * q * q * p0[1] + 3 * q * q * s * c1[1] + 3 * q * s * s * c2[1] + s * s * s * p1[1]]); } }, dir = Math.atan2(my - ey, mx - ex);
  if (mode === 'apollo') { const ro = er * 1.28, a0 = dir + Math.PI * 0.5; for (let i = 0; i <= 80; i++) { const a = a0 - (i / 80) * TAU * 1.0; pts.push([ex + Math.cos(a) * ro, ey + Math.sin(a) * ro]); } const aE = a0 - TAU, p0 = [ex + Math.cos(aE) * ro, ey + Math.sin(aE) * ro], tg = [Math.sin(aE), -Math.cos(aE)], rl = mr * 1.45, aL = dir + Math.PI * 0.62, pL = [mx + Math.cos(aL) * rl, my + Math.sin(aL) * rl], tgL = [-Math.sin(aL), Math.cos(aL)]; const dd = Math.hypot(mx - ex, my - ey); bez(p0, [p0[0] - tg[0] * dd * 0.45, p0[1] - tg[1] * dd * 0.45], [pL[0] - tgL[0] * dd * 0.35, pL[1] - tgL[1] * dd * 0.35], pL, 110); for (let i = 1; i <= 90; i++) { const a = aL + (i / 90) * TAU * 1.15; pts.push([mx + Math.cos(a) * rl, my + Math.sin(a) * rl]); } }
  else { const ps = [ex + Math.cos(dir - 0.5) * er * 1.05, ey + Math.sin(dir - 0.5) * er * 1.05], rv = mr * 1.6, aIn = dir + Math.PI * 0.55, pIn = [mx + Math.cos(aIn) * rv, my + Math.sin(aIn) * rv], tIn = [-Math.sin(aIn), Math.cos(aIn)], dd = Math.hypot(mx - ex, my - ey); bez(ps, [ps[0] + Math.cos(dir - 0.3) * dd * 0.4, ps[1] + Math.sin(dir - 0.3) * dd * 0.4], [pIn[0] + tIn[0] * dd * 0.3, pIn[1] + tIn[1] * dd * 0.3], pIn, 100); for (let i = 1; i <= 80; i++) { const a = aIn - (i / 80) * TAU * 1.0; pts.push([mx + Math.cos(a) * rv, my + Math.sin(a) * rv]); } const pOut = pts[pts.length - 1], tOut = [Math.sin(aIn), -Math.cos(aIn)], pe = [ex + Math.cos(dir + 0.7) * er * 1.4, ey + Math.sin(dir + 0.7) * er * 1.4]; bez(pOut, [pOut[0] + tOut[0] * dd * 0.3, pOut[1] + tOut[1] * dd * 0.3], [pe[0] + Math.cos(dir + 0.3) * dd * 0.35, pe[1] + Math.sin(dir + 0.3) * dd * 0.35], pe, 100); }
  const n = Math.max(1, Math.floor(cl(u) * (pts.length - 1))); ctx.save(); ctx.strokeStyle = o.col || (mode === 'apollo' ? '#53C5E8' : '#E7B56E'); ctx.lineWidth = o.lw || 5; ctx.setLineDash(o.dash || [14, 10]); ctx.lineDashOffset = -t * 30; ctx.beginPath(); for (let i = 0; i <= n; i++) ctx[i ? 'lineTo' : 'moveTo'](pts[i][0], pts[i][1]); ctx.stroke(); ctx.setLineDash([]);
  if (mode === 'apollo' && o.lm && u >= 1) { const a = dir + Math.PI * 1.1, p1 = [mx + Math.cos(a) * mr * 1.45, my + Math.sin(a) * mr * 1.45], p2 = [mx + Math.cos(a) * mr * 1.0, my + Math.sin(a) * mr * 1.0]; ctx.strokeStyle = '#FFD447'; ctx.lineWidth = 4; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#FFD447'; ctx.beginPath(); ctx.arc(p2[0], p2[1], 7, 0, TAU); ctx.fill(); }
  const cur = pts[n], prv = pts[Math.max(0, n - 2)]; ctx.restore(); return { pos: cur, ang: Math.atan2(cur[1] - prv[1], cur[0] - prv[0]), landing: mode === 'apollo' ? [mx + Math.cos(dir + Math.PI * 1.1) * mr, my + Math.sin(dir + Math.PI * 1.1) * mr] : null };
 };
 // ---------------- v1.23 · TARJETAS PERFORADAS (IBM de 80 columnas, 1928 → · Hollerith, censo de 1890) ----------------
 // Unidades 3D en MILÍMETROS. Tarjeta IBM (IBM Heritage: «7⅜ × 3¼ in, 80 columnas, 12 filas, agujeros rectangulares»): 187,3 × 82,6 mm,
 // grosor ≈ 0,18 mm, paso de columna 0,087 in, paso de fila 0,25 in; filas de arriba abajo 12, 11, 0, 1 … 9; agujero 1,40 × 3,18 mm.
 // Los agujeros son HUECOS REALES (relleno evenodd): se ve lo que hay detrás y la pared del agujero (grosor) en planos macro.
 // Formato 'h1890' (tarjeta de Hollerith, censo de 1890): más corta, agujeros REDONDOS y sin impresión; otro formato, otra época.
 const CARDF = {
  ibm: { w: 187.325, h: 82.55, th: 0.178, cols: 80, rows: 12, c0: 6.375, dc: 2.2098, r0: 6.35, dr: 6.35, hw: 1.397, hh: 3.175, round: false, col: '#E4D7BA', ink: '#8c5a4e', cut: [6.4, 3.6] },
  h1890: { w: 168.3, h: 82.55, th: 0.25, cols: 24, rows: 12, c0: 8.2, dc: 6.62, r0: 6.35, dr: 6.35, hw: 3.4, hh: 3.4, round: true, col: '#D8C5A3', ink: '#7a6448', cut: [7, 5] },
 };
 P.CARDF = CARDF;
 P.poly3 = poly3; // v1.23.1: polígono 3D con recorte (para escenarios simples en los episodios)
 const CROWS = [12, 11, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
 P.CROWS = CROWS;
 // Código de tarjeta (caracteres comunes a las perforadoras IBM 026 y 029): dígito = UNA perforación en su fila;
 // A–I = 12 + 1…9 · J–R = 11 + 1…9 · S–Z = 0 + 2…9 (combinación «zona + dígito» en la MISMA columna). Devuelve filas perforadas.
 // v1.23.1: = ( ) + según el juego FORTRAN de la perforadora IBM 026 (3-8, 0-4-8, 12-4-8, 12); en la 029 esos cuatro cambian.
 P.cardCode = (ch) => { ch = (ch || ' ').toUpperCase(); const c = ch.charCodeAt(0); if (ch >= '0' && ch <= '9') return [+ch]; if (ch >= 'A' && ch <= 'I') return [12, c - 64]; if (ch >= 'J' && ch <= 'R') return [11, c - 73]; if (ch >= 'S' && ch <= 'Z') return [0, c - 81]; return ({ ' ': [], ',': [0, 3, 8], '.': [12, 3, 8], '-': [11], '/': [0, 1], '*': [11, 4, 8], '$': [11, 3, 8], '=': [3, 8], '(': [0, 4, 8], ')': [12, 4, 8], '+': [12] })[ch] || []; };
 // línea de 80 caracteres → lista de perforaciones [[columna (1–80), fila], …]; o.n = columnas ya perforadas (animación)
 P.cardHoles = (s, o = {}) => { const out = [], n = o.n ?? 80; for (let i = 0; i < Math.min(80, n); i++) for (const r of P.cardCode(s[i] || ' ')) out.push([i + 1, r]); return out; };
 const cv3 = { crs: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], nrm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; } };
 const crX = (v, a) => { const c = Math.cos(a), s = Math.sin(a); return [v[0], v[1] * c - v[2] * s, v[1] * s + v[2] * c]; };
 const crY = (v, a) => { const c = Math.cos(a), s = Math.sin(a); return [v[0] * c + v[2] * s, v[1], -v[0] * s + v[2] * c]; };
 const crZ = (v, a) => { const c = Math.cos(a), s = Math.sin(a); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2]]; };
 P.cardRot = (v, o = {}) => crY(crX(crZ(v, o.roll || 0), o.pitch || 0), o.yaw || 0);
 // Marco de una tarjeta centrada en c. Sin giros: vertical, cara hacia +z. pitch = -π/2 → tumbada boca arriba (cara hacia +y).
 P.cardFrame = (c, o = {}) => { const fmt = o.fmt || 'ibm', F = CARDF[fmt], ex = P.cardRot([1, 0, 0], o), ey = P.cardRot([0, -1, 0], o); return { fmt, ex, ey, o: [0, 1, 2].map((i) => c[i] - ex[i] * F.w / 2 - ey[i] * F.h / 2) }; };
 P.cardNormal = (cd) => cv3.nrm(cv3.crs(cd.ey, cd.ex));
 P.cardPt = (cd, u, v, d = 0) => { const n = P.cardNormal(cd); return [0, 1, 2].map((i) => cd.o[i] + cd.ex[i] * u + cd.ey[i] * v + n[i] * d); };
 // centro (u, v) en mm de una posición: IBM → (columna 1–80, fila 12/11/0–9); 1890 → (columna 1–24, índice de fila 0–11)
 P.holeUV = (fmt, c, r) => { const F = CARDF[fmt || 'ibm'], i = fmt === 'h1890' ? r : CROWS.indexOf(r); return [F.c0 + (c - 1) * F.dc, F.r0 + i * F.dr]; };
 // Dibuja la tarjeta. cd = cardFrame(...) + { holes: [[c, r], …], text (impresión superior, como la perforadora impresora), seq }.
 // o: { print (dígitos y campos FORTRAN), textN (caracteres impresos visibles), hl: [{c, r, col, a, fill}], band: {c, a, col},
 //      L (luz), thk (exageración del grosor en macro), col, alpha }. Devuelve { front, F, proj, s (px por mm) } o null.
 P.punchCard3 = (ctx, cam, cd, t, o = {}) => {
  const fmt = cd.fmt || 'ibm', F = CARDF[fmt], n = P.cardNormal(cd), holes = o.holes || cd.holes || [], thk = F.th * (o.thk ?? 1);
  const proj = (u, v, d = 0) => cam.pr(P.cardPt(cd, u, v, d)), cen = P.cardPt(cd, F.w / 2, F.h / 2), front = faceVis(cam, n, cen);
  const out = [[F.cut[0], 0], [F.w, 0], [F.w, F.h], [0, F.h], [0, F.cut[1]]];
  const nearCam = out.some(([u, v]) => proj(u, v)[2] < 2), c0 = proj(F.w / 2, F.h / 2), c1 = proj(F.w / 2 + 1, F.h / 2), s = c0[2] > 2 ? Math.hypot(c1[0] - c0[0], c1[1] - c0[1]) : 50;
  if (!nearCam && c0[0] < -2 * s * F.w - 400 || c0[0] > W + 2 * s * F.w + 400 || c0[1] < -2 * s * F.w - 400 || c0[1] > HH + 2 * s * F.w + 400) return null;
  const path = (d) => { ctx.beginPath(); const ol = nearCam ? cam.clip(out.map(([u, v]) => P.cardPt(cd, u, v, d)), 2) : out.map(([u, v]) => proj(u, v, d)); if (ol.length < 3) return; ol.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath();
   if (s * F.hw < 0.35) return; for (const [c, r] of holes) { const [hu, hv] = P.holeUV(fmt, c, r);
    if (F.round) { for (let k = 0; k <= 10; k++) { const q = (k / 10) * TAU, p = proj(hu + Math.cos(q) * F.hw / 2, hv - Math.sin(q) * F.hh / 2, d); k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); } ctx.closePath(); }
    else { const a = proj(hu - F.hw / 2, hv - F.hh / 2, d), b = proj(hu + F.hw / 2, hv - F.hh / 2, d), c2 = proj(hu + F.hw / 2, hv + F.hh / 2, d), e = proj(hu - F.hw / 2, hv + F.hh / 2, d); if (Math.min(a[2], b[2], c2[2], e[2]) < 2) continue; ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c2[0], c2[1]); ctx.lineTo(e[0], e[1]); ctx.closePath(); } } };
  const L = cv3.nrm(o.L || [-0.45, 0.55, 0.7]), lam = Math.abs(cv3.dot(n, L)), base = o.col || F.col, k = 0.7 + 0.34 * lam;
  const near = front ? 0 : -thk, far = front ? -thk : 0; ctx.save(); if (o.alpha != null) ctx.globalAlpha *= o.alpha;
  path(far); ctx.fillStyle = rmShade(base, 0.52); ctx.fill('evenodd');
  path(near); ctx.fillStyle = rmShade(base, front ? k : k * 0.96); ctx.fill('evenodd'); ctx.strokeStyle = rmShade(base, 0.62); ctx.lineWidth = Math.max(0.6, Math.min(2, s * 0.25)); ctx.stroke();
  ctx.save(); path(near); ctx.clip('evenodd');
  if (!nearCam) { const p0 = proj(0, 0), p1 = proj(F.w, F.h), g = ctx.createLinearGradient(p0[0], p0[1], p1[0], p1[1]); g.addColorStop(0, `rgba(255,250,235,${0.14 * lam})`); g.addColorStop(0.55, 'rgba(255,255,255,0)'); g.addColorStop(1, `rgba(60,40,20,${0.12})`); ctx.fillStyle = g; ctx.fillRect(-50, -50, W + 100, HH + 100); }
  if (front && !nearCam && o.print !== false && fmt === 'ibm' && s * F.dc > 3.2) {
   const M0 = ctx.getTransform(), glyph = (str, u, v, size, col2, font) => { const p = proj(u, v), a = proj(u + 1, v), b = proj(u, v + 1), kk = size / 10; ctx.setTransform(M0); ctx.transform((a[0] - p[0]) * kk, (a[1] - p[1]) * kk, (b[0] - p[0]) * kk, (b[1] - p[1]) * kk, p[0], p[1]); ctx.fillStyle = col2; ctx.font = font || '600 10px "IBM Plex Mono"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(str, 0, 0); };
   const ink = o.ink || F.ink, inkA = H.rgba(H.mix(base, ink, 0.75));
   for (let c = 1; c <= 80; c++) { const u = F.c0 + (c - 1) * F.dc; for (let i = 2; i < 12; i++) glyph(String(CROWS[i]), u, F.r0 + i * F.dr, 1.75, inkA); if (s * F.dc > 7) { glyph(String(c), u, F.r0 + 2.5 * F.dr, 0.95, inkA); glyph(String(c), u, F.h - 1.5, 0.95, inkA); } }
   ctx.setTransform(M0); ctx.strokeStyle = inkA; ctx.lineWidth = Math.max(0.6, s * 0.18); for (const cc of [5, 6, 72]) { const u = F.c0 + (cc - 0.5) * F.dc, p = proj(u, F.r0 + 1.5 * F.dr), q = proj(u, F.h - 3); ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); }
   if (o.fields !== false) { glyph('STATEMENT', F.c0 + 2 * F.dc, F.r0 + 1.5 * F.dr, 1.2, inkA, '700 10px Nunito'); glyph('FORTRAN   STATEMENT', F.c0 + 39 * F.dc, F.r0 + 1.5 * F.dr, 1.6, inkA, '800 10px Nunito'); glyph('IDENTIFICATION', F.c0 + 75.5 * F.dc, F.r0 + 1.5 * F.dr, 1.2, inkA, '700 10px Nunito'); }
   const tx = o.text ?? cd.text; if (tx) { const tn = o.textN ?? 80; for (let i = 0; i < Math.min(tn, tx.length, 80); i++) if (tx[i] !== ' ') glyph(tx[i], F.c0 + i * F.dc, 2.35, 2.6, o.textCol || '#2a2522', '700 10px "IBM Plex Mono"'); }
   ctx.setTransform(M0);
  }
  ctx.restore();
  if (o.band) { const b = o.band, u = F.c0 + (b.c - 1) * F.dc, pts = [proj(u - F.dc / 2, 1), proj(u + F.dc / 2, 1), proj(u + F.dc / 2, F.h - 1), proj(u - F.dc / 2, F.h - 1)]; ctx.save(); ctx.globalAlpha *= b.a ?? 1; ctx.fillStyle = b.fill || 'rgba(76,211,232,0.16)'; ctx.strokeStyle = b.col || '#4CD3E8'; ctx.lineWidth = Math.max(2, s * 0.35); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore(); }
  for (const h of o.hl || []) { const a = h.a ?? 1; if (a <= 0) continue; const [hu, hv] = P.holeUV(fmt, h.c, h.r), m = 0.9, pts = [proj(hu - F.hw / 2 - m, hv - F.hh / 2 - m), proj(hu + F.hw / 2 + m, hv - F.hh / 2 - m), proj(hu + F.hw / 2 + m, hv + F.hh / 2 + m), proj(hu - F.hw / 2 - m, hv + F.hh / 2 + m)], cc = proj(hu, hv); ctx.save(); ctx.globalAlpha *= a; P.glow(ctx, cc[0], cc[1], Math.max(14, s * 6), h.rgb || '255,212,71', 0.5); ctx.strokeStyle = h.col || '#FFD447'; ctx.lineWidth = Math.max(2.5, s * 0.4); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); if (h.fill) { ctx.fillStyle = h.fill; ctx.fill(); } ctx.stroke(); ctx.restore(); }
  ctx.restore(); return { front, F, proj, s, c: c0 };
 };
 // Pila de tarjetas tumbadas (boca arriba) centrada en (x, z) sobre y. v1.23.1: TARJETAS INDIVIDUALES — cada tarjeta (o grupo, cuando
 // su canto mide < 1 px en pantalla) es una lámina con desplazamiento y giro mínimos deterministas, tono propio y junta oscura: los
 // cantos se leen como capas reales, no como un bloque. Sombra de contacto sobre la mesa. o: { yaw, topCard, topOpts, exag, jitter, seed, col }
 P.cardDeck3 = (ctx, cam, x, y, z, n, t, o = {}) => { const F = CARDF.ibm, th = F.th * (o.exag ?? 1), hgt = Math.max(0.2, n * th), yaw = o.yaw || 0, col = o.col || F.col, jit = o.jitter ?? 0.55, hw = F.w / 2, hh = F.h / 2, Lg = cv3.nrm([-0.45, 0.55, 0.7]);
  const c0 = cam.pr([x, y, z]), c1 = cam.pr([x, y + 10, z]); if (c0[2] < 1) return null; const ppm = Math.abs(c1[1] - c0[1]) / 10, g = Math.max(1, Math.ceil(0.9 / Math.max(1e-6, ppm * th))), nb = Math.ceil(n / g);
  const corners = (dx, dz, yw) => [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]].map(([a, b]) => { const r = crY([a, 0, b], yaw + yw); return [x + dx + r[0], z + dz + r[2]]; });
  const base = corners(0, 0, 0), vis = []; for (let i = 0; i < 4; i++) { const a = base[i], b = base[(i + 1) % 4], nn = cv3.nrm([b[1] - a[1], 0, -(b[0] - a[0])]), c = [(a[0] + b[0]) / 2, y + hgt / 2, (a[1] + b[1]) / 2]; if (faceVis(cam, nn, c)) vis.push({ i, lit: 0.62 + 0.3 * Math.abs(cv3.dot(nn, Lg)) }); }
  { const s2 = base.map(([a, b]) => cam.pr([x + (a - x) * 1.05 + 5, y + 0.05, z + (b - z) * 1.05 + 7])); if (s2.every((p) => p[2] > 1)) { ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.beginPath(); s2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); } }
  for (const v of vis) { const a = base[v.i], b = base[(v.i + 1) % 4]; poly3(ctx, cam, [[a[0], y, a[1]], [b[0], y, b[1]], [b[0], y + hgt, b[1]], [a[0], y + hgt, a[1]]], rmShade(col, v.lit * 0.86)); }
  const R = H.rng(o.seed ?? 3); let last = [0, 0, 0];
  for (let k = 0; k < nb; k++) { const y0 = y + k * g * th, y1 = Math.min(y + hgt, y0 + g * th), dx = (R() - 0.5) * jit * 2, dz = (R() - 0.5) * jit * 2, yw = (R() - 0.5) * 0.008, shd = 0.9 + R() * 0.12, cs = corners(dx, dz, yw); last = [dx, dz, yw];
   for (const v of vis) { const a = cs[v.i], b = cs[(v.i + 1) % 4], pts = [[a[0], y0, a[1]], [b[0], y0, b[1]], [b[0], y1, b[1]], [a[0], y1, a[1]]].map((p) => cam.pr(p)); if (pts.some((p) => p[2] < 1)) continue; ctx.fillStyle = rmShade(col, v.lit * shd * 0.94); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill();
    if (ppm * g * th > 1.3) { ctx.strokeStyle = `rgba(60,44,28,${ppm * g * th > 3 ? 0.45 : 0.28})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); ctx.lineTo(pts[1][0], pts[1][1]); ctx.stroke(); } } }
  const cd = Object.assign(P.cardFrame([x + last[0], y + hgt + 0.01, z + last[1]], { pitch: -Math.PI / 2, yaw: yaw + last[2] }), o.topCard || {}); return P.punchCard3(ctx, cam, cd, t, Object.assign({ print: true }, o.topOpts || {}));
 };
 // ---------------- LECTOR DE ESCOBILLAS (reconstrucción) ----------------
 // Mecanismo elegido para TODO el episodio (mediados del s. XX): la tarjeta avanza boca abajo, borde de la fila 9 primero; una escobilla
 // metálica por columna (80) roza la tarjeta sobre un rodillo de contacto. Donde hay AGUJERO la escobilla toca el rodillo: se cierra el
 // circuito y sale un impulso; el INSTANTE del impulso indica qué fila estaba bajo la escobilla. (No se presenta como el único sistema.)
 // Cilindro de eje X con tapas, eje y marcas de giro (rot en rad) — piezas MÓVILES. o: { rot, caps, stripes, axle }
 const CH = (ctx, cam, x0, x1, cy, cz, r, col, N = 18, o = {}) => { const items = [], rot = o.rot || 0; for (let i = 0; i < N; i++) { const a = (i / N) * TAU, b = ((i + 1) / N) * TAU, nn = [0, Math.cos((a + b) / 2), Math.sin((a + b) / 2)], c = [(x0 + x1) / 2, cy + nn[1] * r, cz + nn[2] * r]; if (!faceVis(cam, nn, c)) continue; items.push({ d: cam.depth(c), f: () => poly3(ctx, cam, [[x0, cy + Math.cos(a) * r, cz + Math.sin(a) * r], [x1, cy + Math.cos(a) * r, cz + Math.sin(a) * r], [x1, cy + Math.cos(b) * r, cz + Math.sin(b) * r], [x0, cy + Math.cos(b) * r, cz + Math.sin(b) * r]], rmShade(col, 0.5 + 0.62 * Math.max(0, nn[1] * 0.75 + nn[2] * 0.45))) }); }
  items.sort((p, q) => q.d - p.d).forEach((p) => p.f());
  if (o.stripes !== false) for (let k = 0; k < 3; k++) { const a = rot + (k * TAU) / 3, nn = [0, Math.cos(a), Math.sin(a)]; if (!faceVis(cam, nn, [(x0 + x1) / 2, cy + nn[1] * r, cz + nn[2] * r])) continue; const p = cam.pr([x0 + 3, cy + nn[1] * r * 1.01, cz + nn[2] * r * 1.01]), q = cam.pr([x1 - 3, cy + nn[1] * r * 1.01, cz + nn[2] * r * 1.01]); if (p[2] < 1 || q[2] < 1) continue; ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = Math.max(1, 1200 / p[2]); ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); }
  if (o.caps !== false) for (const xe of [x0, x1]) { if ((cam.pos[0] - xe) * (xe === x0 ? -1 : 1) <= 0) continue; const pts = []; for (let i = 0; i < 18; i++) { const a = (i / 18) * TAU; pts.push([xe, cy + Math.cos(a) * r, cz + Math.sin(a) * r]); } poly3(ctx, cam, pts, rmShade(col, 0.85)); const hub = []; for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU + rot; hub.push([xe + (xe === x0 ? -0.2 : 0.2), cy + Math.cos(a) * r * 0.35, cz + Math.sin(a) * r * 0.35]); } poly3(ctx, cam, hub, '#9aa5ab'); } };
 P.cylX3 = CH;
 // Lector de tarjetas en 3D (mm). PIEZAS FIJAS (bastidor azul acero, guías, soportes, porta-escobillas aislante) y MÓVILES (rodillos de
 // goma y de acero, escobillas de bronce fosforoso). Bancada a y = bedY; la tarjeta avanza boca abajo hacia −z. Estación de lectura en
 // z = 0. o: { card, cardOpts, contacts:[col…], roll (mm avanzados: giran los rodillos), signal 0..1, sigAge (s desde el último contacto),
 // cover, hopper, stacker }. Devuelve { bedY, brushX, lamp (punto 3D de la lámpara de lectura) }.
 P.cardReader3 = (ctx, cam, t, o = {}) => { const bedY = o.bedY ?? 900, F = CARDF.ibm, frame = '#56656e', steel = '#b9c3c8', rubber = '#2a2c2e', bake = '#2a2522', roll = o.roll ?? 0, sig = cl(o.signal ?? 0), lamp = [205, bedY + 46, 0];
  const list = [];
  list.push({ d: cam.depth([0, bedY / 2, 0]) + 1e5, f: () => { P.box3(ctx, cam, -195, 195, 0, bedY - 6, -335, 335, frame, {}); P.box3(ctx, cam, -200, 200, bedY - 6, bedY, -340, 340, '#47545c', {});
   for (const yy of [bedY * 0.35, bedY * 0.7]) poly3(ctx, cam, [[-175, yy, 336], [175, yy, 336], [175, yy + 3, 336], [-175, yy + 3, 336]], '#46525a');
   poly3(ctx, cam, [[-128, bedY + 0.2, -305], [128, bedY + 0.2, -305], [128, bedY + 0.2, 305], [-128, bedY + 0.2, 305]], '#3d474e');
   { const g0 = cam.pr([0, bedY + 0.2, 300]), g1 = cam.pr([0, bedY + 0.2, -300]); if (g0[2] > 1 && g1[2] > 1) { const gr = ctx.createLinearGradient(g0[0], g0[1], g1[0], g1[1]); gr.addColorStop(0, 'rgba(255,255,255,0.05)'); gr.addColorStop(1, 'rgba(0,0,0,0.12)'); poly3(ctx, cam, [[-128, bedY + 0.25, -305], [128, bedY + 0.25, -305], [128, bedY + 0.25, 305], [-128, bedY + 0.25, 305]], gr); } }
   poly3(ctx, cam, [[-110, bedY + 0.4, -6.5], [110, bedY + 0.4, -6.5], [110, bedY + 0.4, 6.5], [-110, bedY + 0.4, 6.5]], '#0c0f11');
   CH(ctx, cam, -108, 108, bedY - 9.6, 0, 10, steel, 22, { rot: -roll / 10, caps: false });
   for (const sx of [-1, 1]) { P.box3(ctx, cam, sx > 0 ? 96 : -104, sx > 0 ? 104 : -96, bedY, bedY + 6, -305, 305, '#7f8d95', {}); P.box3(ctx, cam, sx > 0 ? 92 : -104, sx > 0 ? 104 : -92, bedY + 6, bedY + 7.5, -305, 305, '#9aa7ae', {}); } } });
  if (o.card) list.push({ d: cam.depth([0, bedY, 200]) + 2e4, f: () => { const pts = [[0, 0], [F.w, 0], [F.w, F.h], [0, F.h]].map(([u, v]) => { const p = P.cardPt(o.card, u, v); return cam.pr([p[0] + 2.2, bedY + 0.3, p[2] - 2.5]); }); if (pts.every((p) => p[2] > 1)) { ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill(); } } });
  if (o.hopper !== 0) list.push({ d: cam.depth([0, bedY + 40, 250]), f: () => { P.box3(ctx, cam, -112, 112, bedY, bedY + 6, 205, 300, '#2b3439', {}); for (const sx of [-1, 1]) P.box3(ctx, cam, sx * 108 - 4, sx * 108 + 4, bedY, bedY + 110, 205, 300, '#56636b', {}); P.box3(ctx, cam, -112, 112, bedY, bedY + 110, 296, 302, '#56636b', {}); if (o.hopper) P.cardDeck3(ctx, cam, 0, bedY + 6, 250, o.hopper, t, { topOpts: { print: false } }); } });
  list.push({ d: cam.depth([0, bedY + 40, -250]), f: () => { P.box3(ctx, cam, -112, 112, bedY - 30, bedY - 24, -320, -215, '#2b3439', {}); for (const sx of [-1, 1]) P.box3(ctx, cam, sx * 108 - 4, sx * 108 + 4, bedY - 30, bedY + 40, -320, -215, '#56636b', {}); if (o.stacker) P.cardDeck3(ctx, cam, 0, bedY - 24, -268, o.stacker, t, { topOpts: { print: false } }); } });
  // rodillos de arrastre: goma (móvil) con eje de acero y soportes con rodamiento (fijos)
  for (const rz of [120, -120]) list.push({ d: cam.depth([0, bedY + 12, rz]), f: () => { const cy = bedY + 0.8 + 10.5; for (const sx of [-1, 1]) { P.box3(ctx, cam, sx * 118 - 7, sx * 118 + 7, bedY, cy + 14, rz - 11, rz + 11, '#6c7a82', {}); } CH(ctx, cam, -124, -96, cy, rz, 2.6, steel, 10, { stripes: false, caps: false }); CH(ctx, cam, 96, 124, cy, rz, 2.6, steel, 10, { stripes: false, caps: false }); CH(ctx, cam, -96, 96, cy, rz, 10.5, rubber, 22, { rot: roll / 10.5 * (rz > 0 ? 1 : 1) }); } });
  if (o.card) list.push({ d: cam.depth(P.cardPt(o.card, F.w / 2, F.h / 2)) + 30, f: () => P.punchCard3(ctx, cam, o.card, t, o.cardOpts || {}) });
  // estación de lectura: porta-escobillas aislante + barra colectora de cobre + 80 escobillas (láminas) + cable al circuito de lectura
  list.push({ d: cam.depth([0, bedY + 25, 0]) - 5, f: () => { const hy = bedY + 20; for (const sx of [-1, 1]) P.box3(ctx, cam, sx * 120 - 8, sx * 120 + 8, bedY, hy + 22, -10, 10, '#6c7a82', {}); P.box3(ctx, cam, -112, 112, hy, hy + 16, -8, 8, bake, {}); P.box3(ctx, cam, -112, 112, hy + 16, hy + 20, -9, 9, '#b87333', {});
   const xs = (c) => -F.w / 2 + F.c0 + (c - 1) * F.dc, act = new Set(o.contacts || []);
   for (let c = 1; c <= 80; c++) { const bx = xs(c), on = act.has(c), tip = on ? bedY + 0.45 : bedY + 0.85, root = [[bx - 0.6, hy, 5], [bx + 0.6, hy, 5]], mid = [[bx + 0.6, bedY + 6, 0.5], [bx - 0.6, bedY + 6, 0.5]], end = [[bx - 0.55, tip, -3.2], [bx + 0.55, tip, -3.2]];
    const A1 = poly3(ctx, cam, [root[0], root[1], mid[0], mid[1]], on ? '#e8b85c' : '#a8773a'); poly3(ctx, cam, [mid[1], mid[0], end[1], end[0]], on ? '#ffd77a' : '#c08a3e'); void A1;
    if (on) { const p = cam.pr([bx, tip, -3.2]); if (p[2] > 1) P.glow(ctx, p[0], p[1], Math.max(10, 7000 / p[2]), '81,215,190', 0.75); } }
   if (o.cover > 0) { ctx.save(); ctx.globalAlpha *= cl(o.cover); P.box3(ctx, cam, -150, 150, bedY + 8, bedY + 70, -205, 60, '#6b7880', {}); ctx.restore(); }
   // cable de señal (de la barra colectora a la caja de lectura) y lámpara de estado
   P.box3(ctx, cam, 190, 222, bedY, bedY + 60, -22, 22, '#3b464d', {}); const cab = [[112, hy + 18, 0], [150, hy + 34, 0], [190, hy + 34, 0]].map((p) => cam.pr(p)); if (cab.every((p) => p[2] > 1)) { ctx.strokeStyle = sig > 0 ? '#51D7BE' : '#20282c'; ctx.lineWidth = Math.max(2, Math.min(14, 3000 / cab[0][2])); ctx.beginPath(); cab.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke();
    const age = o.sigAge ?? 99; if (age < 0.6) { const q = age / 0.6, k = q < 0.5 ? 0 : 1, f = q < 0.5 ? q * 2 : (q - 0.5) * 2, px = lerp(cab[k][0], cab[k + 1][0], f), py = lerp(cab[k][1], cab[k + 1][1], f); P.glow(ctx, px, py, 40, '81,215,190', 0.9); ctx.fillStyle = '#F5F7F7'; ctx.beginPath(); ctx.arc(px, py, Math.max(3, 4000 / cab[0][2]), 0, TAU); ctx.fill(); } }
   const L = cam.pr([lamp[0], lamp[1], 23]); if (L[2] > 1) { const lr = Math.max(4, 9000 / L[2]), on = (o.sigAge ?? 99) < 0.5; ctx.fillStyle = on ? '#51D7BE' : '#1b2a2a'; ctx.beginPath(); ctx.arc(L[0], L[1], lr, 0, TAU); ctx.fill(); if (on) P.glow(ctx, L[0], L[1], lr * 5, '81,215,190', 0.8); } } });
  ykDrawList(ctx, cam, list); return { bedY, brushX: (c) => -F.w / 2 + F.c0 + (c - 1) * F.dc, lamp };
 };
 // Corte técnico 2D del lector (vista lateral) con DOS ESTADOS claros: A) cartón entre escobilla y rodillo → circuito ABIERTO, «SIN
 // CONTACTO»; B) un agujero llega bajo la escobilla → contacto físico, circuito CERRADO, «CONTACTO DETECTADO» y el impulso viaja hasta
 // la lectura (lámpara). o: { u 0..1 (avance), rows (filas perforadas), sigAge (s desde el último contacto; mantiene el estado B 0,5 s) }
 P.readerSection = (ctx, x, y, w, h, t, o = {}) => { const F = CARDF.ibm, rows = o.rows || [], u = cl(o.u ?? 0), k = (w * 1.05) / F.h, bx = x + w * 0.42, ry = y + h * 0.62, rr = h * 0.13, cy = ry - rr - 11, age = o.sigAge ?? 99;
  ctx.save(); ctx.fillStyle = 'rgba(10,22,33,0.94)'; ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.fill(); ctx.strokeStyle = 'rgba(76,211,232,0.35)'; ctx.lineWidth = 2; ctx.stroke(); ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.clip();
  const lead = lerp(x + w + 40, x - F.h * k - 60, u), vAt = (px) => (px - lead) / k, gapAt = (vl) => rows.some((r) => Math.abs(vl - (F.h - P.holeUV('ibm', 1, r)[1])) < F.hh / 2);
  const vB = vAt(bx), onCard = vB >= 0 && vB <= F.h, contact = onCard && gapAt(vB), lit = contact || age < 0.5;
  // rodillo de contacto (acero, gira con el avance) sobre su eje y soporte fijo
  ctx.fillStyle = '#3a444a'; ctx.fillRect(bx - 18, ry, 36, y + h - ry); { const g = ctx.createRadialGradient(bx - rr * 0.35, ry - rr * 0.45, rr * 0.1, bx, ry, rr); g.addColorStop(0, '#f2f6f7'); g.addColorStop(0.55, '#a7b2b8'); g.addColorStop(1, '#4b565c'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, ry, rr, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(40,50,55,0.55)'; ctx.lineWidth = 3; for (let i = 0; i < 6; i++) { const a = -u * 14 + (i / 6) * TAU; ctx.beginPath(); ctx.moveTo(bx + Math.cos(a) * rr * 0.3, ry + Math.sin(a) * rr * 0.3); ctx.lineTo(bx + Math.cos(a) * rr * 0.85, ry + Math.sin(a) * rr * 0.85); ctx.stroke(); } ctx.fillStyle = '#6c777d'; ctx.beginPath(); ctx.arc(bx, ry, rr * 0.18, 0, TAU); ctx.fill(); }
  // tarjeta de perfil (cartón mate, cantos definidos), agujeros como huecos
  const th = 22; for (let px = Math.max(x, lead); px < Math.min(x + w, lead + F.h * k); px += 2) { if (!gapAt(vAt(px))) { ctx.fillStyle = '#E4D7BA'; ctx.fillRect(px, cy - th / 2, 2.2, th); ctx.fillStyle = 'rgba(90,70,45,0.55)'; ctx.fillRect(px, cy + th / 2 - 3, 2.2, 3); } }
  ctx.font = '700 32px "IBM Plex Mono"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const r of CROWS) { const vl = F.h - P.holeUV('ibm', 1, r)[1], px = lead + vl * k; if (px < x + 20 || px > x + w - 20) continue; const isH = rows.includes(r), under = Math.abs(px - bx) < (F.dr * k) / 2; ctx.fillStyle = under ? '#FFD447' : isH ? 'rgba(245,247,247,0.95)' : 'rgba(245,247,247,0.4)'; ctx.fillText(String(r), px, cy - 40); }
  // escobilla: haz de alambres de bronce en un porta-escobillas aislante, apoyada en el cartón (A) o tocando el rodillo (B)
  const hy = y + h * 0.2, tipY = contact ? ry - rr + 1 : cy - th / 2 - 1; ctx.fillStyle = '#2a2522'; ctx.fillRect(bx - 64, hy - 34, 128, 46); ctx.fillStyle = '#b87333'; ctx.fillRect(bx - 70, hy - 44, 140, 10); for (const sx of [-44, 44]) { ctx.fillStyle = '#9aa5ab'; ctx.beginPath(); ctx.arc(bx + sx, hy - 12, 6, 0, TAU); ctx.fill(); }
  { const bend = contact ? 4 : 22, g = ctx.createLinearGradient(bx - 16, 0, bx + 16, 0); g.addColorStop(0, '#8a5a24'); g.addColorStop(0.5, lit ? '#ffe39a' : '#d39a4a'); g.addColorStop(1, '#8a5a24'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(bx - 16, hy + 12); ctx.lineTo(bx + 16, hy + 12); ctx.quadraticCurveTo(bx + 14 + bend * 0.5, (hy + tipY) / 2, bx + 5 + bend, tipY); ctx.lineTo(bx - 5 + bend, tipY); ctx.quadraticCurveTo(bx - 14 + bend * 0.5, (hy + tipY) / 2, bx - 16, hy + 12); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(60,35,10,0.6)'; ctx.lineWidth = 1.5; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(bx + i * 4, hy + 14); ctx.quadraticCurveTo(bx + i * 3.4 + bend * 0.5, (hy + tipY) / 2, bx + i * 1.3 + bend, tipY - 2); ctx.stroke(); } }
  if (contact) P.glow(ctx, bx + 4, tipY, 60, '81,215,190', 0.75);
  // circuito: barra colectora → cable → LECTURA (lámpara) → retorno al eje del rodillo. Abierto en A, cerrado (iluminado) en B.
  const boxX = x + w - 290, boxY = y + 60; ctx.lineWidth = 6; ctx.strokeStyle = lit ? '#51D7BE' : 'rgba(150,170,180,0.35)'; ctx.beginPath(); ctx.moveTo(bx, hy - 44); ctx.lineTo(bx, y + 40); ctx.lineTo(boxX, y + 40); ctx.stroke(); ctx.beginPath(); ctx.moveTo(boxX + 150, boxY + 70); ctx.lineTo(boxX + 150, y + h - 18); ctx.lineTo(bx, y + h - 18); ctx.lineTo(bx, ry + rr * 0.2); ctx.stroke();
  ctx.fillStyle = '#1b2a33'; ctx.beginPath(); ctx.roundRect(boxX, boxY - 34, 250, 104, 14); ctx.fill(); ctx.strokeStyle = lit ? '#51D7BE' : 'rgba(150,170,180,0.4)'; ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = lit ? '#51D7BE' : '#22343a'; ctx.beginPath(); ctx.arc(boxX + 40, boxY + 18, 18, 0, TAU); ctx.fill(); if (lit) P.glow(ctx, boxX + 40, boxY + 18, 70, '81,215,190', 0.8); ctx.fillStyle = 'rgba(245,247,247,0.9)'; ctx.font = '800 32px Nunito'; ctx.textAlign = 'left'; ctx.fillText('LECTURA', boxX + 66, boxY + 18);
  if (age < 0.6) { const q = age / 0.6, L1 = y + 40 - (hy - 44), L2 = boxX - bx, d = q * (Math.abs(L1) + L2), px = d < Math.abs(L1) ? bx : bx + (d - Math.abs(L1)), py = d < Math.abs(L1) ? hy - 44 - d : y + 40; P.glow(ctx, px, py, 36, '81,215,190', 0.9); ctx.fillStyle = '#F5F7F7'; ctx.beginPath(); ctx.arc(px, py, 7, 0, TAU); ctx.fill(); }
  ctx.fillStyle = 'rgba(245,247,247,0.85)'; ctx.font = '800 32px Nunito'; ctx.textAlign = 'left'; ctx.fillText('ESCOBILLA', bx + 80, hy - 10); ctx.fillText('RODILLO', bx - rr - 170, ry + 10); ctx.textAlign = 'center'; ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,247,0.7)'; ctx.fillText('← avance', x + w * 0.66, cy - 100);
  // rótulo de estado (uno solo a la vez)
  ctx.font = '900 40px Nunito'; ctx.textAlign = 'center'; const sx2 = x + w / 2 - 60, sy = y + h - 62; ctx.fillStyle = '#0d1c26'; ctx.beginPath(); ctx.roundRect(sx2 - 250, sy - 32, 500, 64, 32); ctx.fill(); ctx.strokeStyle = lit ? '#51D7BE' : 'rgba(245,247,247,0.3)'; ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = lit ? '#51D7BE' : 'rgba(245,247,247,0.75)'; ctx.fillText(lit ? 'CONTACTO DETECTADO' : 'SIN CONTACTO', sx2, sy + 2);
  ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(245,247,247,0.7)'; ctx.fillText(lit ? 'circuito cerrado: hay señal' : 'el cartón separa escobilla y rodillo', sx2, sy - 56);
  const passed = rows.filter((r) => lead + (F.h - P.holeUV('ibm', 1, r)[1]) * k < bx); ctx.restore(); return { contact, onCard, passed, lit };
 };
 P.readerSectionU = (x, w, r) => { const F = CARDF.ibm, k = (w * 1.05) / F.h, bx = x + w * 0.42, a = x + w + 40, b = x - F.h * k - 60, vl = F.h - P.holeUV('ibm', 1, r)[1]; return (a + vl * k - bx) / (a - b); };
 // Panel de decodificación: una columna con sus 12 posiciones (12, 11, 0–9), las detectadas encendidas, y el símbolo resultante.
 // o: { rows (detectadas), a (aparición del símbolo), sym, note }
 P.decodePanel = (ctx, x, y, w, h, t, o = {}) => { const rows = o.rows || [], cw = Math.min(110, w * 0.3), sh = (h - 60) / 12; ctx.save(); ctx.fillStyle = 'rgba(10,22,33,0.92)'; ctx.beginPath(); ctx.roundRect(x, y, w, h, 24); ctx.fill(); ctx.strokeStyle = 'rgba(76,211,232,0.35)'; ctx.lineWidth = 2; ctx.stroke();
  ctx.font = '700 32px "IBM Plex Mono"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; const cx = x + 40 + cw / 2;
  CROWS.forEach((r, i) => { const yy = y + 30 + sh * (i + 0.5), on = rows.includes(r); ctx.fillStyle = on ? '#FFD447' : 'rgba(245,247,247,0.55)'; ctx.fillText(String(r), x + 30 + 10, yy); ctx.fillStyle = on ? 'rgba(255,212,71,0.95)' : 'rgba(228,215,186,0.18)'; ctx.fillRect(cx - 12, yy - sh * 0.32, 34, sh * 0.64); if (on) P.glow(ctx, cx + 5, yy, 40, '255,212,71', 0.5); });
  const a = cl(o.a ?? 1); if (a > 0 && o.sym) { ctx.globalAlpha *= a; ctx.fillStyle = '#4CD3E8'; ctx.font = '900 64px Nunito'; ctx.fillText('→', x + cw + 110, y + h / 2); ctx.fillStyle = '#F5F7F7'; ctx.font = `900 ${Math.min(200, h * 0.42)}px "IBM Plex Mono"`; ctx.fillText(o.sym, x + w - (w - cw - 160) / 2 - 10, y + h / 2 - 10); if (o.note) { ctx.font = '700 32px Nunito'; ctx.fillStyle = 'rgba(245,247,247,0.85)'; ctx.fillText(o.note, x + w - (w - cw - 160) / 2 - 10, y + h - 50); } }
  ctx.restore(); };
 // ---------------- PERFORADORA DE TECLADO (tipo IBM 026, reconstrucción genérica sin marcas, mm) ----------------
 // v1.23.1: teclado inclinado con teclas de dos tonos sobre su base, mesa con patas y travesaño, canal de alimentación (dos placas guía
 // con la tarjeta de canto), cabezal perforador sobre la columna activa y cremallera de avance. o: { card, cardOpts, press, key,
 // hopper, stacker }. Devuelve { punchX, bedY, bedZ }.
 P.keypunch3 = (ctx, cam, t, o = {}) => { const gray = '#8b959a', gray2 = '#6f7a80', dark = '#2f373c', cream = '#d9d3c4', bedY = 1040, bedZ = -66, punchX = 70, pr = cl(o.press ?? 0);
  const list = [];
  list.push({ d: cam.depth([0, 380, 0]) + 2e4, f: () => { P.box3(ctx, cam, -480, 480, 720, 760, -340, 330, '#9aa3a6', {}); P.box3(ctx, cam, 200, 470, 0, 720, -320, 300, gray2, {}); for (const lx of [-470, -330]) P.box3(ctx, cam, lx, lx + 30, 0, 720, 230, 270, '#59646a', {}); P.box3(ctx, cam, -470, -300, 40, 70, -320, 270, '#59646a', {}); P.box3(ctx, cam, -470, -440, 0, 720, -320, -280, '#59646a', {}); P.box3(ctx, cam, -440, 200, 260, 720, -320, -296, '#5f6a70', {});
   for (const yy of [180, 380, 560]) { poly3(ctx, cam, [[215, yy, 301], [455, yy, 301], [455, yy + 6, 301], [215, yy + 6, 301]], '#535d63'); P.box3(ctx, cam, 310, 360, yy + 60, yy + 70, 300, 306, '#c9d0d3', {}); }
   // teclado: base inclinada y teclas con casquete claro
   const kb = (u, v, hgt) => [lerp(-240, 80, u), 760 + lerp(16, 52, v) + hgt, lerp(310, 130, v)]; poly3(ctx, cam, [kb(0, 0, 0), kb(1, 0, 0), kb(1, 1, 0), kb(0, 1, 0)], '#cfc9ba'); poly3(ctx, cam, [[-240, 760, 310], [80, 760, 310], kb(1, 0, 0), kb(0, 0, 0)], '#b9b3a4');
   for (let r = 0; r < 4; r++) for (let c = 0; c < 11; c++) { const on = o.key === r * 11 + c, kd = on ? 4.5 * pr : 0, u0 = (c + 0.12 + r * 0.25) / 11.8, u1 = u0 + 0.7 / 11.8, v0 = (r + 0.15) / 4.2, v1 = v0 + 0.7 / 4.2, top = 13 - kd, capc = on ? '#f0c95c' : (r === 3 && c > 8 ? '#5b88a6' : '#3e4448');
    poly3(ctx, cam, [kb(u0, v0, 0), kb(u1, v0, 0), kb(u1, v0, top), kb(u0, v0, top)], rmShade(capc, 0.7)); poly3(ctx, cam, [kb(u0, v0, top), kb(u1, v0, top), kb(u1, v1, top), kb(u0, v1, top)], capc); } } });
  list.push({ d: cam.depth([0, 900, -200]) + 1e4, f: () => { P.box3(ctx, cam, -440, 440, 760, 1030, -330, -80, gray, {}); poly3(ctx, cam, [[-440, 1030, -80], [440, 1030, -80], [440, 1090, -150], [-440, 1090, -150]], rmShade(gray, 1.05));
   P.box3(ctx, cam, -440, 440, 1030, 1090, -330, -150, gray, {}); const w0 = cam.pr([-60, 900, -79]), w1 = cam.pr([40, 900, -79]), r = Math.abs(w1[0] - w0[0]) / 2; if (w0[2] > 1 && r < 60) { ctx.fillStyle = '#20282c'; ctx.beginPath(); ctx.arc((w0[0] + w1[0]) / 2, w0[1], r, 0, TAU); ctx.fill(); ctx.strokeStyle = '#c9d0d3'; ctx.lineWidth = Math.max(1, r * 0.08); ctx.stroke(); }
   // canal de alimentación: placa trasera, riel inferior y cremallera de avance (dientes al paso de una columna)
   P.box3(ctx, cam, -410, 410, bedY - 34, bedY + 62, bedZ - 14, bedZ - 6, '#46525a', {}); P.box3(ctx, cam, -410, 410, bedY - 30, bedY - 22, bedZ - 6, bedZ + 10, '#9aa7ae', {});
   const rp = cam.pr([0, bedY - 40, bedZ + 12]); if (rp[2] > 1 && rp[2] < 1600) { P.box3(ctx, cam, -380, 380, bedY - 48, bedY - 38, bedZ - 4, bedZ + 12, '#7d878c', {}); for (let i = -170; i <= 170; i++) { const xx = i * 2.2098 + (o.rack || 0); if (Math.abs(xx) > 378) continue; const a = cam.pr([xx, bedY - 38, bedZ + 12]), b = cam.pr([xx, bedY - 35, bedZ + 12]); if (a[2] > 1) { ctx.strokeStyle = 'rgba(40,46,50,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } } } } });
  for (const [x0, x1, n] of [[220, 430, o.hopper ?? 300], [-430, -220, o.stacker ?? 120]]) list.push({ d: cam.depth([(x0 + x1) / 2, 1150, -240]), f: () => { P.box3(ctx, cam, x0, x1, 1090, 1100, -320, -160, dark, {}); P.box3(ctx, cam, x0, x0 + 8, 1100, 1230, -320, -160, '#59646a', {}); P.box3(ctx, cam, x1 - 8, x1, 1100, 1230, -320, -160, '#59646a', {}); P.box3(ctx, cam, x0, x1, 1100, 1230, -326, -318, '#59646a', {}); const dep = Math.min(150, n * 0.178 * 2.2); P.box3(ctx, cam, x0 + 10, x1 - 10, 1100, 1185, -318 + 2, -318 + 2 + dep, '#E4D7BA', {}); } });
  if (o.card) list.push({ d: cam.depth([0, bedY, bedZ]) - 40, f: () => P.punchCard3(ctx, cam, o.card, t, o.cardOpts || {}) });
  // cabezal perforador (fijo) con punzones (móviles) sobre la columna activa; matriz detrás; estación de lectura a la izquierda
  list.push({ d: cam.depth([punchX, bedY, bedZ + 20]) - 60, f: () => { P.box3(ctx, cam, punchX - 22, punchX + 22, bedY + 46, bedY + 96, bedZ - 30, bedZ + 34, '#4b555b', {}); P.box3(ctx, cam, punchX - 14, punchX + 14, bedY - 30, bedY + 46, bedZ + 14 + (1 - pr) * 16, bedZ + 30 + (1 - pr) * 16, '#7d878c', {}); P.box3(ctx, cam, punchX - 14, punchX + 14, bedY - 30, bedY + 46, bedZ - 22, bedZ - 2, '#5a646a', {}); P.box3(ctx, cam, -150, -90, bedY + 46, bedY + 84, bedZ - 30, bedZ + 22, '#4b555b', {}); } });
  ykDrawList(ctx, cam, list); return { punchX, bedY, bedZ };
 };
 // Mecanismo de perforación en primer plano (mm, la columna activa en x = 0, tarjeta de canto en z = 0 mirando a +z):
 // TECLA → varilla → barra de empuje → PUNZONES seleccionados atraviesan el cartón y entran en la MATRIZ → el RECORTE cae a la caja →
 // los punzones regresan → la CREMALLERA avanza la tarjeta una columna. Todas las piezas se mueven ligadas a la misma fase.
 // o: { card (cd ya desplazada), rows (filas del carácter), ph 0..1 (fase de la pulsación), label (carácter) }
 P.punchMech3 = (ctx, cam, t, o = {}) => { const F = CARDF.ibm, ph = cl(o.ph ?? 0), rows = o.rows || [], key = E.inOut(cl(ph / 0.16)) * (1 - E.inOut(cl((ph - 0.42) / 0.16))), stroke = E.inOut(cl((ph - 0.1) / 0.16)) * (1 - E.inOut(cl((ph - 0.32) / 0.16))), cardTopY = F.h / 2;
  const rowY = (r) => cardTopY - P.holeUV('ibm', 1, r)[1], steel = '#aeb8bd', dark = '#4b555b', list = [];
  list.push({ d: cam.depth([0, -70, -30]) + 500, f: () => { P.box3(ctx, cam, -120, 120, -cardTopY - 14, -cardTopY - 4, -16, 16, '#7f8d95', {}); P.box3(ctx, cam, -120, 120, -cardTopY - 4, -cardTopY + 3, -16, -2, '#9aa7ae', {}); P.box3(ctx, cam, -120, 120, -cardTopY - 4, -cardTopY + 3, 2, 16, '#9aa7ae', {});
   P.box3(ctx, cam, -24, 24, -cardTopY - 80, -cardTopY - 26, -40, -6, '#39434a', {}); poly3(ctx, cam, [[-24, -cardTopY - 26, -6], [24, -cardTopY - 26, -6], [24, -cardTopY - 26, -40], [-24, -cardTopY - 26, -40]], '#1d2428');
   const rk = (o.rack || 0); P.box3(ctx, cam, -110, 110, -cardTopY - 24, -cardTopY - 16, -30, -18, '#7d878c', {}); for (let i = -50; i <= 50; i++) { const xx = i * F.dc + rk; if (Math.abs(xx) > 108) continue; P.box3(ctx, cam, xx - 0.5, xx + 0.5, -cardTopY - 16, -cardTopY - 13.5, -28, -20, '#6a747a', {}); } P.box3(ctx, cam, -3, 3, -cardTopY - 14, -cardTopY - 6, -34, -26, '#c9a646', {}); } });
  // matriz (fija) detrás de la tarjeta, con sus agujeros
  list.push({ d: cam.depth([0, 0, -12]) + 200, f: () => { P.box3(ctx, cam, -9, 9, -cardTopY + 2, cardTopY - 2, -20, -1.2, dark, {}); for (const r of CROWS) { const yy = rowY(r); poly3(ctx, cam, [[-0.8, yy - 1.7, -1.1], [0.8, yy - 1.7, -1.1], [0.8, yy + 1.7, -1.1], [-0.8, yy + 1.7, -1.1]], '#0d1012'); } } });
  if (o.card) list.push({ d: cam.depth([0, 0, 0]) + 100, f: () => P.punchCard3(ctx, cam, o.card, t, Object.assign({ thk: 4 }, o.cardOpts || {})) });
  // recortes que caen (detrás de la tarjeta, por la matriz hacia la caja)
  const fall = cl((ph - 0.24) / 0.6); if (fall > 0 && fall < 1) for (const r of rows) { const yy = rowY(r) - 140 * fall * fall, zz = -8 - 10 * fall, rot = fall * 3 + r; list.push({ d: cam.depth([0, yy, zz]) + 150, f: () => { const c = Math.cos(rot), s = Math.sin(rot), pts = [[-0.7, -1.6], [0.7, -1.6], [0.7, 1.6], [-0.7, 1.6]].map(([a, b]) => [a * c, yy + b, zz + a * s]); poly3(ctx, cam, pts, '#E4D7BA', { stroke: 'rgba(90,70,45,0.6)', lw: 1 }); } }); }
  // cabezal: bloque guía (fijo), 12 punzones (seleccionados avanzan), barra de empuje (móvil) y varilla a la tecla
  list.push({ d: cam.depth([0, 0, 30]) - 50, f: () => { const zt = (sel) => (sel ? lerp(1.6, -6, stroke) : 1.6);
   for (const r of CROWS) { const sel = rows.includes(r), yy = rowY(r), z0 = zt(sel); P.box3(ctx, cam, -0.7, 0.7, yy - 1.58, yy + 1.58, z0, z0 + 26, sel ? '#e9eef0' : '#8f999e', {}); }
   P.box3(ctx, cam, -12, 12, -cardTopY + 2, cardTopY - 2, 12, 22, steel, { k: 0.9 }); for (const r of CROWS) { const yy = rowY(r); poly3(ctx, cam, [[-0.9, yy - 1.8, 22.1], [0.9, yy - 1.8, 22.1], [0.9, yy + 1.8, 22.1], [-0.9, yy + 1.8, 22.1]], '#2a3236'); }
   const bz = lerp(30, 22.4, stroke); P.box3(ctx, cam, -6, 6, -cardTopY - 4, cardTopY + 4, bz + 6, bz + 11, '#c9a646', {});
   const kz = 46, ky = -cardTopY - 58 - 7 * key; P.box3(ctx, cam, 52, 76, ky, ky + 12, kz - 12, kz + 12, '#f0c95c', {}); P.box3(ctx, cam, 60, 68, ky - 40, ky, kz - 4, kz + 4, '#7d878c', {});
   const a = cam.pr([64, ky - 40, kz]), b = cam.pr([20, -cardTopY - 40, bz + 30]), c2 = cam.pr([0, -cardTopY - 4, bz + 9]); if (a[2] > 1 && b[2] > 1 && c2[2] > 1) { ctx.strokeStyle = '#9aa5ab'; ctx.lineWidth = Math.max(3, 2600 / b[2]); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c2[0], c2[1]); ctx.stroke(); ctx.fillStyle = '#c9d0d3'; ctx.beginPath(); ctx.arc(b[0], b[1], Math.max(4, 3200 / b[2]), 0, TAU); ctx.fill(); }
   if (o.label) { const p = cam.pr([64, ky + 14, kz]); if (p[2] > 1) { ctx.fillStyle = '#1c2024'; ctx.font = `900 ${Math.max(18, Math.min(60, 12000 / p[2]))}px "IBM Plex Mono"`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; const q = cam.pr([64, ky + 12.1, kz]); ctx.fillText(o.label, q[0], q[1]); } } } });
  ykDrawList(ctx, cam, list); return { key, stroke };
 };
 // Operador/a sentado de espaldas (2D, en pantalla) tecleando: silla, espalda, brazos hacia el teclado; o.press 0..1 baja la mano derecha.
 P.operatorSeated = (ctx, x, y, h, t, o = {}) => { const u = h / 100, pr = cl(o.press ?? 0), hair = o.hair || '#3a2a20', top = o.top || '#5d7f9e'; ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = '#2b2622'; ctx.fillRect(-26 * u, -34 * u, 52 * u, 8 * u); ctx.fillRect(-4 * u, -26 * u, 8 * u, 26 * u); ctx.fillRect(-22 * u, -3 * u, 44 * u, 3 * u);
  ctx.fillStyle = '#3b3a40'; ctx.beginPath(); ctx.ellipse(0, -38 * u, 24 * u, 10 * u, 0, 0, TAU); ctx.fill();
  const g = ctx.createLinearGradient(-22 * u, 0, 22 * u, 0); g.addColorStop(0, H.rgba(H.mix(top, '#000', 0.25))); g.addColorStop(0.5, top); g.addColorStop(1, H.rgba(H.mix(top, '#000', 0.35))); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-20 * u, -40 * u); ctx.quadraticCurveTo(-24 * u, -62 * u, -18 * u, -78 * u); ctx.quadraticCurveTo(0, -86 * u, 18 * u, -78 * u); ctx.quadraticCurveTo(24 * u, -62 * u, 20 * u, -40 * u); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = H.rgba(H.mix(top, '#000', 0.2)); ctx.lineCap = 'round'; ctx.lineWidth = 9 * u; for (const sx of [-1, 1]) { const dy = sx > 0 ? pr * 5 : 0; ctx.beginPath(); ctx.moveTo(sx * 17 * u, -76 * u); ctx.quadraticCurveTo(sx * 30 * u, -60 * u, sx * 14 * u, (-54 + dy) * u); ctx.stroke(); ctx.fillStyle = '#d6a483'; ctx.beginPath(); ctx.arc(sx * 12 * u, (-54 + dy) * u, 4.5 * u, 0, TAU); ctx.fill(); }
  ctx.fillStyle = '#c89676'; ctx.fillRect(-5 * u, -88 * u, 10 * u, 6 * u); ctx.fillStyle = hair; ctx.beginPath(); ctx.ellipse(0, -96 * u, 11 * u, 12.5 * u, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(0, -86 * u, 9 * u, 5 * u, 0, 0, Math.PI); ctx.fill(); ctx.restore(); };
 // ---------------- HOLLERITH · CENSO DE 1890 (reconstrucción) ----------------
 // Según la Oficina del Censo de EE. UU.: lector manual de dos placas con bisagra; al cerrar, agujas con resorte atraviesan los agujeros
 // y llegan a pocillos de MERCURIO: el circuito cerrado mueve las agujas de los DIALES (40 en 1890) y suena un timbre; la mesa de
 // clasificación indica en qué cajón va la tarjeta. Sistema ELECTROMECÁNICO de tabulación, no una computadora electrónica.
 // Corte 2D v1.23.1: la tarjeta entra (cardIn), la palanca baja la placa superior; cada aguja vive en su tubo con su resorte; donde hay
 // agujero llega al mercurio, se energiza el ELECTROIMÁN, su armadura empuja el trinquete y la rueda dentada avanza UN diente el dial.
 // o: { cardIn 0..1, press 0..1, holes [bool], counts [valor], bell 0..1 }
 P.hollerithPress = (ctx, x, y, w, h, t, o = {}) => { const holes = o.holes || [true, false, true, false, false, true], N = holes.length, pr = E.inOut(cl(o.press ?? 0)), sp = (w - 80) / N, px0 = x + 40 + sp / 2, cardY = y + h * 0.36, plateB = cardY + 14, cupY = plateB + 74, travel = 56, cin = E.out(cl(o.cardIn ?? 1));
  ctx.save(); const bg = ctx.createLinearGradient(0, y, 0, y + h); bg.addColorStop(0, 'rgba(42,32,22,0.96)'); bg.addColorStop(1, 'rgba(24,18,12,0.96)'); ctx.fillStyle = bg; ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.fill(); ctx.strokeStyle = 'rgba(223,183,127,0.5)'; ctx.lineWidth = 2; ctx.stroke(); ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.clip();
  const topY = y + 120 + pr * travel; { const g = ctx.createLinearGradient(0, topY - 52, 0, topY); g.addColorStop(0, '#7c5a3a'); g.addColorStop(1, '#5a3f28'); ctx.fillStyle = g; ctx.fillRect(x + 24, topY - 52, w - 48, 52); ctx.fillStyle = '#9aa3a6'; ctx.fillRect(x + 24, topY, w - 48, 10); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x + 24, topY + 10, w - 48, 5); }
  const cx0 = lerp(x - w, x + 36, cin); ctx.fillStyle = '#D8C5A3'; ctx.fillRect(cx0, cardY - 4, w - 72, 8); ctx.fillStyle = 'rgba(90,70,45,0.5)'; ctx.fillRect(cx0, cardY + 2, w - 72, 2); for (let i = 0; i < N; i++) if (holes[i]) { const hx = px0 + sp * i - (x + 36 - cx0); ctx.fillStyle = 'rgba(30,22,15,1)'; ctx.fillRect(hx - 9, cardY - 5, 18, 10); }
  ctx.fillStyle = '#465258'; ctx.fillRect(x + 24, plateB, w - 48, 24); ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(x + 24, plateB, w - 48, 3); ctx.fillStyle = '#14181a'; for (let i = 0; i < N; i++) ctx.fillRect(px0 + sp * i - 7, plateB, 14, 24);
  let closed = 0; for (let i = 0; i < N; i++) { const px = px0 + sp * i, aligned = cin > 0.98, stopY = holes[i] && aligned ? cupY + 8 : cardY - 6, tipY = Math.min(stopY, topY + 52 + pr * (cupY - cardY + 30)), tubeTop = topY - 120;
   ctx.fillStyle = '#5f696e'; ctx.fillRect(px - 9, tubeTop, 18, topY - tubeTop); ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(px - 9, tubeTop, 4, topY - tubeTop);
   const comp = cl((topY + 52 + pr * (cupY - cardY + 30) - tipY) / 80); ctx.strokeStyle = '#d4dbde'; ctx.lineWidth = 2.5; ctx.beginPath(); for (let kk = 0; kk <= 12; kk++) { const yy = lerp(tubeTop + 6, lerp(topY - 4, topY - 60, comp), kk / 12); ctx.lineTo(px + (kk % 2 ? 6 : -6), yy); } ctx.stroke();
   ctx.fillStyle = '#e3e8ea'; ctx.fillRect(px - 3.5, topY + 10, 7, tipY - topY - 10); ctx.beginPath(); ctx.moveTo(px - 3.5, tipY); ctx.lineTo(px + 3.5, tipY); ctx.lineTo(px, tipY + 8); ctx.closePath(); ctx.fill();
   ctx.fillStyle = '#3a2c20'; ctx.fillRect(px - 21, cupY - 12, 42, 52); ctx.fillStyle = '#26292b'; ctx.fillRect(px - 17, cupY - 8, 34, 44); const g = ctx.createLinearGradient(0, cupY, 0, cupY + 30); g.addColorStop(0, '#f6f8f9'); g.addColorStop(0.4, '#aab4b9'); g.addColorStop(1, '#68737a'); ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(px, cupY + 6, 15, 5, 0, 0, TAU); ctx.fill(); ctx.fillRect(px - 15, cupY + 6, 30, 26);
   const on = holes[i] && aligned && tipY >= cupY + 4; if (on) { closed++; P.glow(ctx, px, cupY + 6, 54, '81,215,190', 0.85); }
   ctx.strokeStyle = on ? '#51D7BE' : 'rgba(150,170,160,0.28)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(px, cupY + 40); ctx.lineTo(px, y + h - 200); ctx.stroke();
   if (holes[i]) { const cyC = y + h - 175, dy = y + h - 82, r = 50, cnt = (o.counts || [])[i] ?? 0, arm = on ? 1 : 0;
    ctx.fillStyle = '#6b4a2a'; ctx.fillRect(px - 16, cyC - 18, 32, 36); ctx.strokeStyle = '#c98f4a'; ctx.lineWidth = 2; for (let kk = 0; kk < 7; kk++) { ctx.beginPath(); ctx.moveTo(px - 16, cyC - 15 + kk * 5); ctx.lineTo(px + 16, cyC - 13 + kk * 5); ctx.stroke(); }
    ctx.strokeStyle = '#9aa5ab'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(px + 18, cyC - 22); ctx.lineTo(px + 38, cyC - 22 + (arm ? 10 : 0)); ctx.lineTo(px + 44, dy - r - 4); ctx.stroke();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(px + 3, dy + 4, r + 4, 0, TAU); ctx.fill(); ctx.fillStyle = '#8a6a44'; ctx.beginPath(); ctx.arc(px, dy, r + 5, 0, TAU); ctx.fill();
    ctx.fillStyle = '#efe6d2'; ctx.beginPath(); ctx.arc(px, dy, r, 0, TAU); ctx.fill(); ctx.strokeStyle = '#3a2c20'; ctx.lineWidth = 2; for (let m = 0; m < 20; m++) { const a = (m / 20) * TAU; ctx.beginPath(); ctx.moveTo(px + Math.sin(a) * r * 0.8, dy - Math.cos(a) * r * 0.8); ctx.lineTo(px + Math.sin(a) * r * 0.95, dy - Math.cos(a) * r * 0.95); ctx.stroke(); }
    const ha = (cnt / 20) * TAU; ctx.strokeStyle = '#b23a2a'; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(px, dy); ctx.lineTo(px + Math.sin(ha) * r * 0.74, dy - Math.cos(ha) * r * 0.74); ctx.stroke(); ctx.fillStyle = '#3a2c20'; ctx.beginPath(); ctx.arc(px, dy, 5, 0, TAU); ctx.fill(); } }
  ctx.fillStyle = 'rgba(245,247,247,0.92)'; ctx.font = '800 32px Nunito'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText('AGUJAS CON RESORTE', x + 36, y + 36); ctx.fillText('MERCURIO', x + 36, cupY + 66); ctx.fillText('ELECTROIMÁN → DIAL', x + 36, y + h - 228);
  if (o.bell > 0) { ctx.globalAlpha *= cl(o.bell); ctx.fillStyle = '#DFB77F'; ctx.font = '900 32px Nunito'; ctx.textAlign = 'right'; ctx.fillText('¡TIMBRE!', x + w - 36, y + 36); }
  ctx.restore(); return { closed }; };
 // ---------------- MICROSD 3D (v1.23.1) ----------------
 // Tarjeta microSD a escala real (11 × 15 × 1 mm, escalón lateral, esquinas redondeadas): plástico negro mate con brillo suave, área
 // impresa sin marcas y 8 contactos dorados en la cara posterior. Marco como cardFrame: ex = ancho, ey = largo (hacia abajo desde el
 // borde de contactos), n = ey × ex (cara frontal). o: { L (luz) }. Devuelve { front, s (px por mm) }.
 const SDO = (() => { const p = [[0.5, 0], [9.8, 0], [11, 1.2], [11, 5.2], [10.2, 5.9], [10.2, 7.4], [11, 8], [11, 14.5]]; for (let i = 0; i <= 3; i++) { const a = (i / 3) * (Math.PI / 2); p.push([10.5 + 0.5 * Math.cos(a), 14.5 + 0.5 * Math.sin(a)]); } for (let i = 0; i <= 3; i++) { const a = Math.PI / 2 + (i / 3) * (Math.PI / 2); p.push([0.5 + 0.5 * Math.cos(a), 14.5 + 0.5 * Math.sin(a)]); } p.push([0, 0.5]); return p; })();
 P.sdFrame = (c, o = {}) => { const ex = P.cardRot([1, 0, 0], o), ey = P.cardRot([0, -1, 0], o); return { ex, ey, o: [0, 1, 2].map((i) => c[i] - ex[i] * 5.5 - ey[i] * 7.5) }; };
 P.microSD3 = (ctx, cam, sd, t, o = {}) => { const n = cv3.nrm(cv3.crs(sd.ey, sd.ex)), T3 = 1.0, pt = (u, v, d = 0) => [0, 1, 2].map((i) => sd.o[i] + sd.ex[i] * u + sd.ey[i] * v + n[i] * d), cen = pt(5.5, 7.5, -T3 / 2), front = faceVis(cam, n, pt(5.5, 7.5, 0)), L = cv3.nrm(o.L || [-0.4, 0.6, 0.7]);
  const c0 = cam.pr(cen), c1 = cam.pr(pt(6.5, 7.5, -T3 / 2)); if (c0[2] < 1) return null; const s = Math.hypot(c1[0] - c0[0], c1[1] - c0[1]);
  const m = SDO.length; for (let i = 0; i < m; i++) { const a = SDO[i], b = SDO[(i + 1) % m], e = [0, 1, 2].map((k) => sd.ex[k] * (b[0] - a[0]) + sd.ey[k] * (b[1] - a[1])), nn = cv3.nrm(cv3.crs(e, n)), mid = pt((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, -T3 / 2); if (!faceVis(cam, nn, mid)) continue; const lit = 0.35 + 0.5 * Math.max(0, cv3.dot(nn, L)); poly3(ctx, cam, [pt(a[0], a[1], 0), pt(b[0], b[1], 0), pt(b[0], b[1], -T3), pt(a[0], a[1], -T3)], `rgb(${30 * lit + 18 | 0},${32 * lit + 20 | 0},${36 * lit + 24 | 0})`); }
  const d = front ? 0 : -T3, lit = Math.abs(cv3.dot(n, L)), P2 = poly3(ctx, cam, SDO.map(([u, v]) => pt(u, v, d)), `rgb(${22 + 26 * lit | 0},${24 + 28 * lit | 0},${28 + 32 * lit | 0})`);
  if (P2) { ctx.save(); ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.clip(); const a = cam.pr(pt(0, 0, d)), b = cam.pr(pt(11, 15, d)), g = ctx.createLinearGradient(a[0], a[1], b[0], b[1]); g.addColorStop(0, `rgba(255,255,255,${0.1 + 0.12 * lit})`); g.addColorStop(0.45, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(255,255,255,0.05)'); ctx.fillStyle = g; ctx.fillRect(-50, -50, W + 100, HH + 100); ctx.restore();
   if (front) { poly3(ctx, cam, [pt(0.9, 3.4, 0.01), pt(9.4, 3.4, 0.01), pt(9.4, 14.1, 0.01), pt(0.9, 14.1, 0.01)], 'rgba(46,52,60,0.9)'); for (let k = 0; k < 3; k++) poly3(ctx, cam, [pt(1.6, 9 + k * 1.4, 0.02), pt(8, 9 + k * 1.4, 0.02), pt(8, 9.25 + k * 1.4, 0.02), pt(1.6, 9.25 + k * 1.4, 0.02)], 'rgba(140,150,160,0.5)'); }
   else { for (let k = 0; k < 8; k++) { const u0 = 0.9 + k * 1.15; poly3(ctx, cam, [pt(u0, 0.7, d - 0.01), pt(u0 + 0.8, 0.7, d - 0.01), pt(u0 + 0.8, 4.1, d - 0.01), pt(u0, 4.1, d - 0.01)], k % 2 ? '#d6b354' : '#c9a646'); } } }
  ctx.strokeStyle = 'rgba(200,210,220,0.25)'; ctx.lineWidth = 1; if (P2) { ctx.beginPath(); P2.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.stroke(); }
  return { front, s };
 };
 // Oficina de 1890 (mm): suelo de tablas, pared con zócalo de madera y papel pintado, ventanales con luz cálida y lámparas.
 P.office1890 = (ctx, cam, t, o = {}) => { const bz = o.back ?? -1400; ctx.save(); ctx.fillStyle = '#2a2018'; ctx.fillRect(0, 0, W, HH);
  poly3(ctx, cam, [[-4000, 0, bz], [4000, 0, bz], [4000, 3800, bz], [-4000, 3800, bz]], '#7d6a4f'); poly3(ctx, cam, [[-4000, 0, bz + 1], [4000, 0, bz + 1], [4000, 1000, bz + 1], [-4000, 1000, bz + 1]], '#5a3d27');
  for (let x = -3800; x <= 3800; x += 250) { const p = cam.pr([x, 1000, bz + 2]), q = cam.pr([x, 3800, bz + 2]); if (p[2] > 1) { ctx.strokeStyle = 'rgba(60,45,30,0.25)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); } }
  for (const wx of [-2600, -900, 800, 2500]) { poly3(ctx, cam, [[wx - 450, 1100, bz + 3], [wx + 450, 1100, bz + 3], [wx + 450, 3300, bz + 3], [wx - 450, 3300, bz + 3]], '#e9d3a3'); poly3(ctx, cam, [[wx - 30, 1100, bz + 4], [wx + 30, 1100, bz + 4], [wx + 30, 3300, bz + 4], [wx - 30, 3300, bz + 4]], '#5a3d27'); poly3(ctx, cam, [[wx - 450, 2150, bz + 4], [wx + 450, 2150, bz + 4], [wx + 450, 2200, bz + 4], [wx - 450, 2200, bz + 4]], '#5a3d27'); }
  for (let z = bz; z < 4000; z += 180) poly3(ctx, cam, [[-4000, 0, z], [4000, 0, z], [4000, 0, z + 180], [-4000, 0, z + 180]], ((z / 180) | 0) % 2 ? '#6e4f33' : '#76563a');
  const L = cam.pr([0, 3000, bz + 200]); if (L[2] > 1) { const g = ctx.createRadialGradient(L[0], L[1], 20, L[0], L[1], 1300); g.addColorStop(0, `rgba(223,183,127,${0.28 * (o.warm ?? 1)})`); g.addColorStop(1, 'rgba(223,183,127,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); }
  ctx.restore(); };
 // Tabuladora de Hollerith (1890, mm): mesa de madera con la prensa lectora al frente, armario vertical con 40 diales (4 × 10) y,
 // a la derecha, la mesa de clasificación con cajones de tapa. o: { press 0..1, counts (40 valores), lid (cajón abierto), lidA 0..1 }
 P.tabulator1890 = (ctx, cam, t, o = {}) => { const wood = '#6B4D35', wood2 = '#7c5a3a', list = [];
  list.push({ d: cam.depth([0, 1200, -240]), f: () => { P.box3(ctx, cam, -700, 700, 0, 760, -300, 260, wood, {}); P.box3(ctx, cam, -720, 720, 760, 790, -320, 280, wood2, {}); P.box3(ctx, cam, -680, 680, 790, 1750, -300, -200, wood, {}); P.box3(ctx, cam, -700, 700, 1750, 1800, -320, -190, wood2, {});
   for (let r = 0; r < 4; r++) for (let c = 0; c < 10; c++) { const dx = -560 + c * 124, dy = 1640 - r * 220, p = cam.pr([dx, dy, -199]), q = cam.pr([dx + 48, dy, -199]); if (p[2] < 1) continue; const rr = Math.abs(q[0] - p[0]); ctx.fillStyle = '#efe6d2'; ctx.beginPath(); ctx.arc(p[0], p[1], rr, 0, TAU); ctx.fill(); ctx.strokeStyle = '#2b2018'; ctx.lineWidth = Math.max(1, rr * 0.08); ctx.stroke(); const a = (((o.counts || [])[r * 10 + c] ?? (r * 3 + c * 7) % 20) / 20) * TAU; ctx.strokeStyle = '#b23a2a'; ctx.lineWidth = Math.max(1, rr * 0.1); ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(p[0] + Math.sin(a) * rr * 0.75, p[1] - Math.cos(a) * rr * 0.75); ctx.stroke(); } } });
  list.push({ d: cam.depth([200, 820, 150]) - 50, f: () => { P.box3(ctx, cam, 120, 460, 790, 830, 40, 250, '#2f2a26', {}); const a = (1 - cl(o.press ?? 0)) * 0.7, hy = 830, pts = [[120, hy, 40], [460, hy, 40], [460, hy + Math.sin(a) * 210, 40 + Math.cos(a) * 210], [120, hy + Math.sin(a) * 210, 40 + Math.cos(a) * 210]]; poly3(ctx, cam, pts, '#4a423b'); const tip = [460, hy + Math.sin(a) * 210 + 40, 40 + Math.cos(a) * 210 + 30], A2 = cam.pr([460, hy + Math.sin(a) * 210, 40 + Math.cos(a) * 210]), B2 = cam.pr(tip); ctx.strokeStyle = '#899397'; ctx.lineWidth = Math.max(2, 9000 / Math.max(1, A2[2])); ctx.beginPath(); ctx.moveTo(A2[0], A2[1]); ctx.lineTo(B2[0], B2[1]); ctx.stroke(); } });
  list.push({ d: cam.depth([1050, 600, 0]), f: () => { P.box3(ctx, cam, 820, 1360, 0, 980, -260, 220, wood2, {}); for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) { const x0 = 840 + c * 128, y0 = 80 + r * 215; poly3(ctx, cam, [[x0, y0, 221], [x0 + 118, y0, 221], [x0 + 118, y0 + 200, 221], [x0, y0 + 200, 221]], '#5f4430'); }
   for (let c = 0; c < 4; c++) for (let r = 0; r < 3; r++) { const lx = 840 + c * 128, lz = -240 + r * 150, open = o.lid === c * 3 + r ? cl(o.lidA ?? 0) : 0, an = open * 1.1, pts = [[lx, 980, lz], [lx + 118, 980, lz], [lx + 118, 980 + Math.sin(an) * 140, lz + Math.cos(an) * 140], [lx, 980 + Math.sin(an) * 140, lz + Math.cos(an) * 140]]; poly3(ctx, cam, pts, open > 0 ? '#c79a52' : '#8a6544', { stroke: '#3b281a', lw: 1.5 }); } } });
  ykDrawList(ctx, cam, list); };
 // ---------------- SALA DE COMPUTACIÓN ELECTRÓNICA (mediados del s. XX, reconstrucción genérica, mm) ----------------
 // Lector de tarjetas a la izquierda conectado por un canal de cables a los armarios del computador y a una consola de operación.
 // o: { pulse 0..1 (impulsos de datos por el cable), lights (actividad de la consola), reader (opciones de cardReader3) }
 P.computerRoom60 = (ctx, cam, t, o = {}) => { const bz = -1800; ctx.save(); ctx.fillStyle = '#151C21'; ctx.fillRect(0, 0, W, HH);
  poly3(ctx, cam, [[-5000, 0, bz], [5000, 0, bz], [5000, 3000, bz], [-5000, 3000, bz]], '#5f6a6e'); poly3(ctx, cam, [[-5000, 0, bz + 1], [5000, 0, bz + 1], [5000, 140, bz + 1], [-5000, 140, bz + 1]], '#3b4448');
  for (let x = -5000; x < 5000; x += 600) for (let z = bz; z < 4000; z += 600) poly3(ctx, cam, [[x, 0, z], [x + 600, 0, z], [x + 600, 0, z + 600], [x, 0, z + 600]], ((x / 600 + z / 600) & 1) ? '#c9c6bc' : '#bdb9ae');
  const list = [];
  for (let i = 0; i < 4; i++) { const x0 = -200 + i * 760; list.push({ d: cam.depth([x0 + 350, 900, -1500]), f: () => { P.box3(ctx, cam, x0, x0 + 700, 0, 1800, -1700, -1300, '#8e9aa0', {}); P.box3(ctx, cam, x0 + 40, x0 + 660, 120, 1680, -1301, -1298, '#7d898f', {}); for (let r = 0; r < 6; r++) poly3(ctx, cam, [[x0 + 60, 300 + r * 220, -1297], [x0 + 640, 300 + r * 220, -1297], [x0 + 640, 304 + r * 220, -1297], [x0 + 60, 304 + r * 220, -1297]], '#5a656b'); } }); }
  list.push({ d: cam.depth([1200, 600, -400]), f: () => { P.box3(ctx, cam, 700, 1700, 0, 760, -600, -200, '#9aa3a6', {}); poly3(ctx, cam, [[700, 760, -200], [1700, 760, -200], [1700, 1150, -450], [700, 1150, -450]], '#6d797f'); const R = H.rng(7); for (let r = 0; r < 4; r++) for (let c = 0; c < 16; c++) { const u = (c + 0.5) / 16, v = (r + 0.5) / 4, p = cam.pr([lerp(740, 1660, u), lerp(800, 1110, v), lerp(-225, -425, v)]); if (p[2] < 1) continue; const on = R() < 0.3 + 0.4 * Math.sin(t * 3 + r * 1.7 + c) * (o.lights ?? 0); ctx.fillStyle = on ? '#FFD447' : '#3a3324'; ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(1.5, 9000 / p[2]), 0, TAU); ctx.fill(); } } });
  list.push({ d: cam.depth([-1400, 600, 0]), f: () => { ctx.save(); P.cardReader3(ctx, { ...cam, pr: (p) => cam.pr([p[0] * 1 - 1400, p[1], p[2] * 1 - 100]), clip: (pts, n) => cam.clip(pts.map((q) => [q[0] - 1400, q[1], q[2] - 100]), n), depth: (p) => cam.depth([p[0] - 1400, p[1], p[2] - 100]), pos: [cam.pos[0] + 1400, cam.pos[1], cam.pos[2] + 100] }, t, Object.assign({ hopper: 400, stacker: 150, cover: 1 }, o.reader || {})); ctx.restore(); } });
  ykDrawList(ctx, cam, list);
  const pts = [[-1400, 30, -440], [-1400, 30, -1000], [100, 30, -1000], [100, 30, -1300]].map((q) => cam.pr(q)); if (pts.every((p) => p[2] > 1)) { ctx.strokeStyle = '#263238'; ctx.lineWidth = Math.max(4, 120000 / pts[1][2]); ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke();
   if (o.pulse != null) { const seg = [], tot = []; let L = 0; for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(l); L += l; } for (let j = 0; j < 4; j++) { let d = (((o.pulse + j / 4) % 1) + 1) % 1 * L; for (let i = 1; i < pts.length; i++) { if (d <= seg[i - 1]) { const px = lerp(pts[i - 1][0], pts[i][0], d / seg[i - 1]), py = lerp(pts[i - 1][1], pts[i][1], d / seg[i - 1]); P.glow(ctx, px, py, 40, '81,215,190', 0.9); ctx.fillStyle = '#F5F7F7'; ctx.beginPath(); ctx.arc(px, py, 6, 0, TAU); ctx.fill(); break; } d -= seg[i - 1]; } } void tot; } }
  ctx.restore(); };
 // ---------------- v1.24 · TELÉGRAFO ÓPTICO CHAPPE (Francia, 1792 →) ----------------
 // Unidades 3D en METROS. Modelo maestro ÚNICO de estación (Musée des Arts et Métiers: «un mât pourvu d'un régulateur pivotant et de
 // deux indicateurs mobiles»; cada indicador puede tomar 8 posiciones, 7 usadas → 196 señales de un vocabulario). Torre de piedra con
 // tejado, MÁSTIL, REGULADOR (barra larga con láminas) que gira sobre su eje en lo alto del mástil, dos INDICADORES articulados en sus
 // extremos con varilla y CONTRAPESO, poleas en cada eje y CUERDAS que bajan por el mástil hasta el manipulador del interior.
 // Configuración cfg = { reg, li, ri } en grados: reg = giro del regulador (0 horizontal, 90 vertical); li / ri = giro de cada indicador
 // respecto a la prolongación del regulador (0 = en línea, 90 = perpendicular «hacia arriba» con el regulador horizontal). Pasos de 45°.
 const CHP = { tw: 4.2, th: 7.2, roof: 1.3, mast: 5.6, regL: 4.6, regW: 0.36, indL: 2.0, indW: 0.3, cw: 0.8 };
 P.CHP = CHP;
 P.chappeLerp = (a, b, u) => ({ reg: lerp(a.reg, b.reg, u), li: lerp(a.li, b.li, u), ri: lerp(a.ri, b.ri, u) });
 // keys = [[t, cfg], …]: cada cambio dura ch s (ritmo humano) y la posición se MANTIENE hasta el siguiente
 P.chappeAt = (keys, t, ch = 1.0) => { let c = keys[0][1]; for (let i = 1; i < keys.length; i++) { const [tk, ck] = keys[i]; if (t < tk) break; c = P.chappeLerp(c, ck, E.inOut(cl((t - tk) / ch))); } return c; };
 const chR = (x, y, a) => { const c = Math.cos(a), s = Math.sin(a); return [x * c - y * s, x * s + y * c]; };
 // geometría en el plano del mecanismo (p a la derecha, q hacia arriba; pivote del regulador en 0,0). sc = escala (1 = tamaño real)
 P.chappeGeom = (cfg, sc = 1) => { const a = (cfg.reg * Math.PI) / 180, d = [Math.cos(a), Math.sin(a)], L = CHP.regL * sc / 2, e1 = [-d[0] * L, -d[1] * L], e2 = [d[0] * L, d[1] * L];
  const o1 = chR(-d[0], -d[1], (-cfg.li * Math.PI) / 180), o2 = chR(d[0], d[1], (cfg.ri * Math.PI) / 180), il = CHP.indL * sc, cw = CHP.cw * sc;
  return { d, e1, e2, i1: [e1[0] + o1[0] * il, e1[1] + o1[1] * il], i2: [e2[0] + o2[0] * il, e2[1] + o2[1] * il], c1: [e1[0] - o1[0] * cw, e1[1] - o1[1] * cw], c2: [e2[0] - o2[0] * cw, e2[1] - o2[1] * cw], o1, o2 }; };
 // dibuja el mecanismo en 3D. base = pivote del regulador (mundo), yaw = orientación del plano (normal = [sin yaw, 0, cos yaw]); sc escala
 P.chappeMech = (ctx, cam, base, cfg, o = {}) => { const yaw = o.yaw ?? Math.PI / 2, sc = o.sc ?? 1, n = [Math.sin(yaw), 0, Math.cos(yaw)], rv = [Math.cos(yaw), 0, -Math.sin(yaw)], W3 = (p, q, dz = 0) => [base[0] + rv[0] * p + n[0] * dz, base[1] + q, base[2] + rv[2] * p + n[2] * dz];
  const g = P.chappeGeom(cfg, sc), front = faceVis(cam, n, base), dark = o.col || '#303738', slat = 'rgba(190,190,180,0.55)', thick = 0.07 * sc;
  const bar = (a, b, wd, col) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1, nx = (-dy / l) * wd / 2, ny = (dx / l) * wd / 2, q4 = (dz) => [W3(a[0] + nx, a[1] + ny, dz), W3(b[0] + nx, b[1] + ny, dz), W3(b[0] - nx, b[1] - ny, dz), W3(a[0] - nx, a[1] - ny, dz)];
   poly3(ctx, cam, q4(front ? -thick : thick), rmShade(col, 0.55)); poly3(ctx, cam, q4(0), col, { stroke: 'rgba(0,0,0,0.35)', lw: 1 });
   const ns = Math.max(3, Math.floor(l / (0.22 * sc))); for (let k = 1; k < ns; k++) { const u = k / ns, p = cam.pr(W3(a[0] + dx * u + nx * 0.8, a[1] + dy * u + ny * 0.8, 0.01)), q = cam.pr(W3(a[0] + dx * u - nx * 0.8, a[1] + dy * u - ny * 0.8, 0.01)); if (p[2] > 0.5 && q[2] > 0.5 && Math.hypot(p[0] - q[0], p[1] - q[1]) > 3) { ctx.strokeStyle = slat; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); } } };
  const rod = (a, b, wpx) => { const p = cam.pr(W3(a[0], a[1], 0.02)), q = cam.pr(W3(b[0], b[1], 0.02)); if (p[2] < 0.5 || q[2] < 0.5) return; ctx.strokeStyle = '#454E52'; ctx.lineWidth = Math.max(1, wpx / p[2]); ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); };
  const disc = (c, r, col) => { const p = cam.pr(W3(c[0], c[1], front ? 0.05 : -0.05)), q = cam.pr(W3(c[0] + r, c[1], 0.05)); if (p[2] < 0.5) return; const rr = Math.max(1.2, Math.hypot(q[0] - p[0], q[1] - p[1])); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p[0], p[1], rr, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 1; ctx.stroke(); };
  // cuerdas (bajan por el mástil): del eje de cada indicador al eje central y hacia abajo
  if (o.ropes !== false) { const rp = (pts) => { const P2 = pts.map(([p, q]) => cam.pr(W3(p, q, front ? 0.12 : -0.12))); if (P2.some((x) => x[2] < 0.5)) return; ctx.strokeStyle = o.ropeHi ? '#FFD447' : '#B49D73'; ctx.lineWidth = Math.max(1, (o.ropeHi ? 2.2 : 1.4) * (1 + 40 / P2[0][2])); ctx.beginPath(); P2.forEach((x, i) => (i ? ctx.lineTo(x[0], x[1]) : ctx.moveTo(x[0], x[1]))); ctx.stroke(); };
   const off = 0.07 * sc; rp([[g.e1[0], g.e1[1]], [0, -off], [-off, -CHP.mast * sc]]); rp([[g.e2[0], g.e2[1]], [0, off], [off, -CHP.mast * sc]]); }
  rod(g.e1, g.c1, 260 * sc); rod(g.e2, g.c2, 260 * sc); disc(g.c1, 0.16 * sc, '#454E52'); disc(g.c2, 0.16 * sc, '#454E52');
  bar(g.e1, g.e2, CHP.regW * sc, dark); bar(g.e1, g.i1, CHP.indW * sc, o.colL || dark); bar(g.e2, g.i2, CHP.indW * sc, o.colR || dark);
  disc([0, 0], 0.2 * sc, '#806044'); disc(g.e1, 0.13 * sc, '#806044'); disc(g.e2, 0.13 * sc, '#806044');
  return { g, W3, front };
 };
 // estación completa: torre de piedra (anclada al terreno), tejado, puerta, ventanas hacia las estaciones vecinas, telescopio, mástil con
 // peldaños y el mecanismo. pos = centro de la base sobre el terreno. o: { yaw, cfg, scope (dirección ±1 del telescopio), ropeHi, glow }
 P.chappeTower = (ctx, cam, pos, t, o = {}) => { const [x, y, z] = pos, hw = CHP.tw / 2, top = y + CHP.th, cfg = o.cfg || { reg: 0, li: 90, ri: 90 }, stone = '#B1A28D', list = [];
  const pc = cam.pr([x, y + 8, z]); if (pc[2] < 1) return null; if (pc[2] > 60000) return null;
  list.push({ d: cam.depth([x, y + 4, z]) + 6, f: () => { const pl = []; for (let i = 0; i < 16; i++) { const a = (i / 16) * TAU; pl.push([x + Math.cos(a) * 9, y + 0.15, z + Math.sin(a) * 9]); } poly3(ctx, cam, pl, '#8a7a5c'); poly3(ctx, cam, [[x - hw + 1, y + 0.2, z - hw + 2], [x + hw + 5, y + 0.2, z - hw + 3], [x + hw + 6, y + 0.2, z + hw + 4], [x - hw + 1, y + 0.2, z + hw + 2]], 'rgba(0,0,0,0.3)'); } });
  list.push({ d: cam.depth([x, y + 4, z]) + 2, f: () => { P.box3(ctx, cam, x - hw - 0.3, x + hw + 0.3, y - 1.5, y + 0.4, z - hw - 0.3, z + hw + 0.3, '#716B61', {}); P.box3(ctx, cam, x - hw, x + hw, y + 0.4, top, z - hw, z + hw, stone, {});
   for (const sx of [-1, 1]) { const wx = x + sx * (hw + 0.01); poly3(ctx, cam, [[wx, top - 3.2, z - 0.55], [wx, top - 3.2, z + 0.55], [wx, top - 1.6, z + 0.55], [wx, top - 1.6, z - 0.55]], '#2a2622'); }
   poly3(ctx, cam, [[x - 0.6, y + 0.4, z + hw + 0.01], [x + 0.6, y + 0.4, z + hw + 0.01], [x + 0.6, y + 2.6, z + hw + 0.01], [x - 0.6, y + 2.6, z + hw + 0.01]], '#5a4632');
   const r0 = top, r1 = top + CHP.roof, cs = [[x - hw - 0.25, z - hw - 0.25], [x + hw + 0.25, z - hw - 0.25], [x + hw + 0.25, z + hw + 0.25], [x - hw - 0.25, z + hw + 0.25]];
   const tri = []; for (let i = 0; i < 4; i++) { const a = cs[i], b = cs[(i + 1) % 4], nn = [((a[1] + b[1]) / 2 - z) === 0 ? Math.sign((a[0] + b[0]) / 2 - x) : 0, 0.6, ((a[0] + b[0]) / 2 - x) === 0 ? Math.sign((a[1] + b[1]) / 2 - z) : 0], c = [(a[0] + b[0]) / 2, r0 + 0.3, (a[1] + b[1]) / 2]; if (!faceVis(cam, nn, c)) continue; tri.push({ d: cam.depth(c), f: () => poly3(ctx, cam, [[a[0], r0, a[1]], [b[0], r0, b[1]], [x, r1, z]], rmShade('#6a6560', 0.75 + 0.3 * (nn[0] * -0.5 + nn[2] * 0.6 + 0.4))) }); }
   tri.sort((p, q) => q.d - p.d).forEach((p) => p.f());
   if (o.scope) { const sx = o.scope, wx = x + sx * (hw + 0.01), a = cam.pr([wx - sx * 0.2, top - 2.3, z]), b = cam.pr([wx + sx * 0.9, top - 2.15, z]); if (a[2] > 0.5) { ctx.strokeStyle = '#806044'; ctx.lineWidth = Math.max(1.5, 160 / a[2]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); ctx.fillStyle = '#c9d6dc'; ctx.beginPath(); ctx.arc(b[0], b[1], Math.max(1, 70 / a[2]), 0, TAU); ctx.fill(); } } } });
  const mb = top + CHP.roof * 0.6, pv = top + CHP.mast; let res = null;
  const mast = () => { P.box3(ctx, cam, x - 0.14, x + 0.14, mb, pv + 0.5, z - 0.14, z + 0.14, '#6b5038', {}); for (let k = 0; k < 9; k++) { const yy = mb + 0.4 + k * 0.55, a = cam.pr([x, yy, z - 0.28]), b = cam.pr([x, yy, z + 0.28]); if (a[2] > 0.5 && a[2] < 900) { ctx.strokeStyle = '#4a3828'; ctx.lineWidth = Math.max(1, 40 / a[2]); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } } };
  const yaw = o.yaw ?? Math.PI / 2, n = [Math.sin(yaw), 0, Math.cos(yaw)], base = [x + n[0] * 0.3, pv, z + n[2] * 0.3], camFront = faceVis(cam, n, base);
  const mech = () => { res = P.chappeMech(ctx, cam, base, cfg, { yaw, ropeHi: o.ropeHi }); if (o.glow) { const p = cam.pr(base); if (p[2] > 1) P.glow(ctx, p[0], p[1], Math.max(20, 9000 / p[2]), '255,212,71', o.glow * 0.6); } };
  list.push({ d: cam.depth([x, pv, z]) - 1, f: () => { if (camFront) { mast(); mech(); } else { mech(); mast(); } } });
  ykDrawList(ctx, cam, list); return { top: [x, pv, z], base, mech: res };
 };
 // ---------------- PAISAJE DEL NORTE DE FRANCIA (s. XVIII) ----------------
 // Relieve suave de colinas con las estaciones en las cimas; campos en mosaico, bosques, caminos y aldeas; perspectiva atmosférica.
 // o: { towers: [[x, z]…] (cimas), fog 0..1, night 0..1, storm 0..1, dusk 0..1, rain 0..1, near (detalle local alrededor de [x, z]) }
 P.chappeHeight = (x, z, towers = []) => { let h = 95 * Math.sin(x / 2600 + 0.6) * Math.cos(z / 2100) + 48 * Math.sin(x / 1100 + 1.3) * Math.sin(z / 1500 + 0.4) + 14 * Math.sin((x + z) / 520) + 60; for (const [tx, tz] of towers) { const d2 = (x - tx) ** 2 + (z - tz) ** 2; h += 150 * Math.exp(-d2 / (2 * 1500 * 1500)); } return h; };
 const cA = (h) => H.hex(h), cM = (A, B, u) => A.map((v, i) => v + (B[i] - v) * cl(u)), cS = (A) => `rgb(${A[0] | 0},${A[1] | 0},${A[2] | 0})`, cW = (a, b, c, d, o) => cM(cM(cM(cA(a), cA(b), o.dusk || 0), cA(c), o.storm || 0), cA(d), o.night || 0);
 P.chappeSky = (ctx, o = {}) => { const top = cS(cW('#6f9fbd', '#C89B73', '#586E7D', '#0b1424', o)), hor = cS(cW('#cfe0e6', '#e9c79f', '#8d9ba3', '#1d2a3a', o)), g = ctx.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, top); g.addColorStop(0.62, hor); g.addColorStop(1, hor); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH);
  if ((o.night || 0) < 0.8) { const R = H.rng(12); ctx.save(); ctx.globalAlpha = (1 - (o.night || 0)) * (0.55 + 0.3 * (o.storm || 0)); for (let i = 0; i < 9; i++) { const cx = ((R() * 1.4 - 0.2) * W + (o.drift || 0) * (20 + R() * 30)) % (W + 400) - 200, cy = 120 + R() * 700, w2 = 160 + R() * 260; ctx.fillStyle = cS(cW('#f4f6f6', '#f1d9bd', '#7d8a93', '#1d2a3a', o)); for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.ellipse(cx + (k - 2) * w2 * 0.28, cy - Math.sin(k * 1.3) * 18, w2 * 0.32, w2 * 0.16, 0, 0, TAU); ctx.fill(); } } ctx.restore(); }
  if ((o.night || 0) > 0.3) { const R = H.rng(77); ctx.save(); ctx.globalAlpha = cl((o.night - 0.3) / 0.5) * (1 - (o.fog || 0)); ctx.fillStyle = '#e8eef8'; for (let i = 0; i < 160; i++) ctx.fillRect(R() * W, R() * HH * 0.6, 2, 2); ctx.restore(); } };
 P.chappeLand = (ctx, cam, t, o = {}) => { const tw = o.towers || [], fog = o.fog || 0, night = o.night || 0, storm = o.storm || 0, hz = (x, z) => P.chappeHeight(x, z, tw);
  const hazeC = cW('#c3d3d8', '#d9b892', '#9aa6ad', '#1b2633', o), fogC = cM(cA('#c9cfd2'), cA('#2a3340'), night), Lg = [-0.74, 0.5, 0.45];
  const shade = (base, nn, d) => { const [r, g, b] = H.hex(base), k = (0.38 + 0.85 * Math.max(0, nn[0] * Lg[0] + nn[1] * Lg[1] + nn[2] * Lg[2])) * (1 - 0.72 * night) * (1 - 0.25 * storm), hzk = cl(1 - Math.exp(-d / (26000 - 18000 * storm))), fk = cl(1 - Math.exp(-d * (fog * fog) / 900)); let c = [r * k, g * k, b * k]; c = c.map((v, i) => lerp(v, hazeC[i], hzk * 0.85)); c = c.map((v, i) => lerp(v, fogC[i], fk)); return `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`; };
  const quads = [], addGrid = (x0, x1, z0, z1, cs, seed, skip) => { const R = H.rng(seed); for (let x = x0; x < x1; x += cs) for (let z = z0; z < z1; z += cs) { const v = R(); if (skip && skip(x + cs / 2, z + cs / 2)) continue; const p = [[x, hz(x, z), z], [x + cs, hz(x + cs, z), z], [x + cs, hz(x + cs, z + cs), z + cs], [x, hz(x, z + cs), z + cs]], c = [x + cs / 2, (p[0][1] + p[2][1]) / 2, z + cs / 2], dd = cam.depth(c); if (dd < -cs * 1.5) continue; const ux = [cs, p[1][1] - p[0][1], 0], uz = [0, p[3][1] - p[0][1], cs], nn = [uz[1] * ux[2] - uz[2] * ux[1], uz[2] * ux[0] - uz[0] * ux[2], uz[0] * ux[1] - uz[1] * ux[0]], ln = Math.hypot(...nn) || 1; const fv = cl(0.5 + 0.25 * Math.sin(x / 730 + Math.sin(z / 910) * 2) + 0.2 * Math.sin(z / 560 + x / 1700)), A0 = cA('#5d774a'), A1 = cA('#7f8c5a'), A2 = cA('#978e63'), cc = fv < 0.6 ? cM(A0, A1, fv / 0.6) : cM(A1, A2, (fv - 0.6) / 0.4), jj = 0.95 + 0.1 * v, fieldC = '#' + cc.map((q) => cl(Math.round(q * jj), 0, 255).toString(16).padStart(2, '0')).join(''); quads.push({ d: dd, p, col: shade(fieldC, nn.map((q) => q / ln), Math.hypot(c[0] - cam.pos[0], c[1] - cam.pos[1], c[2] - cam.pos[2])) }); } };
  const near = o.near, nr = 1050, nb = near ? [Math.round((near[0] - nr) / 700) * 700, Math.round((near[0] + nr) / 700) * 700, Math.round((near[1] - nr) / 700) * 700, Math.round((near[1] + nr) / 700) * 700] : null, inNear = near ? (x, z) => x > nb[0] && x < nb[1] && z > nb[2] && z < nb[3] : null;
  const cx0 = Math.floor((cam.pos[0] - 28000) / 700) * 700, cz0 = Math.floor((cam.pos[2] - 28000) / 700) * 700; addGrid(Math.max(-14000, cx0), Math.min(52000, cx0 + 56000), Math.max(-16000, cz0), Math.min(16000, cz0 + 56000), 700, 5, (x, z) => Math.hypot(x - cam.pos[0], z - cam.pos[2]) > 28000); const useNear = near && Math.hypot(cam.pos[0] - near[0], cam.pos[2] - near[1]) < 2600;
  quads.sort((a, b) => b.d - a.d); for (const q of quads) poly3(ctx, cam, q.p, q.col, { near: 2, stroke: q.col, lw: 1.3 });
  if (useNear) { quads.length = 0; addGrid(nb[0], nb[1], nb[2], nb[3], 50, 9); quads.sort((a, b) => b.d - a.d); for (const q of quads) poly3(ctx, cam, q.p, q.col, { near: 2, stroke: q.col, lw: 1.3 }); }
  // matas de hierba en primer plano (textura), bosquecillos alrededor de cada estación y en el campo; aldeas; camino
  if (useNear) { const R5 = H.rng(3); for (let i = 0; i < 900; i++) { const x = cam.pos[0] + R5.range(-260, 260), z = cam.pos[2] + R5.range(-260, 260), y = hz(x, z), p = cam.pr([x, y, z]); if (p[2] < 3 || p[2] > 260) continue; const q = cam.pr([x, y + 0.5, z]), hh2 = Math.max(1, p[1] - q[1]); ctx.strokeStyle = shade(R5() < 0.5 ? '#4e6a40' : '#8c9a62', [0, 1, 0], p[2]); ctx.lineWidth = Math.max(1, hh2 * 0.35); ctx.beginPath(); ctx.moveTo(p[0] - hh2 * 0.6, p[1]); ctx.lineTo(p[0], p[1] - hh2); ctx.lineTo(p[0] + hh2 * 0.6, p[1]); ctx.stroke(); } }
  const trees = []; tw.forEach(([tx, tz], j) => { const R6 = H.rng(40 + j); for (let i = 0; i < 70; i++) { const a = R6() * TAU, r = R6.range(160, 1100); trees.push([tx + Math.cos(a) * r, tz + Math.sin(a) * r, R6.range(7, 14)]); } });
  const R2 = H.rng(31); for (let i = 0; i < 260; i++) trees.push([R2.range(-6000, 44000), R2.range(-9000, 9000), R2.range(6, 12)]);
  trees.map((tr) => ({ tr, d: cam.depth([tr[0], 0, tr[1]]) })).sort((a, b) => b.d - a.d).forEach(({ tr }) => { const [x, z, s] = tr, y = hz(x, z), p = cam.pr([x, y, z]); if (p[2] < 2 || p[2] > 9000) return; const q = cam.pr([x, y + s * 1.6, z]), hh2 = p[1] - q[1]; if (hh2 < 1.2) return; ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.beginPath(); ctx.ellipse(p[0] + hh2 * 0.3, p[1], hh2 * 0.5, hh2 * 0.12, 0, 0, TAU); ctx.fill(); ctx.fillStyle = shade('#3f5a3c', [0, 1, 0], p[2]); ctx.beginPath(); ctx.ellipse(p[0], p[1] - hh2 * 0.55, hh2 * 0.42, hh2 * 0.55, 0, 0, TAU); ctx.fill(); ctx.fillStyle = shade('#567a4c', [-0.6, 0.8, 0.2], p[2]); ctx.beginPath(); ctx.ellipse(p[0] - hh2 * 0.12, p[1] - hh2 * 0.68, hh2 * 0.24, hh2 * 0.3, 0, 0, TAU); ctx.fill(); });
  if (o.road !== false) { const pts = []; for (let x = -6000; x <= 46000; x += 400) { const z = -2200 + 900 * Math.sin(x / 5200); pts.push(cam.pr([x, hz(x, z) + 0.6, z])); } ctx.strokeStyle = shade('#b9a780', [0, 1, 0], 4000); ctx.lineWidth = 2.2; ctx.beginPath(); let st = false; for (const p of pts) { if (p[2] < 2) { st = false; continue; } if (!st) { ctx.moveTo(p[0], p[1]); st = true; } else ctx.lineTo(p[0], p[1]); } ctx.stroke(); }
  const R3 = H.rng(17); for (let v = 0; v < 6; v++) { const vx = R3.range(2000, 40000), vz = -2200 + 900 * Math.sin(vx / 5200) + R3.range(-300, 300); for (let k = 0; k < 7; k++) { const x = vx + R3.range(-120, 120), z = vz + R3.range(-90, 90), y = hz(x, z), c = cam.pr([x, y, z]); if (c[2] < 30 || c[2] > 12000) continue; P.box3(ctx, cam, x - 6, x + 6, y, y + 6, z - 4, z + 4, shade('#d8ccb2', [0.3, 0.8, 0.5], c[2]), {}); poly3(ctx, cam, [[x - 6.5, y + 6, z - 4.5], [x + 6.5, y + 6, z - 4.5], [x + 6.5, y + 9, z], [x - 6.5, y + 9, z]], shade('#8a4f3a', [0, 0.8, -0.6], c[2])); } }
  return { hz, shade };
 };
 // lluvia (trazos deterministas) y niebla de pantalla
 P.rainFX = (ctx, t, a = 1) => { if (a <= 0) return; const R = H.rng(5); ctx.save(); ctx.globalAlpha = 0.55 * a; ctx.strokeStyle = '#d6e0e6'; ctx.lineWidth = 2; ctx.beginPath(); for (let i = 0; i < 260; i++) { const x0 = R() * (W + 300), sp = 1700 + R() * 900, y = ((R() * HH + t * sp) % (HH + 200)) - 100, x = (x0 - t * 260) % (W + 300); ctx.moveTo(x, y); ctx.lineTo(x - 14, y + 46); } ctx.stroke(); ctx.restore(); };
 P.fogFX = (ctx, a = 1, night = 0) => { if (a <= 0) return; const g = ctx.createLinearGradient(0, 0, 0, HH); const c = night > 0.5 ? '40,50,62' : '214,220,222'; g.addColorStop(0, `rgba(${c},${0.25 * a})`); g.addColorStop(0.5, `rgba(${c},${0.75 * a})`); g.addColorStop(1, `rgba(${c},${0.45 * a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); };
 // Corte técnico 2D de una estación: muros de piedra, sala con ventana hacia la estación vecina y TELESCOPIO en su soporte, operador
 // ante el MANIPULADOR (réplica pequeña del regulador y los indicadores, con manijas) y CUERDAS que suben por el techo y el mástil hasta las
 // poleas de los ejes: el mecanismo de arriba toma la misma forma que el manipulador (reconstrucción didáctica del principio).
 // o: { cfg (arriba), man (manipulador; por defecto = cfg), look 0..1 (operador mirando por el telescopio), moving 0..1 (cuerdas en
 // movimiento), hi ('L' | 'R' | null: indicador resaltado) }
 P.chappeSection = (ctx, x, y, w, h, t, o = {}) => { const cfg = o.cfg || { reg: 0, li: 90, ri: 90 }, man = o.man || cfg, roofY = y + h * 0.44, floorY = y + h * 0.9, pivY = y + h * 0.13, cx = x + w * 0.46, S = (w * 0.46) / CHP.regL;
  ctx.save(); ctx.fillStyle = 'rgba(17,27,35,0.94)'; ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.fill(); ctx.strokeStyle = 'rgba(81,202,217,0.35)'; ctx.lineWidth = 2; ctx.stroke(); ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.clip();
  // muros (corte) y suelo
  const wl = x + w * 0.12, wr = x + w * 0.86; ctx.fillStyle = '#B1A28D'; ctx.fillRect(wl - 34, roofY, 34, floorY - roofY + 30); ctx.fillRect(wr, roofY, 34, floorY - roofY + 30); ctx.fillStyle = '#716B61'; ctx.fillRect(wl - 34, floorY, wr - wl + 68, 30);
  ctx.strokeStyle = 'rgba(80,70,58,0.55)'; ctx.lineWidth = 2; for (let yy = roofY + 26; yy < floorY; yy += 26) for (const xx of [wl - 34, wr]) { ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx + 34, yy); ctx.stroke(); }
  ctx.fillStyle = '#6a6560'; ctx.beginPath(); ctx.moveTo(wl - 60, roofY); ctx.lineTo(cx, roofY - h * 0.07); ctx.lineTo(wr + 60, roofY); ctx.lineTo(wr + 60, roofY + 14); ctx.lineTo(wl - 60, roofY + 14); ctx.closePath(); ctx.fill();
  // ventana y telescopio apuntando a la estación vecina (derecha)
  const winY = roofY + (floorY - roofY) * 0.3; ctx.fillStyle = '#92B7C8'; ctx.fillRect(wr, winY, 34, 70); const tsx = wr - 150, tsy = winY + 38; ctx.strokeStyle = '#806044'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(tsx + 60, tsy + 10); ctx.lineTo(tsx + 40, floorY); ctx.moveTo(tsx + 60, tsy + 10); ctx.lineTo(tsx + 90, floorY); ctx.stroke();
  { const g = ctx.createLinearGradient(0, tsy - 10, 0, tsy + 10); g.addColorStop(0, '#a88a5c'); g.addColorStop(1, '#5e4a30'); ctx.fillStyle = g; ctx.save(); ctx.translate(tsx, tsy); ctx.rotate(-0.04); ctx.fillRect(0, -9, 150, 18); ctx.fillStyle = '#c9a646'; ctx.fillRect(-6, -11, 12, 22); ctx.fillRect(140, -11, 10, 22); ctx.restore(); }
  // mástil, cuerdas y mecanismo de arriba
  ctx.fillStyle = '#6b5038'; ctx.fillRect(cx - 8, pivY, 16, roofY - pivY + 6);
  const G = P.chappeGeom(cfg, S), toS = ([p, q]) => [cx + p, pivY - q], GM = P.chappeGeom(man, S * 0.2), manY = floorY - (floorY - roofY) * 0.46, toM = ([p, q]) => [cx + p, manY - q];
  const ropeCol = o.moving > 0 ? '#FFD447' : '#B49D73'; ctx.lineWidth = 3; ctx.strokeStyle = ropeCol; ctx.setLineDash(o.moving > 0 ? [10, 8] : []); ctx.lineDashOffset = -t * 60;
  for (const [e, sgn] of [[G.e1, -1], [G.e2, 1]]) { const a = toS(e), m = toM(sgn < 0 ? GM.e1 : GM.e2); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(cx + sgn * 6, pivY + 4); ctx.lineTo(cx + sgn * 6, manY - 26); ctx.lineTo(m[0], m[1]); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(cx, pivY + 4); ctx.lineTo(cx, manY - 26); ctx.stroke(); ctx.setLineDash([]);
  const barS = (a, b, wd, col, hi) => { const A = toS(a), B = toS(b), dx = B[0] - A[0], dy = B[1] - A[1], l = Math.hypot(dx, dy) || 1, nx = (-dy / l) * wd / 2, ny = (dx / l) * wd / 2; ctx.fillStyle = hi ? '#FFD447' : col; ctx.beginPath(); ctx.moveTo(A[0] + nx, A[1] + ny); ctx.lineTo(B[0] + nx, B[1] + ny); ctx.lineTo(B[0] - nx, B[1] - ny); ctx.lineTo(A[0] - nx, A[1] - ny); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(200,200,190,0.45)'; ctx.lineWidth = 1.5; const ns = Math.floor(l / 14); for (let k = 1; k < ns; k++) { const u = k / ns; ctx.beginPath(); ctx.moveTo(A[0] + dx * u + nx * 0.8, A[1] + dy * u + ny * 0.8); ctx.lineTo(A[0] + dx * u - nx * 0.8, A[1] + dy * u - ny * 0.8); ctx.stroke(); } };
  { const c1 = toS(G.c1), c2 = toS(G.c2), e1 = toS(G.e1), e2 = toS(G.e2); ctx.strokeStyle = '#454E52'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(e1[0], e1[1]); ctx.lineTo(c1[0], c1[1]); ctx.moveTo(e2[0], e2[1]); ctx.lineTo(c2[0], c2[1]); ctx.stroke(); ctx.fillStyle = '#454E52'; for (const c of [c1, c2]) { ctx.beginPath(); ctx.arc(c[0], c[1], 9, 0, TAU); ctx.fill(); } }
  barS(G.e1, G.e2, CHP.regW * S, '#303738'); barS(G.e1, G.i1, CHP.indW * S, '#303738', o.hi === 'L'); barS(G.e2, G.i2, CHP.indW * S, '#303738', o.hi === 'R'); ctx.fillStyle = '#806044'; for (const c of [[0, 0], G.e1, G.e2]) { const p = toS(c); ctx.beginPath(); ctx.arc(p[0], p[1], 9, 0, TAU); ctx.fill(); }
  // manipulador (réplica pequeña con manijas) sobre su poste
  ctx.fillStyle = '#806044'; ctx.fillRect(cx - 7, manY, 14, floorY - manY);
  { const m1 = toM(GM.e1), m2 = toM(GM.e2), i1 = toM(GM.i1), i2 = toM(GM.i2); ctx.lineCap = 'round'; ctx.strokeStyle = '#3a2c20'; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(m1[0], m1[1]); ctx.lineTo(m2[0], m2[1]); ctx.stroke(); ctx.lineWidth = 9; ctx.strokeStyle = o.hi === 'L' ? '#FFD447' : '#5a4632'; ctx.beginPath(); ctx.moveTo(m1[0], m1[1]); ctx.lineTo(i1[0], i1[1]); ctx.stroke(); ctx.strokeStyle = o.hi === 'R' ? '#FFD447' : '#5a4632'; ctx.beginPath(); ctx.moveTo(m2[0], m2[1]); ctx.lineTo(i2[0], i2[1]); ctx.stroke(); ctx.fillStyle = '#c9a646'; for (const c of [i1, i2]) { ctx.beginPath(); ctx.arc(c[0], c[1], 8, 0, TAU); ctx.fill(); } ctx.lineCap = 'butt'; }
  // operador: junto al manipulador o mirando por el telescopio
  const look = cl(o.look ?? 0), opx = lerp(cx - 120, tsx - 20, look), oh = (floorY - roofY) * 0.78; P.traveler1865(ctx, opx, floorY, oh, t, { var: o.var ?? 2, pose: look > 0.5 ? 'stand' : 'point', dir: look > 0.5 ? 1 : 1 });
  ctx.fillStyle = 'rgba(245,247,246,0.9)'; ctx.font = '800 32px Nunito'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText('REGULADOR', x + 24, y + 40); ctx.fillText('MANIPULADOR', cx + 40, manY + 40); ctx.fillText('TELESCOPIO', tsx - 30, winY - 22); ctx.textAlign = 'right'; ctx.fillText('INDICADORES', x + w - 24, y + 40);
  ctx.restore(); return { G }; };
 // Mapa estilizado del norte de Francia con la línea París–Lille (1794) como cadena ESQUEMÁTICA de estaciones (sin coordenadas de las
 // estaciones intermedias). o: { u 0..1 (avance de la señal), n (estaciones del esquema) }. Devuelve { pr }.
 P.chappeMap = (ctx, cx, cy, w, t, o = {}) => { const lon0 = 2.5, lat0 = 49.9, k = w / 4.6, cosl = Math.cos(50 / 57.3), pr = (lo, la) => [cx + (lo - lon0) * k * cosl, cy - (la - lat0) * k], n = o.n ?? 9, u = cl(o.u ?? 0);
  ctx.save(); ctx.fillStyle = '#b9c7c4'; ctx.fillRect(cx - w, cy - w * 1.2, w * 2, w * 2.4);
  const coast = [[0.1, 49.49], [0.6, 49.86], [1.08, 49.93], [1.4, 50.07], [1.58, 50.25], [1.6, 50.72], [1.86, 50.95], [2.37, 51.04], [2.55, 51.09]], border = [[2.6, 50.94], [2.9, 50.73], [3.15, 50.79], [3.3, 50.52], [3.7, 50.36], [4.2, 50.28], [4.15, 49.98], [4.9, 49.8]];
  ctx.beginPath(); [...coast, [5.5, 51.6], [5.5, 47.5], [-0.5, 47.5], [-0.5, 49.4]].forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.closePath(); ctx.fillStyle = '#d5c7a6'; ctx.fill();
  ctx.beginPath(); [[2.55, 51.09], ...border, [5.5, 49.8], [5.5, 51.6], [2.55, 51.6]].forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.closePath(); ctx.fillStyle = '#c3b593'; ctx.fill();
  ctx.beginPath(); [...coast, ...border].forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.strokeStyle = '#6d5a3e'; ctx.lineWidth = 3; ctx.stroke();
  ctx.font = '600 32px Nunito'; ctx.fillStyle = 'rgba(80,64,42,0.75)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; { const [a, b] = pr(1.0, 50.65); ctx.fillText('Canal de la Mancha', a, b); const [c, d] = pr(3.9, 50.65); ctx.fillText('Países Bajos austriacos', c, d - 40); }
  const PA = [2.35, 48.86], LI = [3.06, 50.63], st = []; for (let i = 0; i < n; i++) { const s = i / (n - 1); st.push([lerp(PA[0], LI[0], s) + 0.12 * Math.sin(s * Math.PI * 1.3), lerp(PA[1], LI[1], s)]); }
  ctx.strokeStyle = 'rgba(80,64,42,0.55)'; ctx.setLineDash([8, 8]); ctx.lineWidth = 3; ctx.beginPath(); st.forEach(([lo, la], i) => { const [x, y] = pr(lo, la); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke(); ctx.setLineDash([]);
  st.forEach(([lo, la], i) => { const [x, y] = pr(lo, la), on = u * (n - 1) >= i - 0.01; if (on) P.glow(ctx, x, y, 34, '255,212,71', 0.6); ctx.fillStyle = on ? '#FFD447' : '#806044'; ctx.beginPath(); ctx.arc(x, y, i === 0 || i === n - 1 ? 13 : 8, 0, TAU); ctx.fill(); ctx.strokeStyle = '#3a2c20'; ctx.lineWidth = 2; ctx.stroke(); });
  ctx.font = '900 40px Nunito'; ctx.fillStyle = '#2a2018'; ctx.textAlign = 'left'; { const [a, b] = pr(...PA); ctx.fillText('PARÍS', a + 22, b + 6); const [c, d] = pr(...LI); ctx.fillText('LILLE', c + 22, d); }
  ctx.restore(); return { pr, st }; };
 // Mensajero a caballo (2D, perfil, galope de 4 tiempos simplificado). (x, y) = suelo bajo el caballo; h = altura a la cruz en px; o.dir ±1
 P.horseRider = (ctx, x, y, h, t, o = {}) => { const u = h / 100, ph = t * (o.rate ?? 2.6) * TAU, d = o.dir ?? 1; ctx.save(); ctx.translate(x, y); ctx.scale(d, 1); const bob = Math.sin(ph * 2) * 2.5 * u, col = o.col || '#4a3324', dk = '#2e1f15';
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(0, 2 * u, 70 * u, 7 * u, 0, 0, TAU); ctx.fill();
  const leg = (bx, by, ph0, front) => { const a = Math.sin(ph + ph0), kx = bx + a * 16 * u, ky = by + 30 * u, fx = kx + (front ? 10 : -6) * u * Math.max(0, -a) - a * 6 * u, fy = 0 - Math.max(0, Math.cos(ph + ph0)) * 10 * u; ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = 7 * u; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke(); };
  leg(-38 * u, -62 * u + bob, 0.6, false); leg(32 * u, -62 * u + bob, 2.4, true);
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, -72 * u + bob, 50 * u, 20 * u, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(34 * u, -82 * u + bob); ctx.quadraticCurveTo(52 * u, -110 * u + bob, 62 * u, -118 * u + bob); ctx.lineTo(80 * u, -104 * u + bob); ctx.lineTo(74 * u, -96 * u + bob); ctx.quadraticCurveTo(58 * u, -92 * u + bob, 48 * u, -66 * u + bob); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = dk; ctx.lineWidth = 5 * u; ctx.beginPath(); ctx.moveTo(-48 * u, -76 * u + bob); ctx.quadraticCurveTo(-66 * u, -70 * u + bob, -70 * u, -48 * u + bob + Math.sin(ph) * 4 * u); ctx.stroke();
  leg(-30 * u, -62 * u + bob, 3.6, false); leg(40 * u, -62 * u + bob, 5.2, true);
  ctx.fillStyle = '#2f3a4e'; ctx.beginPath(); ctx.moveTo(-8 * u, -86 * u + bob); ctx.lineTo(10 * u, -86 * u + bob); ctx.lineTo(16 * u, -128 * u + bob); ctx.lineTo(0, -132 * u + bob); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#2f3a4e'; ctx.lineWidth = 6 * u; ctx.beginPath(); ctx.moveTo(10 * u, -122 * u + bob); ctx.lineTo(30 * u, -104 * u + bob); ctx.stroke(); ctx.strokeStyle = '#d8d0c0'; ctx.lineWidth = 6 * u; ctx.beginPath(); ctx.moveTo(2 * u, -88 * u + bob); ctx.lineTo(8 * u, -66 * u + bob); ctx.stroke();
  ctx.fillStyle = '#d6a483'; ctx.beginPath(); ctx.arc(10 * u, -140 * u + bob, 7 * u, 0, TAU); ctx.fill(); ctx.fillStyle = '#1c1c22'; ctx.beginPath(); ctx.ellipse(10 * u, -147 * u + bob, 15 * u, 5 * u, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.moveTo(-4 * u, -147 * u + bob); ctx.quadraticCurveTo(10 * u, -160 * u + bob, 24 * u, -147 * u + bob); ctx.fill();
  ctx.restore(); };
 // Manipulador Morse (telégrafo eléctrico del s. XIX, genérico): base de madera, palanca de latón, contactos y bornes. o.press 0..1
 P.telegraphKey = (ctx, x, y, s, t, o = {}) => { const pr = cl(o.press ?? 0); ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(0, 46, 190, 18, 0, 0, TAU); ctx.fill();
  const g = ctx.createLinearGradient(0, 0, 0, 40); g.addColorStop(0, '#8a6644'); g.addColorStop(1, '#5a3f28'); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-180, 0, 360, 40, 8); ctx.fill();
  ctx.fillStyle = '#c9a646'; ctx.fillRect(-120, -28, 40, 28); ctx.fillRect(60, -14, 24, 14); for (const bx of [-160, 150]) { ctx.beginPath(); ctx.arc(bx, -6, 11, 0, TAU); ctx.fill(); }
  ctx.save(); ctx.translate(-100, -26); ctx.rotate(0.05 + pr * 0.09); const lg = ctx.createLinearGradient(0, -8, 0, 8); lg.addColorStop(0, '#f0d27a'); lg.addColorStop(1, '#a8852e'); ctx.fillStyle = lg; ctx.fillRect(0, -7, 250, 14); ctx.fillStyle = '#1c1c22'; ctx.beginPath(); ctx.ellipse(250, -10, 28, 12, 0, 0, TAU); ctx.fill(); ctx.restore();
  if (pr > 0.6) P.glow(ctx, 72, -16, 40, '81,202,217', 0.8); ctx.restore(); };
 // Postes y cables del telégrafo eléctrico a lo largo del camino (mundo en metros). o: { a (aparición), pulse (u del impulso) }
 P.telegraphPoles = (ctx, cam, hz, t, o = {}) => { const a = cl(o.a ?? 1); if (a <= 0) return; ctx.save(); ctx.globalAlpha *= a; const pts = []; for (let x = -800; x <= 9000; x += 70) { const z = -2200 + 900 * Math.sin(x / 5200) + 14, y = hz(x, z); pts.push([x, y, z]); }
  const tops = []; for (const [x, y, z] of pts) { const b = cam.pr([x, y, z]), tp = cam.pr([x, y + 7, z]); if (b[2] < 2) { tops.push(null); continue; } ctx.strokeStyle = '#5a4632'; ctx.lineWidth = Math.max(2, 700 / b[2]); ctx.beginPath(); ctx.moveTo(b[0], b[1]); ctx.lineTo(tp[0], tp[1]); ctx.stroke(); const c1 = cam.pr([x, y + 6.6, z - 0.8]), c2 = cam.pr([x, y + 6.6, z + 0.8]); ctx.lineWidth = Math.max(1, 150 / b[2]); ctx.beginPath(); ctx.moveTo(c1[0], c1[1]); ctx.lineTo(c2[0], c2[1]); ctx.stroke(); tops.push([x, y + 6.6, z]); }
  ctx.strokeStyle = 'rgba(40,40,40,0.85)'; ctx.lineWidth = 2; for (let i = 1; i < tops.length; i++) { const A = tops[i - 1], B = tops[i]; if (!A || !B) continue; ctx.beginPath(); for (let k = 0; k <= 8; k++) { const s = k / 8, p = cam.pr([lerp(A[0], B[0], s), lerp(A[1], B[1], s) - Math.sin(s * Math.PI) * 0.6, lerp(A[2], B[2], s)]); k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); } ctx.stroke(); }
  if (o.pulse != null) { const i = Math.floor(cl(o.pulse) * (tops.length - 1)), T2 = tops[i]; if (T2) { const p = cam.pr(T2); if (p[2] > 2) { P.glow(ctx, p[0], p[1], 40, '81,202,217', 0.9); ctx.fillStyle = '#F5F7F6'; ctx.beginPath(); ctx.arc(p[0], p[1], 5, 0, TAU); ctx.fill(); } } }
  ctx.restore(); };
 // Taller de finales del s. XVIII (mundo en metros): suelo de tablas, paredes encaladas, ventana con luz, mesa con un MODELO del telégrafo
 // (el mismo mecanismo maestro a escala 1:12 sobre su peana). o: { cfg }
 P.workshop1790 = (ctx, cam, t, o = {}) => { ctx.save(); ctx.fillStyle = '#2a2018'; ctx.fillRect(0, 0, W, HH);
  poly3(ctx, cam, [[-5, 0, -3], [5, 0, -3], [5, 3.2, -3], [-5, 3.2, -3]], '#d9cdb4'); poly3(ctx, cam, [[-5, 0, -2.99], [5, 0, -2.99], [5, 0.9, -2.99], [-5, 0.9, -2.99]], '#806044'); poly3(ctx, cam, [[0.8, 1.2, -2.98], [2.4, 1.2, -2.98], [2.4, 2.6, -2.98], [0.8, 2.6, -2.98]], '#f2e2bc'); poly3(ctx, cam, [[1.57, 1.2, -2.97], [1.63, 1.2, -2.97], [1.63, 2.6, -2.97], [1.57, 2.6, -2.97]], '#5a4632');
  for (let z = -3; z < 4; z += 0.35) poly3(ctx, cam, [[-5, 0, z], [5, 0, z], [5, 0, z + 0.35], [-5, 0, z + 0.35]], ((z * 3) | 0) % 2 ? '#6e4f33' : '#76563a');
  const L = cam.pr([1.6, 2, -2.9]); if (L[2] > 0.5) { const g = ctx.createRadialGradient(L[0], L[1], 10, L[0], L[1], 1200); g.addColorStop(0, 'rgba(242,214,160,0.35)'); g.addColorStop(1, 'rgba(242,214,160,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HH); }
  P.box3(ctx, cam, -0.9, 0.9, 0.74, 0.8, -0.5, 0.5, '#806044', {}); for (const [lx, lz] of [[-0.85, -0.45], [0.8, -0.45], [-0.85, 0.4], [0.8, 0.4]]) P.box3(ctx, cam, lx, lx + 0.05, 0, 0.74, lz, lz + 0.05, '#5a4632', {});
  P.box3(ctx, cam, -0.13, 0.13, 0.8, 0.84, -0.09, 0.09, '#3f5a50', {}); P.box3(ctx, cam, -0.012, 0.012, 0.84, 1.3, -0.012, 0.012, '#c9a646', {});
  P.chappeMech(ctx, cam, [0, 1.3, 0.02], o.cfg || { reg: 0, li: 90, ri: 90 }, { yaw: 0, sc: 1 / 12, ropes: false }); ctx.restore(); };
 // ---------------- SUBTÍTULOS (arriba, palabra a palabra, palabra clave seleccionada) ----------------
 // Trozos de ≤3 palabras (≤4 si son cortas); las palabras aparecen al decirse: la actual en blanco y negrita,
 // las ya dichas en gris; la palabra clave lleva recuadro de selección con asas en el color de acento.
 let CHUNKS = null;
 function chunks(A) {
  if (CHUNKS) return CHUNKS;
  const out = [];
  for (const ph of A.phrases) {
   const ws = ph.w.map((w, i) => ({ ...w, txt: ph.lines.join(' ').split(' ')[i] || w.w }));
   let cur = [];
   const flush = () => { if (cur.length) out.push(cur); cur = []; };
   ws.forEach((w) => { const chars = cur.reduce((s, x) => s + x.txt.length + 1, 0) + w.txt.length; if (cur.length >= 4 || (cur.length >= 3 && chars > 16) || chars > 22) flush(); cur.push(w); });
   flush();
  }
  out.forEach((c, i) => { c.s = c[0].s; c.e = i + 1 < out.length ? Math.min(out[i + 1][0].s, c[c.length - 1].e + 0.6) : c[c.length - 1].e + 0.6; });
  return (CHUNKS = out);
 }
 const nrm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ]/g, '');
 function captions(ctx, A, t, cfg) {
  if (cfg.capStyle === 'barra') return captionsBar(ctx, A, t, cfg);
  const ch = chunks(A).find((c) => t >= c.s - 0.05 && t < c.e); if (!ch) return;
  const KW = cfg.keywords || [], y = cfg.capY || 300;
  const px = cfg.capPx || 64, fB = `${SK.font.capW} ${px}px "${SK.font.cap}"`, fD = `${SK.font.capDim} ${px}px "${SK.font.cap}"`;
  ctx.save(); ctx.textBaseline = 'alphabetic';
  const vis = ch.filter((w) => t >= w.s - 0.04);
  if (!vis.length) { ctx.restore(); return; }
  // reparto en 1-2 líneas
  const meas = (w, i) => { ctx.font = i === vis.length - 1 ? fB : fD; return ctx.measureText(w.txt).width; };
  ctx.font = fB; const sp = ctx.measureText(' ').width;
  const all = ch.map((w) => { ctx.font = fB; return ctx.measureText(w.txt).width; });
  const total = all.reduce((a, b) => a + b, 0) + sp * (ch.length - 1);
  let lines = [ch.map((_, i) => i)];
  if (total > 900 && ch.length > 1) { let best = 1, bd = 1e9; for (let k = 1; k < ch.length; k++) { const a = all.slice(0, k).reduce((s, v) => s + v, 0), b = all.slice(k).reduce((s, v) => s + v, 0); if (Math.abs(a - b) < bd) { bd = Math.abs(a - b); best = k; } } lines = [ch.map((_, i) => i).slice(0, best), ch.map((_, i) => i).slice(best)]; }
  const lh = px * 1.18, y0 = y - (lines.length - 1) * lh / 2;
  const fade = 1 - sm(ch.e - 0.12, ch.e, t);
  lines.forEach((ln, li) => {
   const lw = ln.reduce((s, i) => s + all[i], 0) + sp * (ln.length - 1); let x = 540 - lw / 2;
   ln.forEach((i) => {
    const w = ch[i], shown = t >= w.s - 0.04, active = shown && (i === ch.length - 1 || t < ch[i + 1].s - 0.04);
    if (shown) {
     const pop = E.out(win(t, w.s - 0.04, w.s + 0.1)), yy = y0 + li * lh + (1 - pop) * 10;
     const isKW = KW.some((k) => (Array.isArray(k) ? nrm(w.txt) === nrm(k[0]) && w.s >= k[1] && w.s <= k[2] : nrm(w.txt) === nrm(k)));
     if (isKW) { // recuadro de selección con asas
      const bx = x - 12, by = yy - px * 0.86, bw = all[i] + 24, bh = px * 1.16, ka = fade * pop;
      ctx.save(); ctx.globalAlpha = ka; ctx.fillStyle = SK.name === 'plana' ? 'rgba(20,16,60,0.28)' : 'rgba(242,184,75,0.12)'; ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = col('handle'); ctx.lineWidth = 3; ctx.strokeRect(bx, by, bw, bh);
      ctx.fillStyle = '#ffffff'; for (const [hx, hy] of [[bx, by], [bx + bw, by], [bx, by + bh], [bx + bw, by + bh]]) { ctx.fillRect(hx - 7, hy - 7, 14, 14); ctx.strokeRect(hx - 7, hy - 7, 14, 14); }
      ctx.restore();
     }
     ctx.font = active || isKW ? fB : fD;
     ctx.globalAlpha = fade * pop * (active || isKW ? 1 : 0.62);
     ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 14; ctx.shadowOffsetY = 3;
     ctx.fillStyle = '#ffffff'; ctx.fillText(w.txt, x, yy); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
    }
    x += all[i] + sp;
   });
  });
  ctx.restore();
 }


 // ---- estilo «barra» (estándar Asombroteca): frase completa en blanco (≤2 líneas), barra amarilla animada bajo la
 // palabra que se dice; las palabras clave se tiñen de amarillo. Posición por defecto: franja segura inferior (y≈1500).
 function captionsBar(ctx, A, t, cfg) {
  const ph = A.phrases.find((p) => t >= p.s - 0.03 && t < p.e); if (!ph) return;
  const KW = cfg.keywords || [], y = cfg.capY || 1500, maxW = 920;
  const a = sm(ph.s - 0.03, ph.s + 0.08, t) * (1 - sm(ph.e - 0.1, ph.e, t));
  let px = cfg.capPx || 60; const fam = SK.font.cap;
  ctx.save(); ctx.font = `${SK.font.capW} ${px}px "${fam}"`;
  const widest = Math.max(...ph.lines.map((l) => ctx.measureText(l).width)); if (widest > maxW) { px = Math.floor(px * maxW / widest); ctx.font = `${SK.font.capW} ${px}px "${fam}"`; }
  const lh = px * 1.24, y0 = y - (ph.lines.length - 1) * lh / 2, sp = ctx.measureText(' ').width, boxes = []; let wi = 0;
  ph.lines.forEach((ln, li) => { const lw = ctx.measureText(ln).width; let x = 540 - lw / 2; ln.split(' ').forEach((w) => { const ww = ctx.measureText(w).width, wd = ph.w[wi] || {}; boxes.push({ w, x, y: y0 + li * lh, ww, s: wd.s ?? ph.s, e: wd.e ?? ph.e }); wi++; x += ww + sp; }); });
  let act = boxes.findIndex((b) => t >= b.s && t < b.e); if (act < 0) act = t >= boxes[boxes.length - 1].s ? boxes.length - 1 : 0;
  const b0 = boxes[act], nb = boxes[act + 1]; let bx = b0.x, bw = b0.ww;
  if (nb && nb.y === b0.y) { const f = E.inOut(sm(b0.e - 0.08, b0.e, t)); bx = lerp(b0.x, nb.x, f); bw = lerp(b0.ww, nb.ww, f); }
  ctx.globalAlpha = a; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#f0b90b'; ctx.beginPath(); ctx.roundRect(bx, b0.y + px * 0.2, bw, Math.max(6, px * 0.1), 4); ctx.fill();
  ctx.shadowColor = 'rgba(0,0,0,0.75)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 3;
  for (const b of boxes) { const kw = KW.some((k) => (Array.isArray(k) ? nrm(b.w) === nrm(k[0]) && b.s >= k[1] && b.s <= k[2] : nrm(b.w) === nrm(k))); ctx.fillStyle = kw ? '#ffd54a' : '#ffffff'; ctx.fillText(b.w, b.x, b.y); }
  ctx.restore();
 }

 // ---------------- TRANSICIONES ----------------
 // cut | iris (círculo desde un punto) | slide (barrido lateral con desenfoque de movimiento) | rise (sube) | fade | zoom (entra por un punto)
 function transition(ctx, type, u, o, drawPrev, drawNext, L) {
  const e = E.inOut(u);
  if (type === 'iris' || type === 'zoom') {
   if (type === 'zoom') { ctx.save(); const s = lerp(1, 4, e); ctx.translate(o.x, o.y); ctx.scale(s, s); ctx.translate(-o.x, -o.y); drawPrev(ctx); ctx.restore(); } else drawPrev(ctx);
   const r = lerp(0, 2300, E.in(u) * 0.35 + e * 0.65);
   ctx.save(); ctx.beginPath(); ctx.arc(o.x ?? 540, o.y ?? 960, r, 0, TAU); ctx.clip(); drawNext(ctx); ctx.restore();
   ctx.save(); ctx.strokeStyle = col('accent'); ctx.lineWidth = 18 * (1 - u); ctx.beginPath(); ctx.arc(o.x ?? 540, o.y ?? 960, r, 0, TAU); ctx.stroke(); ctx.restore();
  } else if (type === 'slide' || type === 'rise') {
   const dx = type === 'slide' ? -W * e : 0, dy = type === 'rise' ? -HH * e : 0;
   ctx.save(); ctx.translate(dx, dy); drawPrev(ctx); ctx.restore();
   ctx.save(); ctx.translate(dx + (type === 'slide' ? W : 0), dy + (type === 'rise' ? HH : 0)); drawNext(ctx); ctx.restore();
   const blur = Math.sin(u * Math.PI);
   if (blur > 0.05) { const c = L.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, W, HH); c.drawImage(ctx.canvas, 0, 0); ctx.save(); ctx.globalAlpha = 0.45 * blur; ctx.filter = type === 'slide' ? `blur(${10 * blur}px)` : `blur(${8 * blur}px)`; ctx.drawImage(L, 0, 0); ctx.restore(); }
  } else if (type === 'fade') {
   drawPrev(ctx); ctx.save(); ctx.globalAlpha = e; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, HH); ctx.restore();
   if (u > 0.5) { ctx.save(); ctx.globalAlpha = (u - 0.5) * 2; drawNext(ctx); ctx.restore(); }
  } else drawNext(ctx);
 }

 // ---------------- EPISODIO ----------------
 // cfg = { skin, align, duration, beats:[{t0,t1,in:{type,d,x,y}, draw(ctx,t,api), sfx(k,api)}], keywords, music(k,api), capY }
 function make(cfg) {
  SK = SKINS[cfg.skin || 'plana'];
  const A = cfg.align, D = cfg.duration;
  let LA = null, LB = null;
  const api = { P, W, HH, cl, sm, win, E, lerp, col, fill, SK: () => SK, TAU };
  function drawBeat(ctx, b, t) { ctx.save(); b.draw(ctx, t, api); ctx.restore(); }
  function explainer(ctx, Wd, Hd, t) {
   if (!LA) { LA = H.layer(W, HH); LB = H.layer(W, HH); }
   const bs = cfg.beats; let i = bs.findIndex((b) => t >= b.t0 && t < b.t1); if (i < 0) i = t < bs[0].t0 ? 0 : bs.length - 1;
   const b = bs[i], tr = b.in || { type: 'cut', d: 0 }, u = tr.d ? win(t, b.t0, b.t0 + tr.d) : 1;
   ctx.save(); ctx.fillStyle = col('ink'); ctx.fillRect(0, 0, W, HH); ctx.restore();
   if (i > 0 && u < 1 && tr.type !== 'cut') transition(ctx, tr.type, u, tr, (c) => drawBeat(c, bs[i - 1], t), (c) => drawBeat(c, b, t), LA);
   else drawBeat(ctx, b, t);
   // acabado de la piel
   H.vignette(ctx, W, HH, SK.vignette, SK.vigCol);
   captions(ctx, A, t, cfg);
   if (SK.grain) H.grain(ctx, W, HH, SK.grain, 1 + Math.floor(t * 24), true);
  }
  // sonido: cada beat declara sus efectos; el motor añade las transiciones
  const TS = TRANS_SFX;
  function scoreSound(k) {
   cfg.beats.forEach((b, i) => { if (i > 0 && b.in && b.in.type !== 'cut' && TS[b.in.type]) TS[b.in.type](k, b.t0, b.in.d || 0.5); if (b.sfx) b.sfx(k, api); });
   if (cfg.ambience) cfg.ambience(k, api);
  }
  function scoreMusic(k) { if (cfg.music) cfg.music(k, api); }
  return { explainer, scoreSound, scoreMusic, DURATION: D };
 }
 // sonidos de transición (paleta del medio: papel/tinta plana → swish y whoosh suaves)
 const TRANS_SFX = {
  iris: (k, t, d) => { k.play('whoosh', t - 0.05, { dur: d + 0.1, top: 1800, gain: 0.45, minor: true }); k.play('pop', t + d * 0.6, { f: 420, gain: 0.3, minor: true }); },
  zoom: (k, t, d) => { k.play('riser', t - 0.2, { dur: d + 0.2, gain: 0.3, minor: true }); k.play('whoosh', t, { dur: d, top: 2600, gain: 0.45, minor: true }); },
  slide: (k, t, d) => k.play('swish', t, { dur: Math.max(0.2, d * 0.8), gain: 0.55, minor: true }),
  rise: (k, t, d) => k.play('whoosh', t, { dur: d + 0.1, top: 1400, gain: 0.45, minor: true }),
  fade: (k, t, d) => k.noise(t, { dur: d + 0.3, color: 'brown', filter: 'lowpass', f: [[0, 600], [d + 0.3, 120]], gain: 0.12, a: d * 0.5, minor: true }),
 };
 // efectos con nombre para los bloques (consistencia entre episodios)
 const FX = {
  aparece: (k, t, f = 560) => k.play('pop', t, { f, gain: 0.5 }),
  etiqueta: (k, t) => { k.play('pop', t, { f: 700, gain: 0.35, minor: true }); k.play('tick', t + 0.02, { gain: 0.25, minor: true }); },
  flecha: (k, t, d = 0.4) => k.play('swish', t, { dur: d, gain: 0.35, minor: true }),
  tachado: (k, t) => { k.play('error', t, { f: 'A3', gain: 0.4 }); k.play('slap', t, { gain: 0.3, minor: true }); },
  correcto: (k, t) => k.play('success', t, { gain: 0.4 }),
  sello: (k, t) => k.play('stamp', t, { gain: 0.5 }),
  contador: (k, t0, t1, from, to) => { let last = -1; const val = (t) => Math.round(lerp(from, to, E.out(win(t, t0, t1)))); let prev = val(t0); for (let t = t0; t <= t1; t += 0.005) { const v = val(t); if (v !== prev && t - last >= 1 / 12) { k.play('count', t, { gain: 0.9, minor: true }); last = t; } prev = v; } k.play('tock', t1, { f: 520, gain: 0.5 }); },
  onomatopeya: (k, t) => k.play('slap', t, { gain: 0.35, minor: true }),
  burbujas: (k, t, d, rate = 9, seed = 1, g = 1) => { const R = H.rng(seed); for (let x = 0; x < d; x += 1 / rate) { const f = 380 + R() * 700; k.tone(t + x + R() * 0.05, { f: [[0, f], [0.06, f * 1.7]], dur: 0.07, gain: 0.05 * g, a: 0.004, pan: R() - 0.5, minor: true }); } },
  siseo: (k, t, d) => k.noise(t, { dur: d, color: 'white', filter: 'highpass', f: [[0, 2500], [0.3, 3800], [d, 2000]], gain: 0.07, a: 0.05, hold: d * 0.7 }),
  agua: (k, t, d) => k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: [[0, 400], [Math.min(1, d * 0.4), 1300], [d, 500]], gain: 0.12, a: 0.3, hold: d * 0.6 }),
  alarma: (k, t, n = 3) => { for (let i = 0; i < n; i++) k.tone(t + i * 0.36, { f: [[0, 760], [0.16, 620]], type: 'square', dur: 0.3, gain: 0.05, filter: 'lowpass', f2: 1800, a: 0.01 }); },
  sonar: (k, t, g = 1) => { for (let e = 0; e < 3; e++) k.tone(t + e * 0.42, { f: 1180, dur: 1.1, gain: 0.1 * g * Math.pow(0.42, e), a: 0.004, verb: 0.4, minor: e > 0 }); },
  crujido: (k, t, g = 1, f = 90) => k.tone(t, { f: [[0, f], [0.35, f * 0.8], [0.6, f * 1.05]], type: 'sawtooth', dur: 0.65, gain: 0.05 * g, filter: 'bandpass', f2: f * 4, q: 3, a: 0.08 }),
  golpeSordo: (k, t) => { k.play('thud', t, { f: 55, gain: 0.55 }); k.noise(t, { dur: 1.2, color: 'brown', filter: 'lowpass', f: [[0, 400], [1.2, 80]], gain: 0.18, a: 0.01 }); },
  domino: (k, t) => { k.play('tock', t, { f: 380, gain: 0.5 }); k.play('click', t + 0.03, { gain: 0.4, minor: true }); },
  clic: (k, t) => k.play('click', t, { gain: 0.6 }),
  campana: (k, t) => k.play('bell', t, { f: 'A3', gain: 0.18 }),
  // v1.2 · aparatos y ciencia
  pitido: (k, t, f = 'E6', n = 1) => { for (let i = 0; i < n; i++) k.tone(t + i * 0.16, { f, type: 'square', dur: 0.1, gain: 0.05, a: 0.003, hold: 0.07, filter: 'lowpass', f2: 3200 }); },
  zumbido: (k, t, d, g = 1) => { k.tone(t, { f: 120, type: 'sawtooth', dur: d, gain: 0.03 * g, a: 0.15, hold: d * 0.85, filter: 'lowpass', f2: 600 }); k.tone(t, { f: 60, dur: d, gain: 0.06 * g, a: 0.15, hold: d * 0.85 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 900, q: 1.5, gain: 0.025 * g, a: 0.2, hold: d * 0.8 }); },
  motor: (k, t, d, g = 1) => { k.tone(t, { f: 48, type: 'triangle', dur: d, gain: 0.05 * g, a: 0.3, hold: d * 0.8 }); for (let x = 0; x < d; x += 0.5) k.play('tick', t + x, { f: 2400, gain: 0.08 * g, minor: true }); },
  campo: (k, t, d = 1.2, g = 1) => { const R = H.rng(Math.round(t * 100)); for (let x = 0; x < d; x += 0.07) k.tone(t + x, { f: [523, 659, 784, 988, 1175][Math.floor(R() * 5)], dur: 0.5, gain: 0.02 * g, a: 0.02, filter: 'lowpass', f2: 2200, verb: 0.4, pan: R() * 1.2 - 0.6, minor: true }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 2400, q: 2, gain: 0.03 * g, a: d * 0.4 }); },
  escala: (k, t, d = 1) => { k.play('riser', t, { dur: d, gain: 0.35 }); k.tone(t + d, { f: [[0, 90], [0.4, 45]], dur: 0.6, gain: 0.25 }); },
  revelar: (k, t) => { k.play('whoosh', t, { dur: 0.6, top: 2000, gain: 0.35, minor: true }); k.play('ding', t + 0.35, { f: 'C6', gain: 0.18, minor: true }); },
  puerta: (k, t) => { k.play('click', t, { gain: 0.7 }); k.play('thud', t + 0.03, { f: 160, gain: 0.25 }); k.noise(t + 0.05, { dur: 0.35, color: 'pink', filter: 'bandpass', f: 1200, q: 1, gain: 0.05, a: 0.05 }); },
  // v1.4 · aire y refrigeración
  ventilador: (k, t, d, g = 1, f = 300) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, f * 0.6], [Math.min(1.5, d * 0.3), f], [d, f]], q: 0.9, gain: 0.05 * g, a: Math.min(1.2, d * 0.3), hold: d * 0.7 }); },
  compresion: (k, t, d = 1.2) => { k.tone(t, { f: [[0, 70], [d, 140]], type: 'sawtooth', dur: d, gain: 0.05, filter: 'lowpass', f2: 700, a: 0.2 }); k.play('riser', t, { dur: d, gain: 0.25 }); k.play('thud', t + d, { f: 90, gain: 0.35 }); },
  expansion: (k, t, d = 0.9) => { k.noise(t, { dur: d, color: 'white', filter: 'highpass', f: [[0, 5000], [d, 2200]], gain: 0.09, a: 0.01 }); k.tone(t, { f: [[0, 900], [d, 300]], dur: d, gain: 0.03, filter: 'lowpass', f2: 1500 }); },
  goteo: (k, t, n = 5, gap = 0.22, seed = 5) => { const R = H.rng(seed); for (let i = 0; i < n; i++) { const f = 600 + R() * 500; k.tone(t + i * gap + R() * 0.05, { f: [[0, f * 1.6], [0.08, f]], dur: 0.12, gain: 0.05, a: 0.003, pan: R() - 0.5, minor: true }); } },
  calor: (k, t, d = 1.5, g = 1) => k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 200], [d * 0.6, 600], [d, 250]], gain: 0.12 * g, a: d * 0.4, hold: d * 0.2 }),
  // v1.5 · señales, tiempo y ubicación
  senal: (k, t, g = 1, f = 1400) => { k.tone(t, { f: [[0, f], [0.12, f * 0.92]], type: 'sine', dur: 0.18, gain: 0.07 * g, a: 0.004, verb: 0.3 }); k.tone(t + 0.16, { f: f * 1.5, type: 'sine', dur: 0.12, gain: 0.04 * g, a: 0.004, minor: true }); },
  datos: (k, t, n = 10, g = 1) => { for (let i = 0; i < n; i++) k.tone(t + i * 0.045, { f: i % 2 ? 2100 : 1600, type: 'square', dur: 0.03, gain: 0.025 * g, a: 0.002, hold: 0.02, filter: 'lowpass', f2: 4000, minor: true }); },
  tictac: (k, t, n = 4, gap = 0.5) => { for (let i = 0; i < n; i++) k.play('tock', t + i * gap, { f: i % 2 ? 1500 : 1900, gain: 0.3, minor: true }); },
  ubicacion: (k, t) => { k.tone(t, { f: 'E5', dur: 0.5, gain: 0.12, verb: 0.3 }); k.tone(t + 0.1, { f: 'B5', dur: 0.6, gain: 0.11, verb: 0.3 }); k.tone(t + 0.2, { f: 'E6', dur: 0.9, gain: 0.09, verb: 0.35 }); },
  fin: (k, t) => { k.tone(t, { f: 'E6', dur: 1.6, gain: 0.16, verb: 0.3 }); k.tone(t, { f: 'E7', dur: 0.6, gain: 0.04 }); },
  // v1.6 · océano, cables y telecomunicaciones
  bajoAgua: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: 240, gain: 0.08 * g, a: Math.min(1, d * 0.3), hold: d * 0.7 }); FX.burbujas(k, t, d, 1.4, Math.round(t * 10) + 3, 0.6 * g); },
  inmersion: (k, t, d = 1.2) => { k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: [[0, 3200], [d, 200]], gain: 0.24, a: 0.02 }); k.play('thud', t, { f: 80, gain: 0.25 }); FX.burbujas(k, t, d * 0.8, 16, 3, 1.4); },
  olas: (k, t, d, g = 1) => k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 450], [d * 0.5, 900], [d, 450]], q: 0.6, gain: 0.07 * g, a: Math.min(1, d * 0.3), hold: d * 0.5 }),
  pulsoLuz: (k, t, n = 4, gap = 0.16, g = 1) => { for (let i = 0; i < n; i++) k.tone(t + i * gap, { f: [[0, 2500 + (i % 3) * 180], [0.1, 2300]], dur: 0.25, gain: 0.035 * g, a: 0.003, verb: 0.35, minor: true }); },
  amplifica: (k, t, g = 1) => { k.tone(t, { f: [[0, 300], [0.35, 900]], type: 'triangle', dur: 0.4, gain: 0.05 * g, a: 0.3 }); k.play('ding', t + 0.35, { f: 'E6', gain: 0.14 * g, minor: true }); },
  cabrestante: (k, t, d, g = 1) => { k.tone(t, { f: 55, type: 'sawtooth', dur: d, gain: 0.035 * g, filter: 'lowpass', f2: 420, a: 0.2, hold: d * 0.8 }); for (let x = 0; x < d; x += 0.12) k.play('tick', t + x, { f: 1700, gain: 0.12 * g, minor: true }); },
  ancla: (k, t) => { const R = H.rng(Math.round(t * 100)); for (let i = 0; i < 10; i++) k.play('tick', t + i * 0.05 + R() * 0.02, { f: 2800 + R() * 1600, gain: 0.22, minor: true }); k.play('thud', t + 0.55, { f: 70, gain: 0.45 }); k.noise(t + 0.55, { dur: 0.8, color: 'brown', filter: 'lowpass', f: 600, gain: 0.15 }); },
  rotura: (k, t) => { k.noise(t, { dur: 0.12, filter: 'highpass', f: 1500, gain: 0.4, a: 0.001 }); k.play('thud', t, { f: 110, gain: 0.4 }); k.tone(t + 0.02, { f: [[0, 900], [0.3, 120]], type: 'sawtooth', dur: 0.32, gain: 0.04, filter: 'lowpass', f2: 2000 }); },
  empalme: (k, t, d = 0.8) => { const R = H.rng(Math.round(t * 100) + 7); for (let x = 0; x < d; x += 0.03 + R() * 0.04) k.noise(t + x, { dur: 0.02, filter: 'highpass', f: 4000, gain: 0.12 + R() * 0.1, minor: true }); k.tone(t, { f: 240, type: 'square', dur: d, gain: 0.015, filter: 'lowpass', f2: 1500, a: 0.02, hold: d * 0.8 }); },
  // v1.7 · agua, energía y electricidad
  compuerta: (k, t, d = 1.6) => { k.play('click', t, { gain: 0.6 }); k.tone(t, { f: [[0, 60], [d, 75]], type: 'sawtooth', dur: d, gain: 0.04, filter: 'lowpass', f2: 380, a: 0.1, hold: d * 0.8 }); for (let x = 0.1; x < d; x += 0.18) k.play('tick', t + x, { f: 1300, gain: 0.1, minor: true }); k.play('thud', t + d, { f: 90, gain: 0.4 }); },
  corriente: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: [[0, 300], [Math.min(1.2, d * 0.4), 900], [d, 700]], gain: 0.13 * g, a: Math.min(1, d * 0.3), hold: d * 0.6 }); k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: 160, gain: 0.1 * g, a: 0.5, hold: d * 0.7 }); },
  turbina: (k, t, d, g = 1, f0 = 90, f1 = 220) => { k.tone(t, { f: [[0, f0], [Math.min(2.5, d * 0.6), f1], [d, f1]], type: 'sawtooth', dur: d, gain: 0.035 * g, filter: 'lowpass', f2: 900, a: 0.4, hold: d * 0.75 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 500], [Math.min(2.5, d * 0.6), 1400]], q: 2, gain: 0.05 * g, a: 0.5, hold: d * 0.7 }); },
  generador: (k, t, d, g = 1) => { for (const [f, gg] of [[60, 0.06], [120, 0.035], [180, 0.015]]) k.tone(t, { f, dur: d, gain: gg * g, a: 0.4, hold: d * 0.8 }); },
  induccion: (k, t, d = 1.2, g = 1) => { const R = H.rng(Math.round(t * 100)); for (let x = 0; x < d; x += 0.06) k.tone(t + x, { f: 1200 + R() * 1800, dur: 0.35, gain: 0.018 * g, a: 0.02, verb: 0.4, pan: R() - 0.5, minor: true }); k.play('riser', t, { dur: d, gain: 0.2 * g }); },
  transformador: (k, t, d, g = 1) => { k.tone(t, { f: 100, type: 'square', dur: d, gain: 0.012 * g, filter: 'lowpass', f2: 500, a: 0.3, hold: d * 0.8 }); k.tone(t, { f: 200, dur: d, gain: 0.03 * g, a: 0.3, hold: d * 0.8 }); },
  lineas: (k, t, d, g = 1) => { const R = H.rng(Math.round(t * 10) + 9); k.noise(t, { dur: d, color: 'white', filter: 'bandpass', f: 3500, q: 3, gain: 0.025 * g, a: 0.3, hold: d * 0.7 }); for (let x = 0; x < d; x += 0.2 + R() * 0.3) k.noise(t + x, { dur: 0.015, filter: 'highpass', f: 5000, gain: 0.08 * g, minor: true }); },
  bombilla: (k, t) => { k.play('click', t, { gain: 0.8 }); k.tone(t + 0.04, { f: 'E6', dur: 0.9, gain: 0.06, verb: 0.35 }); k.tone(t + 0.04, { f: 'B6', dur: 0.6, gain: 0.03, verb: 0.35, minor: true }); },
  lluvia: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'white', filter: 'highpass', f: 2500, gain: 0.04 * g, a: 0.4, hold: d * 0.6 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 1200, q: 0.6, gain: 0.04 * g, a: 0.4, hold: d * 0.6 }); },
  // v1.8 · historia antigua y construcción
  arrastre: (k, t, d, g = 1, f = 700) => { k.noise(t, { dur: d, color: 'brown', filter: 'bandpass', f, q: 0.8, gain: 0.1 * g, a: 0.3, hold: d * 0.7 }); const R = H.rng(Math.round(t * 10) + 1); for (let x = 0; x < d; x += 0.15 + R() * 0.2) k.noise(t + x, { dur: 0.06, color: 'pink', filter: 'bandpass', f: 1800 + R() * 900, q: 1, gain: 0.04 * g, minor: true }); },
  cuerda: (k, t, g = 1) => { k.tone(t, { f: [[0, 180], [0.35, 140]], type: 'sawtooth', dur: 0.4, gain: 0.03 * g, filter: 'bandpass', f2: 700, q: 4, a: 0.05 }); k.noise(t, { dur: 0.3, filter: 'bandpass', f: 1200, q: 2, gain: 0.05 * g, a: 0.05 }); },
  esfuerzo: (k, t, n = 4, gap = 0.9, g = 1) => { for (let i = 0; i < n; i++) { k.play('thud', t + i * gap, { f: 70, gain: 0.25 * g }); k.noise(t + i * gap, { dur: 0.25, color: 'brown', filter: 'bandpass', f: 400, q: 1.5, gain: 0.06 * g, a: 0.02 }); FX.cuerda(k, t + i * gap + 0.05, 0.6 * g); } },
  vertido: (k, t, d = 1.2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 900], [d, 1500]], q: 1.2, gain: 0.08 * g, a: 0.1, hold: d * 0.7 }); FX.goteo(k, t + 0.1, Math.round(d * 6), 0.15, Math.round(t * 10)); },
  cincel: (k, t, n = 4, gap = 0.32) => { for (let i = 0; i < n; i++) { k.tone(t + i * gap, { f: 2400, dur: 0.12, gain: 0.05, a: 0.001, verb: 0.2 }); k.noise(t + i * gap, { dur: 0.04, filter: 'highpass', f: 2500, gain: 0.25, minor: true }); k.play('tock', t + i * gap, { f: 600, gain: 0.25, minor: true }); } },
  piedra: (k, t, g = 1) => { k.play('thud', t, { f: 55, gain: 0.6 * g }); k.noise(t, { dur: 0.6, color: 'brown', filter: 'lowpass', f: [[0, 900], [0.6, 120]], gain: 0.2 * g, a: 0.005 }); k.noise(t + 0.02, { dur: 0.4, color: 'pink', filter: 'bandpass', f: 2500, q: 0.8, gain: 0.04 * g, a: 0.01 }); },
  viento: (k, t, d, g = 1) => k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 500], [d * 0.4, 900], [d, 600]], q: 1.4, gain: 0.05 * g, a: Math.min(1.5, d * 0.3), hold: d * 0.5 }),
  // v1.9 · flotación y barcos
  chapuzon: (k, t, g = 1) => { k.play('thud', t, { f: 90, gain: 0.5 * g }); k.noise(t, { dur: 1.2, color: 'pink', filter: 'lowpass', f: [[0, 4000], [1.2, 600]], gain: 0.28 * g, a: 0.005 }); FX.burbujas(k, t + 0.1, 1.2, 14, Math.round(t * 10), 1.2 * g); },
  hundirse: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 400], [d, 120]], gain: 0.12 * g, a: 0.2, hold: d * 0.6 }); FX.burbujas(k, t, d, 3, Math.round(t * 10) + 2, 0.8 * g); },
  casco: (k, t, g = 1, f = 70) => k.tone(t, { f: [[0, f], [0.6, f * 0.85], [1.2, f * 1.05]], type: 'sawtooth', dur: 1.3, gain: 0.04 * g, filter: 'bandpass', f2: f * 3, q: 4, a: 0.2 }),
  grua: (k, t, d, g = 1) => { k.tone(t, { f: [[0, 90], [d * 0.5, 120], [d, 95]], type: 'sawtooth', dur: d, gain: 0.03 * g, filter: 'lowpass', f2: 500, a: 0.15, hold: d * 0.7 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 1600, q: 3, gain: 0.02 * g, a: 0.2, hold: d * 0.6 }); },
  contenedor: (k, t, g = 1) => { k.play('thud', t, { f: 75, gain: 0.45 * g }); k.tone(t, { f: 310, dur: 0.6, gain: 0.04 * g, a: 0.002, verb: 0.3 }); k.tone(t, { f: 523, dur: 0.4, gain: 0.02 * g, a: 0.002, minor: true }); },
  inundacion: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: [[0, 1800], [d, 500]], gain: 0.16 * g, a: 0.1, hold: d * 0.7 }); FX.burbujas(k, t, d, 10, Math.round(t * 10) + 5, g); },
  bocina: (k, t, d = 1.6, g = 1) => { for (const [f, gg] of [[73, 0.09], [110, 0.05], [146, 0.03]]) k.tone(t, { f, type: 'sawtooth', dur: d, gain: gg * g, filter: 'lowpass', f2: 700, a: 0.08, hold: d * 0.8, verb: 0.4 }); },
  equilibrio: (k, t, g = 1) => { k.tone(t, { f: 'C5', dur: 1.6, gain: 0.07 * g, verb: 0.4 }); k.tone(t + 0.12, { f: 'G5', dur: 1.5, gain: 0.06 * g, verb: 0.4 }); k.tone(t + 0.24, { f: 'C6', dur: 1.4, gain: 0.05 * g, verb: 0.4 }); },
  // v1.10 · espacio y relatividad (recursos cinematográficos: en el vacío no se propaga el sonido)
  espacio: (k, t, d, g = 1) => { k.tone(t, { f: 55, dur: d, gain: 0.05 * g, a: Math.min(2, d * 0.3), hold: d * 0.6, verb: 0.4 }); k.tone(t, { f: 82.4, dur: d, gain: 0.03 * g, a: Math.min(2.5, d * 0.4), hold: d * 0.5, verb: 0.5 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 300], [d, 700]], q: 2, gain: 0.02 * g, a: d * 0.4, hold: d * 0.4 }); },
  propulsion: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 120], [Math.min(1, d * 0.3), 400], [d, 350]], gain: 0.16 * g, a: 0.3, hold: d * 0.7 }); k.tone(t, { f: 41, type: 'sawtooth', dur: d, gain: 0.03 * g, filter: 'lowpass', f2: 200, a: 0.4, hold: d * 0.7 }); },
  aceleracion: (k, t, d, g = 1) => { k.tone(t, { f: [[0, 110], [d, 880]], type: 'sawtooth', dur: d, gain: 0.025 * g, filter: 'lowpass', f2: 1800, a: d * 0.5 }); k.play('riser', t, { dur: d, gain: 0.3 * g }); },
  frenado: (k, t, d, g = 1) => { k.tone(t, { f: [[0, 880], [d, 110]], type: 'sawtooth', dur: d, gain: 0.025 * g, filter: 'lowpass', f2: 1600, a: 0.1, hold: d * 0.6 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 3000], [d, 400]], q: 1, gain: 0.08 * g, a: 0.1 }); },
  reloj: (k, t, n = 6, gap = 0.12, g = 1, f = 2200) => { for (let i = 0; i < n; i++) k.tone(t + i * gap, { f, type: 'square', dur: 0.02, gain: 0.03 * g, a: 0.001, hold: 0.012, filter: 'lowpass', f2: 4000, minor: true }); },
  galaxia: (k, t, g = 1) => { FX.campo(k, t, 1.6, 0.8 * g); k.play('whoosh', t, { dur: 1.4, top: 1400, gain: 0.3 * g }); k.tone(t + 0.4, { f: 'E5', dur: 2, gain: 0.04 * g, verb: 0.5 }); },
  contraer: (k, t, d = 1.2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 600], [d, 3200]], q: 1.5, gain: 0.12 * g, a: d * 0.7 }); k.tone(t, { f: [[0, 300], [d, 1200]], dur: d, gain: 0.03 * g, a: d * 0.6 }); k.play('thud', t + d, { f: 120, gain: 0.25 * g }); },
  llegada: (k, t, g = 1) => { for (const [n, dt] of [['D4', 0], ['A4', 0.15], ['F#5', 0.3], ['D6', 0.5]]) k.tone(t + dt, { f: n, dur: 2.4, gain: 0.045 * g, verb: 0.5 }); },
  // v1.11 · capas de sonido para naves (recursos cinematográficos)
  encendido: (k, t, d = 2.5, g = 1) => { k.tone(t, { f: [[0, 30], [d, 70]], type: 'sawtooth', dur: d + 1, gain: 0.05 * g, filter: 'lowpass', f2: 320, a: d * 0.7, hold: 0.8 }); k.noise(t, { dur: d + 1, color: 'brown', filter: 'lowpass', f: [[0, 80], [d, 520]], gain: 0.18 * g, a: d * 0.8, hold: 0.5 }); k.tone(t + d * 0.6, { f: [[0, 220], [0.8, 440]], dur: 1.2, gain: 0.03 * g, verb: 0.4, a: 0.3 }); k.play('thud', t + d, { f: 60, gain: 0.4 * g }); },
  pasada: (k, t, d = 1.6, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 200], [d * 0.5, 1200], [d, 180]], q: 0.8, gain: 0.25 * g, a: d * 0.5 }); k.tone(t, { f: [[0, 70], [d * 0.5, 110], [d, 55]], type: 'sawtooth', dur: d, gain: 0.03 * g, filter: 'lowpass', f2: 300, a: d * 0.5 }); },
  holo: (k, t, g = 1) => { k.tone(t, { f: [[0, 900], [0.25, 1800]], dur: 0.35, gain: 0.04 * g, a: 0.01, verb: 0.3 }); k.tone(t + 0.08, { f: 2600, dur: 0.25, gain: 0.02 * g, a: 0.005, minor: true }); k.noise(t, { dur: 0.3, filter: 'highpass', f: 5000, gain: 0.03 * g, a: 0.05 }); },
  // v1.12 · montaña, piedra y agua
  lluviaFuerte: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'white', filter: 'bandpass', f: 2800, q: 0.6, gain: 0.06 * g, a: Math.min(1.2, d * 0.3), hold: d * 0.6 }); k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: 900, gain: 0.08 * g, a: Math.min(1.2, d * 0.3), hold: d * 0.6 }); },
  golpePiedra: (k, t, n = 4, gap = 0.4, g = 1) => { for (let i = 0; i < n; i++) { k.play('thud', t + i * gap, { f: 120, gain: 0.3 * g }); k.noise(t + i * gap, { dur: 0.06, filter: 'bandpass', f: 1800, q: 1.5, gain: 0.25 * g, a: 0.001 }); k.tone(t + i * gap, { f: 1600 + (i % 2) * 300, dur: 0.08, gain: 0.03 * g, a: 0.001, minor: true }); } },
  abrasion: (k, t, d, g = 1) => { const R = H.rng(Math.round(t * 10) + 4); for (let x = 0; x < d; x += 0.32) k.noise(t + x, { dur: 0.28, color: 'pink', filter: 'bandpass', f: 1400 + R() * 400, q: 0.9, gain: 0.07 * g, a: 0.1 }); },
  encaje: (k, t, g = 1) => { k.play('thud', t, { f: 70, gain: 0.5 * g }); k.noise(t, { dur: 0.08, filter: 'bandpass', f: 900, q: 2, gain: 0.25 * g }); k.tone(t + 0.02, { f: 'A4', dur: 0.8, gain: 0.04 * g, verb: 0.3, minor: true }); },
  arroyo: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 1200], [d * 0.5, 1700], [d, 1300]], q: 1.2, gain: 0.06 * g, a: Math.min(1, d * 0.3), hold: d * 0.6 }); FX.goteo(k, t, Math.round(d * 2), 0.5, Math.round(t * 10)); },
  tiempo: (k, t, d = 2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 400], [d, 3000]], q: 1.5, gain: 0.1 * g, a: d * 0.6 }); for (let i = 0; i < 8; i++) k.tone(t + i * d / 8, { f: 1800 - i * 120, dur: 0.3, gain: 0.02 * g, verb: 0.4, minor: true }); },
  // v1.13 · navegación nórdica
  oleaje: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 300], [d * 0.5, 650], [d, 300]], gain: 0.16 * g, a: Math.min(1.5, d * 0.3), hold: d * 0.5 }); const R = H.rng(Math.round(t * 7)); for (let x = 0.4; x < d - 0.6; x += R.range(1.6, 2.6)) k.noise(t + x, { dur: 1.4, color: 'pink', filter: 'bandpass', f: [[0, 600], [0.5, 1400], [1.4, 500]], q: 0.7, gain: 0.08 * g, a: 0.35, hold: 0.3 }); },
  madera: (k, t, n = 3, g = 1) => { const R = H.rng(Math.round(t * 13)); for (let i = 0; i < n; i++) { const tt = t + i * R.range(0.5, 1.1), f = R.range(70, 120); k.tone(tt, { f: [[0, f], [0.25, f * 0.86], [0.5, f * 1.08]], type: 'sawtooth', dur: 0.55, gain: 0.04 * g, filter: 'bandpass', f2: f * 5, q: 4, a: 0.06, minor: true }); } },
  vela: (k, t, g = 1) => { for (let i = 0; i < 3; i++) k.noise(t + i * 0.09, { dur: 0.12, color: 'pink', filter: 'bandpass', f: 900 + i * 300, q: 1, gain: 0.09 * g, a: 0.005 }); k.play('thud', t + 0.32, { f: 85, gain: 0.35 * g }); k.noise(t + 0.3, { dur: 1.2, color: 'pink', filter: 'lowpass', f: 700, gain: 0.07 * g, a: 0.05 }); },
  cuerdas: (k, t, g = 1) => { k.tone(t, { f: [[0, 340], [0.3, 300], [0.5, 360]], type: 'sawtooth', dur: 0.5, gain: 0.025 * g, filter: 'bandpass', f2: 1200, q: 6, a: 0.04 }); k.play('tick', t + 0.4, { f: 1600, gain: 0.15 * g, minor: true }); },
  remo: (k, t, n = 4, gap = 1, g = 1) => { for (let i = 0; i < n; i++) { const tt = t + i * gap; k.noise(tt, { dur: 0.35, color: 'pink', filter: 'bandpass', f: [[0, 1800], [0.35, 700]], q: 1, gain: 0.1 * g, a: 0.01 }); k.tone(tt + 0.02, { f: [[0, 260], [0.12, 140]], dur: 0.15, gain: 0.06 * g }); k.noise(tt + 0.45, { dur: 0.4, color: 'pink', filter: 'lowpass', f: 900, gain: 0.04 * g, a: 0.1 }); } },
  pasos: (k, t, n = 4, gap = 0.42, g = 1) => { for (let i = 0; i < n; i++) k.play('tock', t + i * gap, { f: 170 + (i % 2) * 30, gain: 0.3 * g, minor: true }); },
  martillo: (k, t, n = 4, gap = 0.28, g = 1) => { for (let i = 0; i < n; i++) { k.play('tock', t + i * gap, { f: 900, gain: 0.35 * g }); k.play('click', t + i * gap + 0.01, { gain: 0.3 * g, minor: true }); } },
  mapa: (k, t, g = 1) => { k.noise(t, { dur: 0.6, color: 'pink', filter: 'bandpass', f: [[0, 2500], [0.6, 1200]], q: 0.8, gain: 0.07 * g, a: 0.05 }); k.play('whoosh', t + 0.1, { dur: 0.7, top: 1600, gain: 0.3 * g, minor: true }); },
  descubrir: (k, t, g = 1) => { ['E5', 'B5', 'E6', 'G#6'].forEach((f, i) => k.tone(t + i * 0.08, { f, dur: 1.4, gain: 0.06 * g, verb: 0.45, a: 0.01 })); k.play('riser', t - 0.6, { dur: 0.6, gain: 0.2 * g, minor: true }); },
  costa: (k, t, d, g = 1) => { FX.oleaje(k, t, d, 0.7 * g); k.noise(t, { dur: d, color: 'pink', filter: 'highpass', f: 3000, gain: 0.015 * g, a: 1, hold: d * 0.6 }); },
  // v1.14 · construcción y logística
  apisonar: (k, t, n = 6, gap = 0.4, g = 1) => { for (let i = 0; i < n; i++) { const tt = t + i * gap; k.tone(tt, { f: [[0, 120], [0.08, 55]], dur: 0.16, gain: 0.32 * g, a: 0.002 }); k.noise(tt, { dur: 0.18, color: 'brown', filter: 'lowpass', f: 500, gain: 0.12 * g, a: 0.002 }); k.noise(tt + 0.01, { dur: 0.25, color: 'pink', filter: 'bandpass', f: 1800, q: 0.8, gain: 0.025 * g, a: 0.01, minor: true }); } },
  vertido: (k, t, d = 1, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 900], [d, 500]], q: 0.6, gain: 0.09 * g, a: 0.08, hold: d * 0.6 }); const R = H.rng(Math.round(t * 11)); for (let x = 0; x < d; x += 0.05) k.play('tick', t + x + R() * 0.03, { f: 900 + R() * 900, gain: 0.05 * g, minor: true }); },
  ruedas: (k, t, d = 2, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: 260, gain: 0.08 * g, a: 0.3, hold: d * 0.7 }); for (let x = 0; x < d; x += 0.9) k.tone(t + x, { f: [[0, 230], [0.3, 190], [0.5, 250]], type: 'sawtooth', dur: 0.5, gain: 0.02 * g, filter: 'bandpass', f2: 900, q: 5, a: 0.05, minor: true }); },
  cascos: (k, t, n = 6, gap = 0.32, g = 1) => { for (let i = 0; i < n; i++) k.play('tock', t + i * gap + (i % 2) * 0.06, { f: 520 + (i % 2) * 60, gain: 0.22 * g, minor: true }); },
  ladrillo: (k, t, n = 3, gap = 0.45, g = 1) => { for (let i = 0; i < n; i++) { k.play('tock', t + i * gap, { f: 1100 + (i % 2) * 140, gain: 0.3 * g }); k.noise(t + i * gap + 0.02, { dur: 0.12, color: 'white', filter: 'bandpass', f: 3500, q: 1, gain: 0.03 * g, a: 0.003, minor: true }); } },
  hoguera: (k, t, d = 2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 1200, q: 0.5, gain: 0.05 * g, a: 0.4, hold: d * 0.6 }); const R = H.rng(Math.round(t * 17)); for (let x = 0; x < d; x += 0.06 + R() * 0.12) k.play('click', t + x, { gain: 0.08 * g, minor: true }); },
  pasosTierra: (k, t, n = 6, gap = 0.4, g = 1) => { for (let i = 0; i < n; i++) k.noise(t + i * gap, { dur: 0.12, color: 'brown', filter: 'bandpass', f: 600 + (i % 2) * 120, q: 1, gain: 0.07 * g, a: 0.005 }); },
  // v1.15 · sismos y estructuras
  temblor: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 90], [d * 0.3, 160], [d, 80]], gain: 0.26 * g, a: Math.min(1.2, d * 0.25), hold: d * 0.55 }); k.tone(t, { f: [[0, 38], [d, 30]], dur: d, gain: 0.12 * g, a: Math.min(1.2, d * 0.25), hold: d * 0.55 }); const R = H.rng(Math.round(t * 9)); for (let x = 0.3; x < d - 0.3; x += R.range(0.35, 0.8)) k.noise(t + x, { dur: 0.25, color: 'pink', filter: 'bandpass', f: 380 + R() * 300, q: 1.2, gain: 0.04 * g, a: 0.02, minor: true }); },
  estructura: (k, t, n = 3, g = 1) => { const R = H.rng(Math.round(t * 13)); for (let i = 0; i < n; i++) { const tt = t + i * R.range(0.4, 0.9), f = R.range(55, 90); k.tone(tt, { f: [[0, f], [0.4, f * 0.85]], type: 'sawtooth', dur: 0.6, gain: 0.035 * g, filter: 'bandpass', f2: f * 4, q: 3, a: 0.06, minor: true }); } },
  hidraulico: (k, t, d = 1.2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 700], [d * 0.5, 1300], [d, 800]], q: 1.4, gain: 0.06 * g, a: 0.15, hold: d * 0.5 }); k.tone(t, { f: [[0, 110], [d, 140]], type: 'triangle', dur: d, gain: 0.03 * g, a: 0.2 }); },
  metal: (k, t, g = 1) => { k.play('tock', t, { f: 1500, gain: 0.3 * g }); k.tone(t, { f: 2300, dur: 0.6, gain: 0.03 * g, a: 0.002, minor: true }); },
  trafico: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 600, q: 0.6, gain: 0.03 * g, a: 1, hold: d * 0.7 }); const R = H.rng(Math.round(t * 3)); for (let x = 0.5; x < d - 1; x += R.range(1.5, 3)) k.noise(t + x, { dur: 1.4, color: 'pink', filter: 'bandpass', f: [[0, 400], [0.7, 900], [1.4, 380]], q: 1, gain: 0.03 * g, a: 0.5, minor: true }); },
  // v1.16 · túneles
  corteTBM: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'bandpass', f: [[0, 160], [d * 0.5, 220], [d, 170]], q: 0.9, gain: 0.12 * g, a: Math.min(0.8, d * 0.2), hold: d * 0.7 }); k.tone(t, { f: 42, type: 'sawtooth', dur: d, gain: 0.04 * g, filter: 'lowpass', f2: 300, a: 0.4, hold: d * 0.7 }); const R = H.rng(Math.round(t * 13)); for (let x = 0.2; x < d - 0.2; x += R.range(0.18, 0.4)) k.noise(t + x, { dur: 0.09, color: 'pink', filter: 'bandpass', f: R.range(700, 1500), q: 2, gain: 0.05 * g, a: 0.004, minor: true }); },
  sinfin: (k, t, d, g = 1) => { k.tone(t, { f: 65, type: 'triangle', dur: d, gain: 0.05 * g, a: 0.3, hold: d * 0.7 }); for (let x = 0; x < d; x += 0.33) k.noise(t + x, { dur: 0.22, color: 'brown', filter: 'bandpass', f: 380, q: 1.2, gain: 0.06 * g, a: 0.02, minor: true }); },
  tren: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 200], [d * 0.6, 700], [d, 250]], gain: 0.14 * g, a: d * 0.4, hold: d * 0.3 }); for (let x = 0.3; x < d - 0.3; x += 0.24) k.play('tick', t + x, { f: 700, gain: 0.07 * g, minor: true }); },
  // v1.17 · puente colgante y viento
  aleteo: (k, t, d, per = 5, g = 1) => { for (let x = 0; x < d; x += per / 2) k.noise(t + x, { dur: per / 2, color: 'brown', filter: 'lowpass', f: [[0, 120], [per / 4, 260], [per / 2, 120]], gain: 0.09 * g, a: per / 6, hold: 0.1 }); },
  desgarro: (k, t, g = 1) => { k.noise(t, { dur: 0.7, color: 'white', filter: 'bandpass', f: [[0, 2600], [0.7, 900]], q: 3, gain: 0.07 * g, a: 0.01 }); k.tone(t, { f: [[0, 420], [0.6, 160]], type: 'sawtooth', dur: 0.6, gain: 0.03 * g, filter: 'lowpass', f2: 1200 }); k.play('thud', t + 0.05, { f: 60, gain: 0.3 * g }); },
  salpicadura: (k, t, g = 1) => { k.play('thud', t, { f: 50, gain: 0.5 * g }); k.noise(t, { dur: 2.4, color: 'pink', filter: 'lowpass', f: [[0, 3000], [2.4, 300]], gain: 0.22 * g, a: 0.02 }); FX.burbujas(k, t + 0.2, 1.6, 10, Math.round(t * 10), 0.8 * g); },
  // ---- v1.18 · comunicaciones y épocas ----
  // timbre electromecánico de un teléfono antiguo (campanillas alternas ~20 Hz) durante d s
  timbre: (k, t, d = 1.2, g = 1) => { for (let x = 0; x < d; x += 0.05) { const f = (Math.round(x / 0.05) % 2) ? 2350 : 2610; k.tone(t + x, { f, dur: 0.12, gain: 0.035 * g, a: 0.002, verb: 0.25, minor: x > 0 }); k.tone(t + x, { f: f * 2.4, dur: 0.06, gain: 0.012 * g, a: 0.002, minor: true }); } },
  // descolgar / colgar el auricular (horquilla metálica + golpe de baquelita)
  auricular: (k, t, g = 1) => { k.play('click', t, { f: 1300, gain: 0.6 * g }); k.play('thud', t + 0.03, { f: 180, gain: 0.25 * g, minor: true }); k.noise(t + 0.02, { dur: 0.12, filter: 'bandpass', f: 2600, q: 3, gain: 0.08 * g, minor: true }); },
  // clavija entrando en un jack de centralita
  clavija: (k, t, g = 1) => { k.noise(t, { dur: 0.05, filter: 'bandpass', f: 1800, q: 2, gain: 0.12 * g, a: 0.002 }); k.play('click', t + 0.045, { f: 900, gain: 0.5 * g, minor: true }); },
  // oficina de los años 20 (ambiente): murmullo, máquinas de escribir lejanas y algún timbre muy suave
  oficina: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 420, q: 0.5, gain: 0.02 * g, a: 0.6, hold: d - 1.2 }); const R = H.rng(Math.round(t * 7) + 3); for (let x = 0.4; x < d - 0.6; x += R.range(0.9, 1.8)) k.play('typing', t + x, { n: 4 + Math.floor(R() * 5), rate: 0.11, gain: 0.12 * g, pan: R() - 0.5, minor: true }); },
  // páginas de revista
  paginas: (k, t, n = 2, g = 1) => { for (let i = 0; i < n; i++) k.play('paper', t + i * 0.28, { dur: 0.32, gain: 0.5 * g, minor: i > 0 }); },
  // radio de válvulas de los años 20: chisporroteo + portadora que se sintoniza
  radio1920: (k, t, d = 1.6, g = 1) => { k.noise(t, { dur: d, color: 'white', filter: 'bandpass', f: 2400, q: 0.6, gain: 0.035 * g, a: 0.1, hold: d * 0.6 }); k.tone(t, { f: [[0, 1400], [d * 0.6, 820], [d, 880]], dur: d, gain: 0.012 * g, a: 0.2, hold: d * 0.5, filter: 'lowpass', f2: 2000 }); const R = H.rng(Math.round(t * 11)); for (let x = 0; x < d; x += R.range(0.03, 0.12)) k.play('tick', t + x, { f: 3000 + R() * 2000, gain: 0.12 * g, minor: true }); },
  // transición temporal (1926 → hoy): barrido inverso + destello cristalino
  saltoTiempo: (k, t, d = 1.2, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 4000], [d * 0.7, 400], [d, 1200]], q: 1, gain: 0.18 * g, a: d * 0.6 }); k.tone(t, { f: [[0, 220], [d, 880]], dur: d + 0.4, gain: 0.03 * g, a: d * 0.8, verb: 0.5 }); k.play('sparkle', t + d * 0.85, { gain: 0.5 * g, minor: true }); },
  // señal de radio (pulsos cortos ascendentes)
  senalRadio: (k, t, n = 3, g = 1) => { for (let i = 0; i < n; i++) k.tone(t + i * 0.16, { f: 1500 + i * 260, dur: 0.12, gain: 0.04 * g * (1 - i * 0.15), a: 0.003, verb: 0.3, minor: i > 0 }); },
  // el teléfono se enciende (acorde suave)
  encender: (k, t, g = 1) => { ['E5', 'B5', 'E6'].forEach((n, i) => k.tone(t + i * 0.07, { f: n, dur: 0.9, gain: 0.05 * g, a: 0.01, verb: 0.4, minor: i > 0 })); },
  // conexión de llamada (dos tonos ascendentes y confirmación)
  llamada: (k, t, g = 1) => { k.tone(t, { f: 'G5', dur: 0.16, gain: 0.05 * g, a: 0.005 }); k.tone(t + 0.18, { f: 'D6', dur: 0.4, gain: 0.05 * g, a: 0.005, verb: 0.3, minor: true }); },
  // flujo de datos (blips rápidos durante d s)
  flujoDatos: (k, t, d = 1, g = 1) => { const R = H.rng(Math.round(t * 13) + 1); for (let x = 0; x < d; x += 0.07) k.play('blip', t + x, { f: 1200 + Math.floor(R() * 6) * 180, dur: 0.035, gain: 0.25 * g, pan: R() - 0.5, minor: true }); },
  // calle de los años 20: motores de explosión lejanos y bocinas de pera ocasionales
  calle1920: (k, t, d, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: 380, gain: 0.05 * g, a: 0.8, hold: d - 1.6 }); const R = H.rng(Math.round(t * 5) + 9); for (let x = 1; x < d - 1; x += R.range(2.2, 3.6)) k.tone(t + x, { f: [[0, 320], [0.25, 280]], type: 'sawtooth', dur: 0.32, gain: 0.012 * g, a: 0.02, filter: 'lowpass', f2: 1200, pan: R() - 0.5, minor: true }); },
  // ---- v1.19 · almacenamiento ----
  // sala informática de 1956: zumbido eléctrico de red, ventilación y relés que chasquean de vez en cuando
  sala1956: (k, t, d, g = 1) => { k.tone(t, { f: 60, type: 'sine', dur: d, gain: 0.012 * g, a: 0.8, hold: d - 1.6 }); k.tone(t, { f: 120, type: 'sine', dur: d, gain: 0.006 * g, a: 0.8, hold: d - 1.6 }); k.noise(t, { dur: d, color: 'pink', filter: 'lowpass', f: 700, gain: 0.025 * g, a: 0.8, hold: d - 1.6 }); const R = H.rng(Math.round(t * 9) + 2); for (let x = 0.6; x < d - 0.4; x += R.range(0.5, 1.4)) k.play('click', t + x, { f: 900 + R() * 600, gain: 0.25 * g, pan: R() - 0.5, minor: true }); },
  // motor y pila de discos girando (zumbido suave y estable; nada de turbinas)
  motorDiscos: (k, t, d, g = 1, up = 0) => { k.tone(t, { f: up ? [[0, 30], [Math.min(d, 1.5), 80]] : 80, type: 'triangle', dur: d, gain: 0.02 * g, a: up ? 1 : 0.4, hold: d * 0.7, bus: 'sfx' }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 320, q: 1.2, gain: 0.03 * g, a: 0.5, hold: d * 0.7 }); k.tone(t, { f: 160, dur: d, gain: 0.006 * g, a: 0.6, hold: d * 0.7 }); },
  // carro de acceso: servo que se desplaza y tope mecánico al llegar
  carro: (k, t, d = 0.6, g = 1) => { k.tone(t, { f: [[0, 260], [d * 0.5, 420], [d, 300]], type: 'sawtooth', dur: d, gain: 0.012 * g, a: 0.05, hold: d * 0.6, filter: 'lowpass', f2: 1200 }); k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 900, q: 1.5, gain: 0.04 * g, a: 0.05, hold: d * 0.6 }); k.play('tock', t + d, { f: 420, gain: 0.35 * g, minor: true }); },
  // panel metálico que se retira
  panel: (k, t, g = 1) => { k.play('click', t, { f: 700, gain: 0.4 * g }); k.noise(t + 0.05, { dur: 0.7, color: 'pink', filter: 'bandpass', f: [[0, 600], [0.7, 1400]], q: 1, gain: 0.08 * g, a: 0.1 }); k.play('thud', t + 0.75, { f: 120, gain: 0.25 * g, minor: true }); },
  // interruptor de palanca de los años 50
  interruptor: (k, t, g = 1) => { k.play('click', t, { f: 1500, gain: 0.6 * g }); k.play('tock', t + 0.015, { f: 300, gain: 0.3 * g, minor: true }); },
  // escritura magnética (pulsos rítmicos con zumbido de bobina)
  escribir: (k, t, d = 1.2, g = 1) => { for (let x = 0; x < d; x += 0.09) k.tone(t + x, { f: (Math.round(x / 0.09) % 2) ? 1500 : 1100, type: 'square', dur: 0.04, gain: 0.012 * g, a: 0.002, filter: 'lowpass', f2: 2500, minor: x > 0 }); k.tone(t, { f: 220, dur: d, gain: 0.01 * g, a: 0.05, hold: d * 0.8 }); },
  // lectura (señal que se detecta: blips suaves y ascendentes)
  leer: (k, t, d = 1.2, g = 1) => { for (let x = 0; x < d; x += 0.12) k.play('blip', t + x, { f: 900 + (Math.round(x / 0.12) % 4) * 220, dur: 0.05, gain: 0.25 * g, minor: x > 0 }); },
  // aparición de un chip flash (destello digital limpio)
  chipFlash: (k, t, g = 1) => { k.play('sparkle', t, { gain: 0.5 * g }); k.tone(t, { f: [[0, 600], [0.4, 1800]], dur: 0.5, gain: 0.03 * g, a: 0.02, verb: 0.4 }); },
  // disquete: persiana metálica que se desliza y clic de inserción
  disquete: (k, t, g = 1) => { k.noise(t, { dur: 0.18, filter: 'bandpass', f: 2600, q: 2, gain: 0.08 * g, a: 0.01 }); k.play('click', t + 0.2, { f: 1100, gain: 0.5 * g, minor: true }); k.play('thud', t + 0.22, { f: 160, gain: 0.2 * g, minor: true }); },
  // miniaturización: barrido descendente que se encoge (para transiciones de escala)
  miniaturizar: (k, t, d = 1, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 400], [d, 4200]], q: 1.4, gain: 0.12 * g, a: d * 0.5 }); k.tone(t, { f: [[0, 300], [d, 1200]], dur: d, gain: 0.02 * g, a: d * 0.6, verb: 0.3 }); },
  // ---- v1.20 · yakhchal ----
  // hielo que cruje mientras se forma o se asienta (chasquidos finos y agudos)
  hieloCrujir: (k, t, d = 1.2, g = 1) => { const R = H.rng(Math.round(t * 17) + 4); for (let x = 0; x < d; x += R.range(0.05, 0.22)) { k.noise(t + x, { dur: 0.03, filter: 'highpass', f: 3500 + R() * 3000, gain: 0.06 * g * R.range(0.4, 1), a: 0.001, pan: R() - 0.5, minor: true }); if (R() < 0.3) k.tone(t + x, { f: 2400 + R() * 1800, dur: 0.05, gain: 0.01 * g, a: 0.001, minor: true }); } },
  // golpe de pico sobre el hielo (metal + grieta)
  pico: (k, t, g = 1) => { k.play('tock', t, { f: 1500, gain: 0.45 * g }); k.noise(t + 0.01, { dur: 0.18, filter: 'bandpass', f: 4200, q: 2, gain: 0.08 * g, a: 0.002 }); k.play('thud', t, { f: 160, gain: 0.15 * g, minor: true }); },
  // bloque de hielo que se apoya (golpe sordo con brillo)
  bloque: (k, t, g = 1) => { k.play('thud', t, { f: 120, gain: 0.35 * g }); k.noise(t, { dur: 0.25, filter: 'bandpass', f: 2600, q: 1.5, gain: 0.04 * g, a: 0.002, minor: true }); },
  // escarcha (brillo frío y suave que crece)
  escarcha: (k, t, d = 1.5, g = 1) => { k.noise(t, { dur: d, filter: 'highpass', f: [[0, 5000], [d, 8000]], gain: 0.02 * g, a: d * 0.6 }); const R = H.rng(Math.round(t * 5) + 2); for (let x = 0; x < d; x += 0.18) k.tone(t + x, { f: 2600 + Math.floor(R() * 5) * 300, dur: 0.4, gain: 0.006 * g, a: 0.01, verb: 0.5, minor: true }); },
  // ---- v1.22 · Verne / Apolo ----
  // cañonazo en la atmósfera: golpe grave, estampido de ruido y retumbo que se aleja (sonido propagado en el aire)
  canonazo: (k, t, g = 1) => { k.tone(t, { f: [[0, 70], [0.6, 28]], dur: 2.2, gain: 0.5 * g, a: 0.002, verb: 0.6 }); k.noise(t, { dur: 0.5, color: 'white', filter: 'lowpass', f: [[0, 3000], [0.5, 300]], gain: 0.4 * g, a: 0.001 }); k.noise(t + 0.05, { dur: 3, color: 'brown', filter: 'lowpass', f: 180, gain: 0.25 * g, a: 0.05, hold: 0.6 }); },
  // rugido de despegue del Saturno V (en tierra): crepitar de baja frecuencia que crece, sube de tono y se aleja; d = duración
  saturno: (k, t, d = 6, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'lowpass', f: [[0, 90], [d * 0.3, 260], [d, 160]], gain: 0.34 * g, a: 0.6, hold: d * 0.6 }); k.noise(t + 0.3, { dur: d, color: 'pink', filter: 'bandpass', f: [[0, 300], [d, 700]], q: 0.7, gain: 0.08 * g, a: 1, hold: d * 0.5 }); for (let x = 0.4; x < d; x += 0.07) k.noise(t + x, { dur: 0.05, color: 'white', filter: 'bandpass', f: 900 + (x * 997 % 600), q: 2, gain: 0.025 * g * Math.min(1, x / 2), a: 0.004, minor: true }); },
  // v1.23 · tarjetas perforadas (sonidos mecánicos, sin ciencia ficción)
  perforar: (k, t, g = 1) => { k.play('thud', t, { f: 150, gain: 0.32 * g }); k.play('click', t + 0.012, { gain: 0.45 * g, minor: true }); },
  tecleo: (k, t, n = 6, dt = 0.22, g = 1) => { for (let i = 0; i < n; i++) { k.play('click', t + i * dt, { gain: 0.45 * g, minor: i > 0 }); k.play('thud', t + i * dt + 0.03, { f: 140, gain: 0.22 * g, minor: true }); } },
  tarjetaRoce: (k, t, d = 0.8, g = 1) => { k.noise(t, { dur: d, color: 'pink', filter: 'bandpass', f: 2600, q: 1.1, gain: 0.035 * g, a: 0.06, hold: d * 0.6 }); },
  escobilla: (k, t, g = 1) => k.play('blip', t, { f: 1450, dur: 0.045, gain: 0.2 * g, minor: true }),
  cascadaTarjetas: (k, t, d = 1.2, g = 1) => { const R = H.rng(Math.round(t * 10) + 5); for (let x = 0; x < d; x += 0.05 + R() * 0.06) k.play('paper', t + x, { dur: 0.12 + R() * 0.12, gain: (0.25 + R() * 0.25) * g, minor: true }); k.play('thud', t + d, { f: 90, gain: 0.25 * g, minor: true }); },
  dialHollerith: (k, t, g = 1) => { k.play('tock', t, { f: 760, gain: 0.4 * g }); k.play('bell', t + 0.08, { gain: 0.18 * g, minor: true }); },
  // v1.24 · telégrafo óptico (madera, poleas, cuerdas, latón; nada electrónico en el s. XVIII)
  galope: (k, t, d = 2, g = 1) => { for (let x = 0; x < d; x += 0.36) { [0, 0.07, 0.16, 0.22].forEach((o2, i) => k.play('thud', t + x + o2, { f: 120 + i * 15, gain: 0.16 * g, minor: true })); } },
  polea: (k, t, d = 0.9, g = 1) => { k.noise(t, { dur: d, color: 'brown', filter: 'bandpass', f: [[0, 520], [d, 380]], q: 4, gain: 0.05 * g, a: 0.06, hold: d * 0.6 }); k.tone(t, { f: [[0, 190], [d, 150]], type: 'triangle', dur: d, gain: 0.012 * g, a: 0.1, hold: d * 0.5 }); k.play('tock', t + d, { f: 300, gain: 0.3 * g, minor: true }); },
  telescopio: (k, t, g = 1) => { k.noise(t, { dur: 0.25, filter: 'bandpass', f: 2600, q: 3, gain: 0.04 * g, a: 0.02 }); k.play('tock', t + 0.24, { f: 1400, gain: 0.22 * g, minor: true }); },
  clicMorse: (k, t, n = 6, g = 1) => { const R = H.rng(Math.round(t * 10)); let x = 0; for (let i = 0; i < n; i++) { const d = R() < 0.5 ? 0.08 : 0.24; k.play('click', t + x, { gain: 0.4 * g, minor: i > 0 }); k.play('tock', t + x + d, { f: 900, gain: 0.25 * g, minor: true }); x += d + 0.12; } },
 };
 // ---------------- MÚSICA ORQUESTAL SINTÉTICA (v1.13) ----------------
 // MUS.epica(k, t0, t1, { bpm, chords, gain, drums (0..1), strings (0..1), drone, ostinato (0..1) }): cuerdas con ataque lento,
 // bordón grave, ostinato de cuerdas y percusión de tambor grave (toms y marco). Todo en el bus de música; no toca SOUND.
 const MUS = {
  epica(k, t0, t1, p = {}) {
   const g = p.gain ?? 1, bpm = p.bpm || 80, beat = 60 / bpm, bar = beat * 4, ch = p.chords || [['D2', 'A2', 'D3', 'F3'], ['A#1', 'F2', 'A#2', 'D3'], ['C2', 'G2', 'C3', 'E3'], ['A1', 'E2', 'A2', 'C#3']];
   const hz = (n) => (typeof n === 'number' ? n : k.hz(n)); let i = 0;
   for (let t = t0; t < t1 - 0.05; t += bar, i++) { const c = ch[i % ch.length], len = Math.min(bar, t1 - t);
    const st = p.strings ?? 1; if (st > 0) c.forEach((n, q) => { const f = hz(n) * (q > 1 ? 2 : 1); k.tone(t, { f, type: 'sawtooth', dur: len + 0.5, gain: 0.012 * g * st, a: Math.min(0.9, len * 0.3), hold: len - 0.5, filter: 'lowpass', f2: 1100, bus: 'music', verb: 0.4, pan: (q - 1.5) * 0.35 }); k.tone(t, { f: f * 1.006, type: 'sawtooth', dur: len + 0.5, gain: 0.008 * g * st, a: Math.min(0.9, len * 0.3), hold: len - 0.5, filter: 'lowpass', f2: 900, bus: 'music', verb: 0.4 }); });
    if ((p.drone ?? 1) > 0) k.tone(t, { f: hz(c[0]) / 2, type: 'triangle', dur: len + 0.3, gain: 0.05 * g * (p.drone ?? 1), a: 0.3, hold: len - 0.3, bus: 'music' });
    const os = p.ostinato || 0; if (os > 0) for (let s = 0; s < 8 && t + s * beat / 2 < t1 - 0.05; s++) { const n = c[[1, 2, 3, 2, 1, 2, 3, 2][s]]; k.tone(t + s * beat / 2, { f: hz(n) * 2, type: 'sawtooth', dur: beat * 0.42, gain: 0.014 * g * os, a: 0.01, hold: beat * 0.2, filter: 'lowpass', f2: 1800, bus: 'music', verb: 0.25 }); }
    const dr = p.drums || 0; if (dr > 0) for (let b = 0; b < 4 && t + b * beat < t1 - 0.05; b++) { const tb = t + b * beat;
     if (b === 0 || b === 2) { k.tone(tb, { f: [[0, 95], [0.25, 48]], dur: 0.6, gain: 0.3 * g * dr, a: 0.003, bus: 'music', verb: 0.3 }); k.noise(tb, { dur: 0.25, color: 'brown', filter: 'lowpass', f: 300, gain: 0.12 * g * dr, a: 0.002, bus: 'music' }); }
     if (b === 3) { k.tone(tb + beat / 2, { f: [[0, 150], [0.2, 90]], dur: 0.3, gain: 0.14 * g * dr, a: 0.003, bus: 'music' }); }
     k.noise(tb + beat / 2, { dur: 0.08, color: 'pink', filter: 'bandpass', f: 1800, q: 1, gain: 0.03 * g * dr, a: 0.002, bus: 'music' }); }
   }
  },
  // golpe orquestal para revelaciones: tambor grave + acorde de cuerdas
  golpe(k, t, p = {}) { const g = p.gain ?? 1; k.tone(t, { f: [[0, 80], [0.5, 40]], dur: 1.6, gain: 0.35 * g, a: 0.003, bus: 'music', verb: 0.5 }); (p.chord || ['D3', 'A3', 'D4', 'F4']).forEach((n, q) => k.tone(t, { f: n, type: 'sawtooth', dur: 2.2, gain: 0.016 * g, a: 0.02, hold: 0.4, filter: 'lowpass', f2: 1600, bus: 'music', verb: 0.5, pan: (q - 1.5) * 0.3 })); },
  // ---- v1.18 ----
  // MUS.piano(k, t0, t1, { bpm, chords, gain, strings 0..1, waltz }): piano sintético (ataque rápido y caída natural) con bajo,
  // arpegio de acompañamiento y colchón de cuerdas suave. Para épocas antiguas, nostalgia, descubrimiento sereno.
  piano(k, t0, t1, p = {}) { const g = p.gain ?? 1, bpm = p.bpm || 76, beat = 60 / bpm, bar = beat * (p.waltz ? 3 : 4), ch = p.chords || [['C3', 'E3', 'G3', 'C4'], ['A2', 'E3', 'A3', 'C4'], ['F2', 'C3', 'F3', 'A3'], ['G2', 'D3', 'G3', 'B3']], hz = (n) => (typeof n === 'number' ? n : k.hz(n)); let i = 0;
   const key = (t, f, v, d = 1.8) => { k.tone(t, { f, type: 'triangle', dur: d, gain: 0.05 * g * v, a: 0.004, bus: 'music', verb: 0.35 }); k.tone(t, { f: f * 2, dur: d * 0.5, gain: 0.014 * g * v, a: 0.003, bus: 'music', verb: 0.35 }); };
   for (let t = t0; t < t1 - 0.05; t += bar, i++) { const c = ch[i % ch.length], len = Math.min(bar, t1 - t), nb = p.waltz ? 3 : 4;
    key(t, hz(c[0]) / 2, 1.1, bar * 1.1); for (let b = 0; b < nb * 2; b++) { const tb = t + b * beat / 2; if (tb > t1 - 0.1) break; const n = c[[1, 2, 3, 2, 1, 2, 3, 2][b % 8]]; key(tb, hz(n) * 2, b % 2 ? 0.45 : 0.65, 1.2); }
    if (p.melody) { const m = p.melody[i % p.melody.length]; m.forEach(([off, n, dv]) => { if (t + off * beat < t1 - 0.1) key(t + off * beat, hz(n), 0.9, dv || 1.6); }); }
    const st = p.strings ?? 0.5; if (st > 0) c.forEach((n, q) => k.tone(t, { f: hz(n) * 2, type: 'sawtooth', dur: len + 0.6, gain: 0.006 * g * st, a: Math.min(1, len * 0.4), hold: len - 0.6, filter: 'lowpass', f2: 900, bus: 'music', verb: 0.5, pan: (q - 1.5) * 0.4 })); }
  },
  // MUS.pulso(k, t0, t1, { bpm, chords, gain, kick 0..1, arp 0..1, pad 0..1 }): pulsos electrónicos (arpegio cuadrado filtrado en
  // semicorcheas, pad de sierra, bombo suave y hi-hat). Para tecnología, datos, futuro.
  pulso(k, t0, t1, p = {}) { const g = p.gain ?? 1, bpm = p.bpm || 104, beat = 60 / bpm, bar = beat * 4, ch = p.chords || [['A2', 'C3', 'E3', 'A3'], ['F2', 'A2', 'C3', 'F3'], ['C3', 'E3', 'G3', 'C4'], ['G2', 'B2', 'D3', 'G3']], hz = (n) => (typeof n === 'number' ? n : k.hz(n)); let i = 0;
   for (let t = t0; t < t1 - 0.05; t += bar, i++) { const c = ch[i % ch.length], len = Math.min(bar, t1 - t);
    const pd = p.pad ?? 0.7; if (pd > 0) c.forEach((n, q) => k.tone(t, { f: hz(n), type: 'sawtooth', dur: len + 0.4, gain: 0.008 * g * pd, a: 0.4, hold: len - 0.5, filter: 'lowpass', f2: 1400, bus: 'music', verb: 0.45, pan: (q - 1.5) * 0.4 }));
    const ar = p.arp ?? 0.7; if (ar > 0) for (let s = 0; s < 16; s++) { const ts = t + s * beat / 4; if (ts > t1 - 0.05) break; const n = c[[0, 1, 2, 3, 2, 1, 2, 3][s % 8]]; k.tone(ts, { f: hz(n) * 4, type: 'square', dur: beat * 0.22, gain: 0.006 * g * ar * (s % 4 ? 0.7 : 1), a: 0.002, filter: 'lowpass', f2: 2600, bus: 'music', verb: 0.2, pan: s % 2 ? 0.25 : -0.25 }); }
    k.tone(t, { f: hz(c[0]) / 2, type: 'sine', dur: len, gain: 0.05 * g, a: 0.05, hold: len * 0.7, bus: 'music' });
    const kk = p.kick ?? 0.5; if (kk > 0) for (let b = 0; b < 4; b++) { const tb = t + b * beat; if (tb > t1 - 0.05) break; k.tone(tb, { f: [[0, 120], [0.12, 45]], dur: 0.32, gain: 0.22 * g * kk, a: 0.002, bus: 'music' }); k.noise(tb + beat / 2, { dur: 0.04, filter: 'highpass', f: 7000, gain: 0.05 * g * kk, a: 0.001, bus: 'music' }); } }
  },
  // ---- v1.19 ----
  // MUS.industrial(k, t0, t1, { bpm, chords, gain, perc 0..1, strings 0..1 }): percusión mecánica suave (golpes metálicos filtrados y
  // tic-tac de relés en corcheas), bordón grave y cuerdas. Para maquinaria histórica, grandeza industrial, asombro mecánico.
  industrial(k, t0, t1, p = {}) { const g = p.gain ?? 1, bpm = p.bpm || 92, beat = 60 / bpm, bar = beat * 4, ch = p.chords || [['A1', 'E2', 'A2', 'C3'], ['F1', 'C2', 'F2', 'A2'], ['G1', 'D2', 'G2', 'B2'], ['E1', 'B1', 'E2', 'G#2']], hz = (n) => (typeof n === 'number' ? n : k.hz(n)); let i = 0;
   for (let t = t0; t < t1 - 0.05; t += bar, i++) { const c = ch[i % ch.length], len = Math.min(bar, t1 - t);
    k.tone(t, { f: hz(c[0]) / 2, type: 'triangle', dur: len + 0.3, gain: 0.05 * g, a: 0.3, hold: len - 0.3, bus: 'music' });
    const st = p.strings ?? 0.7; if (st > 0) c.forEach((n, q) => k.tone(t, { f: hz(n) * 2, type: 'sawtooth', dur: len + 0.5, gain: 0.009 * g * st, a: Math.min(0.9, len * 0.3), hold: len - 0.5, filter: 'lowpass', f2: 1000, bus: 'music', verb: 0.45, pan: (q - 1.5) * 0.4 }));
    const pc = p.perc ?? 0.7; if (pc > 0) for (let s = 0; s < 8; s++) { const ts = t + s * beat / 2; if (ts > t1 - 0.05) break; if (s % 4 === 0) { k.tone(ts, { f: [[0, 110], [0.2, 55]], dur: 0.35, gain: 0.18 * g * pc, a: 0.002, bus: 'music', verb: 0.25 }); } if (s % 4 === 2) { k.noise(ts, { dur: 0.12, filter: 'bandpass', f: 2200, q: 6, gain: 0.05 * g * pc, a: 0.002, bus: 'music', verb: 0.3 }); k.tone(ts, { f: 1760, dur: 0.25, gain: 0.006 * g * pc, a: 0.002, bus: 'music', verb: 0.4 }); } k.noise(ts + beat / 4, { dur: 0.02, filter: 'bandpass', f: 4200, q: 3, gain: 0.04 * g * pc, a: 0.001, bus: 'music' }); } }
  },
  // ---- v1.20 ----
  // MUS.persa(k, t0, t1, { bpm, root, gain, santur 0..1, daf 0..1, drone 0..1, mode }): música de inspiración persa (original):
  // bordón en la tónica y la quinta, arpegios de santur (cuerda percutida: ataque seco, caída rápida y trémolo en las notas largas)
  // sobre un modo de tipo Homayun (1, b2, 3, 4, 5, b6, b7) y ritmo de daf (golpe grave «dum» y aro agudo «tak»). Sin citas de obras.
  persa(k, t0, t1, p = {}) { const g = p.gain ?? 1, bpm = p.bpm || 84, beat = 60 / bpm, root = k.hz(p.root || 'D3'), md = p.mode || [0, 1, 4, 5, 7, 8, 10, 12], st = (n) => root * Math.pow(2, n / 12);
   const sant = p.santur ?? 0.8, daf = p.daf ?? 0.5, dr = p.drone ?? 0.7, R = H.rng(Math.round(t0 * 10) + 7);
   if (dr > 0) { k.tone(t0, { f: root / 2, type: 'triangle', dur: t1 - t0, gain: 0.04 * g * dr, a: 1.2, hold: t1 - t0 - 2, bus: 'music', verb: 0.4 }); k.tone(t0, { f: st(7) / 2, type: 'sine', dur: t1 - t0, gain: 0.018 * g * dr, a: 1.5, hold: t1 - t0 - 2.5, bus: 'music', verb: 0.4 }); }
   const pl = (t, f, v, d = 0.9) => { k.tone(t, { f, type: 'triangle', dur: d, gain: 0.035 * g * v, a: 0.002, bus: 'music', verb: 0.45 }); k.tone(t, { f: f * 2.01, type: 'sine', dur: d * 0.4, gain: 0.012 * g * v, a: 0.002, bus: 'music', verb: 0.45 }); k.tone(t + 0.004, { f: f * 1.003, type: 'triangle', dur: d * 0.8, gain: 0.015 * g * v, a: 0.002, bus: 'music', verb: 0.45 }); };
   let i = 0; if (sant > 0) for (let t = t0; t < t1 - 0.1; t += beat / 2, i++) { const ph = i % 16, deg = [0, 2, 3, 4, 3, 2, 1, 0, 4, 5, 6, 5, 4, 3, 2, 1][ph], oct = ph >= 8 ? 12 : 0; const v = (ph % 4 === 0 ? 1 : 0.6) * sant; pl(t, st(md[deg] + oct), v); if (ph % 8 === 7) for (let q = 0; q < 6; q++) pl(t + beat / 2 + q * beat / 12, st(md[(deg + 1) % 8] + oct), 0.35 * sant, 0.25); }
   if (daf > 0) for (let t = t0; t < t1 - 0.1; t += beat) { const b = Math.round((t - t0) / beat) % 4; if (b === 0 || b === 2.5) { k.tone(t, { f: [[0, 110], [0.2, 60]], dur: 0.4, gain: 0.16 * g * daf, a: 0.002, bus: 'music', verb: 0.3 }); } if (b === 1 || b === 3) k.noise(t, { dur: 0.08, filter: 'bandpass', f: 2600, q: 1.5, gain: 0.05 * g * daf, a: 0.001, bus: 'music', verb: 0.3 }); if (b === 3) k.tone(t + beat / 2, { f: [[0, 120], [0.15, 70]], dur: 0.3, gain: 0.09 * g * daf, a: 0.002, bus: 'music' }); k.noise(t + beat / 2, { dur: 0.03, filter: 'highpass', f: 6000, gain: 0.02 * g * daf * R.range(0.5, 1), a: 0.001, bus: 'music' }); }
  },
 };
 window.PLANTILLA = { make, SKINS, P, FX, MUS, TRANS_SFX, setSkin: (n) => (SK = SKINS[n]), W, HH };
})();
